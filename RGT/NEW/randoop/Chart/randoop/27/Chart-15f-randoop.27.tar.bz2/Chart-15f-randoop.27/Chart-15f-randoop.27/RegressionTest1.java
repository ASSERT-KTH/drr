import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean4 = polarPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset35);
        dateAxis5.setDefaultAutoRange(range36);
        dateAxis5.setAxisLineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        dateAxis40.setVisible(false);
        double[] doubleArray49 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray54 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray59 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray64 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray69 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray70 = new double[][] { doubleArray49, doubleArray54, doubleArray59, doubleArray64, doubleArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray70);
        org.jfree.data.Range range73 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset71, false);
        dateAxis40.setDefaultAutoRange(range73);
        org.jfree.data.Range range75 = dateAxis40.getDefaultAutoRange();
        org.jfree.data.Range range78 = org.jfree.data.Range.shift(range75, (double) 1, true);
        dateAxis5.setRange(range75, true, false);
        try {
            dateAxis5.zoomRange((double) 100L, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1099.0) <= upper (-12.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range78);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        boolean boolean34 = jFreeChart33.isBorderVisible();
        org.jfree.chart.title.LegendTitle legendTitle35 = jFreeChart33.getLegend();
        try {
            java.awt.image.BufferedImage bufferedImage38 = jFreeChart33.createBufferedImage((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (97) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(legendTitle35);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
        java.lang.String str3 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str3.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        int int4 = categoryAxis3.getMaximumCategoryLabelLines();
        categoryAxis3.setMaximumCategoryLabelLines(100);
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        valueMarker10.addChangeListener(markerChangeListener13);
        valueMarker10.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets17.getLeft();
        double double20 = rectangleInsets17.extendHeight(0.0d);
        valueMarker10.setLabelOffset(rectangleInsets17);
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets17.getUnitType();
        categoryAxis3.setTickLabelInsets(rectangleInsets17);
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = piePlot3D29.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.PiePlotState piePlotState33 = ringPlot26.initialise(graphics2D27, rectangle2D28, (org.jfree.chart.plot.PiePlot) piePlot3D29, (java.lang.Integer) 0, plotRenderingInfo32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double38 = size2D37.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) '4', (double) (byte) 1, rectangleAnchor41);
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        dateAxis44.setVisible(false);
        double double47 = dateAxis44.getUpperBound();
        java.awt.Color color49 = java.awt.Color.cyan;
        java.awt.Color color51 = java.awt.Color.black;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color51, stroke52);
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker53.setStroke(stroke54);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color49, stroke54);
        dateAxis44.setAxisLinePaint((java.awt.Paint) color49);
        dateAxis44.setRangeWithMargins((double) (-524308), (double) 1L);
        java.awt.Shape shape61 = dateAxis44.getLeftArrow();
        piePlot43.setLegendItemShape(shape61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.plot.PiePlotState piePlotState65 = piePlot3D29.initialise(graphics2D34, rectangle2D42, piePlot43, (java.lang.Integer) 255, plotRenderingInfo64);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = null;
        double double67 = categoryAxis3.getCategoryMiddle(255, 15, rectangle2D42, rectangleEdge66);
        try {
            lineBorder0.draw(graphics2D2, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(piePlotState33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(piePlotState65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        org.jfree.chart.title.TextTitle textTitle49 = jFreeChart33.getTitle();
        org.jfree.chart.plot.Plot plot50 = jFreeChart33.getPlot();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(textTitle49);
        org.junit.Assert.assertNotNull(plot50);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = xYPlot0.getDrawingSupplier();
        xYPlot0.mapDatasetToDomainAxis((int) '#', 100);
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset((int) (short) -1);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat1);
        boolean boolean3 = numberAxis3D0.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis3D0.setTickUnit(numberTickUnit4, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart4, chartChangeEventType5);
        chartChangeEvent2.setType(chartChangeEventType5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = chartChangeEvent2.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list2 = projectInfo1.getContributors();
        projectInfo0.setContributors(list2);
        java.awt.Image image4 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(image4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        multiplePiePlot29.setLimit(90.0d);
        java.awt.Font font33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("ClassContext", font33);
        textTitle34.setExpandToFitSpace(false);
        java.awt.Paint paint37 = null;
        textTitle34.setBackgroundPaint(paint37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = textTitle34.getHorizontalAlignment();
        textTitle34.setNotify(false);
        java.lang.Object obj42 = textTitle34.clone();
        java.awt.Font font43 = textTitle34.getFont();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int45 = color44.getGreen();
        textTitle34.setBackgroundPaint((java.awt.Paint) color44);
        multiplePiePlot29.setAggregatedItemsPaint((java.awt.Paint) color44);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 128 + "'", int45 == 128);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets2, (java.awt.Paint) color3);
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        boolean boolean5 = xYPlot4.isRangeCrosshairLockedOnData();
        java.awt.Paint paint6 = xYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot4.getDatasetRenderingOrder();
        int int8 = xYPlot4.getDatasetCount();
        boolean boolean9 = xYPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes((double) (short) 0, (double) 0.5f, plotRenderingInfo12, point2D13);
        double double15 = xYPlot4.getDomainCrosshairValue();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot4.setDomainAxes(valueAxisArray16);
        java.awt.Color color20 = java.awt.Color.black;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color20, stroke21);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker22.setStroke(stroke23);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        polarPlot25.setBackgroundAlpha((float) (short) 0);
        valueMarker22.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot25);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel32 = null;
        java.awt.Rectangle rectangle33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.geom.AffineTransform affineTransform35 = null;
        java.awt.RenderingHints renderingHints36 = null;
        java.awt.PaintContext paintContext37 = color31.createContext(colorModel32, rectangle33, rectangle2D34, affineTransform35, renderingHints36);
        xYPlot29.setRangeTickBandPaint((java.awt.Paint) color31);
        xYPlot29.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker22.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot29);
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot29.getRangeAxisLocation();
        xYPlot4.setDomainAxisLocation(2, axisLocation43);
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation43);
        java.awt.Paint paint46 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintContext37);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (short) 0);
        java.lang.Object obj3 = polarPlot0.clone();
        java.awt.Stroke stroke4 = polarPlot0.getRadiusGridlineStroke();
        boolean boolean5 = polarPlot0.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle2.getPadding();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textTitle2.arrange(graphics2D8, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean11 = flowArrangement9.equals((java.lang.Object) 0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 0, 0.12d);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Paint paint18 = xYPlot5.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, 1.0f, textMeasurer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo6);
        double double8 = piePlotState7.getPieHRadius();
        boolean boolean9 = textBlock5.equals((java.lang.Object) double8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = textBlock5.calculateDimensions(graphics2D10);
        java.awt.Font font13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("ClassContext", font13);
        java.lang.Object obj15 = textTitle14.clone();
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("ClassContext", font17, paint18, (float) (byte) 100);
        textTitle14.setFont(font17);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder(rectangleInsets22, (java.awt.Paint) color23);
        textTitle14.setFrame((org.jfree.chart.block.BlockFrame) blockBorder24);
        boolean boolean26 = textBlock5.equals((java.lang.Object) blockBorder24);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        int int2 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat1);
        org.jfree.data.RangeType rangeType3 = null;
        try {
            numberAxis3D0.setRangeType(rangeType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        java.awt.Paint paint49 = jFreeChart33.getBackgroundPaint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(paint49);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color7 = java.awt.Color.black;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color7, stroke8);
        polarPlot5.setAngleLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = polarPlot5.getOrientation();
        xYPlot0.setOrientation(plotOrientation11);
        java.awt.Font font14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("ClassContext", font14);
        xYPlot0.setNoDataMessageFont(font14);
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("ClassContext", font18, paint19, (float) (byte) 100);
        xYPlot0.setRangeZeroBaselinePaint(paint19);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot39.getDataset();
        double[] doubleArray47 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray52 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray57 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray62 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray67 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray68 = new double[][] { doubleArray47, doubleArray52, doubleArray57, doubleArray62, doubleArray67 };
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray68);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = categoryPlot39.getRendererForDataset(categoryDataset69);
        org.jfree.chart.util.SortOrder sortOrder71 = categoryPlot39.getColumnRenderingOrder();
        java.awt.Color color74 = java.awt.Color.black;
        java.awt.Stroke stroke75 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker76 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color74, stroke75);
        java.awt.Stroke stroke77 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker76.setStroke(stroke77);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener79 = null;
        valueMarker76.addChangeListener(markerChangeListener79);
        valueMarker76.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double84 = rectangleInsets83.getLeft();
        double double86 = rectangleInsets83.extendHeight(0.0d);
        valueMarker76.setLabelOffset(rectangleInsets83);
        valueMarker76.setAlpha(0.0f);
        org.jfree.chart.util.Layer layer90 = null;
        categoryPlot39.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker76, layer90);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNull(categoryItemRenderer70);
        org.junit.Assert.assertNotNull(sortOrder71);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleInsets83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 8.0d + "'", double84 == 8.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 8.0d + "'", double86 == 8.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = polarPlot0.getDataset();
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", font3);
        polarPlot0.setAngleLabelFont(font3);
        polarPlot0.setAngleLabelsVisible(true);
        org.junit.Assert.assertNull(xYDataset1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Range[0.0,11.0]");
        java.lang.String str2 = textFragment1.getText();
        float float3 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Range[0.0,11.0]" + "'", str2.equals("Range[0.0,11.0]"));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot3D0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = piePlot3D0.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            piePlot3D0.setLabelPadding(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleConstraintType.RANGE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Stroke stroke2 = xYPlot0.getRangeZeroBaselineStroke();
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset31);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot35 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset31);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        dateAxis37.setVisible(false);
        double double40 = dateAxis37.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer41);
        org.jfree.data.category.CategoryDataset categoryDataset43 = categoryPlot42.getDataset();
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot42.getOrientation();
        xYPlot0.setOrientation(plotOrientation44);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(plotOrientation44);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = xYPlot0.getRangeMarkers(layer2);
        boolean boolean4 = xYPlot0.isDomainGridlinesVisible();
        int int5 = xYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        polarPlot0.setAngleGridlinesVisible(false);
        org.junit.Assert.assertNull(polarItemRenderer1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D0);
        org.jfree.chart.JFreeChart jFreeChart3 = plotChangeEvent2.getChart();
        org.jfree.chart.plot.Plot plot4 = plotChangeEvent2.getPlot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(jFreeChart3);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        java.lang.Object obj3 = textTitle2.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle2.getVerticalAlignment();
        java.lang.String str5 = verticalAlignment4.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VerticalAlignment.CENTER" + "'", str5.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.setNegativeArrowVisible(true);
        java.lang.Object obj5 = dateAxis0.clone();
        java.lang.String str6 = dateAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = xYPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(drawingSupplier13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', (double) 100.0f, plotRenderingInfo4, point2D5);
        boolean boolean7 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getDomainAxisLocation(1);
        java.awt.Color color11 = java.awt.Color.cyan;
        java.awt.Color color13 = java.awt.Color.black;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color13, stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker15.setStroke(stroke16);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color11, stroke16);
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj2 = dateAxis1.clone();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setVisible(false);
        double[] doubleArray15 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset37, false);
        dateAxis6.setDefaultAutoRange(range39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer41);
        double double43 = dateAxis6.getLabelAngle();
        dateAxis6.zoomRange(0.4d, (double) (short) 1);
        dateAxis6.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        xYPlot0.mapDatasetToRangeAxis(100, (int) (short) 1);
        java.awt.Paint paint13 = xYPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        try {
            org.jfree.chart.LegendItem legendItem10 = legendItemCollection7.get((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraintType.RANGE", "java.awt.Color[r=128,g=128,b=128]", "", "java.awt.Color[r=128,g=128,b=128]");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        java.lang.String str6 = basicProjectInfo4.getVersion();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo4.getLibraries();
        basicProjectInfo4.addOptionalLibrary("java.awt.Color[r=0,g=0,b=0]");
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str6.equals("java.awt.Color[r=128,g=128,b=128]"));
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle2.getHorizontalAlignment();
        textTitle2.setNotify(false);
        textTitle2.setText("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle2.setHorizontalAlignment(horizontalAlignment12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "ClassContext");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        org.jfree.data.Range range35 = dateAxis0.getDefaultAutoRange();
        java.util.Date date36 = null;
        try {
            dateAxis0.setMaximumDate(date36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double3 = size2D2.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) '4', (double) (byte) 1, rectangleAnchor6);
        size2D2.setHeight((double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.mapDatasetToDomainAxis((int) (short) -1, 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(layer7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        xYPlot0.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        boolean boolean22 = xYPlot21.isRangeCrosshairLockedOnData();
        java.awt.Paint paint23 = xYPlot21.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = xYPlot21.getDatasetRenderingOrder();
        xYPlot11.setDatasetRenderingOrder(datasetRenderingOrder24);
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double[] doubleArray7 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray28 = new double[][] { doubleArray7, doubleArray12, doubleArray17, doubleArray22, doubleArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset29, false);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset29);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot33 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset29);
        org.jfree.chart.JFreeChart jFreeChart34 = multiplePiePlot33.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder35 = multiplePiePlot33.getDataExtractOrder();
        multiplePiePlot0.setDataExtractOrder(tableOrder35);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(jFreeChart34);
        org.junit.Assert.assertNotNull(tableOrder35);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean4 = polarPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        float float7 = dateAxis5.getTickMarkInsideLength();
        java.awt.Paint paint8 = dateAxis5.getTickLabelPaint();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis5.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setVisible(false);
        double double4 = dateAxis1.getUpperBound();
        java.awt.Color color6 = java.awt.Color.cyan;
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color6, stroke11);
        dateAxis1.setAxisLinePaint((java.awt.Paint) color6);
        dateAxis1.setRangeWithMargins((double) (-524308), (double) 1L);
        java.awt.Shape shape18 = dateAxis1.getLeftArrow();
        piePlot0.setLegendItemShape(shape18);
        java.awt.Paint paint20 = null;
        try {
            piePlot0.setBaseSectionOutlinePaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        float float2 = dateAxis0.getTickMarkOutsideLength();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double6 = dateAxis0.lengthToJava2D((-1.0d), rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16727872) + "'", int1 == (-16727872));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot3D0.getLegendItems();
        java.awt.Stroke stroke2 = piePlot3D0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot39.zoomDomainAxes((double) (-524308), plotRenderingInfo41, point2D42, true);
        int int45 = categoryPlot39.getWeight();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle2.getVerticalAlignment();
        java.lang.String str6 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot4 = xYPlot0.getParent();
        xYPlot0.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo8, point2D9);
        java.lang.Object obj11 = xYPlot0.clone();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        xYPlot12.setRangeTickBandPaint((java.awt.Paint) color14);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("UnitType.ABSOLUTE", 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = jFreeChart33.getPadding();
        boolean boolean50 = jFreeChart33.isNotify();
        org.jfree.chart.plot.Plot plot51 = jFreeChart33.getPlot();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(plot51);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setUpperMargin((double) (byte) -1);
        java.awt.Color color11 = java.awt.Color.gray;
        dateAxis8.setTickMarkPaint((java.awt.Paint) color11);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(10.0d, (double) 2, (double) 10.0f, 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        double double5 = textTitle2.getWidth();
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle2.arrange(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle2.getFrame();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = xYPlot6.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = xYPlot6.getDatasetRenderingOrder();
        int int10 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color13 = java.awt.Color.black;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color13, stroke14);
        polarPlot11.setAngleLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = polarPlot11.getOrientation();
        xYPlot6.setOrientation(plotOrientation17);
        java.awt.Font font20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("ClassContext", font20);
        xYPlot6.setNoDataMessageFont(font20);
        textTitle2.setFont(font20);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockFrame5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        int int40 = categoryPlot39.getDatasetCount();
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot39.getRangeMarkers(layer41);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getDatasetCount();
        boolean boolean5 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, (double) 0.5f, plotRenderingInfo8, point2D9);
        double double11 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray12);
        java.awt.Color color16 = java.awt.Color.black;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker18.setStroke(stroke19);
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        polarPlot21.setBackgroundAlpha((float) (short) 0);
        valueMarker18.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot21);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color27.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        xYPlot25.setRangeTickBandPaint((java.awt.Paint) color27);
        xYPlot25.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker18.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot25);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot25.getRangeAxisLocation();
        xYPlot0.setDomainAxisLocation(2, axisLocation39);
        boolean boolean41 = xYPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator1);
        ringPlot0.setSeparatorsVisible(true);
        java.awt.Font font5 = ringPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        java.awt.Font font10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ClassContext", font10);
        textTitle11.setExpandToFitSpace(false);
        java.awt.Paint paint14 = null;
        textTitle11.setBackgroundPaint(paint14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle11.getHorizontalAlignment();
        textTitle11.setNotify(false);
        textTitle11.setText("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        boolean boolean21 = legendItemCollection7.equals((java.lang.Object) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=0,b=0]", "Range[0.0,11.0]", "RectangleConstraint[RectangleConstraintType.RANGE: width=10.0, height=50.0]", "RectangleConstraintType.RANGE");
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.lang.String str2 = standardPieSectionLabelGenerator0.getLabelFormat();
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset31);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot35 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset31);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        dateAxis37.setVisible(false);
        double double40 = dateAxis37.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer41);
        int int43 = categoryPlot42.getDatasetCount();
        categoryPlot42.configureRangeAxes();
        boolean boolean45 = standardPieSectionLabelGenerator0.equals((java.lang.Object) categoryPlot42);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        textTitle36.setToolTipText("Range[-5.0,50.0]");
        java.lang.Object obj51 = textTitle36.clone();
        java.awt.Paint paint52 = textTitle36.getPaint();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker3.addChangeListener(markerChangeListener6);
        valueMarker3.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getLeft();
        double double13 = rectangleInsets10.extendHeight(0.0d);
        valueMarker3.setLabelOffset(rectangleInsets10);
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets10.getUnitType();
        double double17 = rectangleInsets10.calculateRightInset(4.0d);
        double double19 = rectangleInsets10.calculateRightOutset((-8.0d));
        double double20 = rectangleInsets10.getRight();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        java.awt.Image image2 = piePlot3D0.getBackgroundImage();
        piePlot3D0.setMaximumLabelWidth(0.4d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double7 = size2D6.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) '4', (double) (byte) 1, rectangleAnchor10);
        textTitle2.draw(graphics2D3, rectangle2D11);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot3D5.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.PiePlotState piePlotState9 = ringPlot2.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) piePlot3D5, (java.lang.Integer) 0, plotRenderingInfo8);
        piePlot3D5.setMaximumLabelWidth((double) '#');
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator12 = null;
        piePlot3D5.setToolTipGenerator(pieToolTipGenerator12);
        piePlot3D5.setDarkerSides(false);
        piePlot3D5.setSectionOutlinesVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(rectangleInsets18, (java.awt.Paint) color19);
        piePlot3D5.setLabelPadding(rectangleInsets18);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("ClassContext", font23, paint24, (float) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = null;
        polarPlot27.notifyListeners(plotChangeEvent28);
        boolean boolean31 = polarPlot27.equals((java.lang.Object) 0.0f);
        java.awt.Color color34 = java.awt.Color.getColor("hi!", (int) 'a');
        polarPlot27.setBackgroundPaint((java.awt.Paint) color34);
        boolean boolean36 = textFragment26.equals((java.lang.Object) polarPlot27);
        java.awt.Paint paint37 = textFragment26.getPaint();
        piePlot3D5.setLabelOutlinePaint(paint37);
        piePlot1.setBaseSectionOutlinePaint(paint37);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator40 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator40);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(piePlotState9);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = null;
        try {
            numberAxis3D0.setRangeType(rangeType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
//        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
//        numberAxis3D1.setAutoRangeIncludesZero(false);
//        java.awt.Graphics2D graphics2D8 = null;
//        org.jfree.chart.axis.AxisState axisState9 = null;
//        org.jfree.data.xy.XYDataset xYDataset10 = null;
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Paint paint13 = dateAxis12.getLabelPaint();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
//        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer14);
//        numberAxis3D11.setAutoRangeIncludesZero(false);
//        numberAxis3D11.setLabel("http://www.jfree.org/jfreechart/index.html");
//        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
//        double double24 = size2D23.getWidth();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, (double) '4', (double) (byte) 1, rectangleAnchor27);
//        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.TOP;
//        double double30 = numberAxis3D11.java2DToValue(1.0E-5d, rectangle2D28, rectangleEdge29);
//        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
//        dateAxis31.setVisible(false);
//        dateAxis31.setLabelURL("RectangleConstraintType.RANGE");
//        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
//        java.awt.Graphics2D graphics2D38 = null;
//        java.awt.geom.Rectangle2D rectangle2D39 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
//        org.jfree.chart.LegendItemCollection legendItemCollection41 = piePlot3D40.getLegendItems();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState44 = ringPlot37.initialise(graphics2D38, rectangle2D39, (org.jfree.chart.plot.PiePlot) piePlot3D40, (java.lang.Integer) 0, plotRenderingInfo43);
//        java.awt.Graphics2D graphics2D45 = null;
//        org.jfree.chart.util.Size2D size2D48 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
//        double double49 = size2D48.getWidth();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        java.awt.geom.Rectangle2D rectangle2D53 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D48, (double) '4', (double) (byte) 1, rectangleAnchor52);
//        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot();
//        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
//        dateAxis55.setVisible(false);
//        double double58 = dateAxis55.getUpperBound();
//        java.awt.Color color60 = java.awt.Color.cyan;
//        java.awt.Color color62 = java.awt.Color.black;
//        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color62, stroke63);
//        java.awt.Stroke stroke65 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        valueMarker64.setStroke(stroke65);
//        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color60, stroke65);
//        dateAxis55.setAxisLinePaint((java.awt.Paint) color60);
//        dateAxis55.setRangeWithMargins((double) (-524308), (double) 1L);
//        java.awt.Shape shape72 = dateAxis55.getLeftArrow();
//        piePlot54.setLegendItemShape(shape72);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState76 = piePlot3D40.initialise(graphics2D45, rectangle2D53, piePlot54, (java.lang.Integer) 255, plotRenderingInfo75);
//        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.TOP;
//        double double78 = dateAxis31.dateToJava2D(date36, rectangle2D53, rectangleEdge77);
//        try {
//            java.util.List list79 = numberAxis3D1.refreshTicks(graphics2D8, axisState9, rectangle2D28, rectangleEdge77);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
//        org.junit.Assert.assertNotNull(rectangleAnchor27);
//        org.junit.Assert.assertNotNull(rectangle2D28);
//        org.junit.Assert.assertNotNull(rectangleEdge29);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-0.020999895d) + "'", double30 == (-0.020999895d));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(legendItemCollection41);
//        org.junit.Assert.assertNotNull(piePlotState44);
//        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.0d + "'", double49 == 100.0d);
//        org.junit.Assert.assertNotNull(rectangleAnchor52);
//        org.junit.Assert.assertNotNull(rectangle2D53);
//        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
//        org.junit.Assert.assertNotNull(color60);
//        org.junit.Assert.assertNotNull(color62);
//        org.junit.Assert.assertNotNull(stroke63);
//        org.junit.Assert.assertNotNull(stroke65);
//        org.junit.Assert.assertNotNull(shape72);
//        org.junit.Assert.assertNotNull(piePlotState76);
//        org.junit.Assert.assertNotNull(rectangleEdge77);
//        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.56043833244502E14d + "'", double78 == 1.56043833244502E14d);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setVisible(false);
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        dateAxis2.setDefaultAutoRange(range35);
        int int37 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        xYPlot0.setDomainCrosshairValue((double) 0L);
        boolean boolean40 = xYPlot0.isRangeCrosshairVisible();
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        java.util.List list40 = categoryPlot39.getCategories();
        int int41 = categoryPlot39.getRangeAxisCount();
        categoryPlot39.clearAnnotations();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        int int40 = categoryPlot39.getDatasetCount();
        categoryPlot39.configureRangeAxes();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        categoryPlot39.rendererChanged(rendererChangeEvent42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot39.zoomDomainAxes((double) 1.0f, (double) 'a', plotRenderingInfo46, point2D47);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        int int50 = categoryAxis49.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions51 = categoryAxis49.getCategoryLabelPositions();
        double double52 = categoryAxis49.getLowerMargin();
        categoryAxis49.setUpperMargin((double) (-1L));
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis();
        int int56 = categoryAxis55.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions57 = categoryAxis55.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        int int59 = categoryAxis58.getMaximumCategoryLabelLines();
        categoryAxis58.setMaximumCategoryLabelLines(100);
        java.awt.Color color63 = java.awt.Color.black;
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color63, stroke64);
        java.awt.Stroke stroke66 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker65.setStroke(stroke66);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener68 = null;
        valueMarker65.addChangeListener(markerChangeListener68);
        valueMarker65.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double73 = rectangleInsets72.getLeft();
        double double75 = rectangleInsets72.extendHeight(0.0d);
        valueMarker65.setLabelOffset(rectangleInsets72);
        org.jfree.chart.util.UnitType unitType77 = rectangleInsets72.getUnitType();
        categoryAxis58.setTickLabelInsets(rectangleInsets72);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = new org.jfree.chart.axis.CategoryAxis();
        int int80 = categoryAxis79.getMaximumCategoryLabelLines();
        int int81 = categoryAxis79.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray82 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis49, categoryAxis55, categoryAxis58, categoryAxis79 };
        categoryPlot39.setDomainAxes(categoryAxisArray82);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.05d + "'", double52 == 0.05d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 8.0d + "'", double73 == 8.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 8.0d + "'", double75 == 8.0d);
        org.junit.Assert.assertNotNull(unitType77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 4 + "'", int81 == 4);
        org.junit.Assert.assertNotNull(categoryAxisArray82);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        float[] floatArray5 = new float[] { 100, 0.5f };
        try {
            float[] floatArray6 = java.awt.Color.RGBtoHSB((int) (byte) 100, 100, (int) (byte) 0, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setExplodePercent((java.lang.Comparable) "Other", (-6.0d));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getLabelPaint();
        piePlot3D0.setLabelShadowPaint(paint5);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (short) 0);
        java.lang.Object obj3 = polarPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) '4', plotRenderingInfo5, point2D6);
        int int8 = polarPlot0.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.setVisible(false);
        dateAxis9.setLabelURL("RectangleConstraintType.RANGE");
        java.awt.Shape shape14 = dateAxis9.getRightArrow();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (short) 0);
        java.lang.Object obj3 = polarPlot0.clone();
        polarPlot0.clearCornerTextItems();
        java.awt.Font font5 = polarPlot0.getAngleLabelFont();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setUpperBound((double) (short) -1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color6);
        xYPlot4.mapDatasetToRangeAxis(100, (int) (short) 1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = xYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.plot.Plot plot18 = xYPlot4.getRootPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot4.getDomainAxisLocation(0);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot4);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        multiplePiePlot29.setLimit(90.0d);
        java.lang.String str32 = multiplePiePlot29.getPlotType();
        try {
            multiplePiePlot29.setBackgroundImageAlpha((float) 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Multiple Pie Plot" + "'", str32.equals("Multiple Pie Plot"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isRangeCrosshairLockedOnData();
        java.awt.Paint paint4 = xYPlot2.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot2.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer7 };
        xYPlot0.setRenderers(xYItemRendererArray8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot0.getIndexOf(xYItemRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = xYPlot0.getDataRange(valueAxis12);
        xYPlot0.clearAnnotations();
        boolean boolean15 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean4 = polarPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        float float7 = dateAxis5.getTickMarkInsideLength();
        float float8 = dateAxis5.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        double double3 = categoryAxis0.getLowerMargin();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.5f, "Other");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        dateAxis0.setFixedAutoRange(2.0d);
        java.awt.Shape shape37 = dateAxis0.getLeftArrow();
        dateAxis0.setRange((double) (-524308), (double) 1);
        double double41 = dateAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot4 = xYPlot0.getParent();
        xYPlot0.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo8, point2D9);
        java.lang.Object obj11 = xYPlot0.clone();
        xYPlot0.setNoDataMessage("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ClassContext", font1, paint2, (float) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        polarPlot5.notifyListeners(plotChangeEvent6);
        boolean boolean9 = polarPlot5.equals((java.lang.Object) 0.0f);
        java.awt.Color color12 = java.awt.Color.getColor("hi!", (int) 'a');
        polarPlot5.setBackgroundPaint((java.awt.Paint) color12);
        boolean boolean14 = textFragment4.equals((java.lang.Object) polarPlot5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        polarPlot5.zoomDomainAxes((double) 4, plotRenderingInfo16, point2D17);
        java.awt.Color color20 = java.awt.Color.black;
        java.awt.Color color22 = java.awt.Color.black;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color22, stroke23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker24.setStroke(stroke25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke25);
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = null;
        polarPlot28.notifyListeners(plotChangeEvent29);
        boolean boolean31 = polarPlot28.isAngleLabelsVisible();
        valueMarker27.addChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot28);
        org.jfree.chart.axis.TickUnit tickUnit33 = polarPlot28.getAngleTickUnit();
        polarPlot5.setAngleTickUnit(tickUnit33);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(tickUnit33);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle2.getFrame();
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset34);
        org.jfree.chart.JFreeChart jFreeChart39 = multiplePiePlot38.getPieChart();
        java.awt.Font font41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("ClassContext", font41);
        java.lang.Object obj43 = textTitle42.clone();
        java.awt.Font font45 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("ClassContext", font45, paint46, (float) (byte) 100);
        textTitle42.setFont(font45);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        textTitle42.setFrame((org.jfree.chart.block.BlockFrame) blockBorder52);
        jFreeChart39.addSubtitle((org.jfree.chart.title.Title) textTitle42);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = jFreeChart39.getPadding();
        boolean boolean56 = jFreeChart39.isNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = jFreeChart39.getPadding();
        java.awt.RenderingHints renderingHints58 = jFreeChart39.getRenderingHints();
        jFreeChart39.setBorderVisible(false);
        textTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart39);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockFrame5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(jFreeChart39);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(renderingHints58);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean11 = flowArrangement9.equals((java.lang.Object) 0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 0, 0.12d);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint22 = dateAxis21.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer23);
        numberAxis3D20.setAutoRangeIncludesZero(false);
        numberAxis3D20.setLabel("http://www.jfree.org/jfreechart/index.html");
        org.jfree.chart.util.Size2D size2D32 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double33 = size2D32.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, (double) '4', (double) (byte) 1, rectangleAnchor36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.TOP;
        double double39 = numberAxis3D20.java2DToValue(1.0E-5d, rectangle2D37, rectangleEdge38);
        try {
            legendTitle17.draw(graphics2D18, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-0.020999895d) + "'", double39 == (-0.020999895d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot4 = xYPlot0.getParent();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot0.render(graphics2D5, rectangle2D6, (int) '#', plotRenderingInfo8, crosshairState9);
        boolean boolean11 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        org.jfree.chart.event.ChartProgressListener chartProgressListener49 = null;
        jFreeChart33.removeProgressListener(chartProgressListener49);
        jFreeChart33.setAntiAlias(true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        boolean boolean6 = xYPlot5.isRangeCrosshairLockedOnData();
        java.awt.Paint paint7 = xYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = xYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot9 = xYPlot5.getParent();
        xYPlot5.setRangeCrosshairValue(0.05d);
        boolean boolean12 = xYPlot5.isRangeZoomable();
        java.awt.Paint paint13 = xYPlot5.getRangeZeroBaselinePaint();
        java.awt.geom.Point2D point2D14 = xYPlot5.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) 0.0f, 1.0d, plotRenderingInfo4, point2D14);
        float float16 = xYPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle2.getHorizontalAlignment();
        textTitle2.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle2.getPadding();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '4', 0.0d, (double) (byte) 0, (java.awt.Paint) color5);
        int int7 = color5.getGreen();
        piePlot3D0.setBaseSectionOutlinePaint((java.awt.Paint) color5);
        int int9 = color5.getAlpha();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = jFreeChart33.getPadding();
        java.awt.Paint paint50 = jFreeChart33.getBorderPaint();
        int int51 = jFreeChart33.getBackgroundImageAlignment();
        boolean boolean52 = jFreeChart33.isNotify();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.event.ChartChangeEvent[source=java.awt.Color[r=0,g=0,b=0]]");
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent2.setType(chartChangeEventType3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        boolean boolean6 = xYPlot5.isRangeCrosshairLockedOnData();
        xYPlot5.setBackgroundImageAlignment((int) (byte) 100);
        boolean boolean9 = chartChangeEventType3.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        java.awt.Color color1 = java.awt.Color.black;
//        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
//        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        valueMarker3.setStroke(stroke4);
//        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
//        polarPlot6.setBackgroundAlpha((float) (short) 0);
//        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot6);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
//        java.awt.geom.Point2D point2D12 = null;
//        polarPlot6.zoomDomainAxes((double) (short) 100, plotRenderingInfo11, point2D12, true);
//        java.awt.Graphics2D graphics2D15 = null;
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
//        dateAxis16.setVisible(false);
//        dateAxis16.setLabelURL("RectangleConstraintType.RANGE");
//        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
//        java.awt.Graphics2D graphics2D23 = null;
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
//        org.jfree.chart.LegendItemCollection legendItemCollection26 = piePlot3D25.getLegendItems();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState29 = ringPlot22.initialise(graphics2D23, rectangle2D24, (org.jfree.chart.plot.PiePlot) piePlot3D25, (java.lang.Integer) 0, plotRenderingInfo28);
//        java.awt.Graphics2D graphics2D30 = null;
//        org.jfree.chart.util.Size2D size2D33 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
//        double double34 = size2D33.getWidth();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
//        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D33, (double) '4', (double) (byte) 1, rectangleAnchor37);
//        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot();
//        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
//        dateAxis40.setVisible(false);
//        double double43 = dateAxis40.getUpperBound();
//        java.awt.Color color45 = java.awt.Color.cyan;
//        java.awt.Color color47 = java.awt.Color.black;
//        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color47, stroke48);
//        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
//        valueMarker49.setStroke(stroke50);
//        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color45, stroke50);
//        dateAxis40.setAxisLinePaint((java.awt.Paint) color45);
//        dateAxis40.setRangeWithMargins((double) (-524308), (double) 1L);
//        java.awt.Shape shape57 = dateAxis40.getLeftArrow();
//        piePlot39.setLegendItemShape(shape57);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
//        org.jfree.chart.plot.PiePlotState piePlotState61 = piePlot3D25.initialise(graphics2D30, rectangle2D38, piePlot39, (java.lang.Integer) 255, plotRenderingInfo60);
//        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.TOP;
//        double double63 = dateAxis16.dateToJava2D(date21, rectangle2D38, rectangleEdge62);
//        try {
//            polarPlot6.drawOutline(graphics2D15, rectangle2D38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(color1);
//        org.junit.Assert.assertNotNull(stroke2);
//        org.junit.Assert.assertNotNull(stroke4);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(legendItemCollection26);
//        org.junit.Assert.assertNotNull(piePlotState29);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
//        org.junit.Assert.assertNotNull(rectangleAnchor37);
//        org.junit.Assert.assertNotNull(rectangle2D38);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
//        org.junit.Assert.assertNotNull(color45);
//        org.junit.Assert.assertNotNull(color47);
//        org.junit.Assert.assertNotNull(stroke48);
//        org.junit.Assert.assertNotNull(stroke50);
//        org.junit.Assert.assertNotNull(shape57);
//        org.junit.Assert.assertNotNull(piePlotState61);
//        org.junit.Assert.assertNotNull(rectangleEdge62);
//        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.56043833244502E14d + "'", double63 == 1.56043833244502E14d);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "java.awt.Color[r=0,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot32);
        org.jfree.chart.util.TableOrder tableOrder35 = multiplePiePlot32.getDataExtractOrder();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(tableOrder35);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Color color1 = java.awt.Color.cyan;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color1, stroke6);
        org.jfree.chart.text.TextAnchor textAnchor9 = valueMarker8.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker8.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor11 = valueMarker8.getLabelTextAnchor();
        java.awt.Stroke stroke12 = valueMarker8.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = valueMarker8.getLabelOffsetType();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getDatasetCount();
        java.awt.Color color6 = java.awt.Color.cyan;
        java.awt.Color color8 = java.awt.Color.black;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setStroke(stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color6, stroke11);
        xYPlot0.setDomainZeroBaselineStroke(stroke11);
        xYPlot0.setRangeCrosshairValue(1.56043833244502E14d);
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 0, (int) '4');
        xYPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType2, 0.0d, range4, lengthConstraintType5);
        double[] doubleArray13 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray18 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray33 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray34 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset35, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint6.toRangeHeight(range38);
        org.jfree.data.Range range41 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range44 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType45 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint(10.0d, range41, lengthConstraintType42, 0.0d, range44, lengthConstraintType45);
        double[] doubleArray53 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray58 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray63 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray68 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray73 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray74 = new double[][] { doubleArray53, doubleArray58, doubleArray63, doubleArray68, doubleArray73 };
        org.jfree.data.category.CategoryDataset categoryDataset75 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray74);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset75, false);
        org.jfree.data.Range range78 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset75);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = rectangleConstraint46.toRangeHeight(range78);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = rectangleConstraint6.toRangeHeight(range78);
        java.lang.String str81 = rectangleConstraint80.toString();
        double double82 = rectangleConstraint80.getHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertNotNull(lengthConstraintType45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(categoryDataset75);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNotNull(rectangleConstraint79);
        org.junit.Assert.assertNotNull(rectangleConstraint80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=10.0, height=50.0]" + "'", str81.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=10.0, height=50.0]"));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 50.0d + "'", double82 == 50.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoRangeMinimumSize((double) 2, true);
        org.jfree.data.Range range4 = dateAxis0.getRange();
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj2 = dateAxis1.clone();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setVisible(false);
        double[] doubleArray15 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset37, false);
        dateAxis6.setDefaultAutoRange(range39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer41);
        double double43 = dateAxis6.getLabelAngle();
        dateAxis6.zoomRange(0.4d, (double) (short) 1);
        dateAxis6.resizeRange(0.0d, (double) (short) 1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double3 = size2D2.getWidth();
        double double4 = size2D2.width;
        java.lang.String str5 = size2D2.toString();
        size2D2.width = 0.12d;
        size2D2.setWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Size2D[width=100.0, height=1.0]" + "'", str5.equals("Size2D[width=100.0, height=1.0]"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator1);
        java.awt.Stroke stroke3 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace14);
        boolean boolean16 = ringPlot0.equals((java.lang.Object) axisSpace14);
        java.awt.Paint paint17 = ringPlot0.getSeparatorPaint();
        ringPlot0.setSectionDepth((double) (short) 10);
        ringPlot0.setExplodePercent((java.lang.Comparable) 45.0d, (double) (byte) 10);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        boolean boolean40 = categoryPlot39.isRangeCrosshairVisible();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder47 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '4', 0.0d, (double) (byte) 0, (java.awt.Paint) color46);
        int int48 = color46.getGreen();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color46, stroke49);
        categoryPlot39.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker50);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor52 = categoryPlot39.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 128 + "'", int48 == 128);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categoryAnchor52);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D0);
        java.awt.Paint paint4 = null;
        piePlot3D0.setSectionOutlinePaint((java.lang.Comparable) 1L, paint4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        java.awt.Stroke stroke2 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, (double) (-1L), (-1.0d), (double) (byte) 100);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color5, stroke6);
        polarPlot3.setAngleLabelPaint((java.awt.Paint) color5);
        java.awt.Color color9 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        float[] floatArray11 = null;
        float[] floatArray12 = color5.getColorComponents(colorSpace10, floatArray11);
        boolean boolean13 = size2D2.equals((java.lang.Object) floatArray12);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        int int36 = categoryAxis35.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions37 = categoryAxis35.getCategoryLabelPositions();
        double double38 = categoryAxis35.getLowerMargin();
        categoryAxis35.setUpperMargin((double) (-1L));
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = null;
        polarPlot41.notifyListeners(plotChangeEvent42);
        boolean boolean45 = polarPlot41.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        polarPlot41.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis46);
        double[] doubleArray54 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray59 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray64 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray69 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray74 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray75 = new double[][] { doubleArray54, doubleArray59, doubleArray64, doubleArray69, doubleArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray75);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset76);
        dateAxis46.setDefaultAutoRange(range77);
        dateAxis46.setAxisLineVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer81 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot82 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryItemRenderer81);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions83 = categoryAxis35.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertNotNull(categoryLabelPositions83);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean41 = piePlot3D40.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D40);
        categoryPlot39.notifyListeners(plotChangeEvent42);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot39.getLegendItems();
        java.util.List list45 = categoryPlot39.getCategories();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        piePlotState1.setPieHRadius((double) '4');
        piePlotState1.setPieCenterX((double) 10.0f);
        piePlotState1.setPieHRadius((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot39.setRangeCrosshairStroke(stroke40);
        int int42 = categoryPlot39.getDomainAxisCount();
        categoryPlot39.zoom((double) 0L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[0.0,11.0]", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker3.addChangeListener(markerChangeListener6);
        valueMarker3.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getLeft();
        double double13 = rectangleInsets10.extendHeight(0.0d);
        valueMarker3.setLabelOffset(rectangleInsets10);
        java.lang.Object obj15 = valueMarker3.clone();
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color18 = java.awt.Color.black;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color18, stroke19);
        polarPlot16.setAngleLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.axis.ValueAxis valueAxis22 = polarPlot16.getAxis();
        java.awt.Stroke stroke23 = polarPlot16.getRadiusGridlineStroke();
        valueMarker3.setOutlineStroke(stroke23);
        double double25 = valueMarker3.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle2.getMargin();
        java.awt.Paint paint8 = textTitle2.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean10 = textAnchor8.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) 100, textAnchor4, 1.0d, textAnchor8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setVisible(false);
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray36 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray41 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray42 = new double[][] { doubleArray21, doubleArray26, doubleArray31, doubleArray36, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset43, false);
        dateAxis12.setDefaultAutoRange(range45);
        dateAxis12.setAutoTickUnitSelection(false);
        boolean boolean49 = textAnchor8.equals((java.lang.Object) dateAxis12);
        java.lang.String str50 = textAnchor8.toString();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str50.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot0.getIndexOf(xYItemRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = xYPlot0.getDataRange(valueAxis12);
        java.awt.Paint paint14 = xYPlot0.getBackgroundPaint();
        int int15 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Color color1 = java.awt.Color.cyan;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color1, stroke6);
        java.awt.Paint paint9 = valueMarker8.getLabelPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        org.jfree.chart.title.TextTitle textTitle49 = jFreeChart33.getTitle();
        java.util.List list50 = jFreeChart33.getSubtitles();
        jFreeChart33.setAntiAlias(false);
        boolean boolean53 = jFreeChart33.isBorderVisible();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(textTitle49);
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = xYPlot0.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot0.getDataset();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNull(xYDataset4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Color color1 = java.awt.Color.cyan;
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color1, stroke6);
        org.jfree.chart.text.TextAnchor textAnchor9 = valueMarker8.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker8.getLabelAnchor();
        java.awt.Font font11 = valueMarker8.getLabelFont();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset28);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (-1.0d) + "'", number31.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        boolean boolean4 = polarPlot0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        boolean boolean10 = xYPlot9.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot9.zoomRangeAxes((double) '#', (double) 100.0f, plotRenderingInfo13, point2D14);
        boolean boolean16 = xYPlot9.isDomainZeroBaselineVisible();
        java.awt.Paint paint17 = xYPlot9.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        boolean boolean22 = xYPlot21.isRangeCrosshairLockedOnData();
        java.awt.Paint paint23 = xYPlot21.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = xYPlot21.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = xYPlot21.getParent();
        xYPlot21.setRangeCrosshairValue(0.05d);
        boolean boolean28 = xYPlot21.isRangeZoomable();
        java.awt.Paint paint29 = xYPlot21.getRangeZeroBaselinePaint();
        java.awt.geom.Point2D point2D30 = xYPlot21.getQuadrantOrigin();
        xYPlot9.zoomDomainAxes((double) (short) 0, (double) 0.5f, plotRenderingInfo20, point2D30);
        polarPlot0.zoomDomainAxes(84.0d, plotRenderingInfo8, point2D30);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(point2D30);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot3D3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) piePlot3D3, (java.lang.Integer) 0, plotRenderingInfo6);
        piePlot3D3.setMaximumLabelWidth((double) '#');
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = null;
        piePlot3D3.setToolTipGenerator(pieToolTipGenerator10);
        java.awt.Paint paint12 = piePlot3D3.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(piePlotState7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setVisible(false);
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        dateAxis2.setDefaultAutoRange(range35);
        int int37 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        xYPlot0.zoomDomainAxes((double) (-1.0f), (double) 1.0f, plotRenderingInfo40, point2D41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace43);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 10);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot3D0.getLegendItems();
        java.awt.Paint paint2 = piePlot3D0.getBaseSectionPaint();
        org.jfree.data.general.PieDataset pieDataset3 = piePlot3D0.getDataset();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(pieDataset3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj2 = dateAxis1.clone();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setVisible(false);
        double[] doubleArray15 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset37, false);
        dateAxis6.setDefaultAutoRange(range39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer41);
        xYPlot42.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        xYPlot42.setFixedRangeAxisSpace(axisSpace44, false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        double double3 = rectangleInsets1.extendHeight((double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10.0f, (double) '#');
        columnArrangement4.clear();
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("ClassContext", font7);
        java.lang.Object obj9 = textTitle8.clone();
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("ClassContext", font11, paint12, (float) (byte) 100);
        textTitle8.setFont(font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color17);
        textTitle8.setFrame((org.jfree.chart.block.BlockFrame) blockBorder18);
        double double20 = textTitle8.getContentYOffset();
        java.lang.Object obj21 = null;
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle8, obj21);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2, 1.0f, textMeasurer4);
        org.jfree.chart.text.TextLine textLine6 = textBlock5.getLastLine();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNull(textLine6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.mapDatasetToDomainAxis((int) (short) -1, 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(layer7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        xYPlot0.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        polarPlot11.notifyListeners(plotChangeEvent12);
        boolean boolean15 = polarPlot11.equals((java.lang.Object) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        polarPlot11.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        float float18 = dateAxis16.getTickMarkInsideLength();
        java.awt.Paint paint19 = dateAxis16.getTickLabelPaint();
        dateAxis16.zoomRange(0.4d, (double) 10L);
        int int23 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("ClassContext", font25, paint26, (float) (byte) 100);
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent30 = null;
        polarPlot29.notifyListeners(plotChangeEvent30);
        boolean boolean33 = polarPlot29.equals((java.lang.Object) 0.0f);
        java.awt.Color color36 = java.awt.Color.getColor("hi!", (int) 'a');
        polarPlot29.setBackgroundPaint((java.awt.Paint) color36);
        boolean boolean38 = textFragment28.equals((java.lang.Object) polarPlot29);
        java.awt.Stroke stroke39 = polarPlot29.getAngleGridlineStroke();
        xYPlot0.setRangeCrosshairStroke(stroke39);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        piePlotState1.setPieHRadius((double) '4');
        org.jfree.chart.entity.EntityCollection entityCollection5 = piePlotState1.getEntityCollection();
        double double6 = piePlotState1.getTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(entityCollection5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Other");
        categoryAxis3D1.setMaximumCategoryLabelLines((int) (byte) 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        java.awt.Image image2 = piePlot3D0.getBackgroundImage();
        piePlot3D0.setDepthFactor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat1);
        java.text.NumberFormat numberFormat3 = numberAxis3D0.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.black;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color2, stroke3);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj7 = dateAxis6.clone();
        float float8 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setNegativeArrowVisible(true);
        java.lang.Object obj11 = dateAxis6.clone();
        org.jfree.data.Range range12 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.Timeline timeline13 = dateAxis6.getTimeline();
        double double14 = dateAxis6.getFixedDimension();
        java.lang.String str15 = dateAxis6.getLabelURL();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(timeline13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent2.setType(chartChangeEventType3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent2.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot3D0.getLegendItems();
        java.awt.Paint paint2 = piePlot3D0.getBaseSectionPaint();
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        double double4 = piePlot3D0.getLabelLinkMargin();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot3D0.getLabelDistributor();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double double3 = dateAxis0.getUpperBound();
        dateAxis0.setLowerMargin((double) (short) 10);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis6.setStandardTickUnits(tickUnitSource9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis6.getStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setVisible(false);
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray37 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray42 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray43 = new double[][] { doubleArray22, doubleArray27, doubleArray32, doubleArray37, doubleArray42 };
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset44, false);
        dateAxis13.setDefaultAutoRange(range46);
        dateAxis0.setDefaultAutoRange(range46);
        boolean boolean51 = range46.intersects(0.4d, 12.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = polarPlot2.getLegendItems();
        objectList0.set((int) (short) 0, (java.lang.Object) legendItemCollection3);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX(0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setUpperMargin((double) (byte) -1);
        java.awt.Color color11 = java.awt.Color.gray;
        dateAxis8.setTickMarkPaint((java.awt.Paint) color11);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        xYPlot0.setDomainCrosshairValue(10.0d, true);
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setVersion("ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        boolean boolean40 = categoryPlot39.isRangeCrosshairVisible();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder47 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '4', 0.0d, (double) (byte) 0, (java.awt.Paint) color46);
        int int48 = color46.getGreen();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color46, stroke49);
        categoryPlot39.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        int int53 = categoryAxis52.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions54 = categoryAxis52.getCategoryLabelPositions();
        double double55 = categoryAxis52.getLowerMargin();
        categoryAxis52.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        categoryAxis52.setLowerMargin((double) 8);
        int int60 = categoryPlot39.getDomainAxisIndex(categoryAxis52);
        categoryPlot39.mapDatasetToDomainAxis(2, (int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        categoryPlot39.setFixedDomainAxisSpace(axisSpace64);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 128 + "'", int48 == 128);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot3D3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) piePlot3D3, (java.lang.Integer) 0, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double12 = size2D11.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) '4', (double) (byte) 1, rectangleAnchor15);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setVisible(false);
        double double21 = dateAxis18.getUpperBound();
        java.awt.Color color23 = java.awt.Color.cyan;
        java.awt.Color color25 = java.awt.Color.black;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color25, stroke26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker27.setStroke(stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color23, stroke28);
        dateAxis18.setAxisLinePaint((java.awt.Paint) color23);
        dateAxis18.setRangeWithMargins((double) (-524308), (double) 1L);
        java.awt.Shape shape35 = dateAxis18.getLeftArrow();
        piePlot17.setLegendItemShape(shape35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.PiePlotState piePlotState39 = piePlot3D3.initialise(graphics2D8, rectangle2D16, piePlot17, (java.lang.Integer) 255, plotRenderingInfo38);
        piePlotState39.setLatestAngle((double) 2.0f);
        double double42 = piePlotState39.getPieCenterY();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(piePlotState7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(piePlotState39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean11 = flowArrangement9.equals((java.lang.Object) 0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 0, 0.12d);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.Range range20 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range23 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(10.0d, range20, lengthConstraintType21, 0.0d, range23, lengthConstraintType24);
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray37 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray42 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray47 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray52 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray53 = new double[][] { doubleArray32, doubleArray37, doubleArray42, doubleArray47, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray53);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset54, false);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset54);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = rectangleConstraint25.toRangeHeight(range57);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = rectangleConstraint58.toFixedHeight((double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = rectangleConstraint58.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D62 = legendTitle17.arrange(graphics2D18, rectangleConstraint58);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = rectangleConstraint58.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(rectangleConstraint58);
        org.junit.Assert.assertNotNull(rectangleConstraint60);
        org.junit.Assert.assertNotNull(rectangleConstraint61);
        org.junit.Assert.assertNotNull(size2D62);
        org.junit.Assert.assertNotNull(rectangleConstraint63);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.black;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color2, stroke3);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        polarPlot0.notifyListeners(plotChangeEvent6);
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        polarPlot0.setAngleLabelFont(font8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        polarPlot0.rendererChanged(rendererChangeEvent10);
        java.awt.Font font12 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setUpperMargin((double) (byte) -1);
        java.awt.Color color16 = java.awt.Color.gray;
        dateAxis13.setTickMarkPaint((java.awt.Paint) color16);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        polarPlot0.clearCornerTextItems();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot3D3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) piePlot3D3, (java.lang.Integer) 0, plotRenderingInfo6);
        java.lang.String str8 = piePlot3D3.getPlotType();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(piePlotState7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie 3D Plot" + "'", str8.equals("Pie 3D Plot"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10.0f, (double) '#');
        java.awt.Font font6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("ClassContext", font6);
        textTitle7.setExpandToFitSpace(false);
        java.awt.Paint paint10 = null;
        textTitle7.setBackgroundPaint(paint10);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle7, (java.lang.Object) (-6.0d));
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray40 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray41 = new double[][] { doubleArray20, doubleArray25, doubleArray30, doubleArray35, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray41);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset42, false);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset42);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot46 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset42);
        org.jfree.chart.JFreeChart jFreeChart47 = multiplePiePlot46.getPieChart();
        java.awt.Font font49 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("ClassContext", font49);
        java.lang.Object obj51 = textTitle50.clone();
        java.awt.Font font53 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("ClassContext", font53, paint54, (float) (byte) 100);
        textTitle50.setFont(font53);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder60 = new org.jfree.chart.block.BlockBorder(rectangleInsets58, (java.awt.Paint) color59);
        textTitle50.setFrame((org.jfree.chart.block.BlockFrame) blockBorder60);
        jFreeChart47.addSubtitle((org.jfree.chart.title.Title) textTitle50);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = jFreeChart47.getPadding();
        boolean boolean64 = jFreeChart47.isNotify();
        jFreeChart47.setTextAntiAlias(true);
        java.awt.Paint paint67 = jFreeChart47.getBackgroundPaint();
        textTitle7.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart47);
        org.jfree.chart.plot.PolarPlot polarPlot69 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color71 = java.awt.Color.black;
        java.awt.Stroke stroke72 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color71, stroke72);
        polarPlot69.setAngleLabelPaint((java.awt.Paint) color71);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent75 = null;
        polarPlot69.notifyListeners(plotChangeEvent75);
        java.awt.Font font77 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        polarPlot69.setAngleLabelFont(font77);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent79 = null;
        polarPlot69.rendererChanged(rendererChangeEvent79);
        java.awt.Font font81 = polarPlot69.getAngleLabelFont();
        textTitle7.setFont(font81);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(jFreeChart47);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNull(paint67);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(font81);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        textTitle2.setExpandToFitSpace(false);
        java.awt.Paint paint5 = null;
        textTitle2.setBackgroundPaint(paint5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle2.getHorizontalAlignment();
        textTitle2.setNotify(false);
        java.lang.Object obj10 = textTitle2.clone();
        double double11 = textTitle2.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot39.setRangeCrosshairStroke(stroke40);
        int int42 = categoryPlot39.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot39.getFixedRangeAxisSpace();
        boolean boolean44 = categoryPlot39.isRangeZoomable();
        categoryPlot39.setBackgroundAlpha((float) 1L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource3);
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis0.setTimeline(timeline5);
        double double7 = dateAxis0.getLowerBound();
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray34 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray35 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray35);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset36);
        dateAxis0.setRange(range37, false, false);
        double double41 = dateAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-524308), 10.0d, (double) (short) -1, (double) 500);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot39.getDataset();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset40);
        org.jfree.data.Range range44 = org.jfree.data.Range.shift(range41, (double) 100.0f, true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker3.addChangeListener(markerChangeListener6);
        valueMarker3.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getLeft();
        double double13 = rectangleInsets10.extendHeight(0.0d);
        valueMarker3.setLabelOffset(rectangleInsets10);
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets10.getUnitType();
        double double17 = rectangleInsets10.trimWidth(0.12d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-15.879999999999999d) + "'", double17 == (-15.879999999999999d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ClassContext", font1, paint2, (float) (byte) 100);
        float float5 = textFragment4.getBaselineOffset();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis6.setStandardTickUnits(tickUnitSource9);
        org.jfree.chart.axis.Timeline timeline11 = null;
        dateAxis6.setTimeline(timeline11);
        boolean boolean13 = textFragment4.equals((java.lang.Object) timeline11);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = xYPlot0.getRendererForDataset(xYDataset1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = xYPlot0.getDrawingSupplier();
        int int4 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(xYItemRenderer2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftOutset(55.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Range[-5.0,50.0]");
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D0);
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean4 = piePlot3D3.getIgnoreNullValues();
        java.awt.Color color6 = java.awt.Color.black;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker8.setStroke(stroke9);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener11 = null;
        valueMarker8.addChangeListener(markerChangeListener11);
        valueMarker8.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double16 = rectangleInsets15.getLeft();
        double double18 = rectangleInsets15.extendHeight(0.0d);
        valueMarker8.setLabelOffset(rectangleInsets15);
        double double21 = rectangleInsets15.trimWidth((double) 100L);
        piePlot3D3.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.util.Size2D size2D25 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double26 = size2D25.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) '4', (double) (byte) 1, rectangleAnchor29);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets15.createOutsetRectangle(rectangle2D30);
        piePlot3D0.setLegendItemShape((java.awt.Shape) rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 84.0d + "'", double21 == 84.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.mapDatasetToDomainAxis((int) (short) -1, 0);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot0.getDomainMarkers(layer7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        xYPlot0.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        polarPlot6.setBackgroundAlpha((float) (short) 0);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot6);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color12);
        xYPlot10.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot10);
        java.awt.Paint paint24 = xYPlot10.getRangeTickBandPaint();
        xYPlot10.clearRangeAxes();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        numberAxis3D1.setAutoRangeIncludesZero(false);
        numberAxis3D1.setLabel("http://www.jfree.org/jfreechart/index.html");
        java.awt.Color color10 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent12.setType(chartChangeEventType13);
        java.awt.Color color15 = java.awt.Color.black;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent17.setType(chartChangeEventType18);
        chartChangeEvent12.setType(chartChangeEventType18);
        java.lang.Object obj21 = chartChangeEvent12.getSource();
        boolean boolean22 = numberAxis3D1.equals(obj21);
        org.jfree.data.Range range23 = numberAxis3D1.getRange();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setExplodePercent((java.lang.Comparable) "Other", (-6.0d));
        java.lang.String str4 = piePlot3D0.getPlotType();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean11 = flowArrangement9.equals((java.lang.Object) 0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 0, 0.12d);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.Range range20 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range23 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(10.0d, range20, lengthConstraintType21, 0.0d, range23, lengthConstraintType24);
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray37 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray42 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray47 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray52 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray53 = new double[][] { doubleArray32, doubleArray37, doubleArray42, doubleArray47, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray53);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset54, false);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset54);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = rectangleConstraint25.toRangeHeight(range57);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = rectangleConstraint58.toFixedHeight((double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = rectangleConstraint58.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D62 = legendTitle17.arrange(graphics2D18, rectangleConstraint58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = legendTitle17.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = legendTitle17.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(rectangleConstraint58);
        org.junit.Assert.assertNotNull(rectangleConstraint60);
        org.junit.Assert.assertNotNull(rectangleConstraint61);
        org.junit.Assert.assertNotNull(size2D62);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot32.getPieChart();
        java.awt.Font font35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("ClassContext", font35);
        java.lang.Object obj37 = textTitle36.clone();
        java.awt.Font font39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("ClassContext", font39, paint40, (float) (byte) 100);
        textTitle36.setFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, (java.awt.Paint) color45);
        textTitle36.setFrame((org.jfree.chart.block.BlockFrame) blockBorder46);
        jFreeChart33.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = jFreeChart33.getPadding();
        boolean boolean50 = jFreeChart33.isNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = jFreeChart33.getPadding();
        java.util.List list52 = jFreeChart33.getSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle53 = null;
        try {
            jFreeChart33.addLegend(legendTitle53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(list52);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint2 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        int int4 = xYPlot0.getDatasetCount();
        boolean boolean5 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, (double) 0.5f, plotRenderingInfo8, point2D9);
        try {
            java.awt.Paint paint12 = xYPlot0.getQuadrantPaint(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (500) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        numberAxis3D1.setAutoRangeIncludesZero(false);
        numberAxis3D1.setLabel("http://www.jfree.org/jfreechart/index.html");
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D(100.0d, (double) 1);
        double double14 = size2D13.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) '4', (double) (byte) 1, rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.TOP;
        double double20 = numberAxis3D1.java2DToValue(1.0E-5d, rectangle2D18, rectangleEdge19);
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Other", numberArray23);
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset24, (java.lang.Comparable) "Other");
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity32 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D18, pieDataset26, (int) (byte) -1, (int) '#', (java.lang.Comparable) 55.0d, "VerticalAlignment.CENTER", "http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.020999895d) + "'", double20 == (-0.020999895d));
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(pieDataset26);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean41 = piePlot3D40.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D40);
        categoryPlot39.notifyListeners(plotChangeEvent42);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot39.getLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace45 = categoryPlot39.getFixedDomainAxisSpace();
        categoryPlot39.clearRangeMarkers();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertNull(axisSpace45);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot3D3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PiePlotState piePlotState7 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) piePlot3D3, (java.lang.Integer) 0, plotRenderingInfo6);
        piePlot3D3.setMaximumLabelWidth((double) '#');
        int int10 = piePlot3D3.getPieIndex();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(piePlotState7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list6 = projectInfo5.getContributors();
        projectInfo4.setContributors(list6);
        xYPlot0.drawRangeTickBands(graphics2D2, rectangle2D3, list6);
        java.awt.Stroke stroke9 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj2 = dateAxis1.clone();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setVisible(false);
        double[] doubleArray15 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset37, false);
        dateAxis6.setDefaultAutoRange(range39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer41);
        double double43 = dateAxis6.getLabelAngle();
        dateAxis6.setFixedAutoRange((double) 1L);
        double double46 = dateAxis6.getLowerMargin();
        dateAxis6.configure();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getTextAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean11 = flowArrangement9.equals((java.lang.Object) 0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 0, 0.12d);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        legendTitle17.setItemPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot39.setRangeCrosshairStroke(stroke40);
        int int42 = categoryPlot39.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot39.getDataset(0);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot39.getRangeMarkers(layer45);
        categoryPlot39.mapDatasetToRangeAxis(0, (-524308));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(100);
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker7.setStroke(stroke8);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener10 = null;
        valueMarker7.addChangeListener(markerChangeListener10);
        valueMarker7.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getLeft();
        double double17 = rectangleInsets14.extendHeight(0.0d);
        valueMarker7.setLabelOffset(rectangleInsets14);
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets14.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets14);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertNotNull(unitType19);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setVisible(false);
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray27 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray33 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
        dateAxis3.setDefaultAutoRange(range36);
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range40 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        dateAxis3.setUpperBound(100.0d);
        dateAxis3.resizeRange((-5.0d), (double) 255);
        dateAxis3.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(range40);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        java.util.List list40 = categoryPlot39.getCategories();
        int int41 = categoryPlot39.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot39.getRangeAxis((int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(valueAxis43);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color4, stroke5);
        textTitle2.setPaint((java.awt.Paint) color4);
        java.awt.Font font8 = textTitle2.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean10 = textAnchor8.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) 100, textAnchor4, 1.0d, textAnchor8);
        java.lang.Object obj12 = null;
        boolean boolean13 = textAnchor4.equals(obj12);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double[] doubleArray6 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setVisible(false);
        double double37 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer38);
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean41 = piePlot3D40.getDarkerSides();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D40);
        categoryPlot39.notifyListeners(plotChangeEvent42);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot39.getLegendItems();
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot39.getDomainMarkers((int) (short) 0, layer46);
        categoryPlot39.mapDatasetToDomainAxis((int) '4', 8);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setVisible(false);
        double[] doubleArray11 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray32 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, false);
        dateAxis2.setDefaultAutoRange(range35);
        int int37 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis2);
        xYPlot0.setDomainCrosshairValue((double) 0L);
        java.awt.Color color41 = java.awt.Color.black;
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color41, stroke42);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker43.setStroke(stroke44);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener46 = null;
        valueMarker43.addChangeListener(markerChangeListener46);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = valueMarker43.getLabelOffsetType();
        java.awt.Font font49 = valueMarker43.getLabelFont();
        org.jfree.chart.util.Layer layer50 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker43, layer50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot0.getRangeAxis();
        xYPlot0.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNull(valueAxis52);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        polarPlot6.setBackgroundAlpha((float) (short) 0);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot6);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color12);
        xYPlot10.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot10);
        java.awt.Paint paint24 = xYPlot10.getRangeTickBandPaint();
        xYPlot10.mapDatasetToDomainAxis((int) (short) 1, 128);
        java.awt.Stroke stroke28 = xYPlot10.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker3.setStroke(stroke4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        polarPlot6.setBackgroundAlpha((float) (short) 0);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot6);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color12);
        xYPlot10.mapDatasetToRangeAxis(100, (int) (short) 1);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot10.zoomDomainAxes((double) 128, plotRenderingInfo25, point2D26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot10.getDomainMarkers((int) (short) 10, layer29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot10.getDomainAxisLocation();
        org.jfree.chart.plot.Plot plot32 = xYPlot10.getRootPlot();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plot32);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator1);
        ringPlot0.setSeparatorsVisible(true);
        ringPlot0.setInnerSeparatorExtension(0.08d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Other", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ClassContext", font1);
        java.lang.Object obj3 = textTitle2.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle2.getTextAlignment();
        textTitle2.setURLText("");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean37 = dateAxis0.isInverted();
        dateAxis0.zoomRange((double) (short) 1, (double) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = xYPlot1.getRendererForDataset(xYDataset2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = xYPlot1.getDrawingSupplier();
        xYPlot1.mapDatasetToDomainAxis((int) '#', 100);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot1);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color2 = java.awt.Color.black;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color2, stroke3);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        polarPlot0.notifyListeners(plotChangeEvent6);
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        polarPlot0.setAngleLabelFont(font8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        polarPlot0.rendererChanged(rendererChangeEvent10);
        java.awt.Font font12 = polarPlot0.getAngleLabelFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        polarPlot0.handleClick(255, (int) '4', plotRenderingInfo15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = polarPlot0.getAxis();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ClassContext", font2, paint3, (float) (byte) 100);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("RectangleConstraintType.RANGE", font2);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean16 = textAnchor14.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean20 = textAnchor18.equals((java.lang.Object) 0.0d);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D11, 0.0f, (float) 100, textAnchor14, 1.0d, textAnchor18);
        try {
            textLine6.draw(graphics2D7, (float) (short) 100, (float) 0, textAnchor18, (float) (byte) -1, 0.0f, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVisible(false);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray14 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[] doubleArray29 = new double[] { (byte) 10, (byte) 1, (short) 0, (byte) -1 };
        double[][] doubleArray30 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        dateAxis0.setDefaultAutoRange(range33);
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean37 = dateAxis0.isInverted();
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setDefaultAutoRange(range38);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        polarPlot0.notifyListeners(plotChangeEvent1);
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) 0L, 0.0f, 0.0f);
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color6);
        boolean boolean8 = polarPlot0.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double2 = piePlot3D0.getExplodePercent((java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setVisible(false);
        double double6 = dateAxis3.getUpperBound();
        java.awt.Color color8 = java.awt.Color.cyan;
        java.awt.Color color10 = java.awt.Color.black;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color10, stroke11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker12.setStroke(stroke13);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint) color8, stroke13);
        dateAxis3.setAxisLinePaint((java.awt.Paint) color8);
        piePlot3D0.setBaseSectionOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint19 = dateAxis18.getLabelPaint();
        piePlot3D0.setLabelBackgroundPaint(paint19);
        java.awt.Color color21 = java.awt.Color.yellow;
        piePlot3D0.setLabelPaint((java.awt.Paint) color21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isRangeCrosshairLockedOnData();
        java.awt.Paint paint4 = xYPlot2.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = xYPlot2.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder5);
        int int7 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        xYPlot5.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean11 = flowArrangement9.equals((java.lang.Object) 0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 0, 0.12d);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Paint paint18 = legendTitle17.getBackgroundPaint();
        java.awt.Paint paint19 = legendTitle17.getItemPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }
}

