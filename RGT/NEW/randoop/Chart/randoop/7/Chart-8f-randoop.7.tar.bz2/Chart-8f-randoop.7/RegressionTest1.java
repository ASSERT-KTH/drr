import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date9 = week8.getStart();
        int int11 = week8.compareTo((java.lang.Object) true);
        long long12 = week8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean14 = week2.equals((java.lang.Object) regularTimePeriod13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Object obj19 = null;
        boolean boolean20 = week17.equals(obj19);
        int int21 = week17.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.previous();
        java.util.Date date23 = week17.getEnd();
        boolean boolean24 = week2.equals((java.lang.Object) week17);
        java.lang.String str25 = week17.toString();
        try {
            org.jfree.data.time.Year year26 = week17.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        int int3 = week2.getWeek();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61852305600001L) + "'", long4 == (-61852305600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 0, 10" + "'", str5.equals("Week 0, 10"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (-1));
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.lang.String str5 = week4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 45, 1" + "'", str5.equals("Week 45, 1"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            week2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        java.lang.Object obj3 = null;
        int int4 = week2.compareTo(obj3);
        java.util.Date date5 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, 12);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 638L + "'", long3 == 638L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getWeek();
        java.util.Date date10 = week6.getStart();
        java.util.Calendar calendar11 = null;
        try {
            week6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        java.util.Date date3 = week1.getEnd();
//        long long4 = week1.getLastMillisecond();
//        java.lang.String str5 = week1.toString();
//        long long6 = week1.getSerialIndex();
//        org.jfree.data.time.Year year7 = week1.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
//        java.util.Date date14 = regularTimePeriod12.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
//        int int18 = week17.getYearValue();
//        java.lang.String str19 = week17.toString();
//        java.util.Date date20 = week17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date14, timeZone21);
//        long long24 = week23.getSerialIndex();
//        java.util.Date date25 = week23.getEnd();
//        int int26 = week8.compareTo((java.lang.Object) date25);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 35, 53" + "'", str19.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2843L + "'", long24 == 2843L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 53);
        int int19 = week18.getYearValue();
        long long20 = week18.getSerialIndex();
        boolean boolean22 = week18.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date23 = week18.getStart();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = regularTimePeriod27.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
        int int32 = week31.getYearValue();
        java.lang.String str33 = week31.toString();
        java.util.Date date34 = week31.getEnd();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date34, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date23, timeZone37);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) '#', 53);
        int int44 = week43.getYearValue();
        long long45 = week43.getSerialIndex();
        boolean boolean47 = week43.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date48 = week43.getStart();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.previous();
        java.lang.Class<?> wildcardClass53 = regularTimePeriod52.getClass();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
        int int57 = week56.getYearValue();
        java.lang.String str58 = week56.toString();
        java.util.Date date59 = week56.getEnd();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date59, timeZone60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date59, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date48, timeZone62);
        java.lang.Class<?> wildcardClass65 = timeZone62.getClass();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date23, timeZone62);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 53);
        int int70 = week69.getYearValue();
        long long71 = week69.getSerialIndex();
        boolean boolean73 = week69.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date74 = week69.getStart();
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = week77.previous();
        java.lang.Class<?> wildcardClass79 = regularTimePeriod78.getClass();
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week((int) '#', 53);
        int int83 = week82.getYearValue();
        java.lang.String str84 = week82.toString();
        java.util.Date date85 = week82.getEnd();
        java.util.TimeZone timeZone86 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass79, date85, timeZone86);
        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date85, timeZone88);
        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date74, timeZone88);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date23, timeZone88);
        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date5, timeZone88);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2844L + "'", long20 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 53" + "'", str33.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 53 + "'", int44 == 53);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2844L + "'", long45 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 35, 53" + "'", str58.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 53 + "'", int70 == 53);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2844L + "'", long71 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 53 + "'", int83 == 53);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "Week 35, 53" + "'", str84.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(timeZone88);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable throwable19 = null;
        try {
            timePeriodFormatException7.addSuppressed(throwable19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date3 = week2.getStart();
        java.util.Date date4 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        int int10 = week9.getYearValue();
        java.lang.String str11 = week9.toString();
        java.util.Date date12 = week9.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date6, timeZone13);
        long long16 = week15.getSerialIndex();
        java.util.Date date17 = week15.getEnd();
        java.lang.Class<?> wildcardClass18 = week15.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 53);
        int int22 = week21.getYearValue();
        long long23 = week21.getSerialIndex();
        java.lang.String str24 = week21.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week21.next();
        boolean boolean28 = week21.equals((java.lang.Object) 0);
        java.util.Date date29 = week21.getEnd();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        int int38 = week37.getYearValue();
        java.lang.String str39 = week37.toString();
        java.util.Date date40 = week37.getEnd();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date40, timeZone41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date40, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date29, timeZone43);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date29);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass48 = timeZone47.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize(class50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 53);
        int int55 = week54.getYearValue();
        java.lang.String str56 = week54.toString();
        java.util.Date date57 = week54.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass60 = timePeriodFormatException59.getClass();
        java.util.Date date61 = null;
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) '#', 53);
        int int65 = week64.getYearValue();
        java.lang.String str66 = week64.toString();
        java.util.Date date67 = week64.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date61, timeZone68);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date57, timeZone68);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) '#', 53);
        int int75 = week74.getYearValue();
        long long76 = week74.getSerialIndex();
        boolean boolean78 = week74.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date79 = week74.getStart();
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = week82.previous();
        java.lang.Class<?> wildcardClass84 = regularTimePeriod83.getClass();
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week((int) '#', 53);
        int int88 = week87.getYearValue();
        java.lang.String str89 = week87.toString();
        java.util.Date date90 = week87.getEnd();
        java.util.TimeZone timeZone91 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass84, date90, timeZone91);
        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date90, timeZone93);
        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date79, timeZone93);
        java.lang.Class<?> wildcardClass96 = timeZone93.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date57, timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date29, timeZone93);
        try {
            org.jfree.data.time.Week week99 = new org.jfree.data.time.Week(date0, timeZone93);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2843L + "'", long16 == 2843L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2844L + "'", long23 == 2844L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 35, 53" + "'", str39.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 53 + "'", int55 == 53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Week 35, 53" + "'", str56.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 53 + "'", int65 == 53);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Week 35, 53" + "'", str66.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 53 + "'", int75 == 53);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 2844L + "'", long76 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 53 + "'", int88 == 53);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "Week 35, 53" + "'", str89.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNull(regularTimePeriod92);
        org.junit.Assert.assertNotNull(timeZone93);
        org.junit.Assert.assertNotNull(wildcardClass96);
        org.junit.Assert.assertNull(regularTimePeriod97);
        org.junit.Assert.assertNotNull(regularTimePeriod98);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        boolean boolean18 = week14.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date19 = week14.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        java.lang.String str29 = week27.toString();
        java.util.Date date30 = week27.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date30, timeZone33);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date19, timeZone33);
        java.lang.Class<?> wildcardClass36 = timeZone33.getClass();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date11, timeZone33);
        long long38 = week37.getFirstMillisecond();
        java.util.Date date39 = week37.getStart();
        java.lang.Class<?> wildcardClass40 = week37.getClass();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.previous();
        java.lang.Class<?> wildcardClass45 = regularTimePeriod44.getClass();
        java.util.Date date46 = regularTimePeriod44.getEnd();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 53);
        int int50 = week49.getYearValue();
        java.lang.String str51 = week49.toString();
        java.util.Date date52 = week49.getEnd();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date52, timeZone53);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date46, timeZone53);
        long long56 = week55.getSerialIndex();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) '#', 53);
        int int60 = week59.getYearValue();
        long long61 = week59.getSerialIndex();
        long long62 = week59.getMiddleMillisecond();
        long long63 = week59.getMiddleMillisecond();
        boolean boolean64 = week55.equals((java.lang.Object) long63);
        try {
            int int65 = week37.compareTo((java.lang.Object) week55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 53" + "'", str29.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-60474268800000L) + "'", long38 == (-60474268800000L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 53 + "'", int50 == 53);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Week 35, 53" + "'", str51.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2843L + "'", long56 == 2843L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 53 + "'", int60 == 53);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2844L + "'", long61 == 2844L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-60473966400001L) + "'", long62 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-60473966400001L) + "'", long63 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', 53);
        int int6 = week5.getYearValue();
        java.lang.String str7 = week5.toString();
        java.util.Date date8 = week5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8, timeZone9);
        java.lang.Class<?> wildcardClass11 = date8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass16 = week15.getClass();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.util.Date date22 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass27 = timeZone26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 53" + "'", str7.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getSerialIndex();
//        java.util.Date date5 = week3.getEnd();
//        long long6 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(53, year7);
//        java.lang.Class<?> wildcardClass11 = year7.getClass();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        long long7 = week2.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 35, 53" + "'", str6.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2844L + "'", long7 == 2844L);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass1 = week0.getClass();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str22 = timePeriodFormatException21.toString();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException21.getSuppressed();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str10 = timePeriodFormatException6.toString();
        java.lang.Throwable throwable11 = null;
        try {
            timePeriodFormatException6.addSuppressed(throwable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        long long15 = week2.getLastMillisecond();
        int int16 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60473664000001L) + "'", long15 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass14 = week13.getClass();
//        long long15 = week13.getSerialIndex();
//        int int16 = week2.compareTo((java.lang.Object) week13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1966) + "'", int16 == (-1966));
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        long long29 = week28.getMiddleMillisecond();
        java.lang.String str30 = week28.toString();
        java.util.Calendar calendar31 = null;
        try {
            long long32 = week28.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-60474571200001L) + "'", long29 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 34, 53" + "'", str30.equals("Week 34, 53"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        long long9 = week8.getLastMillisecond();
        int int10 = week8.getYearValue();
        long long11 = week8.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473664000001L) + "'", long9 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-60473966400001L) + "'", long11 == (-60473966400001L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date3 = week2.getStart();
        int int5 = week2.compareTo((java.lang.Object) true);
        long long6 = week2.getLastMillisecond();
        try {
            org.jfree.data.time.Year year7 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (short) 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62165894400000L) + "'", long4 == (-62165894400000L));
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getSerialIndex();
//        java.util.Date date6 = week4.getEnd();
//        long long7 = week4.getMiddleMillisecond();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(9, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(4, year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(0, year8);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        int int20 = week19.getYearValue();
        java.lang.String str21 = week19.toString();
        java.util.Date date22 = week19.getEnd();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date22, timeZone25);
        java.util.Locale locale27 = null;
        try {
            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date11, timeZone25, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 35, 53" + "'", str21.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getSerialIndex();
//        java.util.Date date5 = week3.getEnd();
//        long long6 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(53, year7);
//        int int11 = week10.getYearValue();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        long long15 = week2.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            week2.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60474268800000L) + "'", long15 == (-60474268800000L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 1);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 1" + "'", str3.equals("Week 0, 1"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        boolean boolean4 = week2.equals((java.lang.Object) (-60474571200001L));
        java.lang.String str5 = week2.toString();
        int int6 = week2.getWeek();
        int int7 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str21 = timePeriodFormatException20.toString();
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException27.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str31 = timePeriodFormatException30.toString();
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray32);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 53);
        int int14 = week13.getYearValue();
        java.lang.String str15 = week13.toString();
        java.util.Date date16 = week13.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
        java.util.Date date20 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        java.lang.String str25 = week23.toString();
        java.util.Date date26 = week23.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone27);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16, timeZone27);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date10, timeZone27);
        java.util.Date date32 = week31.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 53" + "'", str15.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getFirstMillisecond();
        int int17 = week14.compareTo((java.lang.Object) 10);
        java.util.Date date18 = week14.getEnd();
        java.util.TimeZone timeZone19 = null;
        try {
            org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60474873600000L) + "'", long15 == (-60474873600000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getSerialIndex();
        long long7 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = regularTimePeriod8.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2844L + "'", long6 == 2844L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2844L + "'", long7 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str14 = timePeriodFormatException13.toString();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException13.getSuppressed();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException13.getSuppressed();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable throwable19 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getWeek();
        int int10 = week6.getYearValue();
        java.lang.String str11 = week6.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        java.util.Date date35 = regularTimePeriod33.getEnd();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', 53);
        int int39 = week38.getYearValue();
        java.lang.String str40 = week38.toString();
        java.util.Date date41 = week38.getEnd();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41, timeZone42);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date35, timeZone42);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        java.lang.Class<?> wildcardClass49 = regularTimePeriod48.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 53);
        int int53 = week52.getYearValue();
        java.lang.String str54 = week52.toString();
        java.util.Date date55 = week52.getEnd();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date55, timeZone56);
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date55, timeZone58);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date35, timeZone58);
        long long61 = week60.getSerialIndex();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        java.lang.Class<?> wildcardClass66 = regularTimePeriod65.getClass();
        java.util.Date date67 = regularTimePeriod65.getEnd();
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) '#', 53);
        int int71 = week70.getYearValue();
        java.lang.String str72 = week70.toString();
        java.util.Date date73 = week70.getEnd();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date73, timeZone74);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date67, timeZone74);
        long long77 = week76.getSerialIndex();
        long long78 = week76.getMiddleMillisecond();
        int int79 = week60.compareTo((java.lang.Object) long78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = week60.next();
        boolean boolean81 = week29.equals((java.lang.Object) regularTimePeriod80);
        int int82 = week29.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 53 + "'", int39 == 53);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 35, 53" + "'", str40.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Week 35, 53" + "'", str54.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2843L + "'", long61 == 2843L);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 53 + "'", int71 == 53);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Week 35, 53" + "'", str72.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 2843L + "'", long77 == 2843L);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-60474571200001L) + "'", long78 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 34 + "'", int82 == 34);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        long long9 = week2.getMiddleMillisecond();
        java.lang.Object obj10 = null;
        boolean boolean11 = week2.equals(obj10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        boolean boolean18 = week14.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date19 = week14.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        java.lang.String str29 = week27.toString();
        java.util.Date date30 = week27.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date30, timeZone33);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date19, timeZone33);
        java.lang.Class<?> wildcardClass36 = timeZone33.getClass();
        boolean boolean37 = week2.equals((java.lang.Object) wildcardClass36);
        int int38 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473966400001L) + "'", long9 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 53" + "'", str29.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        long long17 = week15.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass18 = week15.getClass();
        int int19 = week15.getYearValue();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = week15.getMiddleMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-60474571200001L) + "'", long17 == (-60474571200001L));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        long long12 = week11.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2844L + "'", long12 == 2844L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        long long12 = week2.getLastMillisecond();
        long long13 = week2.getFirstMillisecond();
        int int14 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-60473664000001L) + "'", long12 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getFirstMillisecond();
        int int17 = week14.compareTo((java.lang.Object) 10);
        int int19 = week14.compareTo((java.lang.Object) 53);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        java.util.Date date25 = regularTimePeriod23.getEnd();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        int int29 = week28.getYearValue();
        java.lang.String str30 = week28.toString();
        java.util.Date date31 = week28.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date31, timeZone32);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date25, timeZone32);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        int int43 = week42.getYearValue();
        java.lang.String str44 = week42.toString();
        java.util.Date date45 = week42.getEnd();
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date45, timeZone46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date45, timeZone48);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date25, timeZone48);
        long long51 = week50.getSerialIndex();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
        java.lang.Class<?> wildcardClass56 = regularTimePeriod55.getClass();
        java.util.Date date57 = regularTimePeriod55.getEnd();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) '#', 53);
        int int61 = week60.getYearValue();
        java.lang.String str62 = week60.toString();
        java.util.Date date63 = week60.getEnd();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date57, timeZone64);
        long long67 = week66.getSerialIndex();
        long long68 = week66.getMiddleMillisecond();
        int int69 = week50.compareTo((java.lang.Object) long68);
        boolean boolean70 = week14.equals((java.lang.Object) long68);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60474873600000L) + "'", long15 == (-60474873600000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 35, 53" + "'", str44.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2843L + "'", long51 == 2843L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 53 + "'", int61 == 53);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Week 35, 53" + "'", str62.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2843L + "'", long67 == 2843L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-60474571200001L) + "'", long68 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        long long14 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week2.next();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60473664000001L) + "'", long14 == (-60473664000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        int int17 = week14.getWeek();
        long long18 = week14.getLastMillisecond();
        long long19 = week14.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 34 + "'", int17 == 34);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60474268800001L) + "'", long18 == (-60474268800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-60474268800001L) + "'", long19 == (-60474268800001L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        long long8 = week6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        long long20 = week19.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-60473664000001L) + "'", long20 == (-60473664000001L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Object obj12 = null;
        boolean boolean13 = week10.equals(obj12);
        java.lang.Object obj14 = null;
        int int15 = week10.compareTo(obj14);
        java.util.Date date16 = week10.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.util.Date date22 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone23);
        boolean boolean27 = week2.equals((java.lang.Object) week26);
        java.lang.Class<?> wildcardClass28 = week2.getClass();
        java.util.Calendar calendar29 = null;
        try {
            long long30 = week2.getMiddleMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getSerialIndex();
//        java.util.Date date6 = week4.getEnd();
//        long long7 = week4.getMiddleMillisecond();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) ' ', year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(53, year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 0, year8);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week12.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year8);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getSerialIndex();
//        java.util.Date date6 = week4.getEnd();
//        long long7 = week4.getMiddleMillisecond();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(9, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 1, year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(3, year8);
//        long long13 = week12.getSerialIndex();
//        java.util.Date date14 = week12.getEnd();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107010L + "'", long13 == 107010L);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        java.lang.Class<?> wildcardClass10 = timeZone8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week14.previous();
        java.util.Date date20 = week14.getStart();
        java.lang.Class<?> wildcardClass21 = date20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        int int25 = week24.getYearValue();
        java.lang.String str26 = week24.toString();
        java.util.Date date27 = week24.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date20, timeZone28);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date5, timeZone28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 53 + "'", int25 == 53);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 53" + "'", str26.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod30);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week14.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getWeek();
        java.util.Date date10 = week6.getStart();
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        try {
            org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10, timeZone11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        java.util.Date date21 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        int int25 = week24.getYearValue();
        java.lang.String str26 = week24.toString();
        java.util.Date date27 = week24.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date27, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date21, timeZone28);
        java.util.Locale locale31 = null;
        try {
            org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date5, timeZone28, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 53 + "'", int25 == 53);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 53" + "'", str26.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        java.lang.Object obj3 = null;
        int int4 = week2.compareTo(obj3);
        java.lang.String str5 = week2.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 0, 2" + "'", str5.equals("Week 0, 2"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        java.lang.Class<?> wildcardClass12 = week2.getClass();
        java.util.Date date13 = week2.getEnd();
        try {
            org.jfree.data.time.Year year14 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        int int9 = week2.getYearValue();
        java.lang.String str10 = week2.toString();
        long long11 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2844L + "'", long11 == 2844L);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.util.Date date6 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        long long15 = week2.getLastMillisecond();
        long long16 = week2.getSerialIndex();
        int int17 = week2.getYearValue();
        long long18 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60473664000001L) + "'", long15 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60473664000001L) + "'", long18 == (-60473664000001L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        long long16 = week14.getFirstMillisecond();
        int int17 = week14.getYearValue();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week14.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-60474268800000L) + "'", long16 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date9 = week8.getStart();
        int int11 = week8.compareTo((java.lang.Object) true);
        long long12 = week8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean14 = week2.equals((java.lang.Object) regularTimePeriod13);
        java.util.Date date15 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
        java.util.Date date9 = regularTimePeriod7.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9, timeZone10);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone13);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9);
        java.util.Date date17 = week16.getStart();
        java.util.Date date18 = week16.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass14 = week13.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        boolean boolean16 = week2.equals((java.lang.Object) regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
//        java.lang.String str7 = timePeriodFormatException6.toString();
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        boolean boolean10 = week0.equals((java.lang.Object) timePeriodFormatException4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 6);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61977801600001L) + "'", long3 == (-61977801600001L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        java.lang.Object obj6 = null;
        int int7 = week2.compareTo(obj6);
        int int8 = week2.getWeek();
        java.lang.String str9 = week2.toString();
        long long10 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        java.lang.String str25 = week23.toString();
        java.util.Date date26 = week23.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
        java.util.Date date30 = null;
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        java.lang.String str35 = week33.toString();
        java.util.Date date36 = week33.getEnd();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone37);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date26, timeZone37);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) '#', 53);
        int int44 = week43.getYearValue();
        long long45 = week43.getSerialIndex();
        boolean boolean47 = week43.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date48 = week43.getStart();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.previous();
        java.lang.Class<?> wildcardClass53 = regularTimePeriod52.getClass();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
        int int57 = week56.getYearValue();
        java.lang.String str58 = week56.toString();
        java.util.Date date59 = week56.getEnd();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date59, timeZone60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date59, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date48, timeZone62);
        java.lang.Class<?> wildcardClass65 = timeZone62.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date26, timeZone62);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date5, timeZone62);
        java.util.Calendar calendar68 = null;
        try {
            week67.peg(calendar68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 53 + "'", int44 == 53);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2844L + "'", long45 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 35, 53" + "'", str58.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNull(regularTimePeriod66);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        int int17 = week15.getYearValue();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        int int21 = week20.getYearValue();
        long long22 = week20.getSerialIndex();
        boolean boolean24 = week20.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date25 = week20.getStart();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        int int27 = week15.compareTo((java.lang.Object) date25);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = week15.getMiddleMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2844L + "'", long22 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        int int21 = week19.compareTo((java.lang.Object) (-1));
        long long22 = week19.getFirstMillisecond();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(1, 6);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        java.lang.String str35 = week33.toString();
        java.util.Date date36 = week33.getEnd();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date36, timeZone37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date36, timeZone39);
        java.lang.Class<?> wildcardClass41 = timeZone39.getClass();
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        boolean boolean44 = week25.equals((java.lang.Object) class43);
        boolean boolean45 = week19.equals((java.lang.Object) class43);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-60474268800000L) + "'", long22 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        long long9 = week8.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week8.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473664000001L) + "'", long9 == (-60473664000001L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        int int31 = week29.getWeek();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) '#', 53);
        int int35 = week34.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week34.next();
        long long37 = week34.getMiddleMillisecond();
        int int38 = week34.getWeek();
        long long39 = week34.getFirstMillisecond();
        long long40 = week34.getFirstMillisecond();
        boolean boolean41 = week29.equals((java.lang.Object) week34);
        java.lang.Class<?> wildcardClass42 = week29.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 34 + "'", int31 == 34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 53 + "'", int35 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-60473966400001L) + "'", long37 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 35 + "'", int38 == 35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-60474268800000L) + "'", long39 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-60474268800000L) + "'", long40 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        long long12 = week2.getLastMillisecond();
        long long13 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.previous();
        long long15 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-60473664000001L) + "'", long12 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60474268800000L) + "'", long15 == (-60474268800000L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        long long15 = week2.getLastMillisecond();
        java.lang.String str16 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60473664000001L) + "'", long15 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 53" + "'", str16.equals("Week 35, 53"));
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date9 = week8.getStart();
        int int11 = week8.compareTo((java.lang.Object) true);
        long long12 = week8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean14 = week2.equals((java.lang.Object) regularTimePeriod13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Object obj19 = null;
        boolean boolean20 = week17.equals(obj19);
        int int21 = week17.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.previous();
        java.util.Date date23 = week17.getEnd();
        boolean boolean24 = week2.equals((java.lang.Object) week17);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = week17.getMiddleMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = regularTimePeriod7.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Object obj13 = null;
        boolean boolean14 = week11.equals(obj13);
        java.lang.Object obj15 = null;
        int int16 = week11.compareTo(obj15);
        java.util.Date date17 = week11.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        java.lang.Class<?> wildcardClass22 = regularTimePeriod21.getClass();
        java.util.Date date23 = regularTimePeriod21.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass25 = timeZone24.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date23, timeZone24);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date17, timeZone24);
        java.util.Locale locale28 = null;
        try {
            org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date8, timeZone24, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str9 = timePeriodFormatException8.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str19 = timePeriodFormatException18.toString();
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.String str23 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getSerialIndex();
//        java.util.Date date4 = week2.getEnd();
//        long long5 = week2.getLastMillisecond();
//        java.lang.String str6 = week2.toString();
//        long long7 = week2.getSerialIndex();
//        org.jfree.data.time.Year year8 = week2.getYear();
//        long long9 = year8.getMiddleMillisecond();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(0, year8);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
//        java.util.Date date5 = regularTimePeriod3.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6);
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone9);
//        java.util.Date date11 = week10.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(0, 11);
//        java.util.Date date16 = week15.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
//        java.util.Date date20 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
//        int int24 = week23.getYearValue();
//        java.lang.String str25 = week23.toString();
//        java.util.Date date26 = week23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone27);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 53);
//        int int33 = week32.getYearValue();
//        java.lang.String str34 = week32.toString();
//        java.util.Date date35 = week32.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
//        java.lang.Class<?> wildcardClass42 = regularTimePeriod41.getClass();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', 53);
//        int int46 = week45.getYearValue();
//        java.lang.String str47 = week45.toString();
//        java.util.Date date48 = week45.getEnd();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date48, timeZone51);
//        java.lang.Class<?> wildcardClass53 = timeZone51.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date35, timeZone51);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        long long56 = week55.getSerialIndex();
//        java.util.Date date57 = week55.getEnd();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week60.previous();
//        java.lang.Class<?> wildcardClass62 = regularTimePeriod61.getClass();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week((int) '#', 53);
//        int int66 = week65.getYearValue();
//        java.lang.String str67 = week65.toString();
//        java.util.Date date68 = week65.getEnd();
//        java.util.TimeZone timeZone69 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date68, timeZone69);
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date68, timeZone71);
//        java.lang.Class<?> wildcardClass73 = timeZone71.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date57, timeZone71);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date16, timeZone71);
//        java.util.Locale locale76 = null;
//        try {
//            org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date11, timeZone71, locale76);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 53 + "'", int46 == 53);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Week 35, 53" + "'", str47.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 107031L + "'", long56 == 107031L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 53 + "'", int66 == 53);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Week 35, 53" + "'", str67.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(35, 4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        java.lang.String str25 = week23.toString();
        java.util.Date date26 = week23.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
        java.util.Date date30 = null;
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        java.lang.String str35 = week33.toString();
        java.util.Date date36 = week33.getEnd();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone37);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date26, timeZone37);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) '#', 53);
        int int44 = week43.getYearValue();
        long long45 = week43.getSerialIndex();
        boolean boolean47 = week43.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date48 = week43.getStart();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.previous();
        java.lang.Class<?> wildcardClass53 = regularTimePeriod52.getClass();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
        int int57 = week56.getYearValue();
        java.lang.String str58 = week56.toString();
        java.util.Date date59 = week56.getEnd();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date59, timeZone60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date59, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date48, timeZone62);
        java.lang.Class<?> wildcardClass65 = timeZone62.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date26, timeZone62);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date5, timeZone62);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = week70.previous();
        java.lang.Class<?> wildcardClass72 = regularTimePeriod71.getClass();
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) '#', 53);
        int int76 = week75.getYearValue();
        java.lang.String str77 = week75.toString();
        java.util.Date date78 = week75.getEnd();
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date78, timeZone79);
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date78, timeZone81);
        java.util.Locale locale83 = null;
        try {
            org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date5, timeZone81, locale83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 53 + "'", int44 == 53);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2844L + "'", long45 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 35, 53" + "'", str58.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 53 + "'", int76 == 53);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Week 35, 53" + "'", str77.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(timeZone81);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        java.util.Date date13 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 53);
        int int17 = week16.getYearValue();
        java.lang.String str18 = week16.toString();
        java.util.Date date19 = week16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date13, timeZone20);
        long long23 = week22.getSerialIndex();
        java.util.Date date24 = week22.getEnd();
        java.lang.Class<?> wildcardClass25 = week22.getClass();
        java.util.Date date26 = null;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', 53);
        int int30 = week29.getYearValue();
        long long31 = week29.getSerialIndex();
        boolean boolean33 = week29.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date34 = week29.getStart();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        int int43 = week42.getYearValue();
        java.lang.String str44 = week42.toString();
        java.util.Date date45 = week42.getEnd();
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date45, timeZone46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date45, timeZone48);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date34, timeZone48);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date34);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 53);
        int int55 = week54.getYearValue();
        long long56 = week54.getSerialIndex();
        boolean boolean58 = week54.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date59 = week54.getStart();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
        java.lang.Class<?> wildcardClass64 = regularTimePeriod63.getClass();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) '#', 53);
        int int68 = week67.getYearValue();
        java.lang.String str69 = week67.toString();
        java.util.Date date70 = week67.getEnd();
        java.util.TimeZone timeZone71 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date70, timeZone71);
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date70, timeZone73);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date59, timeZone73);
        java.lang.Class<?> wildcardClass76 = timeZone73.getClass();
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date34, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone73);
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date5, timeZone73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 53" + "'", str18.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2843L + "'", long23 == 2843L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2844L + "'", long31 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 35, 53" + "'", str44.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 53 + "'", int55 == 53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2844L + "'", long56 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 53 + "'", int68 == 53);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Week 35, 53" + "'", str69.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNull(regularTimePeriod78);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        long long6 = week2.getLastMillisecond();
        java.util.Date date7 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473664000001L) + "'", long6 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
        java.util.Date date9 = regularTimePeriod7.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9, timeZone10);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone13);
        java.util.Date date16 = regularTimePeriod15.getStart();
        java.util.Date date17 = regularTimePeriod15.getEnd();
        java.util.Date date18 = regularTimePeriod15.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week14.next();
        boolean boolean21 = week14.equals((java.lang.Object) 0);
        java.util.Date date22 = week14.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 53);
        int int31 = week30.getYearValue();
        java.lang.String str32 = week30.toString();
        java.util.Date date33 = week30.getEnd();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date33, timeZone34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date33, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date22, timeZone36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone36);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 53 + "'", int31 == 53);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 35, 53" + "'", str32.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeZone36);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 6, 10");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int8 = week0.compareTo((java.lang.Object) "hi!");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date5);
        long long32 = week31.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-60474873600000L) + "'", long32 == (-60474873600000L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 1);
//        java.lang.String str3 = week2.toString();
//        java.lang.Class<?> wildcardClass4 = week2.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
//        int int8 = week7.getYearValue();
//        java.lang.String str9 = week7.toString();
//        java.util.Date date10 = week7.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = date10.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        long long16 = week15.getSerialIndex();
//        java.util.Date date17 = week15.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
//        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 53);
//        int int27 = week26.getYearValue();
//        java.lang.String str28 = week26.toString();
//        java.util.Date date29 = week26.getEnd();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date29, timeZone30);
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date29, timeZone32);
//        long long34 = week33.getSerialIndex();
//        java.util.Date date35 = week33.getEnd();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
//        java.lang.Class<?> wildcardClass40 = regularTimePeriod39.getClass();
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 53);
//        int int45 = week44.getYearValue();
//        long long46 = week44.getSerialIndex();
//        java.lang.String str47 = week44.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week44.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week44.next();
//        boolean boolean51 = week44.equals((java.lang.Object) 0);
//        java.util.Date date52 = week44.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date52, timeZone53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date52);
//        int int57 = week55.compareTo((java.lang.Object) (-1));
//        int int58 = week55.getYearValue();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 53);
//        int int62 = week61.getYearValue();
//        java.lang.String str63 = week61.toString();
//        java.util.Date date64 = week61.getEnd();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
//        java.lang.Class<?> wildcardClass69 = regularTimePeriod68.getClass();
//        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week((int) '#', 53);
//        int int74 = week73.getYearValue();
//        long long75 = week73.getSerialIndex();
//        java.lang.String str76 = week73.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = week73.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = week73.next();
//        boolean boolean80 = week73.equals((java.lang.Object) 0);
//        java.util.Date date81 = week73.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date81, timeZone82);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date64, timeZone82);
//        boolean boolean85 = week55.equals((java.lang.Object) timeZone82);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date35, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date17, timeZone82);
//        int int88 = week2.compareTo((java.lang.Object) date17);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 1" + "'", str3.equals("Week 0, 1"));
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 35, 53" + "'", str28.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2844L + "'", long34 == 2844L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 53 + "'", int45 == 53);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2844L + "'", long46 == 2844L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Week 35, 53" + "'", str47.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 53 + "'", int58 == 53);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 53 + "'", int62 == 53);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Week 35, 53" + "'", str63.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(class70);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 53 + "'", int74 == 53);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 2844L + "'", long75 == 2844L);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Week 35, 53" + "'", str76.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getSerialIndex();
        long long7 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        long long9 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2844L + "'", long6 == 2844L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2844L + "'", long7 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473664000001L) + "'", long9 == (-60473664000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getSerialIndex();
//        java.util.Date date4 = week2.getEnd();
//        long long5 = week2.getLastMillisecond();
//        java.lang.String str6 = week2.toString();
//        long long7 = week2.getSerialIndex();
//        org.jfree.data.time.Year year8 = week2.getYear();
//        long long9 = year8.getMiddleMillisecond();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(24, year8);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        int int3 = week2.getWeek();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61852305600001L) + "'", long4 == (-61852305600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61852305600001L) + "'", long6 == (-61852305600001L));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
//        int int7 = week6.getYearValue();
//        java.lang.String str8 = week6.toString();
//        java.util.Date date9 = week6.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.lang.Class<?> wildcardClass12 = date9.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        int int14 = week2.compareTo((java.lang.Object) wildcardClass12);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        long long19 = week18.getSerialIndex();
//        java.util.Date date20 = week18.getEnd();
//        long long21 = week18.getMiddleMillisecond();
//        org.jfree.data.time.Year year22 = week18.getYear();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 10, year22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(5, year22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (byte) 10, year22);
//        int int26 = week2.compareTo((java.lang.Object) (byte) 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 107031L + "'", long19 == 107031L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560365999999L + "'", long21 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        long long7 = week6.getLastMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800001L) + "'", long7 == (-60474268800001L));
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getSerialIndex();
//        java.util.Date date4 = week2.getEnd();
//        long long5 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(10, year6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        java.util.Date date14 = week2.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week14.next();
        boolean boolean21 = week14.equals((java.lang.Object) 0);
        java.util.Date date22 = week14.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date22, timeZone23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date5, timeZone23);
        java.lang.Object obj26 = null;
        boolean boolean27 = week25.equals(obj26);
        java.lang.Class<?> wildcardClass28 = week25.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
        int int32 = week31.getYearValue();
        long long33 = week31.getSerialIndex();
        java.lang.String str34 = week31.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week31.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week31.previous();
        long long37 = week31.getLastMillisecond();
        long long38 = week31.getMiddleMillisecond();
        java.lang.Object obj39 = null;
        boolean boolean40 = week31.equals(obj39);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) '#', 53);
        int int44 = week43.getYearValue();
        long long45 = week43.getSerialIndex();
        boolean boolean47 = week43.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date48 = week43.getStart();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.previous();
        java.lang.Class<?> wildcardClass53 = regularTimePeriod52.getClass();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
        int int57 = week56.getYearValue();
        java.lang.String str58 = week56.toString();
        java.util.Date date59 = week56.getEnd();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date59, timeZone60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date59, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date48, timeZone62);
        java.lang.Class<?> wildcardClass65 = timeZone62.getClass();
        boolean boolean66 = week31.equals((java.lang.Object) wildcardClass65);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week69.previous();
        java.lang.Object obj71 = null;
        boolean boolean72 = week69.equals(obj71);
        int int73 = week69.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = week69.previous();
        java.util.Date date75 = week69.getEnd();
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) '#', 53);
        int int79 = week78.getYearValue();
        java.lang.String str80 = week78.toString();
        java.util.Date date81 = week78.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException83 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass84 = timePeriodFormatException83.getClass();
        java.util.Date date85 = null;
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week((int) '#', 53);
        int int89 = week88.getYearValue();
        java.lang.String str90 = week88.toString();
        java.util.Date date91 = week88.getEnd();
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date91, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass84, date85, timeZone92);
        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date81, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date75, timeZone92);
        boolean boolean97 = week25.equals((java.lang.Object) timeZone92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2844L + "'", long33 == 2844L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-60473664000001L) + "'", long37 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-60473966400001L) + "'", long38 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 53 + "'", int44 == 53);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2844L + "'", long45 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 35, 53" + "'", str58.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 35 + "'", int73 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 53 + "'", int79 == 53);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "Week 35, 53" + "'", str80.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 53 + "'", int89 == 53);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "Week 35, 53" + "'", str90.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertNull(regularTimePeriod96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week14.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (-1));
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 44L + "'", long3 == 44L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        int int21 = week19.compareTo((java.lang.Object) (-1));
        int int22 = week19.getYearValue();
        long long23 = week19.getLastMillisecond();
        int int24 = week19.getYearValue();
        java.util.Date date25 = week19.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60473664000001L) + "'", long23 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        long long3 = week2.getSerialIndex();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 2019);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        int int17 = week14.getWeek();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        int int21 = week20.getYearValue();
        long long22 = week20.getSerialIndex();
        java.lang.String str23 = week20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week20.next();
        boolean boolean27 = week20.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week20.next();
        java.lang.Object obj29 = null;
        boolean boolean30 = week20.equals(obj29);
        long long31 = week20.getFirstMillisecond();
        long long32 = week20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week20.next();
        boolean boolean35 = week14.equals((java.lang.Object) regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 34 + "'", int17 == 34);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2844L + "'", long22 == 2844L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 35, 53" + "'", str23.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60474268800000L) + "'", long31 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-60473664000001L) + "'", long32 == (-60473664000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getEnd();
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61852003200001L) + "'", long5 == (-61852003200001L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str10 = week9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        boolean boolean12 = week2.equals((java.lang.Object) week9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week9.next();
        int int14 = week9.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473966400001L) + "'", long6 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 1, 32" + "'", str10.equals("Week 1, 32"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        java.lang.Object obj36 = null;
        boolean boolean37 = week34.equals(obj36);
        int int38 = week34.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week34.previous();
        java.util.Date date40 = week34.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week34.previous();
        java.lang.Class<?> wildcardClass42 = week34.getClass();
        java.lang.String str43 = week34.toString();
        boolean boolean44 = week30.equals((java.lang.Object) week34);
        java.util.Calendar calendar45 = null;
        try {
            long long46 = week30.getMiddleMillisecond(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 35 + "'", int38 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 35, 53" + "'", str43.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        long long7 = week6.getLastMillisecond();
        java.util.Date date8 = week6.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800001L) + "'", long7 == (-60474268800001L));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 0);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getLastMillisecond();
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        int int14 = week2.getYearValue();
        java.util.Date date15 = week2.getEnd();
        java.util.Date date16 = week2.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        long long16 = week14.getFirstMillisecond();
        int int17 = week14.getYearValue();
        java.util.Calendar calendar18 = null;
        try {
            week14.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-60474268800000L) + "'", long16 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date5);
        java.lang.Class<?> wildcardClass30 = week29.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (-1966));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        int int9 = week2.getYearValue();
        java.util.Date date10 = week2.getEnd();
        java.util.Date date11 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getLastMillisecond();
        java.util.Date date32 = week30.getEnd();
        long long33 = week30.getSerialIndex();
        long long34 = week30.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60474268800001L) + "'", long31 == (-60474268800001L));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2843L + "'", long33 == 2843L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-60474268800001L) + "'", long34 == (-60474268800001L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = regularTimePeriod4.getMiddleMillisecond();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod4.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62135956800001L) + "'", long5 == (-62135956800001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.String str4 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 4, 0" + "'", str4.equals("Week 4, 0"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str22 = timePeriodFormatException21.toString();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException21.getSuppressed();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str27 = timePeriodFormatException6.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        int int6 = week2.getWeek();
        int int7 = week2.getYearValue();
        java.util.Calendar calendar8 = null;
        try {
            week2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        java.lang.Object obj6 = null;
        int int7 = week2.compareTo(obj6);
        int int8 = week2.getWeek();
        java.lang.String str9 = week2.toString();
        int int10 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, 53);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 1, 32");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getSerialIndex();
//        java.util.Date date5 = week3.getEnd();
//        long long6 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 100, year7);
//        long long11 = week10.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1606636799999L + "'", long11 == 1606636799999L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str8 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException1.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        java.lang.String str4 = week2.toString();
//        long long5 = week2.getLastMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass7 = week6.getClass();
//        int int8 = week2.compareTo((java.lang.Object) week6);
//        java.lang.String str9 = week6.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1966) + "'", int8 == (-1966));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Object obj12 = null;
        boolean boolean13 = week10.equals(obj12);
        java.lang.Object obj14 = null;
        int int15 = week10.compareTo(obj14);
        java.util.Date date16 = week10.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.util.Date date22 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone23);
        boolean boolean27 = week2.equals((java.lang.Object) week26);
        long long28 = week26.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-60473664000001L) + "'", long28 == (-60473664000001L));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        long long15 = week2.getLastMillisecond();
        long long16 = week2.getSerialIndex();
        int int17 = week2.getYearValue();
        long long18 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60473664000001L) + "'", long15 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60473966400001L) + "'", long18 == (-60473966400001L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException33.getClass();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException33.getSuppressed();
        java.lang.Class<?> wildcardClass36 = timePeriodFormatException33.getClass();
        boolean boolean37 = week31.equals((java.lang.Object) timePeriodFormatException33);
        java.util.Calendar calendar38 = null;
        try {
            long long39 = week31.getMiddleMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        java.lang.String str8 = week6.toString();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        java.lang.Class<?> wildcardClass12 = date9.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        int int14 = week2.compareTo((java.lang.Object) wildcardClass12);
        long long15 = week2.getMiddleMillisecond();
        long long16 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62136561600001L) + "'", long15 == (-62136561600001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62136259200001L) + "'", long16 == (-62136259200001L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        int int3 = week2.getWeek();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getSerialIndex();
//        java.util.Date date6 = week4.getEnd();
//        long long7 = week4.getMiddleMillisecond();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) ' ', year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(53, year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(24, year8);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        java.lang.String str8 = week6.toString();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        java.lang.Class<?> wildcardClass12 = date9.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        int int14 = week2.compareTo((java.lang.Object) wildcardClass12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        long long25 = week23.getSerialIndex();
        java.lang.String str26 = week23.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week23.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week23.next();
        boolean boolean30 = week23.equals((java.lang.Object) 0);
        java.util.Date date31 = week23.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date31, timeZone32);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str37 = week36.toString();
        int int38 = week36.getYearValue();
        java.util.Date date39 = week36.getEnd();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        int int43 = week42.getYearValue();
        long long44 = week42.getSerialIndex();
        java.lang.String str45 = week42.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week42.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week42.next();
        boolean boolean49 = week42.equals((java.lang.Object) 0);
        java.util.Date date50 = week42.getEnd();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.previous();
        java.lang.Class<?> wildcardClass55 = regularTimePeriod54.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) '#', 53);
        int int59 = week58.getYearValue();
        java.lang.String str60 = week58.toString();
        java.util.Date date61 = week58.getEnd();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date61, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date50, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date39, timeZone64);
        java.lang.Class<?> wildcardClass68 = timeZone64.getClass();
        boolean boolean69 = week2.equals((java.lang.Object) timeZone64);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2844L + "'", long25 == 2844L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 53" + "'", str26.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 1, 32" + "'", str37.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 32 + "'", int38 == 32);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2844L + "'", long44 == 2844L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 35, 53" + "'", str45.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 53 + "'", int59 == 53);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Week 35, 53" + "'", str60.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 11);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException33.getClass();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException33.getSuppressed();
        java.lang.Class<?> wildcardClass36 = timePeriodFormatException33.getClass();
        boolean boolean37 = week31.equals((java.lang.Object) timePeriodFormatException33);
        java.lang.Class<?> wildcardClass38 = week31.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        long long9 = week2.getMiddleMillisecond();
        java.lang.Object obj10 = null;
        boolean boolean11 = week2.equals(obj10);
        java.util.Calendar calendar12 = null;
        try {
            week2.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473966400001L) + "'", long9 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Date date33 = week30.getEnd();
        long long34 = week30.getSerialIndex();
        long long35 = week30.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2843L + "'", long34 == 2843L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2843L + "'", long35 == 2843L);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getSerialIndex();
//        java.util.Date date5 = week3.getEnd();
//        long long6 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(5, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 10, year7);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = week10.equals(obj11);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 53);
        int int19 = week18.getYearValue();
        java.lang.String str20 = week18.toString();
        java.util.Date date21 = week18.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date21, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date10, timeZone24);
        long long27 = week26.getSerialIndex();
        int int28 = week26.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2844L + "'", long27 == 2844L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 35 + "'", int28 == 35);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getFirstMillisecond();
        java.lang.String str9 = week2.toString();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60474268800000L) + "'", long8 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getSerialIndex();
//        java.util.Date date7 = week5.getEnd();
//        long long8 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = week5.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(4, year9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (byte) 100, year9);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(2019, year9);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        int int14 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week2.next();
        java.lang.String str16 = week2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 53" + "'", str16.equals("Week 35, 53"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 35);
        long long3 = week2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61063041600001L) + "'", long3 == (-61063041600001L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        java.lang.String str7 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable throwable10 = null;
        try {
            timePeriodFormatException3.addSuppressed(throwable10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.String str22 = timePeriodFormatException7.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
        java.util.Date date14 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        java.lang.String str19 = week17.toString();
        java.util.Date date20 = week17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date10, timeZone21);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        long long29 = week27.getSerialIndex();
        boolean boolean31 = week27.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date32 = week27.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = regularTimePeriod36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date43, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date32, timeZone46);
        java.lang.Class<?> wildcardClass49 = timeZone46.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date10, timeZone46);
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date51, timeZone52);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 35, 53" + "'", str19.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2844L + "'", long29 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNull(regularTimePeriod53);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week14.next();
        boolean boolean21 = week14.equals((java.lang.Object) 0);
        java.util.Date date22 = week14.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date22, timeZone23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date5, timeZone23);
        long long26 = week25.getSerialIndex();
        try {
            org.jfree.data.time.Year year27 = week25.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2844L + "'", long26 == 2844L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        long long6 = week2.getLastMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) (-1L));
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 53);
        int int14 = week13.getYearValue();
        java.lang.String str15 = week13.toString();
        java.util.Date date16 = week13.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
        java.util.Date date20 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        java.lang.String str25 = week23.toString();
        java.util.Date date26 = week23.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone27);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16, timeZone27);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        java.lang.Class<?> wildcardClass35 = regularTimePeriod34.getClass();
        java.util.Date date36 = regularTimePeriod34.getEnd();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) '#', 53);
        int int40 = week39.getYearValue();
        java.lang.String str41 = week39.toString();
        java.util.Date date42 = week39.getEnd();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date42, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date36, timeZone43);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
        java.lang.Class<?> wildcardClass50 = regularTimePeriod49.getClass();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
        int int54 = week53.getYearValue();
        java.lang.String str55 = week53.toString();
        java.util.Date date56 = week53.getEnd();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date56, timeZone57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date56, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date36, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone59);
        int int63 = week2.compareTo((java.lang.Object) wildcardClass10);
        java.util.Calendar calendar64 = null;
        try {
            long long65 = week2.getLastMillisecond(calendar64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473664000001L) + "'", long6 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 53" + "'", str15.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 53 + "'", int40 == 53);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Week 35, 53" + "'", str41.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 53 + "'", int54 == 53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 35, 53" + "'", str55.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getWeek();
        java.util.Date date10 = week6.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getYearValue();
        long long6 = week2.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2844L + "'", long6 == 2844L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        int int4 = week3.getYearValue();
        long long5 = week3.getSerialIndex();
        java.lang.String str6 = week3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week3.next();
        boolean boolean10 = week3.equals((java.lang.Object) 0);
        java.util.Date date11 = week3.getEnd();
        java.lang.Class<?> wildcardClass12 = date11.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        java.lang.Class<?> wildcardClass18 = regularTimePeriod17.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 53);
        int int22 = week21.getYearValue();
        java.lang.String str23 = week21.toString();
        java.util.Date date24 = week21.getEnd();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date24, timeZone25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date24, timeZone27);
        java.lang.Class<?> wildcardClass29 = timeZone27.getClass();
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str34 = week33.toString();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        int int38 = week37.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week37.next();
        int int40 = week37.getYearValue();
        boolean boolean41 = week33.equals((java.lang.Object) int40);
        java.util.Date date42 = week33.getEnd();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.previous();
        java.lang.Class<?> wildcardClass47 = regularTimePeriod46.getClass();
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 53);
        int int52 = week51.getYearValue();
        long long53 = week51.getSerialIndex();
        java.lang.String str54 = week51.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week51.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week51.next();
        boolean boolean58 = week51.equals((java.lang.Object) 0);
        java.util.Date date59 = week51.getEnd();
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date59, timeZone60);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date59);
        int int64 = week62.compareTo((java.lang.Object) (-1));
        int int65 = week62.getYearValue();
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((int) '#', 53);
        int int69 = week68.getYearValue();
        java.lang.String str70 = week68.toString();
        java.util.Date date71 = week68.getEnd();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = week74.previous();
        java.lang.Class<?> wildcardClass76 = regularTimePeriod75.getClass();
        java.lang.Class class77 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass76);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week((int) '#', 53);
        int int81 = week80.getYearValue();
        long long82 = week80.getSerialIndex();
        java.lang.String str83 = week80.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = week80.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = week80.next();
        boolean boolean87 = week80.equals((java.lang.Object) 0);
        java.util.Date date88 = week80.getEnd();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date88, timeZone89);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date71, timeZone89);
        boolean boolean92 = week62.equals((java.lang.Object) timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date42, timeZone89);
        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date11, timeZone89);
        java.util.Locale locale95 = null;
        try {
            org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date0, timeZone89, locale95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2844L + "'", long5 == 2844L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 35, 53" + "'", str6.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 35, 53" + "'", str23.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 53 + "'", int40 == 53);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 53 + "'", int52 == 53);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2844L + "'", long53 == 2844L);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Week 35, 53" + "'", str54.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 53 + "'", int65 == 53);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 53 + "'", int69 == 53);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 35, 53" + "'", str70.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(class77);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 53 + "'", int81 == 53);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 2844L + "'", long82 == 2844L);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "Week 35, 53" + "'", str83.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNull(regularTimePeriod93);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 9, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        java.lang.Class<?> wildcardClass19 = timeZone17.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 530L + "'", long4 == 530L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        long long15 = week2.getLastMillisecond();
        long long16 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week2.previous();
        long long18 = regularTimePeriod17.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60473664000001L) + "'", long15 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60474571200001L) + "'", long18 == (-60474571200001L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException7.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException13.getClass();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException13.getSuppressed();
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException13.getClass();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        int int13 = week2.getWeek();
//        java.lang.Class<?> wildcardClass14 = week2.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
//        int int18 = week17.getYearValue();
//        long long19 = week17.getSerialIndex();
//        java.lang.String str20 = week17.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.previous();
//        java.util.Date date23 = week17.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week17.next();
//        long long25 = week17.getFirstMillisecond();
//        try {
//            int int26 = week2.compareTo((java.lang.Object) week17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-60474268800000L) + "'", long25 == (-60474268800000L));
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        java.lang.String str6 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        int int21 = week19.compareTo((java.lang.Object) (-1));
        int int22 = week19.getWeek();
        java.lang.String str23 = week19.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 35, 53" + "'", str23.equals("Week 35, 53"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        java.lang.Class<?> wildcardClass14 = regularTimePeriod13.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 53);
        int int19 = week18.getYearValue();
        long long20 = week18.getSerialIndex();
        java.lang.String str21 = week18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week18.next();
        boolean boolean25 = week18.equals((java.lang.Object) 0);
        java.util.Date date26 = week18.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date26, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date6, timeZone27);
        try {
            org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date0, timeZone27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2844L + "'", long20 == 2844L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 35, 53" + "'", str21.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = week2.equals(obj3);
        java.util.Date date5 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        int int5 = week0.getYearValue();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 6, 10");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str14 = timePeriodFormatException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Object obj12 = null;
        boolean boolean13 = week10.equals(obj12);
        java.lang.Object obj14 = null;
        int int15 = week10.compareTo(obj14);
        java.util.Date date16 = week10.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.util.Date date22 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone23);
        boolean boolean27 = week2.equals((java.lang.Object) week26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week26.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        int int12 = week11.getYearValue();
        long long13 = week11.getSerialIndex();
        java.lang.String str14 = week11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week11.next();
        boolean boolean18 = week11.equals((java.lang.Object) 0);
        java.util.Date date19 = week11.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass28 = timePeriodFormatException27.getClass();
        java.util.Date date29 = null;
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 53);
        int int33 = week32.getYearValue();
        java.lang.String str34 = week32.toString();
        java.util.Date date35 = week32.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date25, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date19, timeZone36);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date8, timeZone36);
        int int42 = week41.getYearValue();
        long long43 = week41.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2844L + "'", long13 == 2844L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 53 + "'", int42 == 53);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2844L + "'", long43 == 2844L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, 0);
        java.lang.Object obj8 = null;
        boolean boolean9 = week7.equals(obj8);
        int int10 = week2.compareTo(obj8);
        long long11 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61848374400001L) + "'", long11 == (-61848374400001L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        long long8 = week7.getSerialIndex();
        long long9 = week7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2844L + "'", long8 == 2844L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2844L + "'", long9 == 2844L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        int int4 = week3.getYearValue();
        long long5 = week3.getSerialIndex();
        boolean boolean7 = week3.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date8 = week3.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 53);
        int int17 = week16.getYearValue();
        java.lang.String str18 = week16.toString();
        java.util.Date date19 = week16.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date19, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date8, timeZone22);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        long long29 = week27.getSerialIndex();
        java.lang.String str30 = week27.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week27.previous();
        long long33 = week27.getLastMillisecond();
        long long34 = week27.getMiddleMillisecond();
        java.lang.Object obj35 = null;
        boolean boolean36 = week27.equals(obj35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) '#', 53);
        int int40 = week39.getYearValue();
        long long41 = week39.getSerialIndex();
        boolean boolean43 = week39.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date44 = week39.getStart();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        java.lang.Class<?> wildcardClass49 = regularTimePeriod48.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 53);
        int int53 = week52.getYearValue();
        java.lang.String str54 = week52.toString();
        java.util.Date date55 = week52.getEnd();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date55, timeZone56);
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date55, timeZone58);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date44, timeZone58);
        java.lang.Class<?> wildcardClass61 = timeZone58.getClass();
        boolean boolean62 = week27.equals((java.lang.Object) wildcardClass61);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week65.previous();
        java.lang.Object obj67 = null;
        boolean boolean68 = week65.equals(obj67);
        int int69 = week65.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week65.previous();
        java.util.Date date71 = week65.getEnd();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) '#', 53);
        int int75 = week74.getYearValue();
        java.lang.String str76 = week74.toString();
        java.util.Date date77 = week74.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException79 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass80 = timePeriodFormatException79.getClass();
        java.util.Date date81 = null;
        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week((int) '#', 53);
        int int85 = week84.getYearValue();
        java.lang.String str86 = week84.toString();
        java.util.Date date87 = week84.getEnd();
        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date87, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date81, timeZone88);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date77, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date71, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone88);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2844L + "'", long5 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 53" + "'", str18.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2844L + "'", long29 == 2844L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-60473664000001L) + "'", long33 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-60473966400001L) + "'", long34 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 53 + "'", int40 == 53);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2844L + "'", long41 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Week 35, 53" + "'", str54.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 35 + "'", int69 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 53 + "'", int75 == 53);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Week 35, 53" + "'", str76.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 53 + "'", int85 == 53);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "Week 35, 53" + "'", str86.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(timeZone88);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNull(regularTimePeriod92);
        org.junit.Assert.assertNull(regularTimePeriod93);
    }
}

