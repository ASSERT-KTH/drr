import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(35, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable throwable3 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        int int13 = week12.getYearValue();
        java.lang.String str14 = week12.toString();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone16);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        long long24 = week22.getSerialIndex();
        java.lang.String str25 = week22.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week22.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week22.next();
        boolean boolean29 = week22.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week22.next();
        try {
            int int31 = week19.compareTo((java.lang.Object) week22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2844L + "'", long24 == 2844L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException2.getClass();
        java.util.Date date4 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone11);
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date0, timeZone11, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = regularTimePeriod6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 5);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        int int10 = week9.getYearValue();
        long long11 = week9.getSerialIndex();
        java.lang.String str12 = week9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week9.next();
        boolean boolean16 = week9.equals((java.lang.Object) 0);
        java.util.Date date17 = week9.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date17, timeZone18);
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date0, timeZone18, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2844L + "'", long11 == 2844L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 53" + "'", str12.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        int int10 = week9.getYearValue();
        long long11 = week9.getSerialIndex();
        java.lang.String str12 = week9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week9.next();
        boolean boolean16 = week9.equals((java.lang.Object) 0);
        java.util.Date date17 = week9.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date17, timeZone18);
        try {
            org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date0, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2844L + "'", long11 == 2844L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 53" + "'", str12.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        try {
            java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        int int4 = week3.getYearValue();
        long long5 = week3.getSerialIndex();
        boolean boolean7 = week3.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date8 = week3.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 53);
        int int17 = week16.getYearValue();
        java.lang.String str18 = week16.toString();
        java.util.Date date19 = week16.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date19, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date8, timeZone22);
        java.util.Locale locale25 = null;
        try {
            org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date0, timeZone22, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2844L + "'", long5 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 53" + "'", str18.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeZone22);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        java.lang.String str16 = week14.toString();
        java.util.Date date17 = week14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date11, timeZone18, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 53" + "'", str16.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar9 = null;
        try {
            week8.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        int int3 = week2.getWeek();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        java.util.Calendar calendar13 = null;
//        try {
//            week2.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        int int8 = week2.getYearValue();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        int int12 = week11.getYearValue();
        long long13 = week11.getSerialIndex();
        boolean boolean15 = week11.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date16 = week11.getStart();
        java.lang.String str17 = week11.toString();
        try {
            int int18 = week2.compareTo((java.lang.Object) week11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2844L + "'", long13 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass16 = timeZone15.getClass();
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date5, timeZone15, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        try {
            org.jfree.data.time.Year year17 = week14.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            week2.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        try {
            java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        java.lang.String str8 = week2.toString();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        java.lang.Class<?> wildcardClass3 = timeZone1.getClass();
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date0, timeZone1, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        java.util.Date date8 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.util.Date date4 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 35, 53");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getLastMillisecond();
        int int32 = week30.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60474268800001L) + "'", long31 == (-60474268800001L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 34 + "'", int32 == 34);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = week30.getLastMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        java.lang.Class<?> wildcardClass14 = regularTimePeriod13.getClass();
        java.util.Date date15 = regularTimePeriod13.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        long long17 = week16.getLastMillisecond();
        try {
            int int18 = week2.compareTo((java.lang.Object) week16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-60474268800001L) + "'", long17 == (-60474268800001L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date18, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21);
        java.util.Calendar calendar24 = null;
        try {
            week23.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        java.util.Date date20 = regularTimePeriod18.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date20, timeZone21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date20, timeZone24);
        java.util.Locale locale26 = null;
        try {
            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date10, timeZone24, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeZone24);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60474268800000L) + "'", long8 == (-60474268800000L));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        long long16 = week14.getMiddleMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week14.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-60474571200001L) + "'", long16 == (-60474571200001L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str11 = week10.toString();
        int int12 = week10.getWeek();
        java.lang.String str13 = week10.toString();
        try {
            int int14 = week2.compareTo((java.lang.Object) week10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 53" + "'", str13.equals("Week 35, 53"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        long long6 = week2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473664000001L) + "'", long6 == (-60473664000001L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        java.util.Calendar calendar31 = null;
        try {
            week30.peg(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date12, timeZone19);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', 53);
        int int30 = week29.getYearValue();
        java.lang.String str31 = week29.toString();
        java.util.Date date32 = week29.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date12, timeZone35);
        java.lang.Class<?> wildcardClass38 = timeZone35.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date5, timeZone35);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        int int43 = week42.getYearValue();
        java.lang.String str44 = week42.toString();
        java.util.Date date45 = week42.getEnd();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
        java.lang.Class<?> wildcardClass48 = date45.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        int int50 = week39.compareTo((java.lang.Object) wildcardClass48);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 35, 53" + "'", str31.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 35, 53" + "'", str44.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date3 = week2.getStart();
        int int5 = week2.compareTo((java.lang.Object) true);
        long long6 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = regularTimePeriod7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        try {
            org.jfree.data.time.Year year11 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Calendar calendar33 = null;
        try {
            week30.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass6 = throwableArray5.getClass();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week2.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(34, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        long long14 = week2.getLastMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week2.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60473664000001L) + "'", long14 == (-60473664000001L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        java.lang.Class<?> wildcardClass6 = regularTimePeriod3.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = regularTimePeriod7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable throwable3 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getFirstMillisecond();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
//        java.lang.String str7 = week6.toString();
//        int int8 = week6.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        try {
//            int int10 = week0.compareTo((java.lang.Object) regularTimePeriod9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 53" + "'", str7.equals("Week 35, 53"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        java.lang.Object obj6 = null;
        int int7 = week2.compareTo(obj6);
        int int8 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        java.util.Calendar calendar16 = null;
        try {
            week14.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Object obj11 = null;
        boolean boolean12 = week9.equals(obj11);
        java.lang.Object obj13 = null;
        int int14 = week9.compareTo(obj13);
        java.util.Date date15 = week9.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        java.util.Date date21 = regularTimePeriod19.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date15, timeZone22);
        java.util.Locale locale26 = null;
        try {
            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date5, timeZone22, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date5, timeZone6, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        int int10 = week9.getYearValue();
        java.lang.String str11 = week9.toString();
        java.util.Date date12 = week9.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
        java.util.Date date16 = null;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        int int20 = week19.getYearValue();
        java.lang.String str21 = week19.toString();
        java.util.Date date22 = week19.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date12, timeZone23);
        try {
            int int27 = week2.compareTo((java.lang.Object) week26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 35, 53" + "'", str21.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod25);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date12, timeZone19);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', 53);
        int int30 = week29.getYearValue();
        java.lang.String str31 = week29.toString();
        java.util.Date date32 = week29.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date12, timeZone35);
        java.lang.Class<?> wildcardClass38 = timeZone35.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date5, timeZone35);
        java.util.Calendar calendar40 = null;
        try {
            week39.peg(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 35, 53" + "'", str31.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getLastMillisecond();
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        int int12 = week11.getYearValue();
        java.lang.String str13 = week11.toString();
        java.util.Date date14 = week11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date8, timeZone15, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 53" + "'", str13.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Object obj12 = null;
        boolean boolean13 = week10.equals(obj12);
        java.lang.Object obj14 = null;
        int int15 = week10.compareTo(obj14);
        java.util.Date date16 = week10.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.util.Date date22 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone23);
        java.util.Locale locale27 = null;
        try {
            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone23, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getStart();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone10);
        try {
            org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date0, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException2.getClass();
        java.util.Date date4 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone11);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 53);
        int int17 = week16.getYearValue();
        java.lang.String str18 = week16.toString();
        java.util.Date date19 = week16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', 53);
        int int30 = week29.getYearValue();
        java.lang.String str31 = week29.toString();
        java.util.Date date32 = week29.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date32, timeZone35);
        java.lang.Class<?> wildcardClass37 = timeZone35.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date19, timeZone35);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        int int43 = week42.getYearValue();
        long long44 = week42.getSerialIndex();
        boolean boolean46 = week42.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date47 = week42.getStart();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
        java.lang.Class<?> wildcardClass52 = regularTimePeriod51.getClass();
        java.util.Date date53 = regularTimePeriod51.getEnd();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
        int int57 = week56.getYearValue();
        java.lang.String str58 = week56.toString();
        java.util.Date date59 = week56.getEnd();
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date59, timeZone60);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date53, timeZone60);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week65.previous();
        java.lang.Class<?> wildcardClass67 = regularTimePeriod66.getClass();
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) '#', 53);
        int int71 = week70.getYearValue();
        java.lang.String str72 = week70.toString();
        java.util.Date date73 = week70.getEnd();
        java.util.TimeZone timeZone74 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date73, timeZone74);
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date73, timeZone76);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date53, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date47, timeZone76);
        try {
            org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date0, timeZone76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 53" + "'", str18.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 35, 53" + "'", str31.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2844L + "'", long44 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 35, 53" + "'", str58.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 53 + "'", int71 == 53);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Week 35, 53" + "'", str72.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod79);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week2.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getLastMillisecond();
        java.util.Date date32 = week30.getEnd();
        java.util.Calendar calendar33 = null;
        try {
            week30.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60474268800001L) + "'", long31 == (-60474268800001L));
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        int int20 = week19.getYearValue();
        java.lang.String str21 = week19.toString();
        java.util.Date date22 = week19.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
        int int32 = week31.getYearValue();
        long long33 = week31.getSerialIndex();
        java.lang.String str34 = week31.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week31.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week31.next();
        boolean boolean38 = week31.equals((java.lang.Object) 0);
        java.util.Date date39 = week31.getEnd();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date39, timeZone40);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date22, timeZone40);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.previous();
        java.lang.Class<?> wildcardClass47 = regularTimePeriod46.getClass();
        java.util.Date date48 = regularTimePeriod46.getEnd();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 53);
        int int52 = week51.getYearValue();
        java.lang.String str53 = week51.toString();
        java.util.Date date54 = week51.getEnd();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date48, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone55);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        java.util.Date date64 = regularTimePeriod62.getEnd();
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date64);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date64);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = week70.previous();
        java.lang.Class<?> wildcardClass72 = regularTimePeriod71.getClass();
        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass72);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week((int) '#', 53);
        int int77 = week76.getYearValue();
        long long78 = week76.getSerialIndex();
        java.lang.String str79 = week76.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = week76.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = week76.next();
        boolean boolean83 = week76.equals((java.lang.Object) 0);
        java.util.Date date84 = week76.getEnd();
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class73, date84, timeZone85);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date64, timeZone85);
        java.util.Locale locale88 = null;
        try {
            org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date22, timeZone85, locale88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 35, 53" + "'", str21.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2844L + "'", long33 == 2844L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 53 + "'", int52 == 53);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Week 35, 53" + "'", str53.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(class73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 53 + "'", int77 == 53);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 2844L + "'", long78 == 2844L);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "Week 35, 53" + "'", str79.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        long long29 = week28.getMiddleMillisecond();
        long long30 = week28.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-60474571200001L) + "'", long29 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60474873600000L) + "'", long30 == (-60474873600000L));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (short) 0);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62165289600001L) + "'", long3 == (-62165289600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62165894400000L) + "'", long4 == (-62165894400000L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (short) 0);
        java.lang.String str3 = week2.toString();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 4, 0" + "'", str3.equals("Week 4, 0"));
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            week0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        java.lang.String str8 = week2.toString();
        long long9 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2844L + "'", long9 == 2844L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Object obj21 = null;
        boolean boolean22 = week19.equals(obj21);
        java.lang.Object obj23 = null;
        int int24 = week19.compareTo(obj23);
        java.util.Date date25 = week19.getStart();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
        java.util.Date date31 = regularTimePeriod29.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass33 = timeZone32.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date31, timeZone32);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date25, timeZone32);
        java.util.Locale locale36 = null;
        try {
            org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date16, timeZone32, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2844L + "'", long6 == 2844L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        java.lang.String str16 = week15.toString();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week15.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 34, 53" + "'", str16.equals("Week 34, 53"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        long long9 = week7.getSerialIndex();
        java.lang.String str10 = week7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week7.next();
        boolean boolean14 = week7.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week7.next();
        java.lang.Object obj16 = null;
        boolean boolean17 = week7.equals(obj16);
        boolean boolean18 = week2.equals(obj16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2844L + "'", long9 == 2844L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date18, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7);
        java.util.Calendar calendar25 = null;
        try {
            week24.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        long long9 = week7.getSerialIndex();
        java.lang.String str10 = week7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week7.next();
        boolean boolean14 = week7.equals((java.lang.Object) 0);
        java.util.Date date15 = week7.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date15, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        java.lang.Class<?> wildcardClass22 = regularTimePeriod21.getClass();
        java.util.Date date23 = regularTimePeriod21.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        java.util.Date date30 = regularTimePeriod28.getEnd();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        java.lang.String str35 = week33.toString();
        java.util.Date date36 = week33.getEnd();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date36, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date30, timeZone37);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 53);
        int int48 = week47.getYearValue();
        java.lang.String str49 = week47.toString();
        java.util.Date date50 = week47.getEnd();
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date50, timeZone51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date50, timeZone53);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date30, timeZone53);
        java.lang.Class<?> wildcardClass56 = timeZone53.getClass();
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date23, timeZone53);
        java.util.Locale locale58 = null;
        try {
            org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date15, timeZone53, locale58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2844L + "'", long9 == 2844L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 53 + "'", int48 == 53);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Week 35, 53" + "'", str49.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Date date33 = week30.getEnd();
        long long34 = week30.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-60474571200001L) + "'", long34 == (-60474571200001L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        boolean boolean18 = week14.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date19 = week14.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        java.lang.String str29 = week27.toString();
        java.util.Date date30 = week27.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date30, timeZone33);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date19, timeZone33);
        java.lang.Class<?> wildcardClass36 = timeZone33.getClass();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date11, timeZone33);
        java.util.Calendar calendar38 = null;
        try {
            week37.peg(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 53" + "'", str29.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        java.lang.String str15 = week14.toString();
        java.util.Calendar calendar16 = null;
        try {
            week14.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 34, 53" + "'", str15.equals("Week 34, 53"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week14.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        java.lang.String str8 = week6.toString();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone10);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        int int29 = week28.getYearValue();
        java.lang.String str30 = week28.toString();
        java.util.Date date31 = week28.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date31, timeZone34);
        java.lang.Class<?> wildcardClass36 = timeZone34.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone34);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 53);
        int int42 = week41.getYearValue();
        java.lang.String str43 = week41.toString();
        java.util.Date date44 = week41.getEnd();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        java.lang.Class<?> wildcardClass49 = regularTimePeriod48.getClass();
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
        int int54 = week53.getYearValue();
        long long55 = week53.getSerialIndex();
        java.lang.String str56 = week53.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week53.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week53.next();
        boolean boolean60 = week53.equals((java.lang.Object) 0);
        java.util.Date date61 = week53.getEnd();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date61, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date44, timeZone62);
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date44, timeZone65);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week69.previous();
        java.lang.Class<?> wildcardClass71 = regularTimePeriod70.getClass();
        java.lang.Class class72 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) '#', 53);
        int int76 = week75.getYearValue();
        long long77 = week75.getSerialIndex();
        java.lang.String str78 = week75.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week75.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = week75.next();
        boolean boolean82 = week75.equals((java.lang.Object) 0);
        java.util.Date date83 = week75.getEnd();
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date83, timeZone84);
        java.util.Locale locale86 = null;
        try {
            org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date44, timeZone84, locale86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 53 + "'", int42 == 53);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 35, 53" + "'", str43.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 53 + "'", int54 == 53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2844L + "'", long55 == 2844L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Week 35, 53" + "'", str56.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(class72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 53 + "'", int76 == 53);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 2844L + "'", long77 == 2844L);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Week 35, 53" + "'", str78.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNull(regularTimePeriod85);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        try {
            org.jfree.data.time.Year year7 = week6.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException1.getClass();
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str9 = week8.toString();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        int int13 = week12.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        int int15 = week12.getYearValue();
        boolean boolean16 = week8.equals((java.lang.Object) int15);
        java.util.Date date17 = week8.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        int int21 = week20.getYearValue();
        long long22 = week20.getSerialIndex();
        boolean boolean24 = week20.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date25 = week20.getStart();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        java.lang.String str35 = week33.toString();
        java.util.Date date36 = week33.getEnd();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date36, timeZone37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date36, timeZone39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date25, timeZone39);
        java.lang.Class<?> wildcardClass42 = timeZone39.getClass();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date17, timeZone39);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date5, timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2844L + "'", long22 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
        java.util.Date date19 = null;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone26);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
        int int32 = week31.getYearValue();
        java.lang.String str33 = week31.toString();
        java.util.Date date34 = week31.getEnd();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = regularTimePeriod40.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 53);
        int int45 = week44.getYearValue();
        java.lang.String str46 = week44.toString();
        java.util.Date date47 = week44.getEnd();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date47, timeZone50);
        java.lang.Class<?> wildcardClass52 = timeZone50.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date34, timeZone50);
        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) '#', 53);
        int int58 = week57.getYearValue();
        long long59 = week57.getSerialIndex();
        boolean boolean61 = week57.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date62 = week57.getStart();
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week65.previous();
        java.lang.Class<?> wildcardClass67 = regularTimePeriod66.getClass();
        java.util.Date date68 = regularTimePeriod66.getEnd();
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week((int) '#', 53);
        int int72 = week71.getYearValue();
        java.lang.String str73 = week71.toString();
        java.util.Date date74 = week71.getEnd();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date74, timeZone75);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date68, timeZone75);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = week80.previous();
        java.lang.Class<?> wildcardClass82 = regularTimePeriod81.getClass();
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week((int) '#', 53);
        int int86 = week85.getYearValue();
        java.lang.String str87 = week85.toString();
        java.util.Date date88 = week85.getEnd();
        java.util.TimeZone timeZone89 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass82, date88, timeZone89);
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date88, timeZone91);
        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date68, timeZone91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date62, timeZone91);
        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date5, timeZone91);
        java.util.Calendar calendar96 = null;
        try {
            long long97 = week95.getLastMillisecond(calendar96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 53" + "'", str33.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 53 + "'", int45 == 53);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Week 35, 53" + "'", str46.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 53 + "'", int58 == 53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2844L + "'", long59 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 53 + "'", int72 == 53);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Week 35, 53" + "'", str73.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 53 + "'", int86 == 53);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "Week 35, 53" + "'", str87.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        try {
            org.jfree.data.time.Year year12 = week11.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = regularTimePeriod6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        boolean boolean20 = week14.equals((java.lang.Object) regularTimePeriod19);
        int int22 = week14.compareTo((java.lang.Object) 35);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = week14.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week7.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass1 = week0.getClass();
//        long long2 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        try {
            org.jfree.data.time.Year year7 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 35, 53" + "'", str6.equals("Week 35, 53"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable4 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.util.Date date5 = week2.getEnd();
        int int6 = week2.getWeek();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61157088000001L) + "'", long7 == (-61157088000001L));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass1 = week0.getClass();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        long long17 = week15.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass18 = week15.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str22 = week21.toString();
        int int23 = week21.getYearValue();
        java.util.Date date24 = week21.getEnd();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date24, timeZone25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
        java.util.Date date30 = null;
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        java.lang.String str35 = week33.toString();
        java.util.Date date36 = week33.getEnd();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone37);
        java.util.Locale locale40 = null;
        try {
            org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date24, timeZone37, locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-60474571200001L) + "'", long17 == (-60474571200001L));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 1, 32" + "'", str22.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = regularTimePeriod16.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.lang.Class<?> wildcardClass1 = week0.getClass();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        long long9 = week2.getFirstMillisecond();
        long long10 = week2.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            week2.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60474268800000L) + "'", long9 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-60473664000001L) + "'", long10 == (-60473664000001L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        int int9 = week2.getYearValue();
        long long10 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-60474268800000L) + "'", long10 == (-60474268800000L));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date18, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException26.getClass();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 53);
        int int31 = week30.getYearValue();
        java.lang.String str32 = week30.toString();
        java.util.Date date33 = week30.getEnd();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
        java.lang.Class<?> wildcardClass38 = regularTimePeriod37.getClass();
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        int int43 = week42.getYearValue();
        long long44 = week42.getSerialIndex();
        java.lang.String str45 = week42.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week42.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week42.next();
        boolean boolean49 = week42.equals((java.lang.Object) 0);
        java.util.Date date50 = week42.getEnd();
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date50, timeZone51);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date33, timeZone51);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
        int int57 = week56.getYearValue();
        java.lang.String str58 = week56.toString();
        java.util.Date date59 = week56.getEnd();
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date59, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date33, timeZone60);
        java.util.Locale locale63 = null;
        try {
            org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date7, timeZone60, locale63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 53 + "'", int31 == 53);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 35, 53" + "'", str32.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2844L + "'", long44 == 2844L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 35, 53" + "'", str45.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 35, 53" + "'", str58.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod62);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        int int8 = week2.getYearValue();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.util.Date date14 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        java.lang.String str19 = week17.toString();
        java.util.Date date20 = week17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date14, timeZone21);
        long long24 = week23.getSerialIndex();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        boolean boolean29 = week23.equals((java.lang.Object) regularTimePeriod28);
        try {
            int int30 = week2.compareTo((java.lang.Object) regularTimePeriod28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 35, 53" + "'", str19.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2843L + "'", long24 == 2843L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        java.lang.String str8 = week6.toString();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone10);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        int int29 = week28.getYearValue();
        java.lang.String str30 = week28.toString();
        java.util.Date date31 = week28.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date31, timeZone34);
        java.lang.Class<?> wildcardClass36 = timeZone34.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone34);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.lang.Class<?> wildcardClass42 = regularTimePeriod41.getClass();
        java.util.Date date43 = regularTimePeriod41.getEnd();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', 53);
        int int47 = week46.getYearValue();
        java.lang.String str48 = week46.toString();
        java.util.Date date49 = week46.getEnd();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49, timeZone50);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date43, timeZone50);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date43);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
        java.lang.Class<?> wildcardClass58 = regularTimePeriod57.getClass();
        java.util.Date date59 = regularTimePeriod57.getEnd();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date59);
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.previous();
        java.lang.Class<?> wildcardClass65 = regularTimePeriod64.getClass();
        java.util.Date date66 = regularTimePeriod64.getEnd();
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 53);
        int int70 = week69.getYearValue();
        java.lang.String str71 = week69.toString();
        java.util.Date date72 = week69.getEnd();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date72, timeZone73);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date66, timeZone73);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.previous();
        java.lang.Class<?> wildcardClass80 = regularTimePeriod79.getClass();
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week((int) '#', 53);
        int int84 = week83.getYearValue();
        java.lang.String str85 = week83.toString();
        java.util.Date date86 = week83.getEnd();
        java.util.TimeZone timeZone87 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date86, timeZone87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date86, timeZone89);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date66, timeZone89);
        java.lang.Class<?> wildcardClass92 = timeZone89.getClass();
        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date59, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date43, timeZone89);
        java.util.TimeZone timeZone95 = null;
        java.util.Locale locale96 = null;
        try {
            org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date43, timeZone95, locale96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 53 + "'", int47 == 53);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 35, 53" + "'", str48.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 53 + "'", int70 == 53);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Week 35, 53" + "'", str71.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 53 + "'", int84 == 53);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "Week 35, 53" + "'", str85.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168313600001L) + "'", long3 == (-62168313600001L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        java.lang.String str15 = week14.toString();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week14.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 34, 53" + "'", str15.equals("Week 34, 53"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 5);
        int int4 = week2.compareTo((java.lang.Object) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61988385600001L) + "'", long6 == (-61988385600001L));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        long long17 = week15.getMiddleMillisecond();
        java.util.Date date18 = week15.getStart();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        java.util.Date date24 = regularTimePeriod22.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass26 = timeZone25.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone25);
        java.util.Locale locale28 = null;
        try {
            org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date18, timeZone25, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-60474571200001L) + "'", long17 == (-60474571200001L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        try {
            org.jfree.data.time.Year year17 = week15.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (byte) 10);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) 'a', 0);
        try {
            int int6 = week2.compareTo((java.lang.Object) week5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
//        int int8 = week7.getYearValue();
//        java.lang.String str9 = week7.toString();
//        java.util.Date date10 = week7.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        java.util.Date date14 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
//        int int18 = week17.getYearValue();
//        java.lang.String str19 = week17.toString();
//        java.util.Date date20 = week17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone21);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date10, timeZone21);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
//        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
//        java.util.Date date30 = regularTimePeriod28.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
//        int int34 = week33.getYearValue();
//        java.lang.String str35 = week33.toString();
//        java.util.Date date36 = week33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date36, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date30, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
//        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 53);
//        int int48 = week47.getYearValue();
//        java.lang.String str49 = week47.toString();
//        java.util.Date date50 = week47.getEnd();
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date50, timeZone51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date50, timeZone53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date30, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone53);
//        java.util.Locale locale57 = null;
//        try {
//            org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date2, timeZone53, locale57);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 35, 53" + "'", str19.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 53 + "'", int48 == 53);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Week 35, 53" + "'", str49.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        int int13 = week12.getYearValue();
        java.lang.String str14 = week12.toString();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone16);
        try {
            org.jfree.data.time.Year year20 = week19.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        int int12 = week11.getYearValue();
        long long13 = week11.getSerialIndex();
        boolean boolean15 = week11.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date16 = week11.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        int int25 = week24.getYearValue();
        java.lang.String str26 = week24.toString();
        java.util.Date date27 = week24.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date27, timeZone28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date16, timeZone30);
        java.util.Locale locale33 = null;
        try {
            org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date7, timeZone30, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2844L + "'", long13 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 53 + "'", int25 == 53);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 53" + "'", str26.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone30);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (short) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        boolean boolean14 = week2.equals((java.lang.Object) week12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week2.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date18, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        long long29 = week27.getSerialIndex();
        boolean boolean31 = week27.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date32 = week27.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = regularTimePeriod36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date43, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date32, timeZone46);
        java.lang.Class<?> wildcardClass49 = timeZone46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date7, timeZone46);
        int int51 = week50.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2844L + "'", long29 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 35 + "'", int51 == 35);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        int int14 = week2.getYearValue();
        java.util.Calendar calendar15 = null;
        try {
            week2.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        int int13 = week2.getWeek();
//        java.lang.Class<?> wildcardClass14 = week2.getClass();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week2.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        java.util.Date date12 = null;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone19);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        int int25 = week24.getYearValue();
        java.lang.String str26 = week24.toString();
        java.util.Date date27 = week24.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date27, timeZone28);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        int int38 = week37.getYearValue();
        java.lang.String str39 = week37.toString();
        java.util.Date date40 = week37.getEnd();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date40, timeZone41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date40, timeZone43);
        java.lang.Class<?> wildcardClass45 = timeZone43.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date27, timeZone43);
        java.util.Locale locale47 = null;
        try {
            org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date5, timeZone43, locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 53 + "'", int25 == 53);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 53" + "'", str26.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 35, 53" + "'", str39.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(regularTimePeriod46);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getWeek();
        java.util.Calendar calendar10 = null;
        try {
            week6.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60473664000001L) + "'", long7 == (-60473664000001L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(32, (int) '4');
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60507835200001L) + "'", long3 == (-60507835200001L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str13 = week12.toString();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 53);
        int int17 = week16.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week16.next();
        int int19 = week16.getYearValue();
        boolean boolean20 = week12.equals((java.lang.Object) int19);
        java.util.Date date21 = week12.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        int int25 = week24.getYearValue();
        long long26 = week24.getSerialIndex();
        boolean boolean28 = week24.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date29 = week24.getStart();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        int int38 = week37.getYearValue();
        java.lang.String str39 = week37.toString();
        java.util.Date date40 = week37.getEnd();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date40, timeZone41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date40, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date29, timeZone43);
        java.lang.Class<?> wildcardClass46 = timeZone43.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date21, timeZone43);
        java.util.Locale locale48 = null;
        try {
            org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date9, timeZone43, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 35, 53" + "'", str13.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 53 + "'", int25 == 53);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2844L + "'", long26 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 35, 53" + "'", str39.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.String str4 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 6, 10" + "'", str4.equals("Week 6, 10"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 5);
        int int4 = week2.compareTo((java.lang.Object) 11);
        long long5 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61989292800000L) + "'", long5 == (-61989292800000L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = week30.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        long long15 = week2.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            week2.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60473664000001L) + "'", long15 == (-60473664000001L));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        long long14 = week2.getLastMillisecond();
        long long15 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60473664000001L) + "'", long14 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60474268800000L) + "'", long15 == (-60474268800000L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week2.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        long long7 = week6.getLastMillisecond();
        try {
            org.jfree.data.time.Year year8 = week6.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800001L) + "'", long7 == (-60474268800001L));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473664000001L) + "'", long6 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2844L + "'", long7 == 2844L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        java.lang.String str20 = week19.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        long long9 = week2.getFirstMillisecond();
        long long10 = week2.getFirstMillisecond();
        int int11 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60474268800000L) + "'", long9 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-60474268800000L) + "'", long10 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        int int9 = week2.getYearValue();
        java.lang.String str10 = week2.toString();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
//        int int7 = week6.getYearValue();
//        java.lang.String str8 = week6.toString();
//        java.util.Date date9 = week6.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone10);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
//        int int16 = week15.getYearValue();
//        java.lang.String str17 = week15.toString();
//        java.util.Date date18 = week15.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
//        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
//        int int29 = week28.getYearValue();
//        java.lang.String str30 = week28.toString();
//        java.util.Date date31 = week28.getEnd();
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date31, timeZone34);
//        java.lang.Class<?> wildcardClass36 = timeZone34.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone34);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        long long39 = week38.getSerialIndex();
//        java.util.Date date40 = week38.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.previous();
//        java.lang.Class<?> wildcardClass45 = regularTimePeriod44.getClass();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 53);
//        int int49 = week48.getYearValue();
//        java.lang.String str50 = week48.toString();
//        java.util.Date date51 = week48.getEnd();
//        java.util.TimeZone timeZone52 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date51, timeZone52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date51, timeZone54);
//        java.lang.Class<?> wildcardClass56 = timeZone54.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date40, timeZone54);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) '#', 53);
//        java.lang.String str61 = week60.toString();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) '#', 53);
//        int int65 = week64.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week64.next();
//        int int67 = week64.getYearValue();
//        boolean boolean68 = week60.equals((java.lang.Object) int67);
//        java.util.Date date69 = week60.getEnd();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) '#', 53);
//        int int73 = week72.getYearValue();
//        long long74 = week72.getSerialIndex();
//        boolean boolean76 = week72.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date77 = week72.getStart();
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = week80.previous();
//        java.lang.Class<?> wildcardClass82 = regularTimePeriod81.getClass();
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week((int) '#', 53);
//        int int86 = week85.getYearValue();
//        java.lang.String str87 = week85.toString();
//        java.util.Date date88 = week85.getEnd();
//        java.util.TimeZone timeZone89 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass82, date88, timeZone89);
//        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date88, timeZone91);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date77, timeZone91);
//        java.lang.Class<?> wildcardClass94 = timeZone91.getClass();
//        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date69, timeZone91);
//        java.util.Locale locale96 = null;
//        try {
//            org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date40, timeZone91, locale96);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 107031L + "'", long39 == 107031L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 53 + "'", int49 == 53);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 53" + "'", str50.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Week 35, 53" + "'", str61.equals("Week 35, 53"));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 53 + "'", int65 == 53);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 53 + "'", int73 == 53);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 2844L + "'", long74 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 53 + "'", int86 == 53);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "Week 35, 53" + "'", str87.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(timeZone91);
//        org.junit.Assert.assertNotNull(wildcardClass94);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass1 = week0.getClass();
//        long long2 = week0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        int int13 = week12.getYearValue();
        long long14 = week12.getSerialIndex();
        java.lang.String str15 = week12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week12.next();
        boolean boolean19 = week12.equals((java.lang.Object) 0);
        java.util.Date date20 = week12.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        java.lang.String str25 = week23.toString();
        java.util.Date date26 = week23.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
        java.util.Date date30 = null;
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        java.lang.String str35 = week33.toString();
        java.util.Date date36 = week33.getEnd();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone37);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date26, timeZone37);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date20, timeZone37);
        java.util.Locale locale42 = null;
        try {
            org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date9, timeZone37, locale42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2844L + "'", long14 == 2844L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 53" + "'", str15.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date12, timeZone19);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', 53);
        int int30 = week29.getYearValue();
        java.lang.String str31 = week29.toString();
        java.util.Date date32 = week29.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date12, timeZone35);
        java.lang.Class<?> wildcardClass38 = timeZone35.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date5, timeZone35);
        java.lang.Class<?> wildcardClass40 = week39.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 35, 53" + "'", str31.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157692800000L) + "'", long4 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61157692800000L) + "'", long5 == (-61157692800000L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 53);
        int int14 = week13.getYearValue();
        java.lang.String str15 = week13.toString();
        java.util.Date date16 = week13.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
        java.util.Date date20 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        java.lang.String str25 = week23.toString();
        java.util.Date date26 = week23.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone27);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16, timeZone27);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date10, timeZone27);
        java.util.TimeZone timeZone32 = null;
        try {
            org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date10, timeZone32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 53" + "'", str15.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157692800000L) + "'", long4 == (-61157692800000L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Object obj12 = null;
        boolean boolean13 = week10.equals(obj12);
        java.lang.Object obj14 = null;
        int int15 = week10.compareTo(obj14);
        java.util.Date date16 = week10.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.util.Date date22 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone23);
        boolean boolean27 = week2.equals((java.lang.Object) week26);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = week2.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        int int13 = week12.getYearValue();
        java.lang.String str14 = week12.toString();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
        java.util.Date date22 = regularTimePeriod21.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        long long14 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week2.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60473664000001L) + "'", long14 == (-60473664000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        boolean boolean14 = week2.equals((java.lang.Object) week12);
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        java.util.Date date16 = null;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        int int20 = week19.getYearValue();
        long long21 = week19.getSerialIndex();
        boolean boolean23 = week19.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date24 = week19.getStart();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 53);
        int int33 = week32.getYearValue();
        java.lang.String str34 = week32.toString();
        java.util.Date date35 = week32.getEnd();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date35, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date24, timeZone38);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 53);
        int int45 = week44.getYearValue();
        long long46 = week44.getSerialIndex();
        boolean boolean48 = week44.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date49 = week44.getStart();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.previous();
        java.lang.Class<?> wildcardClass54 = regularTimePeriod53.getClass();
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) '#', 53);
        int int58 = week57.getYearValue();
        java.lang.String str59 = week57.toString();
        java.util.Date date60 = week57.getEnd();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date60, timeZone61);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date60, timeZone63);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date49, timeZone63);
        java.lang.Class<?> wildcardClass66 = timeZone63.getClass();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date24, timeZone63);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) '#', 53);
        int int71 = week70.getYearValue();
        long long72 = week70.getSerialIndex();
        boolean boolean74 = week70.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date75 = week70.getStart();
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.previous();
        java.lang.Class<?> wildcardClass80 = regularTimePeriod79.getClass();
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week((int) '#', 53);
        int int84 = week83.getYearValue();
        java.lang.String str85 = week83.toString();
        java.util.Date date86 = week83.getEnd();
        java.util.TimeZone timeZone87 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date86, timeZone87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date86, timeZone89);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date75, timeZone89);
        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date24, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone89);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2844L + "'", long21 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 53 + "'", int45 == 53);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2844L + "'", long46 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 53 + "'", int58 == 53);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Week 35, 53" + "'", str59.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 53 + "'", int71 == 53);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2844L + "'", long72 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 53 + "'", int84 == 53);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "Week 35, 53" + "'", str85.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod93);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) 'a');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (short) 0);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        int int14 = week2.getYearValue();
        long long15 = week2.getSerialIndex();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week2.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getSerialIndex();
        long long7 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.util.Date date9 = regularTimePeriod8.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2844L + "'", long6 == 2844L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2844L + "'", long7 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = week2.equals(obj14);
        java.lang.Class<?> wildcardClass16 = week2.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        java.util.Date date14 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.lang.Class<?> wildcardClass7 = week6.getClass();
        int int8 = week2.compareTo((java.lang.Object) week6);
        java.util.Calendar calendar9 = null;
        try {
            week6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1966) + "'", int8 == (-1966));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        java.util.Date date6 = regularTimePeriod3.getStart();
        java.util.Date date7 = regularTimePeriod3.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        java.util.Calendar calendar17 = null;
        try {
            week14.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getFirstMillisecond();
        int int9 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60474268800000L) + "'", long8 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week14.next();
        boolean boolean21 = week14.equals((java.lang.Object) 0);
        java.util.Date date22 = week14.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date22, timeZone23);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str28 = week27.toString();
        int int29 = week27.getYearValue();
        java.util.Date date30 = week27.getEnd();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        long long35 = week33.getSerialIndex();
        java.lang.String str36 = week33.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week33.next();
        boolean boolean40 = week33.equals((java.lang.Object) 0);
        java.util.Date date41 = week33.getEnd();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        java.lang.Class<?> wildcardClass46 = regularTimePeriod45.getClass();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 53);
        int int50 = week49.getYearValue();
        java.lang.String str51 = week49.toString();
        java.util.Date date52 = week49.getEnd();
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date52, timeZone53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date52, timeZone55);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date41, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date30, timeZone55);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date5, timeZone55);
        java.lang.Class<?> wildcardClass60 = date5.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 1, 32" + "'", str28.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 32 + "'", int29 == 32);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2844L + "'", long35 == 2844L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 35, 53" + "'", str36.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 53 + "'", int50 == 53);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Week 35, 53" + "'", str51.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass60);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        int int17 = week14.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 1, 32");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        int int12 = week11.getYearValue();
        long long13 = week11.getSerialIndex();
        java.lang.String str14 = week11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week11.next();
        boolean boolean18 = week11.equals((java.lang.Object) 0);
        java.util.Date date19 = week11.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass28 = timePeriodFormatException27.getClass();
        java.util.Date date29 = null;
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 53);
        int int33 = week32.getYearValue();
        java.lang.String str34 = week32.toString();
        java.util.Date date35 = week32.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date25, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date19, timeZone36);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date8, timeZone36);
        try {
            org.jfree.data.time.Year year42 = week41.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2844L + "'", long13 == 2844L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod38);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        int int17 = week14.getWeek();
        java.util.Date date18 = week14.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 34 + "'", int17 == 34);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.util.Date date5 = week2.getEnd();
        int int6 = week2.getWeek();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Date date33 = week30.getEnd();
        long long34 = week30.getSerialIndex();
        int int35 = week30.getYearValue();
        java.util.Calendar calendar36 = null;
        try {
            long long37 = week30.getMiddleMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2843L + "'", long34 == 2843L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 53 + "'", int35 == 53);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        java.lang.Class<?> wildcardClass8 = date5.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar11 = null;
        try {
            week10.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        java.util.Date date9 = week2.getEnd();
        java.util.Calendar calendar10 = null;
        try {
            week2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        int int13 = week12.getYearValue();
        java.lang.String str14 = week12.toString();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone16);
        java.util.TimeZone timeZone20 = null;
        java.util.Locale locale21 = null;
        try {
            org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date5, timeZone20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 34, 53");
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date3 = week2.getStart();
        int int5 = week2.compareTo((java.lang.Object) true);
        long long6 = week2.getSerialIndex();
        long long7 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        int int16 = week14.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass1 = week0.getClass();
//        long long2 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
        java.util.Locale locale19 = null;
        try {
            org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date5, timeZone16, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        long long5 = regularTimePeriod3.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass6 = regularTimePeriod3.getClass();
        java.util.Date date7 = regularTimePeriod3.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60474571200001L) + "'", long5 == (-60474571200001L));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException1.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date3 = week2.getStart();
        int int5 = week2.compareTo((java.lang.Object) true);
        long long6 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        int int8 = week2.getYearValue();
        long long9 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62168313600001L) + "'", long9 == (-62168313600001L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2843L + "'", long17 == 2843L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone9);
        java.util.Date date11 = week10.getEnd();
        int int12 = week10.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Date date33 = week30.getEnd();
        java.util.Calendar calendar34 = null;
        try {
            long long35 = week30.getFirstMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 4);
        int int3 = week2.getWeek();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week6.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str10 = week9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        boolean boolean12 = week2.equals((java.lang.Object) week9);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week9.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473966400001L) + "'", long6 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 1, 32" + "'", str10.equals("Week 1, 32"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        boolean boolean18 = week14.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date19 = week14.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        java.lang.String str29 = week27.toString();
        java.util.Date date30 = week27.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date30, timeZone33);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date19, timeZone33);
        java.lang.Class<?> wildcardClass36 = timeZone33.getClass();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date11, timeZone33);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
        java.lang.Class<?> wildcardClass46 = date43.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date43);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43);
        try {
            int int49 = week37.compareTo((java.lang.Object) week48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 53" + "'", str29.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        long long14 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week2.next();
        long long16 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60473664000001L) + "'", long14 == (-60473664000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-60473966400001L) + "'", long16 == (-60473966400001L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable5 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar8 = null;
        try {
            week7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (short) -1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 6);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 319L + "'", long3 == 319L);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        java.lang.String str4 = week2.toString();
//        java.util.Date date5 = week2.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.util.Date date10 = week8.getEnd();
//        long long11 = week8.getLastMillisecond();
//        java.lang.String str12 = week8.toString();
//        long long13 = week8.getSerialIndex();
//        boolean boolean14 = week7.equals((java.lang.Object) long13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        int int14 = week2.getYearValue();
        java.util.Date date15 = week2.getEnd();
        java.util.Date date16 = week2.getEnd();
        java.util.Date date17 = week2.getStart();
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Date date33 = week30.getEnd();
        long long34 = week30.getSerialIndex();
        long long35 = week30.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2843L + "'", long34 == 2843L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-60474873600000L) + "'", long35 == (-60474873600000L));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 53);
        int int14 = week13.getYearValue();
        java.lang.String str15 = week13.toString();
        java.util.Date date16 = week13.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
        int int26 = week25.getYearValue();
        long long27 = week25.getSerialIndex();
        java.lang.String str28 = week25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week25.next();
        boolean boolean32 = week25.equals((java.lang.Object) 0);
        java.util.Date date33 = week25.getEnd();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date33, timeZone34);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date16, timeZone34);
        java.util.Locale locale37 = null;
        try {
            org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date10, timeZone34, locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 53" + "'", str15.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2844L + "'", long27 == 2844L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 35, 53" + "'", str28.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
        java.util.Date date9 = regularTimePeriod7.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9, timeZone10);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone13);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str20 = week19.toString();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week23.next();
        int int26 = week23.getYearValue();
        boolean boolean27 = week19.equals((java.lang.Object) int26);
        java.lang.Object obj28 = null;
        boolean boolean29 = week19.equals(obj28);
        java.util.Date date30 = week19.getEnd();
        int int31 = week19.getYearValue();
        java.util.Date date32 = week19.getEnd();
        java.util.Date date33 = week19.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass36 = timePeriodFormatException35.getClass();
        java.util.Date date37 = null;
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone44);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 53);
        int int50 = week49.getYearValue();
        java.lang.String str51 = week49.toString();
        java.util.Date date52 = week49.getEnd();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date52, timeZone53);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week57.previous();
        java.lang.Class<?> wildcardClass59 = regularTimePeriod58.getClass();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) '#', 53);
        int int63 = week62.getYearValue();
        java.lang.String str64 = week62.toString();
        java.util.Date date65 = week62.getEnd();
        java.util.TimeZone timeZone66 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date65, timeZone66);
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date65, timeZone68);
        java.lang.Class<?> wildcardClass70 = timeZone68.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date52, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date33, timeZone68);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 53 + "'", int31 == 53);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 53 + "'", int50 == 53);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Week 35, 53" + "'", str51.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 53 + "'", int63 == 53);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Week 35, 53" + "'", str64.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getLastMillisecond();
//        java.lang.String str4 = week0.toString();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getLastMillisecond();
        java.util.Date date32 = week30.getEnd();
        java.util.Calendar calendar33 = null;
        try {
            long long34 = week30.getFirstMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60474268800001L) + "'", long31 == (-60474268800001L));
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        int int21 = week20.getYearValue();
        long long22 = week20.getSerialIndex();
        long long23 = week20.getLastMillisecond();
        long long24 = week20.getLastMillisecond();
        int int25 = week15.compareTo((java.lang.Object) long24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week15.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 34, 53" + "'", str17.equals("Week 34, 53"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2844L + "'", long22 == 2844L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60473664000001L) + "'", long23 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60473664000001L) + "'", long24 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        int int14 = week2.getYearValue();
        long long15 = week2.getSerialIndex();
        long long16 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-60473966400001L) + "'", long16 == (-60473966400001L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        java.util.Date date9 = week2.getEnd();
        try {
            org.jfree.data.time.Year year10 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61852608000000L) + "'", long3 == (-61852608000000L));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 4, 0");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getFirstMillisecond();
//        int int3 = week0.getWeek();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        int int21 = week19.compareTo((java.lang.Object) (-1));
        int int22 = week19.getYearValue();
        long long23 = week19.getLastMillisecond();
        int int24 = week19.getYearValue();
        int int25 = week19.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60473664000001L) + "'", long23 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        java.util.Date date3 = week1.getEnd();
//        long long4 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        long long7 = week6.getSerialIndex();
//        java.lang.String str8 = week6.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107016L + "'", long7 == 107016L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 9, 2019" + "'", str8.equals("Week 9, 2019"));
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        long long33 = week30.getMiddleMillisecond();
        java.lang.String str34 = week30.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-60474571200001L) + "'", long33 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 34, 53" + "'", str34.equals("Week 34, 53"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        long long9 = week6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473966400001L) + "'", long9 == (-60473966400001L));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        java.util.Date date6 = regularTimePeriod3.getStart();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod3.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 32");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getWeek();
        java.util.Date date10 = week6.getStart();
        long long11 = week6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-60473966400001L) + "'", long11 == (-60473966400001L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        java.lang.String str17 = week14.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        java.lang.Class<?> wildcardClass2 = timeZone0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Object obj12 = null;
        boolean boolean13 = week10.equals(obj12);
        java.lang.Object obj14 = null;
        int int15 = week10.compareTo(obj14);
        java.util.Date date16 = week10.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.util.Date date22 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone23);
        boolean boolean27 = week2.equals((java.lang.Object) week26);
        long long28 = week26.getSerialIndex();
        long long29 = week26.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2844L + "'", long28 == 2844L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-60474268800000L) + "'", long29 == (-60474268800000L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        int int14 = week2.getYearValue();
        int int15 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 10);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date3 = week2.getStart();
        int int5 = week2.compareTo((java.lang.Object) true);
        long long6 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        java.util.Date date8 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        long long5 = regularTimePeriod3.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass6 = regularTimePeriod3.getClass();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod3.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60474571200001L) + "'", long5 == (-60474571200001L));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        java.lang.String str6 = week2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 35, 53" + "'", str6.equals("Week 35, 53"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 53);
        int int19 = week18.getYearValue();
        java.lang.String str20 = week18.toString();
        java.util.Date date21 = week18.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date21, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date10, timeZone24);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.lang.Class<?> wildcardClass32 = regularTimePeriod31.getClass();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 53);
        int int36 = week35.getYearValue();
        long long37 = week35.getSerialIndex();
        java.lang.String str38 = week35.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week35.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week35.next();
        boolean boolean42 = week35.equals((java.lang.Object) 0);
        java.util.Date date43 = week35.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date43, timeZone44);
        java.util.Locale locale46 = null;
        try {
            org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date10, timeZone44, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 53 + "'", int36 == 53);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2844L + "'", long37 == 2844L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 35, 53" + "'", str38.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        long long30 = regularTimePeriod29.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60475176000001L) + "'", long30 == (-60475176000001L));
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getSerialIndex();
//        java.util.Date date5 = week3.getEnd();
//        long long6 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(24, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getEnd();
        java.lang.String str9 = week2.toString();
        int int10 = week2.getYearValue();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        int int21 = week19.compareTo((java.lang.Object) (-1));
        int int22 = week19.getWeek();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = week19.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', 53);
//        int int6 = week5.getYearValue();
//        java.lang.String str7 = week5.toString();
//        java.util.Date date8 = week5.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
//        int int18 = week17.getYearValue();
//        long long19 = week17.getSerialIndex();
//        java.lang.String str20 = week17.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
//        boolean boolean24 = week17.equals((java.lang.Object) 0);
//        java.util.Date date25 = week17.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date8, timeZone26);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
//        int int32 = week31.getYearValue();
//        java.lang.String str33 = week31.toString();
//        java.util.Date date34 = week31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone35);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        long long40 = week39.getSerialIndex();
//        java.util.Date date41 = week39.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass43 = timeZone42.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', 53);
//        int int47 = week46.getYearValue();
//        java.lang.String str48 = week46.toString();
//        java.util.Date date49 = week46.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass52 = timePeriodFormatException51.getClass();
//        java.util.Date date53 = null;
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
//        int int57 = week56.getYearValue();
//        java.lang.String str58 = week56.toString();
//        java.util.Date date59 = week56.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date59, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone60);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date49, timeZone60);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.previous();
//        java.lang.Class<?> wildcardClass68 = regularTimePeriod67.getClass();
//        java.util.Date date69 = regularTimePeriod67.getEnd();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) '#', 53);
//        int int73 = week72.getYearValue();
//        java.lang.String str74 = week72.toString();
//        java.util.Date date75 = week72.getEnd();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date75, timeZone76);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date69, timeZone76);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = week81.previous();
//        java.lang.Class<?> wildcardClass83 = regularTimePeriod82.getClass();
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week((int) '#', 53);
//        int int87 = week86.getYearValue();
//        java.lang.String str88 = week86.toString();
//        java.util.Date date89 = week86.getEnd();
//        java.util.TimeZone timeZone90 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass83, date89, timeZone90);
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date89, timeZone92);
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date69, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date49, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date41, timeZone92);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 53" + "'", str7.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 53" + "'", str33.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 107031L + "'", long40 == 107031L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 53 + "'", int47 == 53);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 35, 53" + "'", str48.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 35, 53" + "'", str58.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 53 + "'", int73 == 53);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Week 35, 53" + "'", str74.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(wildcardClass83);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 53 + "'", int87 == 53);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "Week 35, 53" + "'", str88.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.lang.Class<?> wildcardClass1 = week0.getClass();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date5 = week4.getStart();
        try {
            int int6 = week0.compareTo((java.lang.Object) week4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473966400001L) + "'", long6 == (-60473966400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        long long8 = week6.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year9 = week6.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473966400001L) + "'", long8 == (-60473966400001L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        int int9 = week2.getYearValue();
        java.lang.String str10 = week2.toString();
        java.util.Calendar calendar11 = null;
        try {
            week2.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        int int14 = week2.getYearValue();
        java.util.Date date15 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 34, 53");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        boolean boolean8 = week2.equals((java.lang.Object) class7);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        java.lang.String str15 = week14.toString();
        int int16 = week14.getWeek();
        long long17 = week14.getMiddleMillisecond();
        long long18 = week14.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 34, 53" + "'", str15.equals("Week 34, 53"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 34 + "'", int16 == 34);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-60474571200001L) + "'", long17 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60474268800001L) + "'", long18 == (-60474268800001L));
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        int int13 = week2.getWeek();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week2.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 9, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
        int int26 = week25.getYearValue();
        long long27 = week25.getSerialIndex();
        java.lang.String str28 = week25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week25.next();
        boolean boolean32 = week25.equals((java.lang.Object) 0);
        java.util.Date date33 = week25.getEnd();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date33, timeZone34);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date33);
        int int38 = week36.compareTo((java.lang.Object) (-1));
        int int39 = week36.getYearValue();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        int int43 = week42.getYearValue();
        java.lang.String str44 = week42.toString();
        java.util.Date date45 = week42.getEnd();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
        java.lang.Class<?> wildcardClass50 = regularTimePeriod49.getClass();
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 53);
        int int55 = week54.getYearValue();
        long long56 = week54.getSerialIndex();
        java.lang.String str57 = week54.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week54.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week54.next();
        boolean boolean61 = week54.equals((java.lang.Object) 0);
        java.util.Date date62 = week54.getEnd();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date62, timeZone63);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date45, timeZone63);
        boolean boolean66 = week36.equals((java.lang.Object) timeZone63);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date16, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
        java.util.Calendar calendar69 = null;
        try {
            long long70 = week67.getFirstMillisecond(calendar69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2844L + "'", long27 == 2844L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 35, 53" + "'", str28.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 53 + "'", int39 == 53);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 35, 53" + "'", str44.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 53 + "'", int55 == 53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2844L + "'", long56 == 2844L);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Week 35, 53" + "'", str57.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        int int13 = week12.getYearValue();
        java.lang.String str14 = week12.toString();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        java.lang.Class<?> wildcardClass36 = regularTimePeriod35.getClass();
        java.util.Date date37 = regularTimePeriod35.getEnd();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date37, timeZone44);
        long long47 = week46.getSerialIndex();
        long long48 = week46.getMiddleMillisecond();
        int int49 = week30.compareTo((java.lang.Object) long48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week30.next();
        java.util.Calendar calendar51 = null;
        try {
            long long52 = week30.getLastMillisecond(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2843L + "'", long47 == 2843L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-60474571200001L) + "'", long48 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date18, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        long long29 = week27.getSerialIndex();
        boolean boolean31 = week27.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date32 = week27.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = regularTimePeriod36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date43, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date32, timeZone46);
        java.lang.Class<?> wildcardClass49 = timeZone46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date7, timeZone46);
        java.util.Calendar calendar51 = null;
        try {
            week50.peg(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2844L + "'", long29 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        long long9 = week8.getMiddleMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week8.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473966400001L) + "'", long9 == (-60473966400001L));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        int int13 = week2.getWeek();
//        java.lang.Class<?> wildcardClass14 = week2.getClass();
//        long long15 = week2.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60473966400001L) + "'", long15 == (-60473966400001L));
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) '#');
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        java.lang.String str10 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str12 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        boolean boolean14 = week2.equals((java.lang.Object) week12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week12.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str16 = timePeriodFormatException15.toString();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException13.getSuppressed();
        java.lang.String str20 = timePeriodFormatException13.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = week29.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        long long16 = week14.getFirstMillisecond();
        int int17 = week14.getYearValue();
        long long18 = week14.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-60474268800000L) + "'", long16 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2844L + "'", long18 == 2844L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        java.lang.String str8 = week6.toString();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone10);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        int int29 = week28.getYearValue();
        java.lang.String str30 = week28.toString();
        java.util.Date date31 = week28.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date31, timeZone34);
        java.lang.Class<?> wildcardClass36 = timeZone34.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone34);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
        java.lang.Class<?> wildcardClass46 = date43.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date43);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass50 = timePeriodFormatException49.getClass();
        java.util.Date date51 = null;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 53);
        int int55 = week54.getYearValue();
        java.lang.String str56 = week54.toString();
        java.util.Date date57 = week54.getEnd();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date57, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone58);
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) '#', 53);
        int int64 = week63.getYearValue();
        java.lang.String str65 = week63.toString();
        java.util.Date date66 = week63.getEnd();
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date66, timeZone67);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.previous();
        java.lang.Class<?> wildcardClass73 = regularTimePeriod72.getClass();
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week((int) '#', 53);
        int int77 = week76.getYearValue();
        java.lang.String str78 = week76.toString();
        java.util.Date date79 = week76.getEnd();
        java.util.TimeZone timeZone80 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date79, timeZone80);
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date79, timeZone82);
        java.lang.Class<?> wildcardClass84 = timeZone82.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date66, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date43, timeZone82);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date43);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 53 + "'", int55 == 53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Week 35, 53" + "'", str56.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 53 + "'", int64 == 53);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Week 35, 53" + "'", str65.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 53 + "'", int77 == 53);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Week 35, 53" + "'", str78.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNull(regularTimePeriod86);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.util.Date date11 = week2.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        long long16 = week14.getSerialIndex();
        boolean boolean18 = week14.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date19 = week14.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        java.lang.String str29 = week27.toString();
        java.util.Date date30 = week27.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date30, timeZone33);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date19, timeZone33);
        java.lang.Class<?> wildcardClass36 = timeZone33.getClass();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date11, timeZone33);
        long long38 = week37.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2844L + "'", long16 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 35, 53" + "'", str29.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2844L + "'", long38 == 2844L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) -1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str11 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        int int13 = week2.getWeek();
//        boolean boolean15 = week2.equals((java.lang.Object) false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473664000001L) + "'", long6 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60473664000001L) + "'", long7 == (-60473664000001L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 1);
        java.util.Date date3 = week2.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 4);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        int int20 = week19.getYearValue();
        java.lang.String str21 = week19.toString();
        java.util.Date date22 = week19.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
        int int32 = week31.getYearValue();
        long long33 = week31.getSerialIndex();
        java.lang.String str34 = week31.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week31.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week31.next();
        boolean boolean38 = week31.equals((java.lang.Object) 0);
        java.util.Date date39 = week31.getEnd();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date39, timeZone40);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date22, timeZone40);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.previous();
        java.lang.Class<?> wildcardClass47 = regularTimePeriod46.getClass();
        java.util.Date date48 = regularTimePeriod46.getEnd();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 53);
        int int52 = week51.getYearValue();
        java.lang.String str53 = week51.toString();
        java.util.Date date54 = week51.getEnd();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54, timeZone55);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date48, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone55);
        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 35, 53" + "'", str21.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2844L + "'", long33 == 2844L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 53 + "'", int52 == 53);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Week 35, 53" + "'", str53.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(class59);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.util.Date date9 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        int int13 = week12.getYearValue();
        java.lang.String str14 = week12.toString();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone16);
        int int20 = week19.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week14.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2843L + "'", long15 == 2843L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str20 = week19.toString();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week23.next();
        int int26 = week23.getYearValue();
        boolean boolean27 = week19.equals((java.lang.Object) int26);
        java.util.Date date28 = week19.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
        java.lang.Class<?> wildcardClass33 = regularTimePeriod32.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        int int38 = week37.getYearValue();
        long long39 = week37.getSerialIndex();
        java.lang.String str40 = week37.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week37.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week37.next();
        boolean boolean44 = week37.equals((java.lang.Object) 0);
        java.util.Date date45 = week37.getEnd();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date45, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date45);
        int int50 = week48.compareTo((java.lang.Object) (-1));
        int int51 = week48.getYearValue();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 53);
        int int55 = week54.getYearValue();
        java.lang.String str56 = week54.toString();
        java.util.Date date57 = week54.getEnd();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week60.previous();
        java.lang.Class<?> wildcardClass62 = regularTimePeriod61.getClass();
        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass62);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week((int) '#', 53);
        int int67 = week66.getYearValue();
        long long68 = week66.getSerialIndex();
        java.lang.String str69 = week66.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week66.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = week66.next();
        boolean boolean73 = week66.equals((java.lang.Object) 0);
        java.util.Date date74 = week66.getEnd();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date74, timeZone75);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date57, timeZone75);
        boolean boolean78 = week48.equals((java.lang.Object) timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date28, timeZone75);
        java.lang.Class class80 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2844L + "'", long39 == 2844L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 35, 53" + "'", str40.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 53 + "'", int51 == 53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 53 + "'", int55 == 53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Week 35, 53" + "'", str56.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(class63);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2844L + "'", long68 == 2844L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Week 35, 53" + "'", str69.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(class80);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getMiddleMillisecond();
        int int8 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473664000001L) + "'", long6 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60473966400001L) + "'", long7 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        java.lang.Class<?> wildcardClass36 = regularTimePeriod35.getClass();
        java.util.Date date37 = regularTimePeriod35.getEnd();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date37, timeZone44);
        long long47 = week46.getSerialIndex();
        long long48 = week46.getMiddleMillisecond();
        int int49 = week30.compareTo((java.lang.Object) long48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week30.next();
        long long51 = week30.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2843L + "'", long47 == 2843L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-60474571200001L) + "'", long48 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2843L + "'", long51 == 2843L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        long long7 = week2.getSerialIndex();
        long long8 = week2.getMiddleMillisecond();
        long long9 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2844L + "'", long7 == 2844L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473966400001L) + "'", long8 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2844L + "'", long9 == 2844L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getStart();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        java.lang.Class<?> wildcardClass14 = regularTimePeriod13.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        java.lang.String str19 = week17.toString();
        java.util.Date date20 = week17.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date20, timeZone21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date20, timeZone23);
        java.util.Locale locale25 = null;
        try {
            org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date9, timeZone23, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 35, 53" + "'", str19.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (short) 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getSerialIndex();
//        java.util.Date date5 = week3.getEnd();
//        long long6 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(9, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 1, year7);
//        java.lang.Object obj11 = null;
//        int int12 = week10.compareTo(obj11);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        java.lang.Class<?> wildcardClass7 = date6.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getLastMillisecond();
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        int int31 = week29.getWeek();
        try {
            org.jfree.data.time.Year year32 = week29.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 34 + "'", int31 == 34);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str22 = week21.toString();
        int int23 = week21.getYearValue();
        java.util.Date date24 = week21.getEnd();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        long long29 = week27.getSerialIndex();
        java.lang.String str30 = week27.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week27.next();
        boolean boolean34 = week27.equals((java.lang.Object) 0);
        java.util.Date date35 = week27.getEnd();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
        java.lang.Class<?> wildcardClass40 = regularTimePeriod39.getClass();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) '#', 53);
        int int44 = week43.getYearValue();
        java.lang.String str45 = week43.toString();
        java.util.Date date46 = week43.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date46, timeZone47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date46, timeZone49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date35, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date24, timeZone49);
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 1, 32" + "'", str22.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2844L + "'", long29 == 2844L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 53 + "'", int44 == 53);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 35, 53" + "'", str45.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(class53);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        java.lang.String str8 = week6.toString();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone10);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        int int29 = week28.getYearValue();
        java.lang.String str30 = week28.toString();
        java.util.Date date31 = week28.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date31, timeZone34);
        java.lang.Class<?> wildcardClass36 = timeZone34.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone34);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 53);
        int int42 = week41.getYearValue();
        java.lang.String str43 = week41.toString();
        java.util.Date date44 = week41.getEnd();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        java.lang.Class<?> wildcardClass49 = regularTimePeriod48.getClass();
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
        int int54 = week53.getYearValue();
        long long55 = week53.getSerialIndex();
        java.lang.String str56 = week53.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week53.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week53.next();
        boolean boolean60 = week53.equals((java.lang.Object) 0);
        java.util.Date date61 = week53.getEnd();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date61, timeZone62);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date44, timeZone62);
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date44, timeZone65);
        java.lang.Class class67 = org.jfree.data.time.RegularTimePeriod.downsize(class38);
        java.lang.Class class68 = org.jfree.data.time.RegularTimePeriod.downsize(class38);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 53 + "'", int42 == 53);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 35, 53" + "'", str43.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 53 + "'", int54 == 53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2844L + "'", long55 == 2844L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Week 35, 53" + "'", str56.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(class67);
        org.junit.Assert.assertNotNull(class68);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, (int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 53);
        int int15 = week14.getYearValue();
        java.lang.String str16 = week14.toString();
        java.util.Date date17 = week14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
        java.lang.Class<?> wildcardClass20 = date17.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        int int22 = week10.compareTo((java.lang.Object) wildcardClass20);
        int int23 = week10.getYearValue();
        java.util.Date date24 = week10.getEnd();
        boolean boolean25 = week6.equals((java.lang.Object) date24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 35, 53" + "'", str16.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (-1));
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.lang.Class<?> wildcardClass5 = week4.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getWeek();
        int int10 = week6.getYearValue();
        int int11 = week6.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date12, timeZone19);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', 53);
        int int30 = week29.getYearValue();
        java.lang.String str31 = week29.toString();
        java.util.Date date32 = week29.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date12, timeZone35);
        java.lang.Class<?> wildcardClass38 = timeZone35.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date5, timeZone35);
        java.util.TimeZone timeZone40 = null;
        try {
            org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date5, timeZone40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 35, 53" + "'", str31.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (short) 100);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = regularTimePeriod7.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        int int12 = week11.getYearValue();
        long long13 = week11.getSerialIndex();
        boolean boolean15 = week11.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date16 = week11.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 53);
        int int25 = week24.getYearValue();
        java.lang.String str26 = week24.toString();
        java.util.Date date27 = week24.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date27, timeZone28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date16, timeZone30);
        java.util.Locale locale33 = null;
        try {
            org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date8, timeZone30, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2844L + "'", long13 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 53 + "'", int25 == 53);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 35, 53" + "'", str26.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone30);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        long long8 = week2.getLastMillisecond();
        java.util.Date date9 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Date date3 = week0.getEnd();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.Class<?> wildcardClass5 = week4.getClass();
//        java.lang.String str6 = week4.toString();
//        boolean boolean7 = week2.equals((java.lang.Object) str6);
//        int int8 = week2.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 11);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 1);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 1" + "'", str3.equals("Week 0, 1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62136259200001L) + "'", long4 == (-62136259200001L));
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getSerialIndex();
//        java.util.Date date5 = week3.getEnd();
//        long long6 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 100, year7);
//        long long11 = year7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.lang.Class<?> wildcardClass7 = week6.getClass();
        int int8 = week2.compareTo((java.lang.Object) week6);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        int int12 = week11.getYearValue();
        long long13 = week11.getSerialIndex();
        java.lang.String str14 = week11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week11.previous();
        java.util.Date date17 = week11.getStart();
        long long18 = week11.getFirstMillisecond();
        int int19 = week6.compareTo((java.lang.Object) long18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1966) + "'", int8 == (-1966));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2844L + "'", long13 == 2844L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60474268800000L) + "'", long18 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        int int6 = week2.getWeek();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Object obj12 = null;
        boolean boolean13 = week10.equals(obj12);
        java.lang.Object obj14 = null;
        int int15 = week10.compareTo(obj14);
        java.util.Date date16 = week10.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.util.Date date22 = regularTimePeriod20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone23);
        boolean boolean27 = week2.equals((java.lang.Object) week26);
        java.lang.Class<?> wildcardClass28 = week2.getClass();
        long long29 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473966400001L) + "'", long5 == (-60473966400001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-60474268800000L) + "'", long29 == (-60474268800000L));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (-1));
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str9 = timePeriodFormatException8.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 5);
        int int4 = week2.compareTo((java.lang.Object) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str11 = timePeriodFormatException10.toString();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass21 = timePeriodFormatException20.getClass();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 6);
        long long3 = week2.getSerialIndex();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 319L + "'", long3 == 319L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 4);
        int int3 = week2.getWeek();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        java.util.Date date3 = week1.getEnd();
//        long long4 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        int int6 = week2.getWeek();
        long long7 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800000L) + "'", long7 == (-60474268800000L));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        long long7 = week6.getLastMillisecond();
        java.util.Date date8 = week6.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        int int12 = week11.getYearValue();
        long long13 = week11.getSerialIndex();
        java.lang.String str14 = week11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week11.previous();
        java.util.Date date17 = week11.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        int int21 = week20.getYearValue();
        long long22 = week20.getSerialIndex();
        java.lang.String str23 = week20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week20.next();
        boolean boolean27 = week20.equals((java.lang.Object) 0);
        java.util.Date date28 = week20.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
        int int32 = week31.getYearValue();
        java.lang.String str33 = week31.toString();
        java.util.Date date34 = week31.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass37 = timePeriodFormatException36.getClass();
        java.util.Date date38 = null;
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 53);
        int int42 = week41.getYearValue();
        java.lang.String str43 = week41.toString();
        java.util.Date date44 = week41.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date38, timeZone45);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date34, timeZone45);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date28, timeZone45);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date17, timeZone45);
        java.util.Locale locale51 = null;
        try {
            org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date8, timeZone45, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60474268800001L) + "'", long7 == (-60474268800001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 53 + "'", int12 == 53);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2844L + "'", long13 == 2844L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 35, 53" + "'", str14.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2844L + "'", long22 == 2844L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 35, 53" + "'", str23.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 53" + "'", str33.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 53 + "'", int42 == 53);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 35, 53" + "'", str43.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod47);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        java.util.Date date3 = week1.getEnd();
//        long long4 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(9, year5);
//        java.lang.Class<?> wildcardClass7 = week6.getClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        long long17 = week15.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass18 = week15.getClass();
        java.lang.String str19 = week15.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-60474571200001L) + "'", long17 == (-60474571200001L));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 34, 53" + "'", str19.equals("Week 34, 53"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473664000001L) + "'", long9 == (-60473664000001L));
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.util.Date date5 = week2.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 11);
        java.util.Date date3 = week2.getEnd();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61820553600001L) + "'", long4 == (-61820553600001L));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        int int21 = week19.compareTo((java.lang.Object) (-1));
        int int22 = week19.getWeek();
        long long23 = week19.getLastMillisecond();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str27 = week26.toString();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 53);
        int int31 = week30.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week30.next();
        int int33 = week30.getYearValue();
        boolean boolean34 = week26.equals((java.lang.Object) int33);
        java.lang.Object obj35 = null;
        boolean boolean36 = week26.equals(obj35);
        java.util.Date date37 = week26.getEnd();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
        boolean boolean39 = week19.equals((java.lang.Object) date37);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60473664000001L) + "'", long23 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 35, 53" + "'", str27.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 53 + "'", int31 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 536L + "'", long5 == 536L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473664000001L) + "'", long6 == (-60473664000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        java.lang.Class<?> wildcardClass8 = date5.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5);
        java.lang.Class<?> wildcardClass11 = week10.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 1);
        java.lang.String str3 = week2.toString();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.util.Date date5 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 1" + "'", str3.equals("Week 0, 1"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 0, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str15 = timePeriodFormatException5.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        java.lang.Class<?> wildcardClass35 = regularTimePeriod34.getClass();
        java.util.Date date36 = regularTimePeriod34.getEnd();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date36);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 53);
        int int49 = week48.getYearValue();
        long long50 = week48.getSerialIndex();
        java.lang.String str51 = week48.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week48.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week48.next();
        boolean boolean55 = week48.equals((java.lang.Object) 0);
        java.util.Date date56 = week48.getEnd();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date56, timeZone57);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date36, timeZone57);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date5, timeZone57);
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) '#', 53);
        int int64 = week63.getYearValue();
        long long65 = week63.getSerialIndex();
        java.lang.String str66 = week63.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week63.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week63.next();
        boolean boolean70 = week63.equals((java.lang.Object) 0);
        java.util.Date date71 = week63.getEnd();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = week74.previous();
        java.lang.Class<?> wildcardClass76 = regularTimePeriod75.getClass();
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week((int) '#', 53);
        int int80 = week79.getYearValue();
        java.lang.String str81 = week79.toString();
        java.util.Date date82 = week79.getEnd();
        java.util.TimeZone timeZone83 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date82, timeZone83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date82, timeZone85);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date71, timeZone85);
        java.util.Locale locale88 = null;
        try {
            org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date5, timeZone85, locale88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 53 + "'", int49 == 53);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2844L + "'", long50 == 2844L);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Week 35, 53" + "'", str51.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 53 + "'", int64 == 53);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2844L + "'", long65 == 2844L);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Week 35, 53" + "'", str66.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 53 + "'", int80 == 53);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "Week 35, 53" + "'", str81.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(timeZone85);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) -1, 0);
        java.util.Date date9 = week8.getStart();
        int int11 = week8.compareTo((java.lang.Object) true);
        long long12 = week8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean14 = week2.equals((java.lang.Object) regularTimePeriod13);
        long long15 = regularTimePeriod13.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60473664000001L) + "'", long5 == (-60473664000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62168011200001L) + "'", long15 == (-62168011200001L));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        int int17 = week15.getYearValue();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week15.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        java.lang.String str5 = week2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
//        java.util.Date date8 = week2.getStart();
//        java.util.Date date9 = week2.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.util.Date date13 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 53);
//        int int17 = week16.getYearValue();
//        java.lang.String str18 = week16.toString();
//        java.util.Date date19 = week16.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone20);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
//        int int26 = week25.getYearValue();
//        java.lang.String str27 = week25.toString();
//        java.util.Date date28 = week25.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date28, timeZone29);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
//        java.lang.Class<?> wildcardClass35 = regularTimePeriod34.getClass();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) '#', 53);
//        int int39 = week38.getYearValue();
//        java.lang.String str40 = week38.toString();
//        java.util.Date date41 = week38.getEnd();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date41, timeZone42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date41, timeZone44);
//        java.lang.Class<?> wildcardClass46 = timeZone44.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date28, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        long long49 = week48.getSerialIndex();
//        java.util.Date date50 = week48.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.previous();
//        java.lang.Class<?> wildcardClass55 = regularTimePeriod54.getClass();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) '#', 53);
//        int int59 = week58.getYearValue();
//        java.lang.String str60 = week58.toString();
//        java.util.Date date61 = week58.getEnd();
//        java.util.TimeZone timeZone62 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone62);
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date61, timeZone64);
//        java.lang.Class<?> wildcardClass66 = timeZone64.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date50, timeZone64);
//        java.util.Locale locale68 = null;
//        try {
//            org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date9, timeZone64, locale68);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 53" + "'", str18.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 35, 53" + "'", str27.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 53 + "'", int39 == 53);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 35, 53" + "'", str40.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 107031L + "'", long49 == 107031L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 53 + "'", int59 == 53);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Week 35, 53" + "'", str60.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        int int18 = week17.getYearValue();
        long long19 = week17.getSerialIndex();
        java.lang.String str20 = week17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week17.next();
        boolean boolean24 = week17.equals((java.lang.Object) 0);
        java.util.Date date25 = week17.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5, timeZone26);
        java.util.Calendar calendar29 = null;
        try {
            week28.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2844L + "'", long19 == 2844L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 35, 53" + "'", str20.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        java.util.Date date13 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 53);
        int int17 = week16.getYearValue();
        java.lang.String str18 = week16.toString();
        java.util.Date date19 = week16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date13, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 53);
        int int31 = week30.getYearValue();
        java.lang.String str32 = week30.toString();
        java.util.Date date33 = week30.getEnd();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date33, timeZone34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date33, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date13, timeZone36);
        long long39 = week38.getSerialIndex();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        java.util.Date date45 = regularTimePeriod43.getEnd();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 53);
        int int49 = week48.getYearValue();
        java.lang.String str50 = week48.toString();
        java.util.Date date51 = week48.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date51, timeZone52);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date45, timeZone52);
        long long55 = week54.getSerialIndex();
        long long56 = week54.getMiddleMillisecond();
        int int57 = week38.compareTo((java.lang.Object) long56);
        int int58 = week2.compareTo((java.lang.Object) int57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 53 + "'", int17 == 53);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 53" + "'", str18.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 53 + "'", int31 == 53);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 35, 53" + "'", str32.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2843L + "'", long39 == 2843L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 53 + "'", int49 == 53);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 35, 53" + "'", str50.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2843L + "'", long55 == 2843L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-60474571200001L) + "'", long56 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, (int) (byte) 1);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62136864000001L) + "'", long3 == (-62136864000001L));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        long long6 = week2.getLastMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) (-1L));
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 53);
        int int14 = week13.getYearValue();
        java.lang.String str15 = week13.toString();
        java.util.Date date16 = week13.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
        java.util.Date date20 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        int int24 = week23.getYearValue();
        java.lang.String str25 = week23.toString();
        java.util.Date date26 = week23.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone27);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16, timeZone27);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        java.lang.Class<?> wildcardClass35 = regularTimePeriod34.getClass();
        java.util.Date date36 = regularTimePeriod34.getEnd();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) '#', 53);
        int int40 = week39.getYearValue();
        java.lang.String str41 = week39.toString();
        java.util.Date date42 = week39.getEnd();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date42, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date36, timeZone43);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
        java.lang.Class<?> wildcardClass50 = regularTimePeriod49.getClass();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
        int int54 = week53.getYearValue();
        java.lang.String str55 = week53.toString();
        java.util.Date date56 = week53.getEnd();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date56, timeZone57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date56, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date36, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone59);
        int int63 = week2.compareTo((java.lang.Object) wildcardClass10);
        int int64 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60473664000001L) + "'", long6 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 35, 53" + "'", str15.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 35, 53" + "'", str25.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 53 + "'", int40 == 53);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Week 35, 53" + "'", str41.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 53 + "'", int54 == 53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 35, 53" + "'", str55.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 35 + "'", int64 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        int int21 = week19.compareTo((java.lang.Object) (-1));
        long long22 = week19.getFirstMillisecond();
        long long23 = week19.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-60474268800000L) + "'", long22 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2844L + "'", long23 == 2844L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week15.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        int int21 = week20.getYearValue();
        long long22 = week20.getSerialIndex();
        long long23 = week20.getLastMillisecond();
        long long24 = week20.getLastMillisecond();
        int int25 = week15.compareTo((java.lang.Object) long24);
        long long26 = week15.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 34, 53" + "'", str17.equals("Week 34, 53"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2844L + "'", long22 == 2844L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-60473664000001L) + "'", long23 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60473664000001L) + "'", long24 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-60474873600000L) + "'", long26 == (-60474873600000L));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getSerialIndex();
        long long7 = week2.getSerialIndex();
        long long8 = week2.getFirstMillisecond();
        int int9 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2844L + "'", long6 == 2844L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2844L + "'", long7 == 2844L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60474268800000L) + "'", long8 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getYearValue();
        long long6 = week2.getSerialIndex();
        java.lang.String str7 = week2.toString();
        java.util.Calendar calendar8 = null;
        try {
            week2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2844L + "'", long6 == 2844L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 53" + "'", str7.equals("Week 35, 53"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        java.lang.String str15 = week14.toString();
        int int16 = week14.getWeek();
        long long17 = week14.getMiddleMillisecond();
        long long18 = week14.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 34, 53" + "'", str15.equals("Week 34, 53"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 34 + "'", int16 == 34);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-60474571200001L) + "'", long17 == (-60474571200001L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60474873600000L) + "'", long18 == (-60474873600000L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 10);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 530L + "'", long3 == 530L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Date date33 = week30.getEnd();
        java.util.Calendar calendar34 = null;
        try {
            long long35 = week30.getLastMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(date33);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
//        java.util.Date date9 = regularTimePeriod7.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
//        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 53);
//        int int22 = week21.getYearValue();
//        long long23 = week21.getSerialIndex();
//        java.lang.String str24 = week21.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week21.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week21.next();
//        boolean boolean28 = week21.equals((java.lang.Object) 0);
//        java.util.Date date29 = week21.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone30);
//        java.util.Locale locale33 = null;
//        try {
//            org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date2, timeZone30, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2844L + "'", long23 == 2844L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str8 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException4.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            week2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        java.lang.String str5 = week2.toString();
        int int6 = week2.getYearValue();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-60473664000001L) + "'", long7 == (-60473664000001L));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass21 = timePeriodFormatException20.getClass();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Class<?> wildcardClass25 = timePeriodFormatException5.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        long long33 = week30.getMiddleMillisecond();
        java.util.Calendar calendar34 = null;
        try {
            long long35 = week30.getFirstMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-60474571200001L) + "'", long33 == (-60474571200001L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        java.lang.String str8 = week6.toString();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone10);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        int int29 = week28.getYearValue();
        java.lang.String str30 = week28.toString();
        java.util.Date date31 = week28.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date31, timeZone34);
        java.lang.Class<?> wildcardClass36 = timeZone34.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone34);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 53);
        int int42 = week41.getYearValue();
        long long43 = week41.getSerialIndex();
        boolean boolean45 = week41.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date46 = week41.getStart();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.previous();
        java.lang.Class<?> wildcardClass51 = regularTimePeriod50.getClass();
        java.util.Date date52 = regularTimePeriod50.getEnd();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) '#', 53);
        int int56 = week55.getYearValue();
        java.lang.String str57 = week55.toString();
        java.util.Date date58 = week55.getEnd();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date52, timeZone59);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        java.lang.Class<?> wildcardClass66 = regularTimePeriod65.getClass();
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 53);
        int int70 = week69.getYearValue();
        java.lang.String str71 = week69.toString();
        java.util.Date date72 = week69.getEnd();
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date72, timeZone75);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date52, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date46, timeZone75);
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date46);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException81 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass82 = timePeriodFormatException81.getClass();
        boolean boolean83 = week79.equals((java.lang.Object) wildcardClass82);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 53 + "'", int42 == 53);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2844L + "'", long43 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 53 + "'", int56 == 53);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Week 35, 53" + "'", str57.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 53 + "'", int70 == 53);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Week 35, 53" + "'", str71.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Date date33 = week30.getEnd();
        long long34 = week30.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-60474268800001L) + "'", long34 == (-60474268800001L));
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        int int3 = week0.getYearValue();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 53);
        int int4 = week3.getYearValue();
        java.lang.String str5 = week3.toString();
        java.util.Date date6 = week3.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        long long17 = week15.getSerialIndex();
        java.lang.String str18 = week15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week15.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week15.next();
        boolean boolean22 = week15.equals((java.lang.Object) 0);
        java.util.Date date23 = week15.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date23, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date6, timeZone24);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        java.lang.Class<?> wildcardClass31 = regularTimePeriod30.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) '#', 53);
        int int35 = week34.getYearValue();
        java.lang.String str36 = week34.toString();
        java.util.Date date37 = week34.getEnd();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date37, timeZone38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date37, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone40);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 53 + "'", int4 == 53);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2844L + "'", long17 == 2844L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 35, 53" + "'", str18.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 53 + "'", int35 == 53);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 35, 53" + "'", str36.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        java.lang.Object obj8 = null;
        int int9 = week6.compareTo(obj8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 4, 0");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        java.util.Date date8 = regularTimePeriod6.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException11.getSuppressed();
        boolean boolean15 = week9.equals((java.lang.Object) timePeriodFormatException11);
        java.lang.String str16 = timePeriodFormatException11.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date18, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        long long29 = week27.getSerialIndex();
        boolean boolean31 = week27.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date32 = week27.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = regularTimePeriod36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date43, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date32, timeZone46);
        java.lang.Class<?> wildcardClass49 = timeZone46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date7, timeZone46);
        int int51 = week50.getYearValue();
        java.util.Date date52 = week50.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2844L + "'", long29 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 53 + "'", int51 == 53);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.util.Date date3 = null;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        java.lang.String str8 = week6.toString();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone10);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        int int29 = week28.getYearValue();
        java.lang.String str30 = week28.toString();
        java.util.Date date31 = week28.getEnd();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date31, timeZone34);
        java.lang.Class<?> wildcardClass36 = timeZone34.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone34);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.lang.Class<?> wildcardClass42 = regularTimePeriod41.getClass();
        java.util.Date date43 = regularTimePeriod41.getEnd();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', 53);
        int int47 = week46.getYearValue();
        java.lang.String str48 = week46.toString();
        java.util.Date date49 = week46.getEnd();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49, timeZone50);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date43, timeZone50);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date43);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
        java.lang.Class<?> wildcardClass58 = regularTimePeriod57.getClass();
        java.util.Date date59 = regularTimePeriod57.getEnd();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date59);
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.previous();
        java.lang.Class<?> wildcardClass65 = regularTimePeriod64.getClass();
        java.util.Date date66 = regularTimePeriod64.getEnd();
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 53);
        int int70 = week69.getYearValue();
        java.lang.String str71 = week69.toString();
        java.util.Date date72 = week69.getEnd();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date72, timeZone73);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date66, timeZone73);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = week78.previous();
        java.lang.Class<?> wildcardClass80 = regularTimePeriod79.getClass();
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week((int) '#', 53);
        int int84 = week83.getYearValue();
        java.lang.String str85 = week83.toString();
        java.util.Date date86 = week83.getEnd();
        java.util.TimeZone timeZone87 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date86, timeZone87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date86, timeZone89);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date66, timeZone89);
        java.lang.Class<?> wildcardClass92 = timeZone89.getClass();
        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date59, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date43, timeZone89);
        java.lang.Class class95 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class96 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 35, 53" + "'", str8.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 53 + "'", int29 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 35, 53" + "'", str30.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 53 + "'", int47 == 53);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 35, 53" + "'", str48.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 53 + "'", int70 == 53);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Week 35, 53" + "'", str71.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 53 + "'", int84 == 53);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "Week 35, 53" + "'", str85.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertNotNull(class95);
        org.junit.Assert.assertNotNull(class96);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 35);
        long long3 = week2.getSerialIndex();
        boolean boolean5 = week2.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1856L + "'", long3 == 1856L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getFirstMillisecond();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.util.Date date11 = regularTimePeriod9.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException14.getSuppressed();
        boolean boolean18 = week12.equals((java.lang.Object) timePeriodFormatException14);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        int int9 = week2.getYearValue();
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        java.util.Date date16 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        int int20 = week19.getYearValue();
        java.lang.String str21 = week19.toString();
        java.util.Date date22 = week19.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date16, timeZone23);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        int int34 = week33.getYearValue();
        java.lang.String str35 = week33.toString();
        java.util.Date date36 = week33.getEnd();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date36, timeZone37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date36, timeZone39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date16, timeZone39);
        long long42 = week41.getSerialIndex();
        int int43 = week41.getYearValue();
        java.util.Date date44 = week41.getEnd();
        boolean boolean45 = week2.equals((java.lang.Object) week41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 35, 53" + "'", str21.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 53" + "'", str35.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2843L + "'", long42 == 2843L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        long long31 = week30.getSerialIndex();
        int int32 = week30.getYearValue();
        java.util.Date date33 = week30.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week30.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2843L + "'", long31 == 2843L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getSerialIndex();
//        java.util.Date date5 = week3.getEnd();
//        long long6 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((-1966), year7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        boolean boolean9 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        long long13 = week2.getFirstMillisecond();
        long long14 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-60474268800000L) + "'", long13 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60474268800000L) + "'", long14 == (-60474268800000L));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        java.lang.String str8 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException1.getClass();
        java.lang.String str10 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        long long15 = week14.getSerialIndex();
        java.util.Date date16 = week14.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
        int int26 = week25.getYearValue();
        long long27 = week25.getSerialIndex();
        java.lang.String str28 = week25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week25.next();
        boolean boolean32 = week25.equals((java.lang.Object) 0);
        java.util.Date date33 = week25.getEnd();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date33, timeZone34);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date33);
        int int38 = week36.compareTo((java.lang.Object) (-1));
        int int39 = week36.getYearValue();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 53);
        int int43 = week42.getYearValue();
        java.lang.String str44 = week42.toString();
        java.util.Date date45 = week42.getEnd();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
        java.lang.Class<?> wildcardClass50 = regularTimePeriod49.getClass();
        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 53);
        int int55 = week54.getYearValue();
        long long56 = week54.getSerialIndex();
        java.lang.String str57 = week54.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week54.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week54.next();
        boolean boolean61 = week54.equals((java.lang.Object) 0);
        java.util.Date date62 = week54.getEnd();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date62, timeZone63);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date45, timeZone63);
        boolean boolean66 = week36.equals((java.lang.Object) timeZone63);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date16, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
        int int69 = week67.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2844L + "'", long27 == 2844L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 35, 53" + "'", str28.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 53 + "'", int39 == 53);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 35, 53" + "'", str44.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 53 + "'", int55 == 53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2844L + "'", long56 == 2844L);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Week 35, 53" + "'", str57.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 53 + "'", int69 == 53);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        java.util.Date date3 = week1.getEnd();
//        long long4 = week1.getLastMillisecond();
//        java.lang.String str5 = week1.toString();
//        long long6 = week1.getSerialIndex();
//        org.jfree.data.time.Year year7 = week1.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year7);
//        long long9 = year7.getMiddleMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = year7.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 35);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61063041600001L) + "'", long3 == (-61063041600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61062739200001L) + "'", long4 == (-61062739200001L));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 6, 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        long long15 = week14.getFirstMillisecond();
        int int17 = week14.compareTo((java.lang.Object) 10);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week14.getMiddleMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-60474873600000L) + "'", long15 == (-60474873600000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        long long9 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(1, 6);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 53);
        int int21 = week20.getYearValue();
        java.lang.String str22 = week20.toString();
        java.util.Date date23 = week20.getEnd();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date23, timeZone26);
        java.lang.Class<?> wildcardClass28 = timeZone26.getClass();
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        boolean boolean31 = week12.equals((java.lang.Object) class30);
        boolean boolean32 = week2.equals((java.lang.Object) class30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60473664000001L) + "'", long8 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473966400001L) + "'", long9 == (-60473966400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 35, 53" + "'", str22.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 4);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 265L + "'", long4 == 265L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        int int6 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getFirstMillisecond();
        java.lang.String str9 = week2.toString();
        int int10 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60474268800000L) + "'", long8 == (-60474268800000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 53);
        int int8 = week7.getYearValue();
        java.lang.String str9 = week7.toString();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10, timeZone13);
        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 53);
        int int22 = week21.getYearValue();
        long long23 = week21.getSerialIndex();
        java.lang.String str24 = week21.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week21.next();
        boolean boolean28 = week21.equals((java.lang.Object) 0);
        java.util.Date date29 = week21.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str34 = week33.toString();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        int int38 = week37.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week37.next();
        int int40 = week37.getYearValue();
        boolean boolean41 = week33.equals((java.lang.Object) int40);
        java.util.Date date42 = week33.getEnd();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', 53);
        int int46 = week45.getYearValue();
        long long47 = week45.getSerialIndex();
        boolean boolean49 = week45.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date50 = week45.getStart();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.previous();
        java.lang.Class<?> wildcardClass55 = regularTimePeriod54.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) '#', 53);
        int int59 = week58.getYearValue();
        java.lang.String str60 = week58.toString();
        java.util.Date date61 = week58.getEnd();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date61, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date50, timeZone64);
        java.lang.Class<?> wildcardClass67 = timeZone64.getClass();
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date42, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date29, timeZone64);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 53" + "'", str9.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2844L + "'", long23 == 2844L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 35, 53" + "'", str34.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 53 + "'", int40 == 53);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 53 + "'", int46 == 53);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2844L + "'", long47 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 53 + "'", int59 == 53);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Week 35, 53" + "'", str60.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNull(regularTimePeriod69);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) '#', 53);
        int int7 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        boolean boolean10 = week2.equals((java.lang.Object) int9);
        java.lang.Object obj11 = null;
        boolean boolean12 = week2.equals(obj11);
        java.util.Date date13 = week2.getEnd();
        int int14 = week2.getYearValue();
        long long15 = week2.getSerialIndex();
        long long16 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-60473664000001L) + "'", long16 == (-60473664000001L));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass1 = timeZone0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize(class2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class2);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException6.getSuppressed();
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException6.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str17 = timePeriodFormatException16.toString();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str20 = timePeriodFormatException13.toString();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
//        java.util.Date date7 = week2.getStart();
//        int int8 = week2.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        boolean boolean12 = week2.equals((java.lang.Object) date11);
//        int int13 = week2.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
//        long long15 = week2.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 53 + "'", int8 == 53);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2844L + "'", long15 == 2844L);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        java.lang.String str11 = week8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
        boolean boolean15 = week8.equals((java.lang.Object) 0);
        java.util.Date date16 = week8.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
        int int21 = week19.compareTo((java.lang.Object) (-1));
        int int22 = week19.getYearValue();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 53);
        int int26 = week25.getYearValue();
        java.lang.String str27 = week25.toString();
        java.util.Date date28 = week25.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
        java.lang.Class<?> wildcardClass33 = regularTimePeriod32.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) '#', 53);
        int int38 = week37.getYearValue();
        long long39 = week37.getSerialIndex();
        java.lang.String str40 = week37.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week37.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week37.next();
        boolean boolean44 = week37.equals((java.lang.Object) 0);
        java.util.Date date45 = week37.getEnd();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date45, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date28, timeZone46);
        boolean boolean49 = week19.equals((java.lang.Object) timeZone46);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 53);
        int int53 = week52.getYearValue();
        long long54 = week52.getSerialIndex();
        java.lang.String str55 = week52.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week52.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week52.previous();
        java.util.Date date58 = week52.getStart();
        java.util.Date date59 = week52.getEnd();
        boolean boolean60 = week19.equals((java.lang.Object) date59);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale62 = null;
        try {
            org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date59, timeZone61, locale62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2844L + "'", long10 == 2844L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 35, 53" + "'", str11.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 53 + "'", int26 == 53);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 35, 53" + "'", str27.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2844L + "'", long39 == 2844L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 35, 53" + "'", str40.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2844L + "'", long54 == 2844L);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 35, 53" + "'", str55.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(timeZone61);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Date date7 = week6.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        long long9 = week6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 53" + "'", str4.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473664000001L) + "'", long9 == (-60473664000001L));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getWeek();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getSerialIndex();
        long long7 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        long long9 = week2.getLastMillisecond();
        int int10 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 53" + "'", str3.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 35, 53" + "'", str5.equals("Week 35, 53"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2844L + "'", long6 == 2844L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2844L + "'", long7 == 2844L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60473664000001L) + "'", long9 == (-60473664000001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getMiddleMillisecond();
        java.util.Date date6 = week2.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62136561600001L) + "'", long5 == (-62136561600001L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 53);
        int int9 = week8.getYearValue();
        java.lang.String str10 = week8.toString();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 53);
        int int23 = week22.getYearValue();
        java.lang.String str24 = week22.toString();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone28);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException33.getClass();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException33.getSuppressed();
        java.lang.Class<?> wildcardClass36 = timePeriodFormatException33.getClass();
        boolean boolean37 = week31.equals((java.lang.Object) timePeriodFormatException33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week31.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 35, 53" + "'", str10.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 35, 53" + "'", str24.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 53");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str8 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 35, 53" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 35, 53"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date18, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        long long29 = week27.getSerialIndex();
        boolean boolean31 = week27.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date32 = week27.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = regularTimePeriod36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date43, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date32, timeZone46);
        java.lang.Class<?> wildcardClass49 = timeZone46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date7, timeZone46);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
        int int54 = week53.getYearValue();
        java.lang.String str55 = week53.toString();
        java.util.Date date56 = week53.getEnd();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.previous();
        java.lang.Class<?> wildcardClass61 = regularTimePeriod60.getClass();
        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week((int) '#', 53);
        int int66 = week65.getYearValue();
        long long67 = week65.getSerialIndex();
        java.lang.String str68 = week65.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = week65.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week65.next();
        boolean boolean72 = week65.equals((java.lang.Object) 0);
        java.util.Date date73 = week65.getEnd();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date73, timeZone74);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date56, timeZone74);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date7, timeZone74);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2844L + "'", long29 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 53 + "'", int54 == 53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 35, 53" + "'", str55.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(class62);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 53 + "'", int66 == 53);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2844L + "'", long67 == 2844L);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Week 35, 53" + "'", str68.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 53);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) '#', 53);
        int int16 = week15.getYearValue();
        java.lang.String str17 = week15.toString();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date18, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 53);
        int int28 = week27.getYearValue();
        long long29 = week27.getSerialIndex();
        boolean boolean31 = week27.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date32 = week27.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = regularTimePeriod36.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 53);
        int int41 = week40.getYearValue();
        java.lang.String str42 = week40.toString();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date43, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date32, timeZone46);
        java.lang.Class<?> wildcardClass49 = timeZone46.getClass();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date7, timeZone46);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 53);
        int int54 = week53.getYearValue();
        long long55 = week53.getSerialIndex();
        boolean boolean57 = week53.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Week 35, 53");
        java.util.Date date58 = week53.getStart();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week((int) '#', 53);
        int int67 = week66.getYearValue();
        java.lang.String str68 = week66.toString();
        java.util.Date date69 = week66.getEnd();
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date69, timeZone70);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date69, timeZone72);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date58, timeZone72);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date7, timeZone72);
        java.lang.String str76 = week75.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2844L + "'", long4 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 35, 53" + "'", str17.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2844L + "'", long29 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 35, 53" + "'", str42.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 53 + "'", int54 == 53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2844L + "'", long55 == 2844L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Week 35, 53" + "'", str68.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Week 35, 53" + "'", str76.equals("Week 35, 53"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 6);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', 53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 53);
        int int11 = week10.getYearValue();
        java.lang.String str12 = week10.toString();
        java.util.Date date13 = week10.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date13, timeZone16);
        java.lang.Class<?> wildcardClass18 = timeZone16.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        boolean boolean21 = week2.equals((java.lang.Object) class20);
        java.lang.String str22 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 53 + "'", int11 == 53);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 35, 53" + "'", str12.equals("Week 35, 53"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 1, 6" + "'", str22.equals("Week 1, 6"));
    }
}

