import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(5, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) ' ', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1900, (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries4.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        try {
            timeSeries4.update(3, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries4.add(regularTimePeriod10, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy(regularTimePeriod11, regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        try {
            java.lang.Number number12 = timeSeries4.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        timeSeries4.setMaximumItemAge((long) 4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(6, (int) ' ', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        try {
            timeSeries4.delete(2958465, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.setKey((java.lang.Comparable) (byte) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Saturday" + "'", str1.equals("Saturday"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        java.lang.String str10 = regularTimePeriod9.toString();
//        try {
//            timeSeries4.add(regularTimePeriod9, (java.lang.Number) 1L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-June-2019" + "'", str10.equals("9-June-2019"));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        long long10 = year6.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 1.0d);
        try {
            timeSeries4.add(timeSeriesDataItem12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        java.lang.Class<?> wildcardClass3 = month1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        java.lang.String str7 = year5.toString();
        java.lang.String str8 = year5.toString();
        long long9 = year5.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1.0d);
        try {
            timeSeries4.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int2 = day0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        timeSeriesDataItem6.setValue((java.lang.Number) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        long long8 = month5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            java.lang.Number number12 = timeSeries4.getValue(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        try {
            timeSeries1.update((int) (byte) 1, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDescription();
        try {
            timeSeries4.removeAgedItems((long) 2958465, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        long long10 = year6.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 1.0d);
        long long13 = year6.getFirstMillisecond();
        java.lang.Number number14 = null;
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) year6, number14);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getYearValue();
        boolean boolean9 = timeSeriesDataItem6.equals((java.lang.Object) month7);
        java.lang.String str10 = month7.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(7, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate4.getPreviousDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("10-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        boolean boolean5 = year0.equals((java.lang.Object) 0.0d);
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month7);
        int int10 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.setKey((java.lang.Comparable) (byte) 1);
        java.lang.String str12 = timeSeries4.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        int int12 = timeSeries4.getIndex(regularTimePeriod10);
        try {
            java.lang.Number number14 = timeSeries4.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1563303599999L + "'", long11 == 1563303599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener10);
        timeSeries4.setMaximumItemCount((int) (byte) 100);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2958465, serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        java.lang.String str13 = year11.toString();
        java.lang.String str14 = year11.toString();
        long long15 = year11.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 1.0d);
        try {
            timeSeries4.add(timeSeriesDataItem17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("");
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries4.createCopy((-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        long long7 = year5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date4, timeZone10);
//        java.util.TimeZone timeZone13 = null;
//        try {
//            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date4, timeZone13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        try {
            timeSeries4.removeAgedItems((long) 9999, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        boolean boolean8 = timeSeries7.isEmpty();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(5, 0);
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month5.toString();
        java.util.Date date9 = month5.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month5.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
        try {
            timeSeries4.add(regularTimePeriod18, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("");
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class17);
        timeSeries18.clear();
        java.lang.String str20 = timeSeries18.getDescription();
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        java.lang.String str24 = year22.toString();
        java.lang.String str25 = year22.toString();
        int int26 = year22.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = year27.getYear();
        java.lang.String str29 = year27.toString();
        java.lang.String str30 = year27.toString();
        java.lang.String str31 = year27.toString();
        long long32 = year27.getFirstMillisecond();
        long long33 = year27.getFirstMillisecond();
        int int34 = year22.compareTo((java.lang.Object) year27);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 1563303599999L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
//        boolean boolean8 = timeSeries4.getNotify();
//        boolean boolean9 = timeSeries4.getNotify();
//        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
//        java.lang.String str11 = timeSeries4.getDomainDescription();
//        timeSeries4.setDomainDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
//        java.lang.Number number16 = timeSeries4.getValue(regularTimePeriod15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.previous();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day17, (double) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNull(class10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int20 = year19.getYear();
        java.lang.String str21 = year19.toString();
        java.lang.String str22 = year19.toString();
        java.lang.String str23 = year19.toString();
        long long24 = year19.getFirstMillisecond();
        long long25 = year19.getFirstMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(7, year19);
        java.lang.Number number27 = null;
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year19, number27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.createCopy(10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.previous();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.lang.String str5 = year1.toString();
        long long6 = year1.getFirstMillisecond();
        long long7 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(7, year1);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year1.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("9-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Date date4 = day2.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(5, serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        java.util.Date date10 = day8.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str14 = serialDate7.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(31, serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
        try {
            timeSeries4.add(regularTimePeriod18, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        java.lang.String str4 = year2.toString();
        java.lang.String str5 = year2.toString();
        long long6 = year2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 1.0d);
        long long9 = year2.getFirstMillisecond();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        java.lang.String str13 = year10.toString();
        long long14 = year10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getYearValue();
        boolean boolean19 = timeSeriesDataItem16.equals((java.lang.Object) month17);
        boolean boolean20 = year2.equals((java.lang.Object) boolean19);
        boolean boolean21 = month0.equals((java.lang.Object) year2);
        java.util.Calendar calendar22 = null;
        try {
            year2.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.setKey((java.lang.Comparable) (byte) 1);
        java.lang.String str12 = timeSeries4.getDescription();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month18);
        java.util.Collection collection21 = timeSeries17.getTimePeriods();
        java.lang.String str22 = timeSeries17.getDomainDescription();
        java.util.Collection collection23 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        java.lang.String str26 = year24.toString();
        java.lang.String str27 = year24.toString();
        long long28 = year24.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 1.0d);
        int int32 = timeSeriesDataItem30.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj33 = timeSeriesDataItem30.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem30.getPeriod();
        try {
            timeSeries4.add(regularTimePeriod34, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 9999, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemAge((long) 11);
        java.lang.String str13 = timeSeries4.getDescription();
        java.lang.String str14 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = null;
        try {
            timeSeries4.add(timeSeriesDataItem6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Date date5 = day3.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(7, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(1, serialDate7);
        int int9 = month0.compareTo((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date4, timeZone10);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = month12.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Date date4 = day2.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(7, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate5);
        java.lang.String str8 = serialDate5.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.setKey((java.lang.Comparable) (byte) 1);
        java.lang.String str12 = timeSeries4.getDescription();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month18);
        java.util.Collection collection21 = timeSeries17.getTimePeriods();
        java.lang.String str22 = timeSeries17.getDomainDescription();
        java.util.Collection collection23 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener24);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries17.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(collection23);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
//        int int8 = timeSeries7.getItemCount();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        java.lang.String str11 = day9.toString();
//        int int12 = day9.getYear();
//        java.util.Date date13 = day9.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        java.util.Date date16 = day14.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16, timeZone19);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date13, timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
//        int int23 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
//        int int24 = month21.getMonth();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        java.lang.Class<?> wildcardClass5 = month3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries(comparable0, "9-June-2019", "org.jfree.data.general.SeriesChangeEvent[source=1]", (java.lang.Class) wildcardClass5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Date date5 = day3.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(7, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(1, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, serialDate8);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(7, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(1, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = serialDate8.getEndOfCurrentMonth(serialDate17);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        timeSeries11.setMaximumItemCount(100);
        boolean boolean16 = timeSeries11.isEmpty();
        java.util.Collection collection17 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = year18.getYear();
        java.lang.String str20 = year18.toString();
        java.lang.String str21 = year18.toString();
        int int22 = year18.getYear();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        java.lang.String str25 = year23.toString();
        java.lang.String str26 = year23.toString();
        java.lang.String str27 = year23.toString();
        long long28 = year23.getFirstMillisecond();
        long long29 = year23.getFirstMillisecond();
        int int30 = year18.compareTo((java.lang.Object) year23);
        try {
            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 10.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDescription("June 2019");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        boolean boolean8 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
//        java.util.Date date14 = regularTimePeriod13.getStart();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, regularTimePeriod13);
//        timeSeries1.removeAgedItems((long) 5, true);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            year2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12, 11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = timeSeries3.equals(obj5);
//        int int7 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries3);
//        long long8 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getFirstMillisecond(calendar9);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2019L + "'", comparable4.equals(2019L));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190500484L + "'", long8 == 1560190500484L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560190500484L + "'", long10 == 1560190500484L);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = month5.toString();
        java.util.Date date9 = month5.getStart();
        java.lang.String str10 = month5.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getLastMillisecond();
        int int5 = month3.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        long long11 = fixedMillisecond8.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = timeSeries3.equals(obj5);
//        int int7 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries3);
//        long long8 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        int int10 = fixedMillisecond0.compareTo((java.lang.Object) year9);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = year9.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2019L + "'", comparable4.equals(2019L));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190500898L + "'", long8 == 1560190500898L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        try {
            java.lang.Number number9 = timeSeries4.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        java.lang.String str9 = year7.toString();
        java.lang.String str10 = year7.toString();
        long long11 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 1.0d);
        timeSeriesDataItem13.setValue((java.lang.Number) (short) 1);
        try {
            timeSeries4.add(timeSeriesDataItem13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate3.getPreviousDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setMaximumItemCount(100);
        java.util.Collection collection9 = timeSeries4.getTimePeriods();
        timeSeries4.clear();
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.Comparable comparable6 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        java.lang.String str8 = regularTimePeriod6.toString();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-June-2019" + "'", str8.equals("9-June-2019"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        boolean boolean4 = month0.equals((java.lang.Object) 7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        int int10 = month8.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setMaximumItemCount(100);
        boolean boolean9 = timeSeries4.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries4.createCopy(8, 2019);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = year13.getYear();
        java.lang.String str15 = year13.toString();
        java.lang.String str16 = year13.toString();
        long long17 = year13.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 1.0d);
        int int21 = timeSeriesDataItem19.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj22 = timeSeriesDataItem19.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem19.getPeriod();
        try {
            timeSeries4.add(timeSeriesDataItem19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        java.lang.String str4 = year2.toString();
        java.lang.String str5 = year2.toString();
        long long6 = year2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 1.0d);
        long long9 = year2.getFirstMillisecond();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        java.lang.String str13 = year10.toString();
        long long14 = year10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getYearValue();
        boolean boolean19 = timeSeriesDataItem16.equals((java.lang.Object) month17);
        boolean boolean20 = year2.equals((java.lang.Object) boolean19);
        boolean boolean21 = month0.equals((java.lang.Object) year2);
        java.util.Calendar calendar22 = null;
        try {
            month0.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date4, timeZone10);
//        int int13 = year12.getYear();
//        long long14 = year12.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        timeSeries1.removeAgedItems((long) 5, false);
//        java.lang.String str11 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
//        try {
//            int int13 = timeSeries1.getIndex(regularTimePeriod12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) ' ');
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.util.Date date3 = regularTimePeriod2.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.setDescription("hi!");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        java.lang.String str14 = year12.toString();
        java.lang.String str15 = year12.toString();
        long long16 = year12.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 1.0d);
        int int20 = timeSeriesDataItem18.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj21 = timeSeriesDataItem18.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem18.getPeriod();
        java.lang.Object obj23 = null;
        boolean boolean24 = timeSeriesDataItem18.equals(obj23);
        try {
            timeSeries4.add(timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.setDescription("hi!");
        timeSeries4.setMaximumItemAge((long) (short) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        try {
            java.lang.Number number9 = timeSeries4.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        int int8 = timeSeries7.getItemCount();
        timeSeries7.fireSeriesChanged();
        try {
            timeSeries7.delete((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        int int8 = timeSeries7.getItemCount();
        timeSeries7.fireSeriesChanged();
        try {
            java.lang.Number number11 = timeSeries7.getValue(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        int int8 = timeSeries7.getItemCount();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        boolean boolean17 = timeSeries13.getNotify();
        java.util.Collection collection18 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        try {
            timeSeries7.update(2958465, (java.lang.Number) 1560754800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        timeSeries15.setRangeDescription("Value");
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        serialDate4.setDescription("org.jfree.data.general.SeriesException: ");
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1900, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        java.lang.Class<?> wildcardClass3 = month1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        java.util.List list6 = timeSeries4.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        long long5 = month3.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        java.lang.String str13 = year10.toString();
        long long14 = year10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1.0d);
        int int18 = timeSeriesDataItem16.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj19 = timeSeriesDataItem16.clone();
        int int21 = timeSeriesDataItem16.compareTo((java.lang.Object) 9999);
        try {
            timeSeries4.add(timeSeriesDataItem16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        java.lang.Class<?> wildcardClass5 = month3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries(comparable0, "17-June-2019", "Following", (java.lang.Class) wildcardClass5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDescription();
        try {
            timeSeries4.delete(2958253, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(str11);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date4, timeZone10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        java.util.Date date15 = day13.getEnd();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date15, timeZone18);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date4, timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeZone18);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemAge((long) 11);
        timeSeries4.removeAgedItems(false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        timeSeries1.removeAgedItems((long) 5, false);
//        java.lang.String str11 = timeSeries1.getRangeDescription();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Date date5 = day3.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(7, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(1, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate8.getPreviousDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 1);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (byte) 1 + "'", obj2.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 1 + "'", obj3.equals((byte) 1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("");
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class17);
        timeSeries18.clear();
        java.lang.String str20 = timeSeries18.getDescription();
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries4.removeChangeListener(seriesChangeListener22);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries4.update(regularTimePeriod12, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        int int8 = timeSeries7.getItemCount();
        timeSeries7.fireSeriesChanged();
        long long10 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 0.0d + "'", obj2.equals(0.0d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        java.lang.Class<?> wildcardClass3 = month1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass3);
//        timeSeries4.setRangeDescription("Saturday");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj9 = timeSeries8.clone();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.previous();
//        timeSeries8.delete(regularTimePeriod13);
//        boolean boolean15 = timeSeries8.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.previous();
//        java.util.Date date21 = regularTimePeriod20.getStart();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.getDataItem(regularTimePeriod20);
//        timeSeries4.setNotify(true);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        try {
            java.lang.Number number3 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class9);
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) class9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        java.util.Date date5 = day3.getEnd();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(7, serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(1, serialDate7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, serialDate8);
//        java.lang.String str10 = serialDate8.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate12 = serialDate8.getPreviousDayOfWeek(9999);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "18-June-2019" + "'", str10.equals("18-June-2019"));
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        try {
            timeSeries4.removeAgedItems(1560150000000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setMaximumItemCount(100);
        java.util.Collection collection9 = timeSeries4.getTimePeriods();
        java.util.List list10 = timeSeries4.getItems();
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        java.lang.Class<?> wildcardClass3 = month1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        java.lang.String str9 = year7.toString();
        java.lang.String str10 = year7.toString();
        long long11 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 1.0d);
        int int15 = timeSeriesDataItem13.compareTo((java.lang.Object) 100.0f);
        try {
            timeSeries4.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        int int12 = timeSeries4.getIndex(regularTimePeriod10);
        java.lang.String str13 = regularTimePeriod10.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1563303599999L + "'", long11 == 1563303599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "July 2019" + "'", str13.equals("July 2019"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(7, serialDate4);
        java.lang.String str6 = serialDate4.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long3 = fixedMillisecond2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond2.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        boolean boolean10 = fixedMillisecond2.equals((java.lang.Object) year8);
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 100, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.lang.String str5 = year1.toString();
        long long6 = year1.getFirstMillisecond();
        long long7 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(7, year1);
        java.util.Calendar calendar9 = null;
        try {
            year1.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj9 = timeSeriesDataItem6.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem6.getPeriod();
        java.util.Date date12 = regularTimePeriod11.getStart();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.lang.Object obj5 = null;
        boolean boolean6 = timeSeries3.equals(obj5);
        int int7 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries3);
        timeSeries3.setMaximumItemCount(6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2019L + "'", comparable4.equals(2019L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        int int10 = month8.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.addAndOrUpdate(timeSeries18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        int int9 = month8.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0.0f);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getDayOfMonth();
//        int int14 = day12.getMonth();
//        long long15 = day12.getFirstMillisecond();
//        timeSeries4.setKey((java.lang.Comparable) day12);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj19 = timeSeries18.clone();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getLastMillisecond();
//        long long22 = day20.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.previous();
//        timeSeries18.delete(regularTimePeriod23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getDayOfMonth();
//        int int27 = day25.getMonth();
//        long long28 = day25.getFirstMillisecond();
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day25, (double) 2147483647);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day25, 0.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560150000000L + "'", long28 == 1560150000000L);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190510924L + "'", long2 == 1560190510924L);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        long long7 = year0.getFirstMillisecond();
        long long8 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries15.createCopy(0, 7);
        timeSeries15.setMaximumItemCount(12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        java.util.Date date7 = day5.getEnd();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(7, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(1, serialDate9);
        boolean boolean11 = spreadsheetDate1.isOnOrAfter(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        boolean boolean14 = spreadsheetDate1.isOnOrAfter(serialDate13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Date date5 = month0.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        int int5 = timeSeries4.getItemCount();
//        long long6 = timeSeries4.getMaximumItemAge();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getLastMillisecond();
//        long long9 = day7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day7.previous();
//        int int11 = day7.getDayOfMonth();
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day7);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNull(number12);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(0, year5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        int int2 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDescription("June 2019");
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        timeSeries9.setRangeDescription("hi!");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        long long16 = regularTimePeriod15.getMiddleMillisecond();
        int int17 = timeSeries9.getIndex(regularTimePeriod15);
        java.util.Date date18 = regularTimePeriod15.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (-1L));
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 1560190500484L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1563303599999L + "'", long16 == 1563303599999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(43633L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        boolean boolean8 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
//        java.util.Date date14 = regularTimePeriod13.getStart();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, regularTimePeriod13);
//        timeSeries15.setDomainDescription("18-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj20 = timeSeries19.clone();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        long long23 = day21.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
//        timeSeries19.delete(regularTimePeriod24);
//        timeSeries15.add(regularTimePeriod24, (java.lang.Number) 1560668399999L);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        timeSeries1.removeAgedItems((long) 5, false);
//        java.lang.String str11 = timeSeries1.getRangeDescription();
//        java.util.List list12 = timeSeries1.getItems();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
//        org.junit.Assert.assertNotNull(list12);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        java.util.Date date5 = day3.getEnd();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(7, serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(1, serialDate7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, serialDate8);
//        java.lang.String str10 = serialDate8.toString();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        java.util.Date date15 = day13.getEnd();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(5, serialDate17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        java.util.Date date21 = day19.getEnd();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate18.getEndOfCurrentMonth(serialDate23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(10, serialDate23);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate8.getEndOfCurrentMonth(serialDate25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "18-June-2019" + "'", str10.equals("18-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        java.util.Collection collection26 = timeSeries22.getTimePeriods();
        java.lang.String str27 = timeSeries22.getRangeDescription();
        timeSeries22.setKey((java.lang.Comparable) (byte) 1);
        java.lang.String str30 = timeSeries22.getDescription();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
        java.lang.Number number38 = timeSeries35.getValue((org.jfree.data.time.RegularTimePeriod) month36);
        java.util.Collection collection39 = timeSeries35.getTimePeriods();
        java.lang.String str40 = timeSeries35.getDomainDescription();
        java.util.Collection collection41 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        boolean boolean42 = timeSeries15.equals((java.lang.Object) timeSeries22);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries15.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone6);
        int int8 = month7.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        int int6 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        java.util.Collection collection26 = timeSeries22.getTimePeriods();
        java.lang.String str27 = timeSeries22.getRangeDescription();
        timeSeries22.setKey((java.lang.Comparable) (byte) 1);
        java.lang.String str30 = timeSeries22.getDescription();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
        java.lang.Number number38 = timeSeries35.getValue((org.jfree.data.time.RegularTimePeriod) month36);
        java.util.Collection collection39 = timeSeries35.getTimePeriods();
        java.lang.String str40 = timeSeries35.getDomainDescription();
        java.util.Collection collection41 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        boolean boolean42 = timeSeries15.equals((java.lang.Object) timeSeries22);
        java.util.List list43 = timeSeries15.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(list43);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemAge((long) 11);
        java.lang.String str13 = timeSeries4.getDescription();
        java.lang.Comparable comparable14 = timeSeries4.getKey();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int16 = year15.getYear();
        java.lang.String str17 = year15.toString();
        java.lang.String str18 = year15.toString();
        long long19 = year15.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 1.0d);
        try {
            timeSeries4.add(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 0.0f + "'", comparable14.equals(0.0f));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getYearValue();
        boolean boolean9 = timeSeriesDataItem6.equals((java.lang.Object) month7);
        java.lang.Number number10 = timeSeriesDataItem6.getValue();
        java.lang.Object obj11 = timeSeriesDataItem6.clone();
        java.lang.Object obj12 = timeSeriesDataItem6.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.0d + "'", number10.equals(1.0d));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.util.List list3 = timeSeries1.getItems();
        try {
            java.lang.Number number5 = timeSeries1.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 2019L + "'", comparable2.equals(2019L));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("July 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj9 = timeSeriesDataItem6.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem6.getPeriod();
        int int13 = timeSeriesDataItem6.compareTo((java.lang.Object) 9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Date date5 = day3.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(5, serialDate7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        java.util.Date date11 = day9.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((-1), serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(11, serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Date date5 = day3.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(7, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(1, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getPreviousDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        long long6 = timeSeries4.getMaximumItemAge();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        java.lang.String str9 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year7, regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class6);
        int int8 = timeSeries7.getItemCount();
        boolean boolean9 = month0.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long12 = fixedMillisecond11.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond11.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond11.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond11.previous();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        java.util.Date date9 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(7, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(1, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate12);
        boolean boolean14 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate13);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class18);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy(2, 4);
        int int23 = timeSeries22.getItemCount();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month29);
        boolean boolean32 = timeSeries28.getNotify();
        java.util.Collection collection33 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        java.lang.String str34 = timeSeries22.getRangeDescription();
        try {
            int int35 = spreadsheetDate3.compareTo((java.lang.Object) timeSeries22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        int int20 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        java.util.Date date26 = day24.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date26);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(5, serialDate28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
        java.util.Date date32 = day30.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.SerialDate serialDate35 = serialDate29.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
        java.util.Date date46 = day44.getEnd();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(5, serialDate48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
        java.util.Date date52 = day50.getEnd();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date52);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date52);
        org.jfree.data.time.SerialDate serialDate55 = serialDate49.getEndOfCurrentMonth(serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate49);
        boolean boolean57 = spreadsheetDate41.isOnOrAfter(serialDate49);
        java.lang.String str58 = spreadsheetDate41.getDescription();
        boolean boolean59 = spreadsheetDate3.isInRange(serialDate35, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.lang.Object obj60 = null;
        try {
            int int61 = spreadsheetDate3.compareTo(obj60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9999 + "'", int20 == 9999);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        java.util.Date date20 = spreadsheetDate3.toDate();
        int int21 = spreadsheetDate3.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        timeSeries4.setNotify(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries4.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class6);
        int int8 = timeSeries7.getItemCount();
        boolean boolean9 = month0.equals((java.lang.Object) timeSeries7);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("18-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class7);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(2, 4);
//        int int12 = timeSeries11.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.addChangeListener(seriesChangeListener13);
//        int int15 = day0.compareTo((java.lang.Object) timeSeries11);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (double) 1900);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        timeSeriesDataItem6.setValue((java.lang.Number) (short) 1);
        timeSeriesDataItem6.setValue((java.lang.Number) 24234L);
        java.lang.Number number11 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 24234L + "'", number11.equals(24234L));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getFirstMillisecond();
        long long6 = year0.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        java.lang.String str4 = year2.toString();
        java.lang.String str5 = year2.toString();
        long long6 = year2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 1.0d);
        long long9 = year2.getFirstMillisecond();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        java.lang.String str13 = year10.toString();
        long long14 = year10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getYearValue();
        boolean boolean19 = timeSeriesDataItem16.equals((java.lang.Object) month17);
        boolean boolean20 = year2.equals((java.lang.Object) boolean19);
        boolean boolean21 = month0.equals((java.lang.Object) year2);
        long long22 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.Object obj3 = null;
        boolean boolean4 = timeSeries1.equals(obj3);
        java.lang.Object obj5 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 2019L + "'", comparable2.equals(2019L));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj9 = timeSeriesDataItem6.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries12.update(regularTimePeriod13, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        java.lang.Class<?> wildcardClass14 = month12.getClass();
        java.lang.String str15 = month12.toString();
        org.jfree.data.time.Year year16 = month12.getYear();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        java.lang.Class<?> wildcardClass21 = month19.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16, "hi!", "hi!", class22);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "2019", "June 2019", class22);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month7.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        java.lang.Class<?> wildcardClass9 = month7.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year4, "hi!", "hi!", class10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year4.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        boolean boolean8 = timeSeries1.isEmpty();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class12);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month14);
//        boolean boolean17 = timeSeries13.getNotify();
//        boolean boolean18 = timeSeries13.getNotify();
//        java.lang.Class class19 = timeSeries13.getTimePeriodClass();
//        java.lang.String str20 = timeSeries13.getDomainDescription();
//        timeSeries13.setDomainDescription("");
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class26);
//        timeSeries27.clear();
//        java.lang.String str29 = timeSeries27.getDescription();
//        java.util.Collection collection30 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        java.util.Collection collection31 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj34 = timeSeries33.clone();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getLastMillisecond();
//        long long37 = day35.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day35.previous();
//        timeSeries33.delete(regularTimePeriod38);
//        boolean boolean40 = timeSeries33.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond41.previous();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        java.util.Date date46 = regularTimePeriod45.getStart();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, regularTimePeriod45);
//        int int48 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        java.util.Date date20 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        java.util.Date date29 = day27.getEnd();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(5, serialDate31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        java.util.Date date35 = day33.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate38 = serialDate32.getEndOfCurrentMonth(serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate32);
        boolean boolean40 = spreadsheetDate24.isOnOrAfter(serialDate32);
        int int41 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.previous();
        java.util.Date date50 = day48.getEnd();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date50);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addDays(5, serialDate52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day54.previous();
        java.util.Date date56 = day54.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate59 = serialDate53.getEndOfCurrentMonth(serialDate58);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate53);
        boolean boolean61 = spreadsheetDate45.isOnOrAfter(serialDate53);
        java.util.Date date62 = spreadsheetDate45.toDate();
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        boolean boolean66 = spreadsheetDate45.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
        try {
            org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate65.getPreviousDayOfWeek((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0.0f);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month8.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
//        java.lang.String str13 = day11.toString();
//        int int14 = day11.getYear();
//        java.util.Date date15 = day11.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        java.util.Date date18 = day16.getEnd();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date18, timeZone21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date15, timeZone21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date7, timeZone21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date2, timeZone21);
//        long long26 = year25.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        java.lang.Class<?> wildcardClass3 = month1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass3);
//        java.lang.String str5 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        java.lang.String str8 = day6.toString();
//        int int9 = day6.getYear();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy(2, 4);
//        int int18 = timeSeries17.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries17.addChangeListener(seriesChangeListener19);
//        int int21 = day6.compareTo((java.lang.Object) timeSeries17);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day6, (double) 1560190522064L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
        int int16 = timeSeries15.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries15.createCopy(0, 7);
        int int21 = timeSeries15.getMaximumItemCount();
        java.util.List list22 = timeSeries15.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        timeSeriesDataItem6.setValue((java.lang.Number) 2019);
        timeSeriesDataItem6.setValue((java.lang.Number) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        java.util.Date date3 = day1.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(7, serialDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getFirstMillisecond();
//        int int8 = day6.getMonth();
//        long long9 = day6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560754800000L + "'", long7 == 1560754800000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560841199999L + "'", long9 == 1560841199999L);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        java.util.Date date20 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        java.util.Date date29 = day27.getEnd();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(5, serialDate31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        java.util.Date date35 = day33.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate38 = serialDate32.getEndOfCurrentMonth(serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate32);
        boolean boolean40 = spreadsheetDate24.isOnOrAfter(serialDate32);
        int int41 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
        java.util.Date date46 = day44.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = day44.getSerialDate();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(7, serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(1, serialDate48);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day52.previous();
        java.util.Date date54 = day52.getEnd();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addDays(5, serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
        java.util.Date date60 = day58.getEnd();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date60);
        org.jfree.data.time.SerialDate serialDate63 = serialDate57.getEndOfCurrentMonth(serialDate62);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays((-1), serialDate62);
        boolean boolean66 = spreadsheetDate24.isInRange(serialDate48, serialDate64, (int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate24.getNearestDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        java.lang.Class<?> wildcardClass3 = month1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        try {
            timeSeries4.update((int) (short) -1, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("");
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class17);
        timeSeries18.clear();
        java.lang.String str20 = timeSeries18.getDescription();
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        try {
            timeSeries18.add(regularTimePeriod22, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class6);
        int int8 = timeSeries7.getItemCount();
        boolean boolean9 = month0.equals((java.lang.Object) timeSeries7);
        int int10 = timeSeries7.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener6);
        timeSeries4.setDescription("17-June-2019");
        org.junit.Assert.assertNull(class5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setMaximumItemCount(100);
        boolean boolean9 = timeSeries4.isEmpty();
        try {
            timeSeries4.removeAgedItems((long) (short) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.setKey((java.lang.Comparable) (byte) 1);
        timeSeries4.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        java.util.Date date20 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        java.util.Date date29 = day27.getEnd();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(5, serialDate31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        java.util.Date date35 = day33.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate38 = serialDate32.getEndOfCurrentMonth(serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate32);
        boolean boolean40 = spreadsheetDate24.isOnOrAfter(serialDate32);
        int int41 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.previous();
        java.util.Date date50 = day48.getEnd();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date50);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addDays(5, serialDate52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day54.previous();
        java.util.Date date56 = day54.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate59 = serialDate53.getEndOfCurrentMonth(serialDate58);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate53);
        boolean boolean61 = spreadsheetDate45.isOnOrAfter(serialDate53);
        java.util.Date date62 = spreadsheetDate45.toDate();
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        boolean boolean66 = spreadsheetDate45.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
        int int67 = spreadsheetDate65.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 31 + "'", int67 == 31);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        int int20 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        java.util.Date date26 = day24.getEnd();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date26);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(5, serialDate28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
        java.util.Date date32 = day30.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.SerialDate serialDate35 = serialDate29.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
        java.util.Date date46 = day44.getEnd();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(5, serialDate48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
        java.util.Date date52 = day50.getEnd();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date52);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date52);
        org.jfree.data.time.SerialDate serialDate55 = serialDate49.getEndOfCurrentMonth(serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate49);
        boolean boolean57 = spreadsheetDate41.isOnOrAfter(serialDate49);
        java.lang.String str58 = spreadsheetDate41.getDescription();
        boolean boolean59 = spreadsheetDate3.isInRange(serialDate35, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        int int61 = year60.getYear();
        java.lang.String str62 = year60.toString();
        java.lang.String str63 = year60.toString();
        long long64 = year60.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year60, (java.lang.Number) 1.0d);
        int int68 = timeSeriesDataItem66.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj69 = timeSeriesDataItem66.clone();
        try {
            int int70 = spreadsheetDate41.compareTo(obj69);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeriesDataItem cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9999 + "'", int20 == 9999);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2019" + "'", str63.equals("2019"));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 2019L + "'", long64 == 2019L);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(obj69);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        int int4 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("July 2019");
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date4, timeZone10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
//        int int14 = month12.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.setDescription("hi!");
        java.lang.Comparable comparable12 = timeSeries4.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0f + "'", comparable12.equals(0.0f));
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        java.util.Date date3 = day1.getEnd();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        java.lang.String str9 = day7.toString();
//        int int10 = day7.getYear();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        java.util.Date date14 = day12.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date14, timeZone17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date11, timeZone17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date3, timeZone17);
//        try {
//            org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date0, timeZone17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(timeZone17);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(8, 31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
//        int int8 = timeSeries7.getItemCount();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class12);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month14);
//        boolean boolean17 = timeSeries13.getNotify();
//        java.util.Collection collection18 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries13.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((-1L));
//        long long22 = fixedMillisecond21.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
//        java.util.Date date27 = day25.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        java.util.Date date32 = day30.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        java.lang.String str38 = day36.toString();
//        int int39 = day36.getYear();
//        java.util.Date date40 = day36.getStart();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        java.util.Date date43 = day41.getEnd();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date43);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date43, timeZone46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date40, timeZone46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date32, timeZone46);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date27, timeZone46);
//        java.lang.String str51 = year50.toString();
//        try {
//            timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year50, (java.lang.Number) 9223372036854775807L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019" + "'", str51.equals("2019"));
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("");
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class17);
        timeSeries18.clear();
        java.lang.String str20 = timeSeries18.getDescription();
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        java.lang.String str24 = year22.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod26, (java.lang.Number) (byte) 0);
        try {
            timeSeries4.add(timeSeriesDataItem28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Date date4 = day2.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(7, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(1, serialDate6);
        try {
            org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        int int12 = timeSeries4.getIndex(regularTimePeriod10);
        java.util.Date date13 = regularTimePeriod10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) (-1L));
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
        timeSeries21.setMaximumItemCount(100);
        boolean boolean26 = timeSeries21.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries21.createCopy(8, 2019);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        java.lang.String str32 = year30.toString();
        java.lang.String str33 = year30.toString();
        int int34 = year30.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        int int36 = year35.getYear();
        java.lang.String str37 = year35.toString();
        java.lang.String str38 = year35.toString();
        java.lang.String str39 = year35.toString();
        long long40 = year35.getFirstMillisecond();
        long long41 = year35.getFirstMillisecond();
        int int42 = year30.compareTo((java.lang.Object) year35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year30.next();
        int int44 = timeSeries21.getIndex(regularTimePeriod43);
        boolean boolean45 = timeSeriesDataItem16.equals((java.lang.Object) timeSeries21);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1563303599999L + "'", long11 == 1563303599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        boolean boolean8 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
//        java.util.Date date14 = regularTimePeriod13.getStart();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, regularTimePeriod13);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class19);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(2, 4);
//        int int24 = timeSeries23.getItemCount();
//        timeSeries23.setNotify(true);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        long long29 = day27.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day27.previous();
//        int int31 = day27.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day27.next();
//        timeSeries1.add(regularTimePeriod34, (java.lang.Number) 2914607);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date4, timeZone10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        java.lang.Class<?> wildcardClass16 = month14.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, class17);
//        try {
//            java.lang.Number number20 = timeSeries18.getValue(2914607);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2914607, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, number4);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        timeSeries4.setDomainDescription("Saturday");
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        java.lang.String str3 = year1.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
//        java.lang.String str13 = day11.toString();
//        int int14 = day11.getYear();
//        java.util.Date date15 = day11.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        java.util.Date date18 = day16.getEnd();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date18, timeZone21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date15, timeZone21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date7, timeZone21);
//        boolean boolean25 = year1.equals((java.lang.Object) day24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(1, year1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3, 2914607, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        java.lang.Class<?> wildcardClass3 = month1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.String str8 = year6.toString();
        int int9 = year6.getYear();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year6, (double) 8);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        java.util.Date date20 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        java.util.Date date29 = day27.getEnd();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(5, serialDate31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        java.util.Date date35 = day33.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate38 = serialDate32.getEndOfCurrentMonth(serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate32);
        boolean boolean40 = spreadsheetDate24.isOnOrAfter(serialDate32);
        int int41 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
        java.util.Date date46 = day44.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = day44.getSerialDate();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(7, serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(1, serialDate48);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day52.previous();
        java.util.Date date54 = day52.getEnd();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addDays(5, serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
        java.util.Date date60 = day58.getEnd();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date60);
        org.jfree.data.time.SerialDate serialDate63 = serialDate57.getEndOfCurrentMonth(serialDate62);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays((-1), serialDate62);
        boolean boolean66 = spreadsheetDate24.isInRange(serialDate48, serialDate64, (int) '#');
        int int67 = spreadsheetDate24.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        long long6 = timeSeries4.getMaximumItemAge();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        java.lang.String str8 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        int int8 = timeSeries7.getItemCount();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        boolean boolean17 = timeSeries13.getNotify();
        java.util.Collection collection18 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries13.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond21.next();
        java.util.Date date26 = fixedMillisecond21.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.util.Date date2 = month0.getStart();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        long long8 = month5.getFirstMillisecond();
        java.lang.String str9 = month5.toString();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        java.lang.Class<?> wildcardClass13 = month11.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str9, (java.lang.Class) wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        java.util.Date date7 = day5.getEnd();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(7, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(1, serialDate9);
        boolean boolean11 = spreadsheetDate1.isOnOrAfter(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        java.util.Date date21 = day19.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(7, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(1, serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate24);
        boolean boolean26 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, serialDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean28 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate1.getPreviousDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560754800000L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560754800000L + "'", long3 == 1560754800000L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        int int8 = timeSeries7.getItemCount();
        timeSeries7.setNotify(true);
        try {
            timeSeries7.delete(9999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        java.lang.String str13 = year10.toString();
        java.lang.String str14 = year10.toString();
        long long15 = year10.getFirstMillisecond();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Date date4 = day2.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(7, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        java.util.Date date13 = day11.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(7, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(1, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate16);
        boolean boolean18 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, serialDate17);
        int int19 = fixedMillisecond1.compareTo((java.lang.Object) spreadsheetDate5);
        java.util.Date date20 = spreadsheetDate5.toDate();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        long long6 = timeSeries4.getMaximumItemAge();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0.0f + "'", comparable8.equals(0.0f));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        int int20 = spreadsheetDate3.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        int int10 = day8.getMonth();
//        long long11 = day8.getFirstMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 2147483647);
//        timeSeries1.clear();
//        timeSeries1.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        java.lang.Class<?> wildcardClass2 = month0.getClass();
//        java.lang.String str3 = month0.toString();
//        org.jfree.data.time.Year year4 = month0.getYear();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year4);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.util.Collection collection14 = timeSeries10.getTimePeriods();
//        java.lang.String str15 = timeSeries10.getRangeDescription();
//        timeSeries10.setKey((java.lang.Comparable) (byte) 1);
//        java.lang.String str18 = timeSeries10.getDescription();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        java.lang.Number number26 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) month24);
//        java.util.Collection collection27 = timeSeries23.getTimePeriods();
//        java.lang.String str28 = timeSeries23.getDomainDescription();
//        java.util.Collection collection29 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getDayOfMonth();
//        int int32 = day30.getMonth();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        boolean boolean34 = timeSeries5.equals((java.lang.Object) day30);
//        try {
//            timeSeries5.delete(0, (-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.util.Date date0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        java.lang.Class<?> wildcardClass3 = month1.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        java.util.Date date7 = day5.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        java.util.Date date10 = day8.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        java.util.Date date13 = day11.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date13, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date10, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date7, timeZone17);
        try {
            org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date0, timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        timeSeries4.clear();
//        java.lang.String str6 = timeSeries4.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) regularTimePeriod11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener13);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        int int10 = day8.getMonth();
//        long long11 = day8.getFirstMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 2147483647);
//        java.util.Calendar calendar14 = null;
//        try {
//            day8.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (7) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
//        java.util.Collection collection8 = timeSeries4.getTimePeriods();
//        java.lang.String str9 = timeSeries4.getRangeDescription();
//        timeSeries4.setKey((java.lang.Comparable) (byte) 1);
//        java.lang.String str12 = timeSeries4.getDescription();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month18);
//        java.util.Collection collection21 = timeSeries17.getTimePeriods();
//        java.lang.String str22 = timeSeries17.getDomainDescription();
//        java.util.Collection collection23 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getDayOfMonth();
//        int int26 = day24.getMonth();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day24);
//        int int28 = day24.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day24.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        java.util.Date date8 = day6.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        java.util.Date date14 = day12.getEnd();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
//        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
//        java.lang.String str20 = spreadsheetDate3.getDescription();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        java.util.Date date23 = day21.getEnd();
//        org.jfree.data.time.SerialDate serialDate24 = day21.getSerialDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
//        int int26 = spreadsheetDate3.compare(serialDate24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2914627 + "'", int26 == 2914627);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Following");
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1905);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1905");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date4, timeZone10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class16);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(2, 4);
//        int int21 = timeSeries20.getItemCount();
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.next();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) month27);
//        boolean boolean30 = timeSeries26.getNotify();
//        java.util.Collection collection31 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries26);
//        java.lang.Class<?> wildcardClass32 = timeSeries26.getClass();
//        java.util.Date date33 = null;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.previous();
//        java.util.Date date36 = day34.getEnd();
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date36);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date36, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone39);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date4, timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("");
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class17);
        timeSeries18.clear();
        java.lang.String str20 = timeSeries18.getDescription();
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        try {
            java.lang.Number number23 = timeSeries18.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        java.util.Date date10 = day8.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(7, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(1, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate13);
        boolean boolean15 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getSerialIndex();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            year4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        java.util.Date date20 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        java.util.Date date29 = day27.getEnd();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(5, serialDate31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        java.util.Date date35 = day33.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate38 = serialDate32.getEndOfCurrentMonth(serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate32);
        boolean boolean40 = spreadsheetDate24.isOnOrAfter(serialDate32);
        int int41 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.previous();
        java.util.Date date50 = day48.getEnd();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date50);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addDays(5, serialDate52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day54.previous();
        java.util.Date date56 = day54.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate59 = serialDate53.getEndOfCurrentMonth(serialDate58);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate53);
        boolean boolean61 = spreadsheetDate45.isOnOrAfter(serialDate53);
        java.util.Date date62 = spreadsheetDate45.toDate();
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
        java.util.Date date73 = day71.getEnd();
        org.jfree.data.time.SerialDate serialDate74 = day71.getSerialDate();
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays(7, serialDate74);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addDays(1, serialDate75);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate76);
        boolean boolean78 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate67, serialDate77);
        boolean boolean79 = spreadsheetDate45.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
        int int80 = spreadsheetDate65.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 14 + "'", int80 == 14);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.lang.String str5 = year1.toString();
        long long6 = year1.getFirstMillisecond();
        long long7 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(7, year1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("18-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        int int8 = timeSeries7.getItemCount();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        boolean boolean17 = timeSeries13.getNotify();
        java.util.Collection collection18 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.createCopy((int) (short) 0, 5);
        try {
            timeSeries22.delete(14, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year4);
        long long6 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        long long9 = month7.getFirstMillisecond();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        timeSeries4.setDomainDescription("Saturday");
        try {
            timeSeries4.delete((int) 'a', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setMaximumItemCount(100);
        try {
            timeSeries4.delete(100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.lang.String str7 = day5.toString();
//        int int8 = day5.getYear();
//        java.util.Date date9 = day5.getStart();
//        long long10 = day5.getSerialIndex();
//        java.lang.Object obj11 = null;
//        int int12 = day5.compareTo(obj11);
//        int int13 = day5.getDayOfMonth();
//        int int14 = month3.compareTo((java.lang.Object) int13);
//        long long15 = month3.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        java.util.Date date5 = day3.getEnd();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(7, serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(1, serialDate7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, serialDate8);
//        java.lang.String str10 = serialDate8.toString();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        java.util.Date date15 = day13.getEnd();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(5, serialDate17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        java.util.Date date21 = day19.getEnd();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate18.getEndOfCurrentMonth(serialDate23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(10, serialDate23);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate8.getEndOfCurrentMonth(serialDate25);
//        java.lang.String str27 = serialDate25.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "18-June-2019" + "'", str10.equals("18-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20-June-2019" + "'", str27.equals("20-June-2019"));
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            timeSeries4.add(regularTimePeriod11, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        java.lang.String str8 = day6.toString();
//        int int9 = day6.getYear();
//        java.util.Date date10 = day6.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
//        java.util.Date date13 = day11.getEnd();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date13, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date10, timeZone16);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date2, timeZone16);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(timeZone16);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setMaximumItemAge(1560150000000L);
        timeSeries4.setMaximumItemCount(0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean14 = timeSeries10.getNotify();
        boolean boolean15 = timeSeries10.getNotify();
        java.lang.Class class16 = timeSeries10.getTimePeriodClass();
        java.lang.String str17 = timeSeries10.getDomainDescription();
        timeSeries10.setDomainDescription("");
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class23);
        timeSeries24.clear();
        java.lang.String str26 = timeSeries24.getDescription();
        java.util.Collection collection27 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        boolean boolean28 = year5.equals((java.lang.Object) collection27);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        timeSeriesDataItem6.setValue((java.lang.Number) 2019);
        int int10 = timeSeriesDataItem6.compareTo((java.lang.Object) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem6.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        java.util.Date date7 = day5.getEnd();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(7, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(1, serialDate9);
        boolean boolean11 = spreadsheetDate1.isOnOrAfter(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        java.util.Date date21 = day19.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(7, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(1, serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate24);
        boolean boolean26 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, serialDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean28 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int29 = spreadsheetDate15.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        java.lang.String str4 = year2.toString();
        java.lang.String str5 = year2.toString();
        long long6 = year2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 1.0d);
        long long9 = year2.getFirstMillisecond();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        java.lang.String str13 = year10.toString();
        long long14 = year10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getYearValue();
        boolean boolean19 = timeSeriesDataItem16.equals((java.lang.Object) month17);
        boolean boolean20 = year2.equals((java.lang.Object) boolean19);
        boolean boolean21 = month0.equals((java.lang.Object) year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (byte) 100);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        java.util.Date date13 = day11.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(7, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(1, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate16);
        boolean boolean18 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, serialDate17);
        int int19 = fixedMillisecond1.compareTo((java.lang.Object) spreadsheetDate5);
        java.util.Date date20 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560106799999L);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        timeSeries4.clear();
//        java.lang.String str6 = timeSeries4.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        int int15 = day13.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.previous();
//        java.lang.Number number17 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        java.util.Calendar calendar18 = null;
//        try {
//            day13.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(number17);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setMaximumItemCount(100);
        boolean boolean9 = timeSeries4.isEmpty();
        timeSeries4.setRangeDescription("2019");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date4, timeZone10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        java.lang.Class<?> wildcardClass16 = month14.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, class17);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = month12.getMiddleMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        int int2 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        java.util.List list6 = timeSeries4.getItems();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        try {
            timeSeries4.update(100, (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 2019L + "'", comparable5.equals(2019L));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        timeSeries4.setRangeDescription("Following");
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        java.util.Date date9 = day7.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(5, serialDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        java.util.Date date15 = day13.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate12.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate12);
        boolean boolean20 = spreadsheetDate4.isOnOrAfter(serialDate12);
        try {
            org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(11, serialDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        java.util.Date date9 = day7.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(5, serialDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        java.util.Date date15 = day13.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate12.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate12);
        boolean boolean20 = spreadsheetDate4.isOnOrAfter(serialDate12);
        int int21 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
        java.util.Date date27 = day25.getEnd();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(5, serialDate29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
        java.util.Date date33 = day31.getEnd();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.jfree.data.time.SerialDate serialDate36 = serialDate30.getEndOfCurrentMonth(serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate36);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.previous();
        java.util.Date date47 = day45.getEnd();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date47);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addDays(5, serialDate49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day51.previous();
        java.util.Date date53 = day51.getEnd();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date53);
        org.jfree.data.time.SerialDate serialDate56 = serialDate50.getEndOfCurrentMonth(serialDate55);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate50);
        boolean boolean58 = spreadsheetDate42.isOnOrAfter(serialDate50);
        java.lang.String str59 = spreadsheetDate42.getDescription();
        boolean boolean60 = spreadsheetDate4.isInRange(serialDate36, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        java.lang.String str61 = spreadsheetDate4.toString();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9999 + "'", int21 == 9999);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2-June-9999" + "'", str61.equals("2-June-9999"));
        org.junit.Assert.assertNotNull(serialDate62);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        int int6 = day0.getYear();
//        int int7 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getFirstMillisecond(calendar14);
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = null;
        try {
            timeSeries4.add(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        java.lang.Class<?> wildcardClass2 = month0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        java.lang.String str6 = day4.toString();
//        int int7 = day4.getYear();
//        java.util.Date date8 = day4.getStart();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        java.util.Date date11 = day9.getEnd();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date11, timeZone14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date8, timeZone14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        java.util.Date date19 = day17.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date8, timeZone20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 1900, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//        java.lang.String str5 = day4.toString();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        int int7 = day4.getDayOfMonth();
//        java.lang.String str8 = day4.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-460));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
//        java.lang.Class<?> wildcardClass6 = month4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        java.util.Date date9 = day7.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        java.lang.String str15 = day13.toString();
//        int int16 = day13.getYear();
//        java.util.Date date17 = day13.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date20);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date20, timeZone23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date17, timeZone23);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date9, timeZone23);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date9, timeZone27);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int3, (java.lang.Class) wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Date date4 = day2.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(5, serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        java.util.Date date10 = day8.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(4, serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2-June-9999");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
//        int int8 = timeSeries7.getItemCount();
//        timeSeries7.setNotify(true);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getLastMillisecond();
//        long long13 = day11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
//        int int15 = day11.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day11.next();
//        long long19 = day11.getLastMillisecond();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long19, class20);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = timeSeries3.equals(obj5);
//        int int7 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries3);
//        long long8 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        int int10 = fixedMillisecond0.compareTo((java.lang.Object) year9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        java.util.Date date19 = day17.getEnd();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date19);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(5, serialDate21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        java.util.Date date25 = day23.getEnd();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate22.getEndOfCurrentMonth(serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate22);
//        boolean boolean30 = spreadsheetDate14.isOnOrAfter(serialDate22);
//        java.util.Date date31 = spreadsheetDate14.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
//        java.util.Date date40 = day38.getEnd();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date40);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays(5, serialDate42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.previous();
//        java.util.Date date46 = day44.getEnd();
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date46);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate43.getEndOfCurrentMonth(serialDate48);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate43);
//        boolean boolean51 = spreadsheetDate35.isOnOrAfter(serialDate43);
//        int int52 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
//        java.util.Date date57 = day55.getEnd();
//        org.jfree.data.time.SerialDate serialDate58 = day55.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays(7, serialDate58);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addDays(1, serialDate59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = day63.previous();
//        java.util.Date date65 = day63.getEnd();
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date65);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date65);
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addDays(5, serialDate67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day69.previous();
//        java.util.Date date71 = day69.getEnd();
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date71);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date71);
//        org.jfree.data.time.SerialDate serialDate74 = serialDate68.getEndOfCurrentMonth(serialDate73);
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays((-1), serialDate73);
//        boolean boolean77 = spreadsheetDate35.isInRange(serialDate59, serialDate75, (int) '#');
//        int int78 = year9.compareTo((java.lang.Object) spreadsheetDate35);
//        int int79 = year9.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2019L + "'", comparable4.equals(2019L));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190545866L + "'", long8 == 1560190545866L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2019 + "'", int79 == 2019);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getSerialIndex();
//        java.lang.Object obj6 = null;
//        int int7 = day0.compareTo(obj6);
//        java.util.Calendar calendar8 = null;
//        try {
//            day0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        java.util.Date date3 = day1.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.lang.String str6 = day5.toString();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        java.lang.String str8 = serialDate7.getDescription();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        long long5 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1.0d);
        int int9 = timeSeriesDataItem7.compareTo((java.lang.Object) 100.0f);
        java.lang.Object obj10 = timeSeriesDataItem7.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem7.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem7.getPeriod();
        java.lang.Object obj13 = timeSeriesDataItem7.clone();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        java.util.Date date16 = day14.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date16);
        int int19 = timeSeriesDataItem7.compareTo((java.lang.Object) serialDate18);
        try {
            org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 10, serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        int int5 = timeSeries4.getItemCount();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        long long8 = day6.getLastMillisecond();
//        int int9 = day6.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day6, 0.0d, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, 31, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 1560190500484L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getYearValue();
        boolean boolean9 = timeSeriesDataItem6.equals((java.lang.Object) month7);
        int int10 = month7.getYearValue();
        java.lang.String str11 = month7.toString();
        int int12 = month7.getMonth();
        java.util.Calendar calendar13 = null;
        try {
            month7.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (-460));
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond1.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj9 = timeSeries8.clone();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.previous();
//        timeSeries8.delete(regularTimePeriod13);
//        boolean boolean15 = timeSeries8.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.previous();
//        java.util.Date date21 = regularTimePeriod20.getStart();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, regularTimePeriod20);
//        timeSeries22.setDomainDescription("18-June-2019");
//        int int25 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries22);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        java.lang.Comparable comparable13 = timeSeries4.getKey();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        java.lang.Class<?> wildcardClass16 = month14.getClass();
        java.lang.String str17 = month14.toString();
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year18, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
//        int int8 = timeSeries7.getItemCount();
//        timeSeries7.setNotify(true);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getLastMillisecond();
//        long long13 = day11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
//        int int15 = day11.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day11.next();
//        long long19 = day11.getMiddleMillisecond();
//        long long20 = day11.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560193199999L + "'", long19 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNull(str6);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
//        java.util.Collection collection8 = timeSeries4.getTimePeriods();
//        java.lang.String str9 = timeSeries4.getRangeDescription();
//        timeSeries4.setKey((java.lang.Comparable) (byte) 1);
//        java.lang.String str12 = timeSeries4.getDescription();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month18);
//        java.util.Collection collection21 = timeSeries17.getTimePeriods();
//        java.lang.String str22 = timeSeries17.getDomainDescription();
//        java.util.Collection collection23 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries17.addPropertyChangeListener(propertyChangeListener24);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class29);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries30.removePropertyChangeListener(propertyChangeListener31);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class36);
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries37.removePropertyChangeListener(propertyChangeListener38);
//        timeSeries37.setMaximumItemCount(100);
//        boolean boolean42 = timeSeries37.isEmpty();
//        java.util.Collection collection43 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.previous();
//        java.util.Date date47 = day45.getEnd();
//        org.jfree.data.time.SerialDate serialDate48 = day45.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(7, serialDate48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
//        long long51 = day50.getFirstMillisecond();
//        long long52 = day50.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Collection collection54 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(collection43);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560754800000L + "'", long51 == 1560754800000L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 43633L + "'", long52 == 43633L);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertNotNull(collection54);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 1 + "'", obj3.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        java.util.Date date9 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(7, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(1, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate12);
        boolean boolean14 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate13);
        int int15 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        java.util.Date date20 = day18.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(7, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate21);
        boolean boolean24 = spreadsheetDate3.isAfter(serialDate21);
        int int25 = spreadsheetDate3.getDayOfWeek();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.next();
        java.lang.Number number33 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) month31);
        long long34 = month31.getFirstMillisecond();
        try {
            int int35 = spreadsheetDate3.compareTo((java.lang.Object) long34);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1559372400000L + "'", long34 == 1559372400000L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate3.getNearestDayOfWeek(2);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        java.util.Date date9 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(7, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(1, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate12);
        boolean boolean14 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate13);
        int int15 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        java.util.Date date20 = day18.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(7, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate21);
        boolean boolean24 = spreadsheetDate3.isAfter(serialDate21);
        int int25 = spreadsheetDate3.toSerial();
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(14, (-460), 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(5, serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate11.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate11);
        boolean boolean19 = spreadsheetDate3.isOnOrAfter(serialDate11);
        java.lang.String str20 = spreadsheetDate3.getDescription();
        int int21 = spreadsheetDate3.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        int int10 = day8.getMonth();
//        long long11 = day8.getFirstMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 2147483647);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries1.getTimePeriod((-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2914607);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        java.lang.String str11 = timeSeries4.getDescription();
        try {
            timeSeries4.delete((int) (byte) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0.0f);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        java.util.Date date14 = day12.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(5, serialDate16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        java.util.Date date20 = day18.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.SerialDate serialDate23 = serialDate17.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate17);
        boolean boolean25 = spreadsheetDate9.isOnOrAfter(serialDate17);
        java.lang.String str26 = spreadsheetDate9.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        java.util.Date date35 = day33.getEnd();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(5, serialDate37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        java.util.Date date41 = day39.getEnd();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date41);
        org.jfree.data.time.SerialDate serialDate44 = serialDate38.getEndOfCurrentMonth(serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate38);
        boolean boolean46 = spreadsheetDate30.isOnOrAfter(serialDate38);
        java.util.Date date47 = spreadsheetDate30.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2, 6, 9999);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day54.previous();
        java.util.Date date56 = day54.getEnd();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays(5, serialDate58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day60.previous();
        java.util.Date date62 = day60.getEnd();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date62);
        org.jfree.data.time.SerialDate serialDate65 = serialDate59.getEndOfCurrentMonth(serialDate64);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate59);
        boolean boolean67 = spreadsheetDate51.isOnOrAfter(serialDate59);
        int int68 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
        java.util.Date date73 = day71.getEnd();
        org.jfree.data.time.SerialDate serialDate74 = day71.getSerialDate();
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays(7, serialDate74);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addDays(1, serialDate75);
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
        java.util.Date date81 = day79.getEnd();
        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month(date81);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date81);
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addDays(5, serialDate83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = day85.previous();
        java.util.Date date87 = day85.getEnd();
        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.createInstance(date87);
        org.jfree.data.time.SerialDate serialDate89 = org.jfree.data.time.SerialDate.createInstance(date87);
        org.jfree.data.time.SerialDate serialDate90 = serialDate84.getEndOfCurrentMonth(serialDate89);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addDays((-1), serialDate89);
        boolean boolean93 = spreadsheetDate51.isInRange(serialDate75, serialDate91, (int) '#');
        int int94 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean95 = fixedMillisecond1.equals((java.lang.Object) int94);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        long long3 = fixedMillisecond1.getSerialIndex();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class7);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(2, 4);
//        int int12 = timeSeries11.getItemCount();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month18);
//        boolean boolean21 = timeSeries17.getNotify();
//        java.util.Collection collection22 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        boolean boolean23 = timeSeries17.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((-1L));
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond25.next();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        java.util.Date date32 = day30.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
//        java.util.Date date37 = day35.getEnd();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        java.lang.String str43 = day41.toString();
//        int int44 = day41.getYear();
//        java.util.Date date45 = day41.getStart();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        java.util.Date date48 = day46.getEnd();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date48);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48, timeZone51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date45, timeZone51);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date37, timeZone51);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date32, timeZone51);
//        boolean boolean56 = fixedMillisecond25.equals((java.lang.Object) date32);
//        int int57 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond25);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.getNotify();
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.lang.String str11 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("");
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class17);
        timeSeries18.clear();
        java.lang.String str20 = timeSeries18.getDescription();
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        long long22 = timeSeries18.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Class<?> wildcardClass7 = month5.getClass();
        java.lang.String str8 = month5.toString();
        org.jfree.data.time.Year year9 = month5.getYear();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        java.lang.Class<?> wildcardClass14 = month12.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year9, "hi!", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class15);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class21);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener23);
        timeSeries22.setRangeDescription("hi!");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.next();
        long long29 = regularTimePeriod28.getMiddleMillisecond();
        int int30 = timeSeries22.getIndex(regularTimePeriod28);
        java.util.Date date31 = regularTimePeriod28.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 9223372036854775807L);
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 1.0f, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1563303599999L + "'", long29 == 1563303599999L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        java.lang.Class<?> wildcardClass3 = month1.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, (java.lang.Class) wildcardClass3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        long long6 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        java.lang.Object obj2 = null;
        try {
            int int3 = spreadsheetDate1.compareTo(obj2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        java.lang.String str9 = timeSeries4.getDomainDescription();
        long long10 = timeSeries4.getMaximumItemAge();
        timeSeries4.removeAgedItems(false);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(2, 4);
        int int21 = timeSeries20.getItemCount();
        java.util.Collection collection22 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        java.lang.Class class23 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNull(class23);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code." + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code." + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        timeSeries1.delete(regularTimePeriod6);
//        boolean boolean8 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
//        java.util.Date date14 = regularTimePeriod13.getStart();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, regularTimePeriod13);
//        timeSeries15.setDomainDescription("18-June-2019");
//        boolean boolean19 = timeSeries15.equals((java.lang.Object) "June 2019");
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, 4);
        int int8 = timeSeries7.getItemCount();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        boolean boolean17 = timeSeries13.getNotify();
        java.util.Collection collection18 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries13.getNotify();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        java.util.Date date22 = day20.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        java.util.Date date25 = day23.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date25, timeZone29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date22, timeZone29);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month31, (double) (short) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone29);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        timeSeries4.clear();
        java.lang.String str6 = timeSeries4.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond8.getMiddleMillisecond(calendar11);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month8.next();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.toSerial();
        int int3 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setMaximumItemCount(100);
        boolean boolean9 = timeSeries4.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries4.createCopy(8, 2019);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class16);
        timeSeries17.clear();
        java.lang.String str19 = timeSeries17.getDescription();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month20);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
        java.util.Date date27 = day25.getEnd();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date27);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date27, timeZone31);
        int int33 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        int int34 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
//        timeSeries3.delete(regularTimePeriod8);
//        boolean boolean10 = timeSeries3.isEmpty();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) month16);
//        boolean boolean19 = timeSeries15.getNotify();
//        boolean boolean20 = timeSeries15.getNotify();
//        java.lang.Class class21 = timeSeries15.getTimePeriodClass();
//        java.lang.String str22 = timeSeries15.getDomainDescription();
//        timeSeries15.setDomainDescription("");
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "", class28);
//        timeSeries29.clear();
//        java.lang.String str31 = timeSeries29.getDescription();
//        java.util.Collection collection32 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        java.util.Collection collection33 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        int int34 = fixedMillisecond0.compareTo((java.lang.Object) collection33);
//        long long35 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond0.getFirstMillisecond(calendar36);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560190551085L + "'", long35 == 1560190551085L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190551085L + "'", long37 == 1560190551085L);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date4, timeZone10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        java.lang.Class<?> wildcardClass16 = month14.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, class17);
//        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("9-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=1]");
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getSerialIndex();
//        java.lang.Object obj6 = null;
//        int int7 = day0.compareTo(obj6);
//        long long8 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//    }
//}

