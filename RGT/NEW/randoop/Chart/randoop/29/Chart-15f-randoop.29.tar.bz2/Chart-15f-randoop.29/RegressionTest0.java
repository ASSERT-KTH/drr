import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (short) 100, 0, (int) (byte) 10, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 100, 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color0 = java.awt.Color.green;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getColorComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0.0d, (java.lang.Object) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        boolean boolean2 = color0.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot0.setDataset(waferMapDataset3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) "ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = java.awt.Color.RED;
        float[] floatArray6 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray7 = color2.getRGBColorComponents(floatArray6);
        try {
            float[] floatArray8 = color0.getRGBComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) (short) -1, (int) 'a', (java.lang.Comparable) (-1.0f), "ThreadContext", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Color color1 = java.awt.Color.green;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) (-1.0f), (double) 1L, (double) (byte) 0);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = null;
        try {
            valueMarker3.setLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint2 = textFragment1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color1 = java.awt.Color.getColor("ThreadContext");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            textFragment1.draw(graphics2D2, 0.0f, 0.0f, textAnchor5, (float) 100L, (float) 1, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        java.lang.String str3 = waferMapPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        waferMapPlot0.removeChangeListener(plotChangeListener4);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "ThreadContext", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double9 = numberAxis3D0.lengthToJava2D(1.0d, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = color2.brighter();
        try {
            org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("ThreadContext", font1, (java.awt.Paint) color3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color5, stroke6);
        valueMarker3.setStroke(stroke6);
        java.awt.Font font9 = null;
        try {
            valueMarker3.setLabelFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        waferMapPlot0.setBackgroundImageAlignment((-1));
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        waferMapPlot0.addChangeListener(plotChangeListener3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        java.lang.String str3 = waferMapPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        waferMapPlot0.handleClick((int) (byte) 0, 10, plotRenderingInfo3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        waferMapPlot0.setDrawingSupplier(drawingSupplier5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            waferMapPlot0.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ThreadContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        java.lang.String str3 = waferMapPlot0.getNoDataMessage();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            waferMapPlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) 'a', 10, 10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        java.lang.String str3 = projectInfo0.toString();
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double12 = numberAxis3D0.lengthToJava2D((double) 'a', rectangle2D10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        try {
            xYPlot13.setRangeAxisLocation(axisLocation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis3D0.setLabelPaint(paint2);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        try {
            xYPlot13.setDomainAxisLocation(axisLocation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.awt.Paint paint6 = numberAxis3D0.getLabelPaint();
        org.jfree.data.RangeType rangeType7 = null;
        try {
            numberAxis3D0.setRangeType(rangeType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("WMAP_Plot", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        double double2 = numberAxis3D0.getUpperBound();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = numberAxis3D0.draw(graphics2D3, 0.0d, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plot2, jFreeChart3, chartChangeEventType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainZeroBaselineVisible();
        java.awt.Color color16 = java.awt.Color.green;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color16, stroke17);
        java.awt.Color color20 = java.awt.Color.green;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color20, stroke21);
        valueMarker18.setStroke(stroke21);
        java.awt.Font font24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker18.setLabelFont(font24);
        try {
            boolean boolean26 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer(xYItemRenderer21);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("WMAP_Plot", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot13.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            xYPlot13.handleClick((int) (short) 100, (int) (byte) -1, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.awt.Paint paint6 = numberAxis3D0.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double10 = numberAxis3D0.valueToJava2D((double) (-1.0f), rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            xYPlot13.drawOutline(graphics2D26, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        xYPlot37.zoomRangeAxes(100.0d, plotRenderingInfo39, point2D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot37.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation45, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation45, plotOrientation48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D0.getTickLabelInsets();
        double double8 = rectangleInsets7.getTop();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        numberAxis3D1.setDefaultAutoRange(range15);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = numberAxis3D1.getMarkerBand();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(markerAxisBand17);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color5, stroke6);
        valueMarker3.setStroke(stroke6);
        java.awt.Paint paint9 = valueMarker3.getOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color26, stroke27);
        java.awt.Color color30 = java.awt.Color.green;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color30, stroke31);
        valueMarker28.setStroke(stroke31);
        java.awt.Font font34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker28.setLabelFont(font34);
        org.jfree.chart.util.Layer layer36 = null;
        try {
            boolean boolean37 = xYPlot13.removeRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker28, layer36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot13.getRendererForDataset(xYDataset15);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        size2D2.setHeight((double) (short) 10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Color color3 = java.awt.Color.RED;
        float[] floatArray7 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray8 = color3.getRGBColorComponents(floatArray7);
        try {
            float[] floatArray9 = color0.getComponents(colorSpace2, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        boolean boolean2 = objectList0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        boolean boolean4 = projectInfo0.equals((java.lang.Object) (byte) 10);
        projectInfo0.addOptionalLibrary("hi!");
        java.lang.String str7 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str7.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        waferMapPlot0.setBackgroundImageAlignment((-1));
        java.awt.Image image3 = null;
        waferMapPlot0.setBackgroundImage(image3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        xYPlot14.zoomRangeAxes(100.0d, plotRenderingInfo16, point2D19, false);
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot14.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray24 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer23 };
        xYPlot14.setRenderers(xYItemRendererArray24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        int int27 = xYPlot14.indexOf(xYDataset26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot14.getFixedDomainAxisSpace();
        boolean boolean29 = textAnchor0.equals((java.lang.Object) axisSpace28);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(xYItemRendererArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot0.setDataset(waferMapDataset3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        waferMapPlot0.setDrawingSupplier(drawingSupplier5);
        java.awt.Paint paint7 = waferMapPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color2, stroke3);
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color6, stroke7);
        valueMarker4.setStroke(stroke7);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker4.setLabelFont(font10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint14 = numberAxis3D13.getTickMarkPaint();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("", font10, paint14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Range[0.0,1.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        java.lang.String str3 = waferMapPlot0.getNoDataMessage();
        waferMapPlot0.setBackgroundImageAlignment((int) (short) 0);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double4 = size2D3.getWidth();
        org.jfree.chart.util.Size2D size2D5 = rectangleConstraint0.calculateConstrainedSize(size2D3);
        double double6 = size2D5.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            xYPlot13.drawBackground(graphics2D26, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Font font4 = numberAxis3D1.getLabelFont();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("", font4, (java.awt.Paint) color5, rectangleEdge6, horizontalAlignment7, verticalAlignment8, rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("ClassContext", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.Block block14 = null;
        java.awt.Font font16 = null;
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer21 = new org.jfree.chart.text.G2TextMeasurer(graphics2D20);
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, paint17, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer21);
        columnArrangement0.add(block14, (java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlock22);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = dateAxis0.draw(graphics2D4, (double) 1, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color5, stroke6);
        valueMarker3.setStroke(stroke6);
        valueMarker3.setValue(10.0d);
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset11);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) waferMapPlot12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        xYPlot13.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        try {
            xYPlot13.zoomRangeAxes((double) 255, (double) '4', plotRenderingInfo29, point2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (26723.025) <= upper (5408.025).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        int int26 = xYPlot13.indexOf(xYDataset25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = xYPlot13.getFixedDomainAxisSpace();
        java.awt.Stroke stroke28 = xYPlot13.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        boolean boolean4 = projectInfo0.equals((java.lang.Object) (byte) 10);
        projectInfo0.addOptionalLibrary("hi!");
        projectInfo0.setInfo("ClassContext");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset27 = xYPlot13.getDataset(100);
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        try {
            xYPlot13.setDomainAxisLocation(axisLocation28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(xYDataset27);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double4 = size2D3.getWidth();
        org.jfree.chart.util.Size2D size2D5 = rectangleConstraint0.calculateConstrainedSize(size2D3);
        size2D5.width = 8;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(size2D5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = null;
        java.awt.geom.Point2D point2D3 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D1, rectangleAnchor2);
        boolean boolean4 = chartChangeEventType0.equals((java.lang.Object) rectangleAnchor2);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(point2D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("ThreadContext", color1);
        int int3 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        boolean boolean27 = xYPlot13.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        waferMapPlot0.handleClick((int) (byte) 0, 10, plotRenderingInfo3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        waferMapPlot0.setDrawingSupplier(drawingSupplier5);
        waferMapPlot0.setForegroundAlpha(1.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (-16711936), (double) (short) 10);
        double double3 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 10, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("WMAP_Plot", graphics2D1, (double) 100.0f, (float) (-16711936), (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color2, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke3, rectangleInsets9);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets9.createOutsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(unitType10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot13.getDomainAxisLocation(0);
        xYPlot13.setWeight(500);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.awt.Shape shape15 = textBlock7.calculateBounds(graphics2D8, 0.5f, (-1.0f), textBlockAnchor11, (float) (byte) 1, (float) (short) 1, (double) 10L);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot13.datasetChanged(datasetChangeEvent27);
        java.awt.Color color30 = java.awt.Color.green;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color30, stroke31);
        java.awt.Color color34 = java.awt.Color.green;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color34, stroke35);
        valueMarker32.setStroke(stroke35);
        try {
            boolean boolean38 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color2, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke3, rectangleInsets9);
        double double13 = rectangleInsets9.calculateLeftInset(0.05d);
        double double15 = rectangleInsets9.calculateBottomInset((double) (short) 1);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets9.createOutsetRectangle(rectangle2D16, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        double double2 = categoryAxis3D1.getLowerMargin();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double7 = categoryAxis3D1.getCategoryEnd((int) 'a', (-655360), rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1, jFreeChart1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        float float27 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        xYPlot13.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range24 = numberAxis3D23.getRange();
        org.jfree.chart.plot.Plot plot25 = numberAxis3D23.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        numberAxis3D23.setRange(range27);
        java.text.NumberFormat numberFormat29 = numberAxis3D23.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis3D23.getTickLabelInsets();
        java.awt.Shape shape31 = numberAxis3D23.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range37 = numberAxis3D36.getRange();
        org.jfree.chart.plot.Plot plot38 = numberAxis3D36.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range40 = numberAxis3D39.getRange();
        numberAxis3D36.setRange(range40);
        xYPlot35.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        double double45 = numberAxis3D43.getUpperBound();
        double double46 = numberAxis3D43.getFixedAutoRange();
        numberAxis3D43.setPositiveArrowVisible(false);
        org.jfree.data.Range range49 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        boolean boolean50 = numberAxis3D43.isNegativeArrowVisible();
        numberAxis3D43.setAutoRangeMinimumSize((double) (short) 100, false);
        org.jfree.data.Range range54 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range58 = numberAxis3D57.getRange();
        org.jfree.chart.plot.Plot plot59 = numberAxis3D57.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range61 = numberAxis3D60.getRange();
        numberAxis3D57.setRange(range61);
        java.text.NumberFormat numberFormat63 = numberAxis3D57.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = numberAxis3D57.getTickLabelInsets();
        java.awt.Shape shape65 = numberAxis3D57.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D66 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range67 = numberAxis3D66.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D66, xYItemRenderer68);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = null;
        java.awt.geom.Point2D point2D74 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D72, rectangleAnchor73);
        xYPlot69.zoomRangeAxes(100.0d, plotRenderingInfo71, point2D74, false);
        double double77 = xYPlot69.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace78 = null;
        xYPlot69.setFixedDomainAxisSpace(axisSpace78, true);
        java.awt.Paint paint81 = xYPlot69.getRangeCrosshairPaint();
        java.awt.Paint paint82 = xYPlot69.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent83 = null;
        xYPlot69.datasetChanged(datasetChangeEvent83);
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        org.jfree.chart.axis.AxisSpace axisSpace87 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace88 = numberAxis3D43.reserveSpace(graphics2D55, (org.jfree.chart.plot.Plot) xYPlot69, rectangle2D85, rectangleEdge86, axisSpace87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(numberFormat29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNull(plot59);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNull(numberFormat63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNotNull(point2D74);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Range[0.0,1.0]", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range42 = numberAxis3D41.getRange();
        org.jfree.chart.plot.Plot plot43 = numberAxis3D41.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        numberAxis3D41.setRange(range45);
        java.text.NumberFormat numberFormat47 = numberAxis3D41.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = numberAxis3D41.getTickLabelInsets();
        java.awt.Shape shape49 = numberAxis3D41.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range51 = numberAxis3D50.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis3D50, xYItemRenderer52);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D50);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = null;
        try {
            numberAxis3D50.setTickLabelInsets(rectangleInsets55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(plot43);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(numberFormat47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(range51);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        waferMapPlot2.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        waferMapPlot2.setInsets(rectangleInsets9, false);
        java.awt.Font font14 = null;
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer19 = new org.jfree.chart.text.G2TextMeasurer(graphics2D18);
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, paint15, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer19);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, paint15);
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) '4', (float) 1, 10.0f);
        int int26 = color25.getRGB();
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color1, paint15, color25 };
        java.awt.Stroke[] strokeArray28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        org.jfree.chart.plot.Plot plot46 = numberAxis3D44.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range48 = numberAxis3D47.getRange();
        numberAxis3D44.setRange(range48);
        java.text.NumberFormat numberFormat50 = numberAxis3D44.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis3D44.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer52);
        java.awt.Stroke stroke54 = xYPlot53.getDomainZeroBaselineStroke();
        java.awt.Color color55 = java.awt.Color.green;
        java.awt.Color color57 = java.awt.Color.green;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color57, stroke58);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType65 = rectangleInsets64.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder66 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color55, stroke58, rectangleInsets64);
        java.awt.Stroke[] strokeArray67 = new java.awt.Stroke[] { stroke54, stroke58 };
        java.awt.Shape[] shapeArray68 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier69 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray27, strokeArray28, strokeArray67, shapeArray68);
        try {
            java.awt.Stroke stroke70 = defaultDrawingSupplier69.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-655360) + "'", int26 == (-655360));
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(plot46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(numberFormat50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(unitType65);
        org.junit.Assert.assertNotNull(strokeArray67);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        int int26 = xYPlot13.indexOf(xYDataset25);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range28 = numberAxis3D27.getRange();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D27);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        try {
            org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset11, (java.lang.Comparable) 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        size2D2.height = (short) 100;
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range24 = numberAxis3D23.getRange();
        org.jfree.chart.plot.Plot plot25 = numberAxis3D23.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        numberAxis3D23.setRange(range27);
        java.text.NumberFormat numberFormat29 = numberAxis3D23.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis3D23.getTickLabelInsets();
        java.awt.Shape shape31 = numberAxis3D23.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range37 = numberAxis3D36.getRange();
        org.jfree.chart.plot.Plot plot38 = numberAxis3D36.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range40 = numberAxis3D39.getRange();
        numberAxis3D36.setRange(range40);
        xYPlot35.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        double double45 = numberAxis3D43.getUpperBound();
        double double46 = numberAxis3D43.getFixedAutoRange();
        numberAxis3D43.setPositiveArrowVisible(false);
        org.jfree.data.Range range49 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        boolean boolean50 = numberAxis3D43.isNegativeArrowVisible();
        numberAxis3D43.setAutoRangeMinimumSize((double) (short) 100, false);
        org.jfree.data.Range range54 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        java.awt.Color color55 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color55);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(numberFormat29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertNotNull(color55);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        double double5 = dateAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.lang.String str7 = range5.toString();
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) str7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment9, (double) 10, 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,1.0]" + "'", str7.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        numberAxis3D0.setTickMarkOutsideLength(0.0f);
        double double5 = numberAxis3D0.getAutoRangeMinimumSize();
        try {
            numberAxis3D0.setRange((double) 500, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (500.0) <= upper (2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-8d + "'", double5 == 1.0E-8d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D33 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double34 = size2D33.getWidth();
        org.jfree.chart.util.Size2D size2D35 = rectangleConstraint30.calculateConstrainedSize(size2D33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, 0.0d, (double) 10L, rectangleAnchor38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str43 = rectangleAnchor42.toString();
        java.awt.geom.Rectangle2D rectangle2D44 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) 100.0f, (double) (-655360), rectangleAnchor42);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D48 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double49 = size2D48.getWidth();
        org.jfree.chart.util.Size2D size2D50 = rectangleConstraint45.calculateConstrainedSize(size2D48);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, 0.0d, (double) 10L, rectangleAnchor53);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str58 = rectangleAnchor57.toString();
        java.awt.geom.Rectangle2D rectangle2D59 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) 100.0f, (double) (-655360), rectangleAnchor57);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        try {
            org.jfree.chart.axis.AxisState axisState62 = numberAxis3D21.draw(graphics2D28, (double) (byte) 1, rectangle2D44, rectangle2D59, rectangleEdge60, plotRenderingInfo61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "RectangleAnchor.LEFT" + "'", str43.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "RectangleAnchor.LEFT" + "'", str58.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D59);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        xYPlot13.clearDomainMarkers((-1));
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color2, stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke3, rectangleInsets9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder11.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot0.setDataset(waferMapDataset3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        waferMapPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        waferMapPlot0.setInsets(rectangleInsets7, false);
        java.awt.Font font12 = null;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer17 = new org.jfree.chart.text.G2TextMeasurer(graphics2D16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer17);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, paint13);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double25 = size2D24.getWidth();
        org.jfree.chart.util.Size2D size2D26 = rectangleConstraint21.calculateConstrainedSize(size2D24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, 0.0d, (double) 10L, rectangleAnchor29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str34 = rectangleAnchor33.toString();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) 100.0f, (double) (-655360), rectangleAnchor33);
        try {
            blockBorder19.draw(graphics2D20, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleAnchor.LEFT" + "'", str34.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.setLabelAngle(0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = null;
        try {
            categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = color2.brighter();
        int int4 = color2.getRGB();
        java.awt.Font font7 = null;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer12 = new org.jfree.chart.text.G2TextMeasurer(graphics2D11);
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint8, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer12);
        try {
            org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("XY Plot", font1, (java.awt.Paint) color2, (float) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16711936) + "'", int4 == (-16711936));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset11);
        try {
            org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset11, (java.lang.Comparable) "ClassContext");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2000.0d + "'", number12.equals(2000.0d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot13.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot13.render(graphics2D29, rectangle2D30, 255, plotRenderingInfo32, crosshairState33);
        java.awt.Color color36 = java.awt.Color.green;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color36, stroke37);
        java.awt.Color color40 = java.awt.Color.green;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color40, stroke41);
        valueMarker38.setStroke(stroke41);
        valueMarker38.setValue(10.0d);
        float float46 = valueMarker38.getAlpha();
        try {
            boolean boolean47 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 1.0f + "'", float46 == 1.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(90.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (90.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        double double2 = categoryAxis3D1.getLowerMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double9 = size2D8.getWidth();
        org.jfree.chart.util.Size2D size2D10 = rectangleConstraint5.calculateConstrainedSize(size2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, 0.0d, (double) 10L, rectangleAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str18 = rectangleAnchor17.toString();
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) 100.0f, (double) (-655360), rectangleAnchor17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double24 = size2D23.getWidth();
        org.jfree.chart.util.Size2D size2D25 = rectangleConstraint20.calculateConstrainedSize(size2D23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, 0.0d, (double) 10L, rectangleAnchor28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str33 = rectangleAnchor32.toString();
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) 100.0f, (double) (-655360), rectangleAnchor32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean36 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            org.jfree.chart.axis.AxisState axisState38 = categoryAxis3D1.draw(graphics2D3, (double) 500, rectangle2D19, rectangle2D34, rectangleEdge35, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleAnchor.LEFT" + "'", str18.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleAnchor.LEFT" + "'", str33.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        try {
            xYPlot13.zoomRangeAxes((double) 100.0f, 0.0d, plotRenderingInfo24, point2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10448.025) <= upper (-51.975).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 2, (double) (byte) 100, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
        org.junit.Assert.assertNotNull(inputStream2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset11);
        try {
            org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset11, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2000.0d + "'", number12.equals(2000.0d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 1.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = valueMarker31.getLabelOffsetType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range42 = numberAxis3D41.getRange();
        org.jfree.chart.plot.Plot plot43 = numberAxis3D41.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        numberAxis3D41.setRange(range45);
        java.awt.Paint paint47 = numberAxis3D41.getLabelPaint();
        valueMarker31.setLabelPaint(paint47);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(plot43);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        double double4 = rectangleInsets0.calculateBottomInset((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.RED;
        float[] floatArray6 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray7 = color2.getRGBColorComponents(floatArray6);
        try {
            float[] floatArray8 = color0.getComponents(colorSpace1, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleAnchor.LEFT");
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        waferMapPlot2.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        waferMapPlot2.setInsets(rectangleInsets9, false);
        java.awt.Font font14 = null;
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer19 = new org.jfree.chart.text.G2TextMeasurer(graphics2D18);
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, paint15, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer19);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, paint15);
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) '4', (float) 1, 10.0f);
        int int26 = color25.getRGB();
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color1, paint15, color25 };
        java.awt.Stroke[] strokeArray28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        org.jfree.chart.plot.Plot plot46 = numberAxis3D44.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range48 = numberAxis3D47.getRange();
        numberAxis3D44.setRange(range48);
        java.text.NumberFormat numberFormat50 = numberAxis3D44.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis3D44.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer52);
        java.awt.Stroke stroke54 = xYPlot53.getDomainZeroBaselineStroke();
        java.awt.Color color55 = java.awt.Color.green;
        java.awt.Color color57 = java.awt.Color.green;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color57, stroke58);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType65 = rectangleInsets64.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder66 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color55, stroke58, rectangleInsets64);
        java.awt.Stroke[] strokeArray67 = new java.awt.Stroke[] { stroke54, stroke58 };
        java.awt.Shape[] shapeArray68 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier69 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray27, strokeArray28, strokeArray67, shapeArray68);
        try {
            java.awt.Shape shape70 = defaultDrawingSupplier69.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-655360) + "'", int26 == (-655360));
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(plot46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(numberFormat50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(unitType65);
        org.junit.Assert.assertNotNull(strokeArray67);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj1 = null;
        boolean boolean2 = chartChangeEventType0.equals(obj1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        float float27 = xYPlot13.getForegroundAlpha();
        xYPlot13.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot13.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation25, plotOrientation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        numberAxis3D21.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.Plot plot31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace35 = numberAxis3D21.reserveSpace(graphics2D30, plot31, rectangle2D32, rectangleEdge33, axisSpace34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        double double30 = numberAxis3D28.getUpperBound();
        java.awt.Font font31 = numberAxis3D28.getLabelFont();
        numberAxis3D21.setLabelFont(font31);
        double double33 = numberAxis3D21.getUpperMargin();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Object obj16 = blockContainer15.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) dateAxis17);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        org.jfree.data.Range range30 = org.jfree.data.Range.expand(range27, (double) (byte) 1, 1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(1.0d, range27);
        try {
            org.jfree.chart.util.Size2D size2D32 = blockContainer15.arrange(graphics2D24, rectangleConstraint31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        int int34 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        float float35 = numberAxis3D25.getTickMarkInsideLength();
        numberAxis3D25.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.lang.Object obj15 = blockContainer14.clone();
        blockContainer14.setWidth((double) (short) 1);
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        org.jfree.chart.plot.Plot plot21 = numberAxis3D19.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range23 = numberAxis3D22.getRange();
        numberAxis3D19.setRange(range23);
        java.text.NumberFormat numberFormat25 = numberAxis3D19.getNumberFormatOverride();
        java.text.NumberFormat numberFormat26 = null;
        numberAxis3D19.setNumberFormatOverride(numberFormat26);
        java.awt.Paint paint28 = numberAxis3D19.getLabelPaint();
        boolean boolean29 = columnArrangement18.equals((java.lang.Object) paint28);
        boolean boolean31 = columnArrangement18.equals((java.lang.Object) "WMAP_Plot");
        blockContainer14.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement18);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(numberFormat25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        numberAxis3D0.setTickMarkOutsideLength(0.0f);
        double double5 = numberAxis3D0.getAutoRangeMinimumSize();
        numberAxis3D0.setFixedDimension((double) 1);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-8d + "'", double5 == 1.0E-8d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj3 = objectList0.get((-16711936));
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        java.lang.Object obj2 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) 1L);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        double double3 = numberAxis3D1.getUpperBound();
        java.awt.Font font4 = numberAxis3D1.getLabelFont();
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("Range[0.0,1.0]", font4, paint5, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot13.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot13.render(graphics2D29, rectangle2D30, 255, plotRenderingInfo32, crosshairState33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot13.getLegendItems();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot13.setRangeGridlineStroke(stroke36);
        xYPlot13.setNoDataMessage("XY Plot");
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (float) 500, 100.0f, textAnchor4, (double) 'a', (float) '#', (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range17 = numberAxis3D16.getRange();
        org.jfree.chart.plot.Plot plot18 = numberAxis3D16.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        numberAxis3D16.setRange(range20);
        java.text.NumberFormat numberFormat22 = numberAxis3D16.getNumberFormatOverride();
        java.text.NumberFormat numberFormat23 = null;
        numberAxis3D16.setNumberFormatOverride(numberFormat23);
        java.awt.Paint paint25 = numberAxis3D16.getLabelPaint();
        boolean boolean26 = columnArrangement15.equals((java.lang.Object) paint25);
        boolean boolean28 = columnArrangement15.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement15);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        xYPlot43.zoomRangeAxes(100.0d, plotRenderingInfo45, point2D48, false);
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot43.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis53 = xYPlot43.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        xYPlot43.setRenderer(xYItemRenderer54);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot43);
        xYPlot43.setRangeCrosshairValue(1.0E-5d, true);
        columnArrangement0.add((org.jfree.chart.block.Block) blockContainer29, (java.lang.Object) xYPlot43);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(numberFormat22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNull(valueAxis53);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (short) 100);
        int int3 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterY((double) (byte) 10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range24 = numberAxis3D23.getRange();
        org.jfree.chart.plot.Plot plot25 = numberAxis3D23.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        numberAxis3D23.setRange(range27);
        java.text.NumberFormat numberFormat29 = numberAxis3D23.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis3D23.getTickLabelInsets();
        java.awt.Shape shape31 = numberAxis3D23.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range37 = numberAxis3D36.getRange();
        org.jfree.chart.plot.Plot plot38 = numberAxis3D36.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range40 = numberAxis3D39.getRange();
        numberAxis3D36.setRange(range40);
        xYPlot35.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        double double45 = numberAxis3D43.getUpperBound();
        double double46 = numberAxis3D43.getFixedAutoRange();
        numberAxis3D43.setPositiveArrowVisible(false);
        org.jfree.data.Range range49 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        boolean boolean50 = numberAxis3D43.isNegativeArrowVisible();
        numberAxis3D43.setAutoRangeMinimumSize((double) (short) 100, false);
        org.jfree.data.Range range54 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        int int55 = xYPlot13.getRangeAxisCount();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(numberFormat29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        float float27 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        int int29 = xYPlot13.getSeriesCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = null;
        try {
            xYPlot13.setOrientation(plotOrientation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.lang.Object obj15 = blockContainer14.clone();
        java.util.List list16 = blockContainer14.getBlocks();
        org.jfree.chart.block.Arrangement arrangement17 = blockContainer14.getArrangement();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(arrangement17);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        numberAxis3D21.setAxisLineVisible(false);
        boolean boolean30 = numberAxis3D21.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        float float27 = xYPlot13.getForegroundAlpha();
        xYPlot13.clearRangeAxes();
        java.awt.Paint paint29 = xYPlot13.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        int int34 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        double double35 = numberAxis3D25.getFixedDimension();
        boolean boolean36 = numberAxis3D25.isInverted();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieHRadius();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.plot.Plot plot8 = numberAxis3D6.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        numberAxis3D6.setRange(range10);
        java.text.NumberFormat numberFormat12 = numberAxis3D6.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D6.getTickLabelInsets();
        java.awt.Shape shape14 = numberAxis3D6.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = null;
        java.awt.geom.Point2D point2D23 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor22);
        xYPlot18.zoomRangeAxes(100.0d, plotRenderingInfo20, point2D23, false);
        double double26 = xYPlot18.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot18.setFixedDomainAxisSpace(axisSpace27, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.plot.Plot plot32 = numberAxis3D30.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range34 = numberAxis3D33.getRange();
        numberAxis3D30.setRange(range34);
        java.text.NumberFormat numberFormat36 = numberAxis3D30.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D30.getTickLabelInsets();
        java.awt.Shape shape38 = numberAxis3D30.getRightArrow();
        int int39 = xYPlot18.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Font font40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D30.setTickLabelFont(font40);
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("Range[0.0,1.0]", font40);
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.text.TextFragment textFragment45 = new org.jfree.chart.text.TextFragment("ThreadContext", font40, paint43, (float) 1);
        boolean boolean46 = unitType2.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(numberFormat36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        numberAxis3D21.setAxisLineVisible(false);
        boolean boolean30 = numberAxis3D21.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        int int14 = xYPlot13.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot13.getDataset((int) (short) -1);
        java.awt.Stroke stroke17 = xYPlot13.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        xYPlot13.zoomDomainAxes(0.0d, (double) 1L, plotRenderingInfo24, point2D27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.plot.Plot plot32 = numberAxis3D30.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range34 = numberAxis3D33.getRange();
        numberAxis3D30.setRange(range34);
        java.text.NumberFormat numberFormat36 = numberAxis3D30.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D30.getTickLabelInsets();
        java.awt.Shape shape38 = numberAxis3D30.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range40 = numberAxis3D39.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer41);
        boolean boolean43 = xYPlot42.isDomainZeroBaselineVisible();
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot42.setDomainTickBandPaint((java.awt.Paint) color44);
        java.awt.Stroke stroke46 = xYPlot42.getRangeZeroBaselineStroke();
        java.awt.Color color48 = java.awt.Color.green;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color48, stroke49);
        boolean boolean52 = valueMarker50.equals((java.lang.Object) 0);
        xYPlot42.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker50);
        org.jfree.chart.util.Layer layer54 = null;
        try {
            xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker50, layer54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(numberFormat36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot13.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot13.render(graphics2D29, rectangle2D30, 255, plotRenderingInfo32, crosshairState33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot13.getLegendItems();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot13.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot13.getDomainAxis(10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        xYPlot13.addChangeListener(plotChangeListener40);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation42 = null;
        try {
            xYPlot13.addAnnotation(xYAnnotation42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot13.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint31 = numberAxis3D30.getTickMarkPaint();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.plot.Plot plot36 = numberAxis3D34.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        numberAxis3D34.setRange(range38);
        java.text.NumberFormat numberFormat40 = numberAxis3D34.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = numberAxis3D34.getTickLabelInsets();
        java.awt.Shape shape42 = numberAxis3D34.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer45);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range48 = numberAxis3D47.getRange();
        org.jfree.chart.plot.Plot plot49 = numberAxis3D47.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range51 = numberAxis3D50.getRange();
        numberAxis3D47.setRange(range51);
        xYPlot46.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D47);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range55 = numberAxis3D54.getRange();
        double double56 = numberAxis3D54.getUpperBound();
        double double57 = numberAxis3D54.getFixedAutoRange();
        numberAxis3D54.setPositiveArrowVisible(false);
        org.jfree.data.Range range60 = xYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D54);
        boolean boolean61 = numberAxis3D54.isNegativeArrowVisible();
        java.awt.Font font62 = numberAxis3D54.getTickLabelFont();
        numberAxis3D30.setTickLabelFont(font62);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = numberAxis3D30.getLabelInsets();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(plot49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNull(range60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(rectangleInsets64);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Object obj16 = blockContainer15.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) dateAxis17);
        double double24 = blockContainer15.getContentXOffset();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        int int34 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        boolean boolean35 = numberAxis3D25.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (-16711936), (float) 8, textAnchor4, (double) 10, textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        double double2 = range1.getLength();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setPieArea(rectangle2D2);
        piePlotState1.setPieCenterX(0.0d);
        double double6 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.setLabelAngle(0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D1.getCategoryLabelPositions();
        double double5 = categoryAxis3D1.getLowerMargin();
        java.lang.Object obj6 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo3.addOptionalLibrary("");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.plot.Plot plot8 = numberAxis3D6.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        numberAxis3D6.setRange(range10);
        java.text.NumberFormat numberFormat12 = numberAxis3D6.getNumberFormatOverride();
        java.text.NumberFormat numberFormat13 = null;
        numberAxis3D6.setNumberFormatOverride(numberFormat13);
        java.awt.Shape shape15 = numberAxis3D6.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape15, "");
        boolean boolean18 = projectInfo3.equals((java.lang.Object) shape15);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        xYPlot37.zoomRangeAxes(100.0d, plotRenderingInfo39, point2D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot37.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation45, true);
        java.awt.Paint paint48 = xYPlot13.getDomainGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range52 = numberAxis3D51.getRange();
        org.jfree.chart.plot.Plot plot53 = numberAxis3D51.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range55 = numberAxis3D54.getRange();
        numberAxis3D51.setRange(range55);
        java.text.NumberFormat numberFormat57 = numberAxis3D51.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = numberAxis3D51.getTickLabelInsets();
        java.awt.Shape shape59 = numberAxis3D51.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range61 = numberAxis3D60.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset50, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, xYItemRenderer62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = null;
        java.awt.geom.Point2D point2D68 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D66, rectangleAnchor67);
        xYPlot63.zoomRangeAxes(100.0d, plotRenderingInfo65, point2D68, false);
        org.jfree.chart.axis.AxisLocation axisLocation71 = xYPlot63.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis73 = xYPlot63.getRangeAxis(100);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot63.setRangeCrosshairStroke(stroke74);
        xYPlot63.clearRangeMarkers((int) 'a');
        java.awt.Color color79 = java.awt.Color.green;
        java.awt.Stroke stroke80 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker81 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color79, stroke80);
        java.awt.Color color83 = java.awt.Color.green;
        java.awt.Stroke stroke84 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker85 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color83, stroke84);
        valueMarker81.setStroke(stroke84);
        valueMarker81.setValue(10.0d);
        xYPlot63.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker81);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType90 = valueMarker81.getLabelOffsetType();
        java.awt.Color color92 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color93 = java.awt.Color.getColor("ThreadContext", color92);
        valueMarker81.setOutlinePaint((java.awt.Paint) color92);
        org.jfree.chart.util.Layer layer95 = null;
        try {
            boolean boolean96 = xYPlot13.removeRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) valueMarker81, layer95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(plot53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNull(numberFormat57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(point2D68);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(lengthAdjustmentType90);
        org.junit.Assert.assertNotNull(color92);
        org.junit.Assert.assertNotNull(color93);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        waferMapPlot0.axisChanged(axisChangeEvent3);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection5 = waferMapPlot0.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot13.getDomainAxisLocation(0);
        java.lang.Object obj26 = null;
        boolean boolean27 = xYPlot13.equals(obj26);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainZeroBaselineVisible();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color15);
        java.util.List list17 = xYPlot13.getAnnotations();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.general.PieDataset pieDataset1 = piePlot3D0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            piePlot3D0.setLabelPadding(rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieDataset1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("WMAP_Plot", "WMAP_Plot", "WMAP_Plot", image3, "WMAP_Plot", "WMAP_Plot", "hi!");
        projectInfo7.setLicenceText("ClassContext");
        projectInfo7.addOptionalLibrary("ThreadContext");
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        org.jfree.chart.plot.Plot plot28 = numberAxis3D26.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range30 = numberAxis3D29.getRange();
        numberAxis3D26.setRange(range30);
        java.text.NumberFormat numberFormat32 = numberAxis3D26.getNumberFormatOverride();
        java.text.NumberFormat numberFormat33 = null;
        numberAxis3D26.setNumberFormatOverride(numberFormat33);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = null;
        numberAxis3D26.setStandardTickUnits(tickUnitSource35);
        int int37 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D26);
        double double38 = xYPlot13.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNull(numberFormat32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color1 = java.awt.Color.RED;
        float[] floatArray5 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray6 = color1.getRGBColorComponents(floatArray5);
        try {
            float[] floatArray7 = color0.getRGBComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Object obj16 = blockContainer15.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) dateAxis17);
        blockContainer15.setPadding((double) 100L, (double) 0, (double) (byte) 0, 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) (byte) 10, (double) (byte) 1, (double) (byte) 100);
        blockContainer15.setPadding(rectangleInsets33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint36.toFixedHeight((double) (byte) -1);
        org.jfree.chart.util.Size2D size2D39 = blockContainer15.arrange(graphics2D35, rectangleConstraint36);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(size2D39);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        float float27 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        int int29 = xYPlot13.getSeriesCount();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        xYPlot13.axisChanged(axisChangeEvent30);
        double double32 = xYPlot13.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.plot.Plot plot36 = numberAxis3D34.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        numberAxis3D34.setRange(range38);
        java.text.NumberFormat numberFormat40 = numberAxis3D34.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = numberAxis3D34.getTickLabelInsets();
        java.awt.Shape shape42 = numberAxis3D34.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer45);
        int int47 = xYPlot46.getRangeAxisCount();
        java.awt.Stroke stroke48 = xYPlot46.getRangeGridlineStroke();
        xYPlot13.setRangeZeroBaselineStroke(stroke48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = null;
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D52, rectangleAnchor53);
        try {
            xYPlot13.zoomRangeAxes((double) (byte) 10, plotRenderingInfo51, point2D54, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(point2D54);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0, (double) 1, (double) (-1L), 0.0d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.calculateBottomOutset((double) 2);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        numberAxis3D0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.LEFT", graphics2D1, 0.0f, (float) (short) 1, textAnchor4, (double) (short) -1, (float) 8, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot13.getDomainMarkers(layer40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range46 = numberAxis3D45.getRange();
        org.jfree.chart.plot.Plot plot47 = numberAxis3D45.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range49 = numberAxis3D48.getRange();
        numberAxis3D45.setRange(range49);
        java.text.NumberFormat numberFormat51 = numberAxis3D45.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = numberAxis3D45.getTickLabelInsets();
        java.awt.Shape shape53 = numberAxis3D45.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range55 = numberAxis3D54.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, (org.jfree.chart.axis.ValueAxis) numberAxis3D54, xYItemRenderer56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = null;
        java.awt.geom.Point2D point2D62 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D60, rectangleAnchor61);
        xYPlot57.zoomRangeAxes(100.0d, plotRenderingInfo59, point2D62, false);
        double double65 = xYPlot57.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = null;
        java.awt.geom.Point2D point2D71 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D69, rectangleAnchor70);
        xYPlot57.zoomDomainAxes(0.0d, (double) 1L, plotRenderingInfo68, point2D71);
        xYPlot13.zoomDomainAxes(0.2d, plotRenderingInfo43, point2D71);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNull(numberFormat51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(point2D62);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(point2D71);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        java.awt.Shape shape9 = numberAxis3D0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        chartEntity11.setURLText("RectangleAnchor.LEFT");
        java.awt.Shape shape14 = chartEntity11.getArea();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range17 = numberAxis3D16.getRange();
        org.jfree.chart.plot.Plot plot18 = numberAxis3D16.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        numberAxis3D16.setRange(range20);
        java.text.NumberFormat numberFormat22 = numberAxis3D16.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D16.getTickLabelInsets();
        java.awt.Shape shape24 = numberAxis3D16.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, xYItemRenderer27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range30 = numberAxis3D29.getRange();
        numberAxis3D16.setDefaultAutoRange(range30);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.plot.Plot plot34 = numberAxis3D32.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range36 = numberAxis3D35.getRange();
        numberAxis3D32.setRange(range36);
        java.text.NumberFormat numberFormat38 = numberAxis3D32.getNumberFormatOverride();
        java.text.NumberFormat numberFormat39 = null;
        numberAxis3D32.setNumberFormatOverride(numberFormat39);
        java.awt.Shape shape41 = numberAxis3D32.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity(shape41, "");
        chartEntity43.setURLText("RectangleAnchor.LEFT");
        java.awt.Shape shape46 = chartEntity43.getArea();
        numberAxis3D16.setRightArrow(shape46);
        chartEntity11.setArea(shape46);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(numberFormat22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint2 = numberAxis3D1.getTickMarkPaint();
        boolean boolean3 = numberAxis3D1.isPositiveArrowVisible();
        boolean boolean4 = numberAxis3D1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        xYPlot13.setRangeCrosshairValue(1.0E-5d, true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = xYPlot13.getFixedLegendItems();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(legendItemCollection30);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        waferMapPlot2.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        waferMapPlot2.setInsets(rectangleInsets9, false);
        java.awt.Font font14 = null;
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer19 = new org.jfree.chart.text.G2TextMeasurer(graphics2D18);
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, paint15, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer19);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, paint15);
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) '4', (float) 1, 10.0f);
        int int26 = color25.getRGB();
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color1, paint15, color25 };
        java.awt.Stroke[] strokeArray28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        org.jfree.chart.plot.Plot plot46 = numberAxis3D44.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range48 = numberAxis3D47.getRange();
        numberAxis3D44.setRange(range48);
        java.text.NumberFormat numberFormat50 = numberAxis3D44.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis3D44.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer52);
        java.awt.Stroke stroke54 = xYPlot53.getDomainZeroBaselineStroke();
        java.awt.Color color55 = java.awt.Color.green;
        java.awt.Color color57 = java.awt.Color.green;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color57, stroke58);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType65 = rectangleInsets64.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder66 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color55, stroke58, rectangleInsets64);
        java.awt.Stroke[] strokeArray67 = new java.awt.Stroke[] { stroke54, stroke58 };
        java.awt.Shape[] shapeArray68 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier69 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray27, strokeArray28, strokeArray67, shapeArray68);
        java.awt.Paint paint70 = defaultDrawingSupplier69.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-655360) + "'", int26 == (-655360));
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(plot46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(numberFormat50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(unitType65);
        org.junit.Assert.assertNotNull(strokeArray67);
        org.junit.Assert.assertNotNull(paint70);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo3.addOptionalLibrary("");
        boolean boolean7 = projectInfo3.equals((java.lang.Object) (byte) 10);
        projectInfo3.addOptionalLibrary("hi!");
        java.lang.String str10 = projectInfo3.getLicenceText();
        java.util.List list11 = projectInfo3.getContributors();
        java.awt.Image image12 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.LEFT", "WMAP_Plot", "WMAP_Plot", image12, "", "RectangleEdge.RIGHT", "RectangleAnchor.LEFT");
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(image12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        int int14 = xYPlot13.getRangeAxisCount();
        xYPlot13.setForegroundAlpha((float) (-16711936));
        java.awt.Color color18 = java.awt.Color.green;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color18, stroke19);
        boolean boolean22 = valueMarker20.equals((java.lang.Object) 0);
        java.lang.Object obj23 = valueMarker20.clone();
        float float24 = valueMarker20.getAlpha();
        org.jfree.chart.util.Layer layer25 = null;
        try {
            xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker20, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot13.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot13.render(graphics2D29, rectangle2D30, 255, plotRenderingInfo32, crosshairState33);
        java.awt.Stroke stroke35 = xYPlot13.getOutlineStroke();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint2 = numberAxis3D1.getTickMarkPaint();
        boolean boolean3 = numberAxis3D1.isPositiveArrowVisible();
        boolean boolean4 = numberAxis3D1.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot13.datasetChanged(datasetChangeEvent27);
        boolean boolean29 = xYPlot13.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        int int27 = xYPlot13.getRangeAxisIndex(valueAxis26);
        xYPlot13.clearAnnotations();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        java.text.NumberFormat numberFormat14 = numberAxis3D1.getNumberFormatOverride();
        numberAxis3D1.setLabelToolTip("WMAP_Plot");
        double double17 = numberAxis3D1.getUpperBound();
        numberAxis3D1.setUpperMargin((double) (short) -1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Object obj16 = blockContainer15.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) dateAxis17);
        blockContainer15.setPadding((double) 100L, (double) 0, (double) (byte) 0, 1.0d);
        double double29 = blockContainer15.getHeight();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        java.lang.String str22 = xYPlot13.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        xYPlot13.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D27, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        java.awt.Shape shape9 = numberAxis3D0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape9, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.lang.String str14 = chartEntity13.getToolTipText();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str14.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        xYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range46 = numberAxis3D45.getRange();
        org.jfree.chart.plot.Plot plot47 = numberAxis3D45.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range49 = numberAxis3D48.getRange();
        numberAxis3D45.setRange(range49);
        java.text.NumberFormat numberFormat51 = numberAxis3D45.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = numberAxis3D45.getTickLabelInsets();
        java.awt.Shape shape53 = numberAxis3D45.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range55 = numberAxis3D54.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, (org.jfree.chart.axis.ValueAxis) numberAxis3D54, xYItemRenderer56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = null;
        java.awt.geom.Point2D point2D62 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D60, rectangleAnchor61);
        xYPlot57.zoomRangeAxes(100.0d, plotRenderingInfo59, point2D62, false);
        org.jfree.chart.axis.AxisLocation axisLocation65 = xYPlot57.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis67 = xYPlot57.getRangeAxis(100);
        java.awt.Stroke stroke68 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot57.setRangeCrosshairStroke(stroke68);
        xYPlot57.clearRangeMarkers((int) 'a');
        java.awt.Color color73 = java.awt.Color.green;
        java.awt.Stroke stroke74 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker75 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color73, stroke74);
        java.awt.Color color77 = java.awt.Color.green;
        java.awt.Stroke stroke78 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker79 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color77, stroke78);
        valueMarker75.setStroke(stroke78);
        valueMarker75.setValue(10.0d);
        xYPlot57.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker75);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType84 = valueMarker75.getLabelOffsetType();
        java.awt.Stroke stroke85 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker75.setStroke(stroke85);
        org.jfree.chart.util.Layer layer87 = null;
        try {
            boolean boolean88 = xYPlot13.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker75, layer87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNull(numberFormat51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(point2D62);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNull(valueAxis67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(lengthAdjustmentType84);
        org.junit.Assert.assertNotNull(stroke85);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        java.awt.Color color4 = java.awt.Color.green;
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color6, stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets13.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke7, rectangleInsets13);
        valueMarker3.setOutlineStroke(stroke7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        try {
            valueMarker3.setLabelAnchor(rectangleAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(unitType14);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = color0.brighter();
        int int2 = color0.getRGB();
        int int3 = color0.getBlue();
        float[] floatArray10 = new float[] { ' ', 1L, '#' };
        float[] floatArray11 = java.awt.Color.RGBtoHSB((-16711936), 0, (int) (short) 100, floatArray10);
        try {
            float[] floatArray12 = color0.getRGBComponents(floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16711936) + "'", int2 == (-16711936));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range4, (double) 1, false);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.ui.Library library18 = new org.jfree.chart.ui.Library("hi!", "ClassContext", "", "ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        boolean boolean21 = library18.equals((java.lang.Object) rectangleInsets19);
        numberAxis3D1.setTickLabelInsets(rectangleInsets19);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Color color1 = java.awt.Color.getColor("Range[0.0,1.0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        boolean boolean40 = xYPlot13.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        java.awt.Shape shape9 = numberAxis3D0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range13 = numberAxis3D12.getRange();
        org.jfree.chart.plot.Plot plot14 = numberAxis3D12.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        numberAxis3D12.setRange(range16);
        java.text.NumberFormat numberFormat18 = numberAxis3D12.getNumberFormatOverride();
        java.text.NumberFormat numberFormat19 = null;
        numberAxis3D12.setNumberFormatOverride(numberFormat19);
        java.awt.Shape shape21 = numberAxis3D12.getLeftArrow();
        chartEntity11.setArea(shape21);
        java.lang.Object obj23 = chartEntity11.clone();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(numberFormat18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot13.getDataset((-1));
        java.awt.Paint paint27 = xYPlot13.getBackgroundPaint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot13.getRendererForDataset(xYDataset28);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(xYItemRenderer29);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        boolean boolean25 = xYPlot24.isRangeZeroBaselineVisible();
        java.lang.String str26 = xYPlot24.getPlotType();
        java.awt.Paint paint27 = null;
        try {
            xYPlot24.setRangeGridlinePaint(paint27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("ThreadContext", color1);
        java.awt.Color color3 = java.awt.Color.RED;
        float[] floatArray7 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray8 = color3.getRGBColorComponents(floatArray7);
        try {
            float[] floatArray9 = color2.getRGBComponents(floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        int int14 = xYPlot13.getRangeAxisCount();
        xYPlot13.setForegroundAlpha((float) (-16711936));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            xYPlot13.handleClick((int) (short) 10, 0, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        blockContainer14.setPadding((double) (byte) 100, 0.0d, 0.05d, (double) 100);
        blockContainer14.setMargin(0.0d, (double) (byte) 1, 1.0E-5d, (double) '#');
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        int int25 = xYPlot13.getDatasetCount();
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = color26.brighter();
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color27);
        int int29 = color27.getRed();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0E-8d, 100.0d, (double) 15, (double) 100L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        java.awt.Stroke stroke25 = xYPlot24.getDomainZeroBaselineStroke();
        boolean boolean26 = xYPlot24.isRangeZeroBaselineVisible();
        xYPlot24.clearRangeAxes();
        xYPlot24.zoom((double) 100);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.LEFT", graphics2D1, (float) 10, (float) (short) 1, (double) 100.0f, 0.0f, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        boolean boolean4 = projectInfo0.equals((java.lang.Object) (byte) 10);
        projectInfo0.addOptionalLibrary("hi!");
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo0.getLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        projectInfo8.addOptionalLibrary("");
        boolean boolean12 = projectInfo8.equals((java.lang.Object) (byte) 10);
        projectInfo8.addOptionalLibrary("hi!");
        org.jfree.chart.ui.Library[] libraryArray15 = projectInfo8.getLibraries();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo8);
        java.awt.Image image17 = projectInfo8.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(libraryArray15);
        org.junit.Assert.assertNotNull(image17);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        numberAxis3D4.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double13 = size2D12.getWidth();
        org.jfree.chart.util.Size2D size2D14 = rectangleConstraint9.calculateConstrainedSize(size2D12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, 0.0d, (double) 10L, rectangleAnchor17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str22 = rectangleAnchor21.toString();
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) 100.0f, (double) (-655360), rectangleAnchor21);
        try {
            blockBorder7.draw(graphics2D8, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleAnchor.LEFT" + "'", str22.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range17 = numberAxis3D16.getRange();
        org.jfree.chart.plot.Plot plot18 = numberAxis3D16.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        numberAxis3D16.setRange(range20);
        java.text.NumberFormat numberFormat22 = numberAxis3D16.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D16.getTickLabelInsets();
        java.awt.Shape shape24 = numberAxis3D16.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, xYItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = null;
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D31, rectangleAnchor32);
        xYPlot28.zoomRangeAxes(100.0d, plotRenderingInfo30, point2D33, false);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot28.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot28.getRangeAxis(100);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot28.setRangeCrosshairStroke(stroke39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot28.getDomainAxisLocation();
        float float42 = xYPlot28.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot28);
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer14, (java.lang.Object) plotChangeEvent43);
        org.jfree.chart.JFreeChart jFreeChart45 = null;
        plotChangeEvent43.setChart(jFreeChart45);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType47 = plotChangeEvent43.getType();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(numberFormat22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(point2D33);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.5f + "'", float42 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType47);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = valueMarker31.getLabelOffsetType();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color43 = java.awt.Color.getColor("ThreadContext", color42);
        valueMarker31.setOutlinePaint((java.awt.Paint) color42);
        java.lang.Class class45 = null;
        try {
            java.util.EventListener[] eventListenerArray46 = valueMarker31.getListeners(class45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        float float27 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        int int29 = xYPlot13.getSeriesCount();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        xYPlot13.axisChanged(axisChangeEvent30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        int int34 = color32.getRGB();
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color32);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-12517568) + "'", int34 == (-12517568));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) "Range[0.0,1.0]");
        strokeMap0.clear();
        boolean boolean5 = strokeMap0.containsKey((java.lang.Comparable) 1L);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor7 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        boolean boolean8 = strokeMap0.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        int int34 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        float float35 = numberAxis3D25.getTickMarkInsideLength();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        org.jfree.chart.plot.Plot plot39 = numberAxis3D37.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        numberAxis3D37.setRange(range41);
        java.text.NumberFormat numberFormat43 = numberAxis3D37.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = numberAxis3D37.getTickLabelInsets();
        java.awt.Shape shape45 = numberAxis3D37.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range47 = numberAxis3D46.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer48);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range51 = numberAxis3D50.getRange();
        org.jfree.chart.plot.Plot plot52 = numberAxis3D50.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range54 = numberAxis3D53.getRange();
        numberAxis3D50.setRange(range54);
        xYPlot49.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D50);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range58 = numberAxis3D57.getRange();
        double double59 = numberAxis3D57.getUpperBound();
        double double60 = numberAxis3D57.getFixedAutoRange();
        numberAxis3D57.setPositiveArrowVisible(false);
        org.jfree.data.Range range63 = xYPlot49.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D57);
        boolean boolean64 = numberAxis3D57.isNegativeArrowVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit65 = numberAxis3D57.getTickUnit();
        numberAxis3D25.setTickUnit(numberTickUnit65);
        numberAxis3D25.setLabelToolTip("ClassContext");
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNull(numberFormat43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNull(plot52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(numberTickUnit65);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.lang.String str7 = range5.toString();
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) str7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment9, (double) (byte) 1, 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,1.0]" + "'", str7.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double10 = size2D9.getWidth();
        org.jfree.chart.util.Size2D size2D11 = rectangleConstraint6.calculateConstrainedSize(size2D9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, 0.0d, (double) 10L, rectangleAnchor14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str19 = rectangleAnchor18.toString();
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) 100.0f, (double) (-655360), rectangleAnchor18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double25 = size2D24.getWidth();
        org.jfree.chart.util.Size2D size2D26 = rectangleConstraint21.calculateConstrainedSize(size2D24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, 0.0d, (double) 10L, rectangleAnchor29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str34 = rectangleAnchor33.toString();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) 100.0f, (double) (-655360), rectangleAnchor33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            org.jfree.chart.axis.AxisState axisState38 = dateAxis0.draw(graphics2D4, (double) (-1), rectangle2D20, rectangle2D35, rectangleEdge36, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleAnchor.LEFT" + "'", str19.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleAnchor.LEFT" + "'", str34.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range24 = numberAxis3D23.getRange();
        org.jfree.chart.plot.Plot plot25 = numberAxis3D23.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        numberAxis3D23.setRange(range27);
        java.text.NumberFormat numberFormat29 = numberAxis3D23.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis3D23.getTickLabelInsets();
        java.awt.Shape shape31 = numberAxis3D23.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range37 = numberAxis3D36.getRange();
        org.jfree.chart.plot.Plot plot38 = numberAxis3D36.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range40 = numberAxis3D39.getRange();
        numberAxis3D36.setRange(range40);
        xYPlot35.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        double double45 = numberAxis3D43.getUpperBound();
        double double46 = numberAxis3D43.getFixedAutoRange();
        numberAxis3D43.setPositiveArrowVisible(false);
        org.jfree.data.Range range49 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        boolean boolean50 = numberAxis3D43.isNegativeArrowVisible();
        numberAxis3D43.setAutoRangeMinimumSize((double) (short) 100, false);
        org.jfree.data.Range range54 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        org.jfree.chart.axis.ValueAxis valueAxis55 = xYPlot13.getRangeAxis();
        float float56 = xYPlot13.getForegroundAlpha();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(numberFormat29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertNotNull(valueAxis55);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 1.0f + "'", float56 == 1.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (-16711936), (double) (short) 10);
        java.lang.Object obj3 = size2D2.clone();
        size2D2.width = 0L;
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        double double4 = rectangleInsets0.calculateTopOutset(0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean3 = dateRange0.intersects((double) (short) 0, 10.0d);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        int int28 = xYPlot13.getIndexOf(xYItemRenderer27);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.setLabelAngle(0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D1.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double12 = size2D11.getWidth();
        org.jfree.chart.util.Size2D size2D13 = rectangleConstraint8.calculateConstrainedSize(size2D11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.0d, (double) 10L, rectangleAnchor16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str21 = rectangleAnchor20.toString();
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) 100.0f, (double) (-655360), rectangleAnchor20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = categoryAxis3D1.draw(graphics2D5, 1.0E-5d, rectangle2D7, rectangle2D22, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleAnchor.LEFT" + "'", str21.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot0.setDataset(waferMapDataset3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        waferMapPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        waferMapPlot0.setInsets(rectangleInsets7, false);
        double double11 = rectangleInsets7.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot13.getDataset((-1));
        java.awt.Paint paint27 = xYPlot13.getBackgroundPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot13.getFixedLegendItems();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(legendItemCollection28);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke3 = dateAxis2.getAxisLineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date5 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit4);
        dateAxis0.setTickUnit(dateTickUnit4, false, true);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double4 = size2D3.getWidth();
        org.jfree.chart.util.Size2D size2D5 = rectangleConstraint0.calculateConstrainedSize(size2D3);
        java.lang.Object obj6 = size2D3.clone();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        int int34 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot13.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        xYPlot13.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation24 = null;
        try {
            xYPlot13.addAnnotation(xYAnnotation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double9 = size2D8.getWidth();
        org.jfree.chart.util.Size2D size2D10 = rectangleConstraint5.calculateConstrainedSize(size2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, 0.0d, (double) 10L, rectangleAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str18 = rectangleAnchor17.toString();
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) 100.0f, (double) (-655360), rectangleAnchor17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double24 = size2D23.getWidth();
        org.jfree.chart.util.Size2D size2D25 = rectangleConstraint20.calculateConstrainedSize(size2D23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, 0.0d, (double) 10L, rectangleAnchor28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str33 = rectangleAnchor32.toString();
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) 100.0f, (double) (-655360), rectangleAnchor32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            org.jfree.chart.axis.AxisState axisState37 = categoryAxis3D1.draw(graphics2D3, 0.0d, rectangle2D19, rectangle2D34, rectangleEdge35, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleAnchor.LEFT" + "'", str18.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleAnchor.LEFT" + "'", str33.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        boolean boolean4 = projectInfo0.equals((java.lang.Object) (byte) 10);
        projectInfo0.addOptionalLibrary("hi!");
        java.lang.String str7 = projectInfo0.getLicenceText();
        java.util.List list8 = projectInfo0.getContributors();
        projectInfo0.addOptionalLibrary("Range[0.0,1.0]");
        org.jfree.chart.ui.ProjectInfo projectInfo11 = org.jfree.chart.JFreeChart.INFO;
        projectInfo11.addOptionalLibrary("");
        boolean boolean15 = projectInfo11.equals((java.lang.Object) (byte) 10);
        projectInfo11.addOptionalLibrary("hi!");
        java.lang.String str18 = projectInfo11.getLicenceText();
        java.util.List list19 = projectInfo11.getContributors();
        java.awt.Image image20 = projectInfo11.getLogo();
        projectInfo0.setLogo(image20);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(projectInfo11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(image20);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10L, 0.12d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setPieArea(rectangle2D2);
        piePlotState1.setPieCenterX(0.0d);
        piePlotState1.setPieHRadius((double) (short) -1);
        piePlotState1.setPieCenterX((double) 500);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        int int14 = xYPlot13.getRangeAxisCount();
        java.lang.String str15 = xYPlot13.getPlotType();
        xYPlot13.zoom(0.0d);
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot13.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "XY Plot" + "'", str15.equals("XY Plot"));
        org.junit.Assert.assertNull(axisSpace18);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        boolean boolean6 = categoryAxis3D1.equals((java.lang.Object) range5);
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double16 = size2D15.getWidth();
        org.jfree.chart.util.Size2D size2D17 = rectangleConstraint12.calculateConstrainedSize(size2D15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 0.0d, (double) 10L, rectangleAnchor20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str25 = rectangleAnchor24.toString();
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, (double) 100.0f, (double) (-655360), rectangleAnchor24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double28 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor9, 2, (int) (byte) 100, rectangle2D26, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "RectangleAnchor.LEFT" + "'", str25.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        int int25 = xYPlot13.getDatasetCount();
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = color26.brighter();
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color27);
        java.awt.Paint paint29 = xYPlot13.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        xYPlot37.zoomRangeAxes(100.0d, plotRenderingInfo39, point2D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot37.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation45, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = null;
        xYPlot13.rendererChanged(rendererChangeEvent48);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot13.getRangeAxisForDataset(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 15 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock7.draw(graphics2D8, (float) (short) 1, (float) (byte) 1, textBlockAnchor11, (float) (short) 0, (float) (byte) -1, 0.2d);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        org.jfree.chart.plot.Plot plot21 = numberAxis3D19.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range23 = numberAxis3D22.getRange();
        numberAxis3D19.setRange(range23);
        java.text.NumberFormat numberFormat25 = numberAxis3D19.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis3D19.getTickLabelInsets();
        java.awt.Shape shape27 = numberAxis3D19.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = null;
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor35);
        xYPlot31.zoomRangeAxes(100.0d, plotRenderingInfo33, point2D36, false);
        double double39 = xYPlot31.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        xYPlot31.setFixedDomainAxisSpace(axisSpace40, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        org.jfree.chart.plot.Plot plot45 = numberAxis3D43.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range47 = numberAxis3D46.getRange();
        numberAxis3D43.setRange(range47);
        java.text.NumberFormat numberFormat49 = numberAxis3D43.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = numberAxis3D43.getTickLabelInsets();
        java.awt.Shape shape51 = numberAxis3D43.getRightArrow();
        int int52 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        java.awt.Font font53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D43.setTickLabelFont(font53);
        org.jfree.chart.text.TextFragment textFragment55 = new org.jfree.chart.text.TextFragment("Range[0.0,1.0]", font53);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot56 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer57 = null;
        waferMapPlot56.setRenderer(waferMapRenderer57);
        org.jfree.data.general.WaferMapDataset waferMapDataset59 = null;
        waferMapPlot56.setDataset(waferMapDataset59);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier61 = null;
        waferMapPlot56.setDrawingSupplier(drawingSupplier61);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType64 = rectangleInsets63.getUnitType();
        waferMapPlot56.setInsets(rectangleInsets63, false);
        java.awt.Font font68 = null;
        java.awt.Paint paint69 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer73 = new org.jfree.chart.text.G2TextMeasurer(graphics2D72);
        org.jfree.chart.text.TextBlock textBlock74 = org.jfree.chart.text.TextUtilities.createTextBlock("", font68, paint69, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer73);
        org.jfree.chart.block.BlockBorder blockBorder75 = new org.jfree.chart.block.BlockBorder(rectangleInsets63, paint69);
        textBlock7.addLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font53, paint69);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(numberFormat25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(unitType64);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(textBlock74);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        numberAxis3D0.setTickMarkOutsideLength(0.0f);
        double double5 = numberAxis3D0.getAutoRangeMinimumSize();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis3D0.getLabelInsets();
        double double8 = rectangleInsets6.calculateTopInset(0.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-8d + "'", double5 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        java.lang.Object obj3 = categoryAxis3D1.clone();
        categoryAxis3D1.setLabel("ThreadContext");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        numberAxis3D21.setAxisLineVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis3D21.getTickLabelInsets();
        org.jfree.data.Range range31 = numberAxis3D21.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, 0.12d, (float) (-655360), (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        try {
            org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset11, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit6);
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity10 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (-16711936), (int) 'a', (java.lang.Comparable) dateTickUnit6, "RectangleEdge.RIGHT", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("WMAP_Plot", "WMAP_Plot", "WMAP_Plot", image3, "WMAP_Plot", "WMAP_Plot", "hi!");
        projectInfo7.setLicenceText("ClassContext");
        java.lang.String str10 = projectInfo7.getName();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "WMAP_Plot" + "'", str10.equals("WMAP_Plot"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = valueMarker31.getLabelOffsetType();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker31.setStroke(stroke41);
        java.awt.Paint paint43 = valueMarker31.getLabelPaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot13.getDataset((-1));
        java.awt.Paint paint27 = xYPlot13.getBackgroundPaint();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        xYPlot13.addChangeListener(plotChangeListener28);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSectionOutlinesVisible();
        java.awt.Paint paint2 = piePlot3D0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP" + "'", str1.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D0.getTickLabelInsets();
        double double8 = numberAxis3D0.getUpperBound();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getHeight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3);
        java.awt.Color color8 = java.awt.Color.getHSBColor((float) '4', (float) 1, 10.0f);
        java.awt.Font font12 = null;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer17 = new org.jfree.chart.text.G2TextMeasurer(graphics2D16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer17);
        try {
            org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font2, (java.awt.Paint) color8, (float) (-16711936), 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock18);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        waferMapPlot0.setBackgroundImageAlpha(0.0f);
        waferMapPlot0.zoom((double) (short) 10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartChangeListener chartChangeListener4 = null;
        try {
            jFreeChart3.addChangeListener(chartChangeListener4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        xYPlot13.zoomDomainAxes(0.0d, (double) 1L, plotRenderingInfo24, point2D27);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation29 = null;
        try {
            xYPlot13.addAnnotation(xYAnnotation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        java.awt.Stroke stroke25 = xYPlot24.getDomainZeroBaselineStroke();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot24.getRangeAxisForDataset((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 100 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        xYPlot37.zoomRangeAxes(100.0d, plotRenderingInfo39, point2D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot37.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation45, true);
        xYPlot13.setBackgroundAlpha((float) 0L);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Object obj16 = blockContainer15.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) dateAxis17);
        blockContainer15.setPadding((double) 100L, (double) 0, (double) (byte) 0, 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) (byte) 10, (double) (byte) 1, (double) (byte) 100);
        blockContainer15.setPadding(rectangleInsets33);
        blockContainer15.setMargin((double) 8, 1.0d, (-1.0d), (double) (-655360));
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        java.awt.Shape shape9 = numberAxis3D0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        chartEntity11.setURLText("RectangleAnchor.LEFT");
        java.awt.Shape shape14 = chartEntity11.getArea();
        chartEntity11.setURLText("RectangleAnchor.LEFT");
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            jFreeChart3.draw(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        boolean boolean4 = projectInfo0.equals((java.lang.Object) (byte) 10);
        projectInfo0.addOptionalLibrary("hi!");
        java.lang.String str7 = projectInfo0.getLicenceText();
        java.util.List list8 = projectInfo0.getContributors();
        projectInfo0.addOptionalLibrary("Range[0.0,1.0]");
        java.lang.String str11 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "LGPL" + "'", str11.equals("LGPL"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        int int27 = xYPlot13.getRangeAxisIndex(valueAxis26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot13.getRenderer();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer28);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        double double2 = numberAxis3D0.getUpperBound();
        double double3 = numberAxis3D0.getFixedAutoRange();
        double double4 = numberAxis3D0.getUpperBound();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        numberAxis3D4.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.RED;
        float[] floatArray12 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray13 = color8.getRGBColorComponents(floatArray12);
        float[] floatArray14 = color5.getColorComponents(floatArray12);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        double double2 = categoryAxis3D1.getLowerMargin();
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        pieLabelDistributor1.sort();
        java.lang.String str3 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("WMAP_Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.Plot plot1 = dateAxis0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.expand(range3, (double) (byte) 1, 1.0E-5d);
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range3, range7);
        try {
            dateAxis0.setRange(range7, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot13.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot13.render(graphics2D29, rectangle2D30, 255, plotRenderingInfo32, crosshairState33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot13.getLegendItems();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot13.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot13.getDomainAxis(10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        xYPlot13.addChangeListener(plotChangeListener40);
        java.awt.Color color44 = java.awt.Color.green;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color44, stroke45);
        java.awt.Color color48 = java.awt.Color.green;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color48, stroke49);
        valueMarker46.setStroke(stroke49);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        valueMarker46.setPaint((java.awt.Paint) color52);
        org.jfree.chart.util.Layer layer54 = null;
        try {
            xYPlot13.addDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker46, layer54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color52);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        java.awt.Stroke stroke25 = xYPlot24.getDomainZeroBaselineStroke();
        boolean boolean26 = xYPlot24.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke27 = xYPlot24.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setTitle("Range[0.0,1.0]");
        try {
            org.jfree.chart.plot.XYPlot xYPlot6 = jFreeChart3.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        waferMapPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint3 = waferMapPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.general.PieDataset pieDataset1 = piePlot3D0.getDataset();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNull(pieDataset1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        float float27 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        xYPlot43.zoomRangeAxes(100.0d, plotRenderingInfo45, point2D48, false);
        double double51 = xYPlot43.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = null;
        java.awt.geom.Point2D point2D57 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D55, rectangleAnchor56);
        xYPlot43.zoomDomainAxes(0.0d, (double) 1L, plotRenderingInfo54, point2D57);
        xYPlot13.zoomRangeAxes((-1.0d), plotRenderingInfo29, point2D57);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(point2D57);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        java.awt.Stroke stroke3 = numberAxis3D0.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            numberAxis3D0.setTickLabelInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        piePlot3D0.setExplodePercent((java.lang.Comparable) date2, 1.0E-5d);
        double double5 = piePlot3D0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.configure();
        categoryAxis3D1.setUpperMargin((double) (byte) -1);
        java.awt.Paint paint6 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) 100L);
        double double7 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        boolean boolean5 = valueMarker3.equals((java.lang.Object) 0);
        float float6 = valueMarker3.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        try {
            java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.lang.String str7 = range5.toString();
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) str7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment9, 10.0d, (double) 1L);
        java.lang.String str13 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,1.0]" + "'", str7.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "HorizontalAlignment.CENTER" + "'", str13.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 10.0f, 1.0E-5d, (int) (short) 0, (java.lang.Comparable) 0.4d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D25.configure();
        categoryAxis3D25.setUpperMargin((double) (byte) -1);
        java.awt.Paint paint30 = categoryAxis3D25.getTickLabelPaint((java.lang.Comparable) 100L);
        xYPlot13.setDomainTickBandPaint(paint30);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        int int14 = xYPlot13.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace15);
        xYPlot13.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D2.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        boolean boolean7 = categoryAxis3D2.equals((java.lang.Object) range6);
        numberAxis3D0.setRangeWithMargins(range6, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D0.setTickUnit(numberTickUnit11, false, false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(numberTickUnit11);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.plot.Plot plot8 = numberAxis3D6.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        numberAxis3D6.setRange(range10);
        java.text.NumberFormat numberFormat12 = numberAxis3D6.getNumberFormatOverride();
        java.text.NumberFormat numberFormat13 = null;
        numberAxis3D6.setNumberFormatOverride(numberFormat13);
        java.awt.Paint paint15 = numberAxis3D6.getLabelPaint();
        boolean boolean16 = columnArrangement5.equals((java.lang.Object) paint15);
        boolean boolean18 = columnArrangement5.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        org.jfree.chart.plot.Plot plot23 = numberAxis3D21.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        numberAxis3D21.setRange(range25);
        java.text.NumberFormat numberFormat27 = numberAxis3D21.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis3D21.getTickLabelInsets();
        java.awt.Shape shape29 = numberAxis3D21.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, xYItemRenderer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        xYPlot33.zoomRangeAxes(100.0d, plotRenderingInfo35, point2D38, false);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot33.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot33.getRangeAxis(100);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot33.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot33.getDomainAxisLocation();
        float float47 = xYPlot33.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot33);
        boolean boolean49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer19, (java.lang.Object) plotChangeEvent48);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double52 = rectangleConstraint51.getWidth();
        org.jfree.chart.util.Size2D size2D53 = blockContainer19.arrange(graphics2D50, rectangleConstraint51);
        java.awt.geom.Rectangle2D rectangle2D54 = blockContainer19.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.TOP;
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean57 = rectangleEdge55.equals((java.lang.Object) color56);
        try {
            double double58 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor2, (int) (short) 10, (-12517568), rectangle2D54, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.5f + "'", float47 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(size2D53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        double double3 = piePlot3D0.getDepthFactor();
        piePlot3D0.setSectionOutlinesVisible(false);
        boolean boolean6 = piePlot3D0.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.12d + "'", double3 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        java.awt.Stroke stroke3 = numberAxis3D0.getAxisLineStroke();
        numberAxis3D0.setTickMarkOutsideLength((float) 100L);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSectionOutlinesVisible();
        boolean boolean2 = piePlot3D0.isCircular();
        java.awt.Color color3 = java.awt.Color.WHITE;
        piePlot3D0.setLabelOutlinePaint((java.awt.Paint) color3);
        org.jfree.chart.util.Rotation rotation5 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        piePlot3D0.setDirection(rotation5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        int int22 = xYPlot13.getWeight();
        java.awt.Stroke stroke23 = xYPlot13.getRangeGridlineStroke();
        java.lang.Object obj24 = xYPlot13.clone();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 1, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke6 = dateAxis5.getAxisLineStroke();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis5.getTimeline();
        dateAxis0.setTimeline(timeline7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource9);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        boolean boolean4 = projectInfo0.equals((java.lang.Object) (byte) 10);
        projectInfo0.addOptionalLibrary("hi!");
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo0.getLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        projectInfo8.addOptionalLibrary("");
        boolean boolean12 = projectInfo8.equals((java.lang.Object) (byte) 10);
        projectInfo8.addOptionalLibrary("hi!");
        org.jfree.chart.ui.Library[] libraryArray15 = projectInfo8.getLibraries();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo8);
        org.jfree.chart.ui.Library[] libraryArray17 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(libraryArray15);
        org.junit.Assert.assertNotNull(libraryArray17);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot13.getDomainAxisLocation(0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range28 = numberAxis3D27.getRange();
        org.jfree.chart.plot.Plot plot29 = numberAxis3D27.getPlot();
        xYPlot13.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot13.getDatasetRenderingOrder();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setDomainGridlineStroke(stroke32);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 255, 90.0d, 100, (java.lang.Comparable) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 10.0f, (double) 1.0f, (double) '4');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        java.lang.Object obj7 = categoryAxis3D6.clone();
        java.lang.Object obj8 = categoryAxis3D6.clone();
        java.awt.Paint paint9 = categoryAxis3D6.getTickMarkPaint();
        categoryAxis3D6.setCategoryLabelPositionOffset(100);
        boolean boolean12 = blockBorder4.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range17 = numberAxis3D16.getRange();
        org.jfree.chart.plot.Plot plot18 = numberAxis3D16.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        numberAxis3D16.setRange(range20);
        java.text.NumberFormat numberFormat22 = numberAxis3D16.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D16.getTickLabelInsets();
        java.awt.Shape shape24 = numberAxis3D16.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, xYItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = null;
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D31, rectangleAnchor32);
        xYPlot28.zoomRangeAxes(100.0d, plotRenderingInfo30, point2D33, false);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot28.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot28.getRangeAxis(100);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot28.setRangeCrosshairStroke(stroke39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot28.getDomainAxisLocation();
        float float42 = xYPlot28.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot28);
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer14, (java.lang.Object) plotChangeEvent43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double47 = rectangleConstraint46.getWidth();
        org.jfree.chart.util.Size2D size2D48 = blockContainer14.arrange(graphics2D45, rectangleConstraint46);
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer14.getBounds();
        blockContainer14.setWidth((double) 10.0f);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(numberFormat22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(point2D33);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.5f + "'", float42 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(size2D48);
        org.junit.Assert.assertNotNull(rectangle2D49);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        piePlot3D0.setSimpleLabels(true);
        piePlot3D0.setLabelGap(1.0E-8d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.chart.plot.Plot plot6 = numberAxis3D4.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        numberAxis3D4.setRange(range8);
        java.text.NumberFormat numberFormat10 = numberAxis3D4.getNumberFormatOverride();
        java.text.NumberFormat numberFormat11 = null;
        numberAxis3D4.setNumberFormatOverride(numberFormat11);
        java.awt.Paint paint13 = numberAxis3D4.getLabelPaint();
        boolean boolean14 = columnArrangement3.equals((java.lang.Object) paint13);
        boolean boolean16 = columnArrangement3.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        org.jfree.chart.plot.Plot plot21 = numberAxis3D19.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range23 = numberAxis3D22.getRange();
        numberAxis3D19.setRange(range23);
        java.text.NumberFormat numberFormat25 = numberAxis3D19.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis3D19.getTickLabelInsets();
        java.awt.Shape shape27 = numberAxis3D19.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = null;
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor35);
        xYPlot31.zoomRangeAxes(100.0d, plotRenderingInfo33, point2D36, false);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot31.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot31.getRangeAxis(100);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot31.setRangeCrosshairStroke(stroke42);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot31.getDomainAxisLocation();
        float float45 = xYPlot31.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent46 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot31);
        boolean boolean47 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer17, (java.lang.Object) plotChangeEvent46);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double50 = rectangleConstraint49.getWidth();
        org.jfree.chart.util.Size2D size2D51 = blockContainer17.arrange(graphics2D48, rectangleConstraint49);
        java.awt.geom.Rectangle2D rectangle2D52 = blockContainer17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = null;
        java.awt.geom.Point2D point2D55 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor54);
        org.jfree.chart.plot.PlotState plotState56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        try {
            multiplePiePlot0.draw(graphics2D2, rectangle2D52, point2D55, plotState56, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(numberFormat25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.5f + "'", float45 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(size2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(point2D55);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        int int25 = xYPlot13.getDatasetCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = xYPlot13.getSeriesRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        org.jfree.chart.plot.Plot plot30 = numberAxis3D28.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        numberAxis3D28.setRange(range32);
        java.text.NumberFormat numberFormat34 = numberAxis3D28.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis3D28.getTickLabelInsets();
        java.awt.Shape shape36 = numberAxis3D28.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = null;
        java.awt.geom.Point2D point2D45 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D43, rectangleAnchor44);
        xYPlot40.zoomRangeAxes(100.0d, plotRenderingInfo42, point2D45, false);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot40.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot40.getRangeAxis(100);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot40.setRangeCrosshairStroke(stroke51);
        xYPlot40.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot40.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.chart.plot.CrosshairState crosshairState60 = null;
        boolean boolean61 = xYPlot40.render(graphics2D56, rectangle2D57, 255, plotRenderingInfo59, crosshairState60);
        org.jfree.chart.LegendItemCollection legendItemCollection62 = xYPlot40.getLegendItems();
        int int63 = legendItemCollection62.getItemCount();
        xYPlot13.setFixedLegendItems(legendItemCollection62);
        try {
            org.jfree.chart.LegendItem legendItem66 = legendItemCollection62.get((-16711936));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(numberFormat34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(point2D45);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNull(valueAxis50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(legendItemCollection62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = null;
        numberAxis3D0.setStandardTickUnits(tickUnitSource9);
        boolean boolean11 = numberAxis3D0.isTickMarksVisible();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke1 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        boolean boolean3 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date5 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date7 = dateAxis6.getMinimumDate();
        try {
            dateAxis0.setRange(date5, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("XY Plot", "XY Plot", "RectangleAnchor.BOTTOM_RIGHT", "ClassContext");
        basicProjectInfo4.setLicenceName("ThreadContext");
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot13.getDataset((-1));
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        xYPlot13.setRenderer(xYItemRenderer27);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertNull(xYDataset26);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D0.getTickLabelInsets();
        double double8 = numberAxis3D0.getFixedAutoRange();
        numberAxis3D0.centerRange((double) 255);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ClassContext");
        try {
            java.lang.Object obj4 = jFreeChartResources0.getObject("RectangleAnchor.TOP");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleAnchor.TOP");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) color1);
        java.lang.String str3 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot13.removeChangeListener(plotChangeListener27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.plot.Plot plot32 = numberAxis3D30.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range34 = numberAxis3D33.getRange();
        numberAxis3D30.setRange(range34);
        java.text.NumberFormat numberFormat36 = numberAxis3D30.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D30.getTickLabelInsets();
        java.awt.Shape shape38 = numberAxis3D30.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range40 = numberAxis3D39.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer41);
        double double43 = numberAxis3D30.getFixedAutoRange();
        int int44 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Paint paint45 = xYPlot13.getOutlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace46);
        java.awt.Stroke stroke48 = null;
        try {
            xYPlot13.setDomainGridlineStroke(stroke48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(numberFormat36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot13.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint31 = numberAxis3D30.getTickMarkPaint();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = null;
        java.awt.geom.Point2D point2D37 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D35, rectangleAnchor36);
        xYPlot13.zoomDomainAxes((double) 100, plotRenderingInfo34, point2D37);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(point2D37);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range17 = numberAxis3D16.getRange();
        org.jfree.chart.plot.Plot plot18 = numberAxis3D16.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        numberAxis3D16.setRange(range20);
        java.text.NumberFormat numberFormat22 = numberAxis3D16.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D16.getTickLabelInsets();
        java.awt.Shape shape24 = numberAxis3D16.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, xYItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = null;
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D31, rectangleAnchor32);
        xYPlot28.zoomRangeAxes(100.0d, plotRenderingInfo30, point2D33, false);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot28.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot28.getRangeAxis(100);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot28.setRangeCrosshairStroke(stroke39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot28.getDomainAxisLocation();
        float float42 = xYPlot28.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot28);
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer14, (java.lang.Object) plotChangeEvent43);
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 10.0f, (double) 1.0f, (double) '4');
        blockContainer14.setFrame((org.jfree.chart.block.BlockFrame) blockBorder49);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(numberFormat22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(point2D33);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.5f + "'", float42 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSectionOutlinesVisible();
        boolean boolean2 = piePlot3D0.isCircular();
        java.awt.Color color3 = java.awt.Color.WHITE;
        piePlot3D0.setLabelOutlinePaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot3D0.getDataset();
        boolean boolean6 = piePlot3D0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setPieArea(rectangle2D2);
        java.awt.geom.Rectangle2D rectangle2D4 = piePlotState1.getExplodedPieArea();
        piePlotState1.setPieCenterX(0.0d);
        double double7 = piePlotState1.getTotal();
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.setLabelAngle(0.0d);
        java.awt.Paint paint4 = null;
        try {
            categoryAxis3D1.setAxisLinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setPieArea(rectangle2D2);
        piePlotState1.setPieCenterX(0.0d);
        piePlotState1.setPieHRadius((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D8 = piePlotState1.getLinkArea();
        org.junit.Assert.assertNull(rectangle2D8);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis0.setTimeline(timeline5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D7.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        numberAxis3D7.setRange(range11);
        java.lang.String str13 = range11.toString();
        boolean boolean15 = range11.contains((double) ' ');
        dateAxis0.setRange(range11);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer18 = null;
        waferMapPlot17.setRenderer(waferMapRenderer18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        waferMapPlot17.axisChanged(axisChangeEvent20);
        boolean boolean22 = range11.equals((java.lang.Object) axisChangeEvent20);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,1.0]" + "'", str13.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeAxes();
        java.awt.Stroke stroke27 = xYPlot13.getDomainGridlineStroke();
        xYPlot13.mapDatasetToRangeAxis(0, 8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        int int32 = xYPlot13.getIndexOf(xYItemRenderer31);
        java.awt.Color color34 = java.awt.Color.green;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color34, stroke35);
        java.awt.Color color38 = java.awt.Color.green;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color38, stroke39);
        valueMarker36.setStroke(stroke39);
        valueMarker36.setValue(10.0d);
        float float44 = valueMarker36.getAlpha();
        float float45 = valueMarker36.getAlpha();
        try {
            boolean boolean46 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.0f + "'", float45 == 1.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        piePlot3D0.setCircular(true, true);
        double double6 = piePlot3D0.getLabelLinkMargin();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.plot.Plot plot10 = numberAxis3D8.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        numberAxis3D8.setRange(range12);
        java.text.NumberFormat numberFormat14 = numberAxis3D8.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D8.getTickLabelInsets();
        java.awt.Shape shape16 = numberAxis3D8.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        xYPlot20.zoomRangeAxes(100.0d, plotRenderingInfo22, point2D25, false);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot20.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getRangeAxis(100);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke31);
        xYPlot20.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot20.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.plot.CrosshairState crosshairState40 = null;
        boolean boolean41 = xYPlot20.render(graphics2D36, rectangle2D37, 255, plotRenderingInfo39, crosshairState40);
        java.awt.Paint paint42 = xYPlot20.getDomainGridlinePaint();
        piePlot3D0.setLabelShadowPaint(paint42);
        org.jfree.data.general.PieDataset pieDataset44 = piePlot3D0.getDataset();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(pieDataset44);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = xYPlot13.getAxisOffset();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint25 = numberAxis3D24.getTickMarkPaint();
        boolean boolean26 = numberAxis3D24.isPositiveArrowVisible();
        boolean boolean27 = rectangleInsets22.equals((java.lang.Object) numberAxis3D24);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot13.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot13.render(graphics2D29, rectangle2D30, 255, plotRenderingInfo32, crosshairState33);
        java.awt.Paint paint35 = xYPlot13.getDomainGridlinePaint();
        java.awt.Color color37 = java.awt.Color.green;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color37, stroke38);
        java.awt.Color color41 = java.awt.Color.green;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color41, stroke42);
        valueMarker39.setStroke(stroke42);
        valueMarker39.setValue(10.0d);
        float float47 = valueMarker39.getAlpha();
        float float48 = valueMarker39.getAlpha();
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker39);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 1.0f + "'", float48 == 1.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        java.awt.Image image3 = waferMapPlot0.getBackgroundImage();
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot0.setDataset(waferMapDataset4);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        java.awt.Color color4 = java.awt.Color.green;
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color6, stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets13.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke7, rectangleInsets13);
        valueMarker3.setOutlineStroke(stroke7);
        java.awt.Paint paint17 = valueMarker3.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        java.awt.Shape shape9 = numberAxis3D0.getLeftArrow();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis3D0.getMarkerBand();
        org.jfree.chart.plot.Plot plot11 = numberAxis3D0.getPlot();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(markerAxisBand10);
        org.junit.Assert.assertNull(plot11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        int int25 = xYPlot13.getDatasetCount();
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = color26.brighter();
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = xYPlot13.getRangeCrosshairStroke();
        xYPlot13.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = null;
        try {
            xYPlot13.setRangeAxes(valueAxisArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.general.PieDataset pieDataset1 = piePlot3D0.getDataset();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke3 = dateAxis2.getAxisLineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date5 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit4);
        java.awt.Stroke stroke6 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) dateTickUnit4);
        org.junit.Assert.assertNull(pieDataset1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ClassContext");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("RectangleAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedWidth(0.2d);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double12 = size2D11.getWidth();
        org.jfree.chart.util.Size2D size2D13 = rectangleConstraint8.calculateConstrainedSize(size2D11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.0d, (double) 10L, rectangleAnchor16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str21 = rectangleAnchor20.toString();
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) 100.0f, (double) (-655360), rectangleAnchor20);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double27 = size2D26.getWidth();
        org.jfree.chart.util.Size2D size2D28 = rectangleConstraint23.calculateConstrainedSize(size2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, 0.0d, (double) 10L, rectangleAnchor31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str36 = rectangleAnchor35.toString();
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, (double) 100.0f, (double) (-655360), rectangleAnchor35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            org.jfree.chart.axis.AxisState axisState40 = dateAxis0.draw(graphics2D6, 2.0d, rectangle2D22, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleAnchor.LEFT" + "'", str21.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleAnchor.LEFT" + "'", str36.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        float float27 = xYPlot13.getForegroundAlpha();
        xYPlot13.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot13.getRangeAxis();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.plot.Plot plot34 = numberAxis3D32.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range36 = numberAxis3D35.getRange();
        numberAxis3D32.setRange(range36);
        java.text.NumberFormat numberFormat38 = numberAxis3D32.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = numberAxis3D32.getTickLabelInsets();
        java.awt.Shape shape40 = numberAxis3D32.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range42 = numberAxis3D41.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, xYItemRenderer43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = null;
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D47, rectangleAnchor48);
        xYPlot44.zoomRangeAxes(100.0d, plotRenderingInfo46, point2D49, false);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot44.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot44.getRangeAxis(100);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot44.setRangeCrosshairStroke(stroke55);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot44.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation((int) (short) 0, axisLocation57);
        java.awt.Color color59 = java.awt.Color.GRAY;
        java.awt.Color color60 = java.awt.Color.RED;
        float[] floatArray64 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray65 = color60.getRGBColorComponents(floatArray64);
        float[] floatArray66 = color59.getColorComponents(floatArray64);
        xYPlot13.setRangeTickBandPaint((java.awt.Paint) color59);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNull(valueAxis54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 255);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable5 = multiplePiePlot4.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder6 = multiplePiePlot4.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        org.jfree.chart.plot.Plot plot11 = numberAxis3D9.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range13 = numberAxis3D12.getRange();
        numberAxis3D9.setRange(range13);
        java.text.NumberFormat numberFormat15 = numberAxis3D9.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis3D9.getTickLabelInsets();
        java.awt.Shape shape17 = numberAxis3D9.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        xYPlot21.zoomRangeAxes(100.0d, plotRenderingInfo23, point2D26, false);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot21.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot21.getRangeAxis(100);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setRangeCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.plot.Plot plot36 = numberAxis3D34.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        numberAxis3D34.setRange(range38);
        java.text.NumberFormat numberFormat40 = numberAxis3D34.getNumberFormatOverride();
        java.text.NumberFormat numberFormat41 = null;
        numberAxis3D34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = null;
        numberAxis3D34.setStandardTickUnits(tickUnitSource43);
        int int45 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D34);
        java.awt.Paint paint46 = numberAxis3D34.getTickLabelPaint();
        jFreeChart7.setBackgroundPaint(paint46);
        multiplePiePlot0.setPieChart(jFreeChart7);
        boolean boolean50 = jFreeChart7.equals((java.lang.Object) 0.2d);
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder6);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color5, stroke6);
        valueMarker3.setStroke(stroke6);
        valueMarker3.setValue(10.0d);
        double double11 = valueMarker3.getValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        double double18 = rectangleInsets16.calculateBottomOutset((double) 1);
        valueMarker3.setLabelOffset(rectangleInsets16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) 0);
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.plot.Plot plot8 = numberAxis3D6.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        numberAxis3D6.setRange(range10);
        java.text.NumberFormat numberFormat12 = numberAxis3D6.getNumberFormatOverride();
        java.text.NumberFormat numberFormat13 = null;
        numberAxis3D6.setNumberFormatOverride(numberFormat13);
        java.awt.Paint paint15 = numberAxis3D6.getLabelPaint();
        boolean boolean16 = columnArrangement5.equals((java.lang.Object) paint15);
        boolean boolean18 = columnArrangement5.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        org.jfree.chart.plot.Plot plot23 = numberAxis3D21.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        numberAxis3D21.setRange(range25);
        java.text.NumberFormat numberFormat27 = numberAxis3D21.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis3D21.getTickLabelInsets();
        java.awt.Shape shape29 = numberAxis3D21.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, xYItemRenderer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        xYPlot33.zoomRangeAxes(100.0d, plotRenderingInfo35, point2D38, false);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot33.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot33.getRangeAxis(100);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot33.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot33.getDomainAxisLocation();
        float float47 = xYPlot33.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot33);
        boolean boolean49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer19, (java.lang.Object) plotChangeEvent48);
        java.awt.Color color50 = java.awt.Color.RED;
        float[] floatArray54 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray55 = color50.getRGBColorComponents(floatArray54);
        flowArrangement4.add((org.jfree.chart.block.Block) blockContainer19, (java.lang.Object) color50);
        org.jfree.chart.plot.PiePlot3D piePlot3D57 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint58 = piePlot3D57.getLabelLinkPaint();
        boolean boolean59 = flowArrangement4.equals((java.lang.Object) paint58);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.5f + "'", float47 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Object obj16 = blockContainer15.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) dateAxis17);
        blockContainer15.setHeight((double) 10L);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot26 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer27 = null;
        waferMapPlot26.setRenderer(waferMapRenderer27);
        org.jfree.data.general.WaferMapDataset waferMapDataset29 = null;
        waferMapPlot26.setDataset(waferMapDataset29);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = null;
        waferMapPlot26.setDrawingSupplier(drawingSupplier31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets33.getUnitType();
        waferMapPlot26.setInsets(rectangleInsets33, false);
        blockContainer15.setMargin(rectangleInsets33);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(unitType34);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setPieArea(rectangle2D2);
        piePlotState1.setPieCenterX(0.0d);
        piePlotState1.setPieWRadius(10.0d);
        piePlotState1.setPieHRadius(0.0d);
        piePlotState1.setPieCenterX((double) (short) 10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot13.getDomainMarkers(layer40);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot13);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        org.jfree.chart.plot.Plot plot46 = numberAxis3D44.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range48 = numberAxis3D47.getRange();
        numberAxis3D44.setRange(range48);
        java.text.NumberFormat numberFormat50 = numberAxis3D44.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis3D44.getTickLabelInsets();
        java.awt.Shape shape52 = numberAxis3D44.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range54 = numberAxis3D53.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D53, xYItemRenderer55);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range58 = numberAxis3D57.getRange();
        org.jfree.chart.plot.Plot plot59 = numberAxis3D57.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range61 = numberAxis3D60.getRange();
        numberAxis3D57.setRange(range61);
        xYPlot56.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D57);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range65 = numberAxis3D64.getRange();
        double double66 = numberAxis3D64.getUpperBound();
        double double67 = numberAxis3D64.getFixedAutoRange();
        numberAxis3D64.setPositiveArrowVisible(false);
        org.jfree.data.Range range70 = xYPlot56.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D64);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D71 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range72 = numberAxis3D71.getRange();
        double double73 = numberAxis3D71.getUpperBound();
        java.awt.Font font74 = numberAxis3D71.getLabelFont();
        numberAxis3D64.setLabelFont(font74);
        legendTitle42.setItemFont(font74);
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        legendTitle42.setItemLabelPadding(rectangleInsets81);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(plot46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(numberFormat50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNull(plot59);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertNotNull(font74);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        double double6 = rectangleInsets4.calculateBottomOutset((double) 1);
        double double8 = rectangleInsets4.calculateLeftOutset((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        polarPlot3.datasetChanged(datasetChangeEvent4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D7.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        numberAxis3D7.setRange(range11);
        java.text.NumberFormat numberFormat13 = numberAxis3D7.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis3D7.getTickLabelInsets();
        java.awt.Shape shape15 = numberAxis3D7.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range17 = numberAxis3D16.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, xYItemRenderer18);
        java.text.NumberFormat numberFormat20 = numberAxis3D7.getNumberFormatOverride();
        polarPlot3.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D7);
        polarPlot3.setAngleLabelsVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        polarPlot3.zoomDomainAxes((double) 0L, plotRenderingInfo25, point2D28);
        boolean boolean30 = polarPlot3.isRangeZoomable();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.TOP;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean34 = rectangleEdge32.equals((java.lang.Object) color33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace36 = categoryAxis3D1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) polarPlot3, rectangle2D31, rectangleEdge32, axisSpace35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(numberFormat20);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        java.awt.Paint paint3 = piePlot3D0.getLabelBackgroundPaint();
        boolean boolean4 = piePlot3D0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot3D0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        java.awt.Stroke stroke25 = numberAxis3D11.getTickMarkStroke();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.chart.plot.Plot plot6 = numberAxis3D4.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        numberAxis3D4.setRange(range8);
        java.text.NumberFormat numberFormat10 = numberAxis3D4.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D4.getTickLabelInsets();
        java.awt.Shape shape12 = numberAxis3D4.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range14 = numberAxis3D13.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer15);
        java.text.NumberFormat numberFormat17 = numberAxis3D4.getNumberFormatOverride();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        java.awt.Color color19 = java.awt.Color.green;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color19);
        double double21 = polarPlot0.getMaxRadius();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        float float27 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        int int29 = xYPlot13.getSeriesCount();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        xYPlot13.axisChanged(axisChangeEvent30);
        double double32 = xYPlot13.getRangeCrosshairValue();
        java.awt.Stroke stroke33 = xYPlot13.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ClassContext");
        float float2 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("ClassContext");
        java.util.Enumeration<java.lang.String> strEnumeration3 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str5 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(strEnumeration3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        boolean boolean28 = numberAxis3D21.isNegativeArrowVisible();
        java.awt.Font font29 = numberAxis3D21.getTickLabelFont();
        numberAxis3D21.setRangeAboutValue((double) (-655360), (double) 0L);
        numberAxis3D21.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        size2D2.width = 0.0d;
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        double double2 = numberAxis3D0.getUpperBound();
        java.awt.Font font3 = numberAxis3D0.getLabelFont();
        boolean boolean5 = numberAxis3D0.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        float float27 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        int int29 = xYPlot13.getSeriesCount();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        xYPlot13.axisChanged(axisChangeEvent30);
        double double32 = xYPlot13.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.plot.Plot plot36 = numberAxis3D34.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        numberAxis3D34.setRange(range38);
        java.text.NumberFormat numberFormat40 = numberAxis3D34.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = numberAxis3D34.getTickLabelInsets();
        java.awt.Shape shape42 = numberAxis3D34.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer45);
        int int47 = xYPlot46.getRangeAxisCount();
        java.awt.Stroke stroke48 = xYPlot46.getRangeGridlineStroke();
        xYPlot13.setRangeZeroBaselineStroke(stroke48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range52 = numberAxis3D51.getRange();
        org.jfree.chart.plot.Plot plot53 = numberAxis3D51.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range55 = numberAxis3D54.getRange();
        numberAxis3D51.setRange(range55);
        java.text.NumberFormat numberFormat57 = numberAxis3D51.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = numberAxis3D51.getTickLabelInsets();
        java.awt.Shape shape59 = numberAxis3D51.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range61 = numberAxis3D60.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset50, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, xYItemRenderer62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = null;
        java.awt.geom.Point2D point2D68 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D66, rectangleAnchor67);
        xYPlot63.zoomRangeAxes(100.0d, plotRenderingInfo65, point2D68, false);
        org.jfree.chart.axis.AxisLocation axisLocation71 = xYPlot63.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis73 = xYPlot63.getRangeAxis(100);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot63.setRangeCrosshairStroke(stroke74);
        xYPlot63.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation78 = xYPlot63.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        org.jfree.chart.plot.CrosshairState crosshairState83 = null;
        boolean boolean84 = xYPlot63.render(graphics2D79, rectangle2D80, 255, plotRenderingInfo82, crosshairState83);
        java.awt.Paint paint85 = xYPlot63.getDomainGridlinePaint();
        xYPlot13.setDomainCrosshairPaint(paint85);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(plot53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNull(numberFormat57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(point2D68);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation78);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(paint85);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.setLabelAngle(0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D1.getCategoryLabelPositions();
        double double5 = categoryAxis3D1.getLowerMargin();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) numberTickUnit6);
        categoryAxis3D1.setCategoryLabelPositionOffset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D11.configure();
        categoryAxis3D11.setUpperMargin((double) (byte) -1);
        java.awt.Paint paint15 = categoryAxis3D11.getLabelPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D17.setLabelAngle(0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis3D17.getCategoryLabelPositions();
        categoryAxis3D11.setCategoryLabelPositions(categoryLabelPositions20);
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.chart.plot.Plot plot6 = numberAxis3D4.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        numberAxis3D4.setRange(range8);
        java.text.NumberFormat numberFormat10 = numberAxis3D4.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D4.getTickLabelInsets();
        java.awt.Shape shape12 = numberAxis3D4.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range14 = numberAxis3D13.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer15);
        java.text.NumberFormat numberFormat17 = numberAxis3D4.getNumberFormatOverride();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        polarPlot0.setAngleLabelsVisible(true);
        boolean boolean21 = polarPlot0.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }
}

