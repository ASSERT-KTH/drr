import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        java.awt.Shape shape9 = numberAxis3D0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        chartEntity11.setURLText("RectangleAnchor.LEFT");
        java.lang.String str14 = chartEntity11.getShapeType();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "poly" + "'", str14.equals("poly"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.lang.String str2 = valueMarker1.getLabel();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainZeroBaselineVisible();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot13);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range21 = numberAxis3D20.getRange();
        org.jfree.chart.plot.Plot plot22 = numberAxis3D20.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range24 = numberAxis3D23.getRange();
        numberAxis3D20.setRange(range24);
        java.text.NumberFormat numberFormat26 = numberAxis3D20.getNumberFormatOverride();
        java.text.NumberFormat numberFormat27 = null;
        numberAxis3D20.setNumberFormatOverride(numberFormat27);
        java.awt.Paint paint29 = numberAxis3D20.getLabelPaint();
        boolean boolean30 = columnArrangement19.equals((java.lang.Object) paint29);
        boolean boolean32 = columnArrangement19.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement19);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range36 = numberAxis3D35.getRange();
        org.jfree.chart.plot.Plot plot37 = numberAxis3D35.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range39 = numberAxis3D38.getRange();
        numberAxis3D35.setRange(range39);
        java.text.NumberFormat numberFormat41 = numberAxis3D35.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = numberAxis3D35.getTickLabelInsets();
        java.awt.Shape shape43 = numberAxis3D35.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = null;
        java.awt.geom.Point2D point2D52 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor51);
        xYPlot47.zoomRangeAxes(100.0d, plotRenderingInfo49, point2D52, false);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot47.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot47.getRangeAxis(100);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot47.setRangeCrosshairStroke(stroke58);
        org.jfree.chart.axis.AxisLocation axisLocation60 = xYPlot47.getDomainAxisLocation();
        float float61 = xYPlot47.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent62 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot47);
        boolean boolean63 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer33, (java.lang.Object) plotChangeEvent62);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint65 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double66 = rectangleConstraint65.getWidth();
        org.jfree.chart.util.Size2D size2D67 = blockContainer33.arrange(graphics2D64, rectangleConstraint65);
        java.awt.geom.Rectangle2D rectangle2D68 = blockContainer33.getBounds();
        org.jfree.chart.ui.ProjectInfo projectInfo69 = org.jfree.chart.JFreeChart.INFO;
        projectInfo69.addOptionalLibrary("");
        boolean boolean73 = projectInfo69.equals((java.lang.Object) (byte) 10);
        projectInfo69.addOptionalLibrary("hi!");
        java.lang.String str76 = projectInfo69.getLicenceText();
        java.util.List list77 = projectInfo69.getContributors();
        try {
            xYPlot13.drawDomainTickBands(graphics2D18, rectangle2D68, list77);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.ui.Contributor cannot be cast to org.jfree.chart.axis.ValueTick");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(numberFormat26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(numberFormat41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(point2D52);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 0.5f + "'", float61 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(size2D67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(projectInfo69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(list77);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textBlock7.getLineAlignment();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 100);
        boolean boolean11 = textBlock7.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ThreadContext");
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis3D0.setMarkerBand(markerAxisBand3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        xYPlot13.setDomainAxis(valueAxis40);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint3 = multiplePiePlot2.getAggregatedItemsPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer7 = new org.jfree.chart.text.G2TextMeasurer(graphics2D6);
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("XY Plot", font1, paint3, (float) ' ', (int) (short) 10, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double4 = size2D3.getWidth();
        org.jfree.chart.util.Size2D size2D5 = rectangleConstraint0.calculateConstrainedSize(size2D3);
        double double6 = size2D3.getWidth();
        size2D3.height = 1.0E-8d;
        java.lang.Object obj9 = size2D3.clone();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot13.datasetChanged(datasetChangeEvent27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.plot.Plot plot32 = numberAxis3D30.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range34 = numberAxis3D33.getRange();
        numberAxis3D30.setRange(range34);
        java.text.NumberFormat numberFormat36 = numberAxis3D30.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = numberAxis3D30.getTickLabelInsets();
        java.awt.Shape shape38 = numberAxis3D30.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range40 = numberAxis3D39.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = null;
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D45, rectangleAnchor46);
        xYPlot42.zoomRangeAxes(100.0d, plotRenderingInfo44, point2D47, false);
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot42.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot42.getRangeAxis(100);
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot42.setRangeCrosshairStroke(stroke53);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot42.getDomainAxisLocation();
        float float56 = xYPlot42.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent57 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot42);
        int int58 = xYPlot42.getSeriesCount();
        xYPlot13.setParent((org.jfree.chart.plot.Plot) xYPlot42);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D61 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range62 = numberAxis3D61.getRange();
        org.jfree.chart.plot.Plot plot63 = numberAxis3D61.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range65 = numberAxis3D64.getRange();
        numberAxis3D61.setRange(range65);
        java.text.NumberFormat numberFormat67 = numberAxis3D61.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = numberAxis3D61.getTickLabelInsets();
        java.awt.Shape shape69 = numberAxis3D61.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D70 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range71 = numberAxis3D70.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = null;
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) numberAxis3D61, (org.jfree.chart.axis.ValueAxis) numberAxis3D70, xYItemRenderer72);
        boolean boolean74 = xYPlot73.isDomainZeroBaselineVisible();
        java.awt.Color color75 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot73.setDomainTickBandPaint((java.awt.Paint) color75);
        java.awt.Stroke stroke77 = xYPlot73.getRangeZeroBaselineStroke();
        xYPlot42.setDomainCrosshairStroke(stroke77);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(numberFormat36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.5f + "'", float56 == 0.5f);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNull(plot63);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNull(numberFormat67);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke77);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot3D0.setDataset(pieDataset3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.lang.String str6 = range4.toString();
        double double7 = range4.getUpperBound();
        boolean boolean9 = range4.contains((double) (byte) 1);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Range[0.0,1.0]" + "'", str6.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setTitle("Range[0.0,1.0]");
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        try {
            jFreeChart3.plotChanged(plotChangeEvent7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double4 = size2D3.getWidth();
        org.jfree.chart.util.Size2D size2D5 = rectangleConstraint0.calculateConstrainedSize(size2D3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, 0.0d, (double) 10L, rectangleAnchor8);
        java.lang.String str10 = size2D5.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Size2D[width=1.0, height=0.0]" + "'", str10.equals("Size2D[width=1.0, height=0.0]"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        waferMapPlot0.handleClick((int) (byte) 0, 10, plotRenderingInfo3);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        waferMapPlot0.setRenderer(waferMapRenderer5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        float float27 = xYPlot13.getForegroundAlpha();
        xYPlot13.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot13.getRangeAxis();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.plot.Plot plot34 = numberAxis3D32.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range36 = numberAxis3D35.getRange();
        numberAxis3D32.setRange(range36);
        java.text.NumberFormat numberFormat38 = numberAxis3D32.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = numberAxis3D32.getTickLabelInsets();
        java.awt.Shape shape40 = numberAxis3D32.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range42 = numberAxis3D41.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, xYItemRenderer43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = null;
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D47, rectangleAnchor48);
        xYPlot44.zoomRangeAxes(100.0d, plotRenderingInfo46, point2D49, false);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot44.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot44.getRangeAxis(100);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot44.setRangeCrosshairStroke(stroke55);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot44.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation((int) (short) 0, axisLocation57);
        xYPlot13.setForegroundAlpha((float) (short) 100);
        xYPlot13.configureRangeAxes();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNull(valueAxis54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(axisLocation57);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        float float27 = xYPlot13.getForegroundAlpha();
        xYPlot13.clearRangeAxes();
        boolean boolean29 = xYPlot13.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        org.jfree.chart.plot.Plot plot46 = numberAxis3D44.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range48 = numberAxis3D47.getRange();
        numberAxis3D44.setRange(range48);
        xYPlot43.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D44);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range52 = numberAxis3D51.getRange();
        double double53 = numberAxis3D51.getUpperBound();
        double double54 = numberAxis3D51.getFixedAutoRange();
        numberAxis3D51.setPositiveArrowVisible(false);
        org.jfree.data.Range range57 = xYPlot43.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D51);
        boolean boolean58 = numberAxis3D51.isNegativeArrowVisible();
        numberAxis3D51.setAutoRangeMinimumSize((double) (short) 100, false);
        numberAxis3D51.setAutoRangeMinimumSize((double) 'a');
        org.jfree.data.Range range64 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D51);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(plot46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(range64);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        piePlot3D0.setSimpleLabels(true);
        piePlot3D0.setPieIndex(0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        boolean boolean4 = projectInfo0.equals((java.lang.Object) (byte) 10);
        projectInfo0.addOptionalLibrary("hi!");
        java.lang.String str7 = projectInfo0.getLicenceText();
        java.util.List list8 = projectInfo0.getContributors();
        java.lang.String str9 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str9.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.chart.plot.Plot plot6 = numberAxis3D4.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        numberAxis3D4.setRange(range8);
        java.text.NumberFormat numberFormat10 = numberAxis3D4.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D4.getTickLabelInsets();
        java.awt.Shape shape12 = numberAxis3D4.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range14 = numberAxis3D13.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer15);
        java.text.NumberFormat numberFormat17 = numberAxis3D4.getNumberFormatOverride();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        java.awt.Paint paint19 = polarPlot0.getAngleGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        polarPlot0.zoomDomainAxes(10.0d, (double) 2, plotRenderingInfo22, point2D25);
        java.lang.Object obj27 = polarPlot0.clone();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace28, true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        piePlot3D0.setSimpleLabels(true);
        piePlot3D0.setLabelGap((double) (-1L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Object obj16 = blockContainer15.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) dateAxis17);
        blockContainer15.setWidth(90.0d);
        blockContainer15.setPadding((double) 0L, (double) 3, (double) (-1L), (double) '#');
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        int int14 = xYPlot13.getRangeAxisCount();
        xYPlot13.setForegroundAlpha((float) (-16711936));
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot13.getOrientation();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D21.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        boolean boolean26 = categoryAxis3D21.equals((java.lang.Object) range25);
        numberAxis3D18.setRangeWithMargins(range25, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(range25, (double) (byte) 0);
        boolean boolean32 = plotOrientation17.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = valueMarker31.getLabelOffsetType();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker31.setStroke(stroke41);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        org.jfree.chart.plot.Plot plot45 = numberAxis3D43.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range47 = numberAxis3D46.getRange();
        numberAxis3D43.setRange(range47);
        java.text.NumberFormat numberFormat49 = numberAxis3D43.getNumberFormatOverride();
        java.text.NumberFormat numberFormat50 = null;
        numberAxis3D43.setNumberFormatOverride(numberFormat50);
        java.awt.Paint paint52 = numberAxis3D43.getLabelPaint();
        valueMarker31.setOutlinePaint(paint52);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNull(numberFormat49);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener4 = null;
        jFreeChart3.addProgressListener(chartProgressListener4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("ClassContext");
        double double8 = textTitle7.getContentXOffset();
        jFreeChart3.setTitle(textTitle7);
        java.awt.Paint paint10 = null;
        try {
            textTitle7.setPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        numberAxis3D14.centerRange((double) 500);
        java.awt.Shape shape23 = numberAxis3D14.getLeftArrow();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        java.awt.Paint paint3 = piePlot3D0.getLabelBackgroundPaint();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        org.jfree.chart.plot.Plot plot7 = numberAxis3D5.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        numberAxis3D5.setRange(range9);
        java.text.NumberFormat numberFormat11 = numberAxis3D5.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D5.getTickLabelInsets();
        java.awt.Shape shape13 = numberAxis3D5.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        xYPlot17.zoomRangeAxes(100.0d, plotRenderingInfo19, point2D22, false);
        double double25 = xYPlot17.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot17.setFixedDomainAxisSpace(axisSpace26, true);
        java.awt.Paint paint29 = xYPlot17.getRangeCrosshairPaint();
        java.awt.Paint paint30 = xYPlot17.getRangeZeroBaselinePaint();
        float float31 = xYPlot17.getForegroundAlpha();
        xYPlot17.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot17.getRangeAxis();
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range37 = numberAxis3D36.getRange();
        org.jfree.chart.plot.Plot plot38 = numberAxis3D36.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range40 = numberAxis3D39.getRange();
        numberAxis3D36.setRange(range40);
        java.text.NumberFormat numberFormat42 = numberAxis3D36.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D36.getTickLabelInsets();
        java.awt.Shape shape44 = numberAxis3D36.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range46 = numberAxis3D45.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, xYItemRenderer47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D51, rectangleAnchor52);
        xYPlot48.zoomRangeAxes(100.0d, plotRenderingInfo50, point2D53, false);
        org.jfree.chart.axis.AxisLocation axisLocation56 = xYPlot48.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis58 = xYPlot48.getRangeAxis(100);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot48.setRangeCrosshairStroke(stroke59);
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot48.getDomainAxisLocation();
        xYPlot17.setDomainAxisLocation((int) (short) 0, axisLocation61);
        xYPlot17.setForegroundAlpha((float) (short) 100);
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot17.setRangeGridlinePaint((java.awt.Paint) color65);
        piePlot3D0.setLabelBackgroundPaint((java.awt.Paint) color65);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(numberFormat42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNull(valueAxis58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ChartChangeEventType.DATASET_UPDATED", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setTitle("Range[0.0,1.0]");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        try {
            java.awt.image.BufferedImage bufferedImage9 = jFreeChart3.createBufferedImage((-1), (int) (byte) 0, chartRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2);
        dateAxis0.setTickMarkInsideLength((float) (byte) 1);
        java.lang.Class<?> wildcardClass6 = dateAxis0.getClass();
        java.awt.Font font7 = dateAxis0.getLabelFont();
        java.awt.Shape shape8 = dateAxis0.getRightArrow();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range2, (double) (byte) 1, 1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(1.0d, range2);
        double double7 = rectangleConstraint6.getHeight();
        double double8 = rectangleConstraint6.getHeight();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        try {
            org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset11, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Range[0.0,1.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        boolean boolean6 = categoryAxis3D1.equals((java.lang.Object) range5);
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.plot.Plot plot12 = numberAxis3D10.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range14 = numberAxis3D13.getRange();
        numberAxis3D10.setRange(range14);
        java.text.NumberFormat numberFormat16 = numberAxis3D10.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis3D10.getTickLabelInsets();
        java.awt.Shape shape18 = numberAxis3D10.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, xYItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        xYPlot22.zoomRangeAxes(100.0d, plotRenderingInfo24, point2D27, false);
        double double30 = xYPlot22.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot22.getAxisOffset();
        categoryAxis3D1.setLabelInsets(rectangleInsets31);
        double double34 = rectangleInsets31.extendHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(numberFormat16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 9.0d + "'", double34 == 9.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.chart.plot.Plot plot6 = numberAxis3D4.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        numberAxis3D4.setRange(range8);
        java.text.NumberFormat numberFormat10 = numberAxis3D4.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D4.getTickLabelInsets();
        java.awt.Shape shape12 = numberAxis3D4.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range14 = numberAxis3D13.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = null;
        java.awt.geom.Point2D point2D21 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D19, rectangleAnchor20);
        xYPlot16.zoomRangeAxes(100.0d, plotRenderingInfo18, point2D21, false);
        double double24 = xYPlot16.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot16.getAxisOffset();
        piePlot3D0.setInsets(rectangleInsets25, true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSectionOutlinesVisible();
        boolean boolean2 = piePlot3D0.isCircular();
        java.awt.Stroke stroke4 = null;
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 0.5f, stroke4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        org.jfree.chart.plot.Plot plot7 = numberAxis3D5.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        numberAxis3D5.setRange(range9);
        java.text.NumberFormat numberFormat11 = numberAxis3D5.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D5.getTickLabelInsets();
        java.awt.Shape shape13 = numberAxis3D5.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        xYPlot17.zoomRangeAxes(100.0d, plotRenderingInfo19, point2D22, false);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot17.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot17.getRangeAxis(100);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot17.setRangeCrosshairStroke(stroke28);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.plot.Plot plot32 = numberAxis3D30.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range34 = numberAxis3D33.getRange();
        numberAxis3D30.setRange(range34);
        java.text.NumberFormat numberFormat36 = numberAxis3D30.getNumberFormatOverride();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis3D30.setNumberFormatOverride(numberFormat37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = null;
        numberAxis3D30.setStandardTickUnits(tickUnitSource39);
        int int41 = xYPlot17.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Paint paint42 = numberAxis3D30.getTickLabelPaint();
        jFreeChart3.setBackgroundPaint(paint42);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("ClassContext");
        double double46 = textTitle45.getContentXOffset();
        jFreeChart3.addSubtitle((org.jfree.chart.title.Title) textTitle45);
        java.awt.Paint paint48 = textTitle45.getPaint();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(numberFormat36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        numberAxis3D1.setLabelAngle(0.2d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset11, false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        double double2 = textTitle1.getContentXOffset();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Color color3 = java.awt.Color.getHSBColor(1.0f, (float) 1L, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        projectInfo0.setName("Pie 3D Plot");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Size2D[width=1.0, height=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot13.getDomainAxisLocation(0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range28 = numberAxis3D27.getRange();
        org.jfree.chart.plot.Plot plot29 = numberAxis3D27.getPlot();
        xYPlot13.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D27);
        java.lang.String str31 = numberAxis3D27.getLabelURL();
        org.jfree.chart.plot.Plot plot32 = numberAxis3D27.getPlot();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(plot32);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        int int26 = xYPlot13.indexOf(xYDataset25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = xYPlot13.getFixedDomainAxisSpace();
        xYPlot13.setRangeGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        int int31 = xYPlot13.indexOf(xYDataset30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot13.getRangeAxisLocation((int) (short) 1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSectionOutlinesVisible();
        java.lang.String str2 = piePlot3D0.getPlotType();
        double double3 = piePlot3D0.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        valueMarker1.notifyListeners(markerChangeEvent2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        org.jfree.chart.plot.Plot plot7 = numberAxis3D5.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        numberAxis3D5.setRange(range9);
        java.text.NumberFormat numberFormat11 = numberAxis3D5.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D5.getTickLabelInsets();
        java.awt.Shape shape13 = numberAxis3D5.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        xYPlot17.zoomRangeAxes(100.0d, plotRenderingInfo19, point2D22, false);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot17.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot17.getRangeAxis(100);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot17.setRangeCrosshairStroke(stroke28);
        xYPlot17.clearRangeAxes();
        java.awt.Stroke stroke31 = xYPlot17.getDomainGridlineStroke();
        xYPlot17.mapDatasetToRangeAxis(0, 8);
        int int35 = xYPlot17.getDatasetCount();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        org.jfree.chart.plot.Plot plot39 = numberAxis3D37.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        numberAxis3D37.setRange(range41);
        java.text.NumberFormat numberFormat43 = numberAxis3D37.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = numberAxis3D37.getTickLabelInsets();
        java.awt.Shape shape45 = numberAxis3D37.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range47 = numberAxis3D46.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer48);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range51 = numberAxis3D50.getRange();
        org.jfree.chart.plot.Plot plot52 = numberAxis3D50.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range54 = numberAxis3D53.getRange();
        numberAxis3D50.setRange(range54);
        xYPlot49.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D50);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range58 = numberAxis3D57.getRange();
        double double59 = numberAxis3D57.getUpperBound();
        double double60 = numberAxis3D57.getFixedAutoRange();
        numberAxis3D57.setPositiveArrowVisible(false);
        org.jfree.data.Range range63 = xYPlot49.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D57);
        boolean boolean64 = numberAxis3D57.isNegativeArrowVisible();
        java.awt.Font font65 = numberAxis3D57.getTickLabelFont();
        numberAxis3D57.setRangeAboutValue((double) (-655360), (double) 0L);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D57);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNull(numberFormat43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNull(plot52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(font65);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        boolean boolean28 = numberAxis3D21.isNegativeArrowVisible();
        numberAxis3D21.setAutoRangeMinimumSize((double) (short) 100, false);
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis3D21.setDownArrow(shape32);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        org.jfree.data.Range range6 = dateAxis0.getRange();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Block block15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.plot.Plot plot19 = numberAxis3D17.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range21 = numberAxis3D20.getRange();
        numberAxis3D17.setRange(range21);
        java.text.NumberFormat numberFormat23 = numberAxis3D17.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis3D17.getTickLabelInsets();
        java.awt.Shape shape25 = numberAxis3D17.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        xYPlot29.zoomRangeAxes(100.0d, plotRenderingInfo31, point2D34, false);
        double double37 = xYPlot29.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        xYPlot29.setFixedDomainAxisSpace(axisSpace38, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range42 = numberAxis3D41.getRange();
        org.jfree.chart.plot.Plot plot43 = numberAxis3D41.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        numberAxis3D41.setRange(range45);
        java.text.NumberFormat numberFormat47 = numberAxis3D41.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = numberAxis3D41.getTickLabelInsets();
        java.awt.Shape shape49 = numberAxis3D41.getRightArrow();
        int int50 = xYPlot29.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D41);
        float float51 = numberAxis3D41.getTickMarkInsideLength();
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range54 = numberAxis3D53.getRange();
        org.jfree.chart.plot.Plot plot55 = numberAxis3D53.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range57 = numberAxis3D56.getRange();
        numberAxis3D53.setRange(range57);
        java.text.NumberFormat numberFormat59 = numberAxis3D53.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = numberAxis3D53.getTickLabelInsets();
        java.awt.Shape shape61 = numberAxis3D53.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range63 = numberAxis3D62.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset52, (org.jfree.chart.axis.ValueAxis) numberAxis3D53, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, xYItemRenderer64);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D66 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range67 = numberAxis3D66.getRange();
        org.jfree.chart.plot.Plot plot68 = numberAxis3D66.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D69 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range70 = numberAxis3D69.getRange();
        numberAxis3D66.setRange(range70);
        xYPlot65.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D66);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D73 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range74 = numberAxis3D73.getRange();
        double double75 = numberAxis3D73.getUpperBound();
        double double76 = numberAxis3D73.getFixedAutoRange();
        numberAxis3D73.setPositiveArrowVisible(false);
        org.jfree.data.Range range79 = xYPlot65.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D73);
        boolean boolean80 = numberAxis3D73.isNegativeArrowVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit81 = numberAxis3D73.getTickUnit();
        numberAxis3D41.setTickUnit(numberTickUnit81);
        numberAxis3D41.setAutoRangeMinimumSize(1.0E-8d);
        blockContainer14.add(block15, (java.lang.Object) 1.0E-8d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(numberFormat23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(plot43);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(numberFormat47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 0.0f + "'", float51 == 0.0f);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNull(plot55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNull(numberFormat59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNull(plot68);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNull(range79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(numberTickUnit81);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        java.text.NumberFormat numberFormat14 = numberAxis3D1.getNumberFormatOverride();
        numberAxis3D1.setLabelToolTip("WMAP_Plot");
        numberAxis3D1.setLabelAngle((double) (-655360));
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(numberFormat14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        org.jfree.chart.plot.Plot plot28 = numberAxis3D26.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range30 = numberAxis3D29.getRange();
        numberAxis3D26.setRange(range30);
        java.text.NumberFormat numberFormat32 = numberAxis3D26.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D26.getTickLabelInsets();
        java.awt.Shape shape34 = numberAxis3D26.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range36 = numberAxis3D35.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, xYItemRenderer37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = null;
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D41, rectangleAnchor42);
        xYPlot38.zoomRangeAxes(100.0d, plotRenderingInfo40, point2D43, false);
        org.jfree.chart.axis.AxisSpace axisSpace46 = xYPlot38.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray48 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer47 };
        xYPlot38.setRenderers(xYItemRendererArray48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        int int51 = xYPlot38.indexOf(xYDataset50);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot38.getDomainAxisLocation();
        numberAxis3D15.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot38);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNull(numberFormat32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNull(axisSpace46);
        org.junit.Assert.assertNotNull(xYItemRendererArray48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement15 = blockContainer14.getArrangement();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(arrangement15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot13.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint31 = numberAxis3D30.getTickMarkPaint();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        numberAxis3D30.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        java.awt.Stroke stroke25 = xYPlot24.getDomainZeroBaselineStroke();
        boolean boolean26 = xYPlot24.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot24.getSeriesRenderingOrder();
        boolean boolean28 = xYPlot24.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.lang.String str7 = range5.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, (double) (byte) 1, 1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(1.0d, range12);
        double double18 = range12.constrain(100.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range5, lengthConstraintType8, (double) 0, range12, lengthConstraintType19);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.FIXED;
        boolean boolean22 = lengthConstraintType8.equals((java.lang.Object) lengthConstraintType21);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,1.0]" + "'", str7.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        java.awt.Paint paint6 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset11);
        try {
            org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset11, (java.lang.Comparable) 0.14d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        java.lang.Object obj27 = plotChangeEvent26.getSource();
        java.lang.String str28 = plotChangeEvent26.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = plotChangeEvent26.getType();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(chartChangeEventType29);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        boolean boolean2 = categoryAxis3D1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        java.lang.Object obj27 = plotChangeEvent26.getSource();
        java.lang.String str28 = plotChangeEvent26.toString();
        try {
            java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) str28);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.chart.plot.Plot plot6 = numberAxis3D4.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        numberAxis3D4.setRange(range8);
        java.text.NumberFormat numberFormat10 = numberAxis3D4.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D4.getTickLabelInsets();
        java.awt.Shape shape12 = numberAxis3D4.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range14 = numberAxis3D13.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer15);
        java.text.NumberFormat numberFormat17 = numberAxis3D4.getNumberFormatOverride();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        polarPlot0.setAngleLabelsVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        polarPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo22, point2D25);
        boolean boolean27 = polarPlot0.isRangeZoomable();
        org.jfree.chart.axis.TickUnit tickUnit28 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(tickUnit28);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.Color color1 = java.awt.Color.RED;
        float[] floatArray5 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray6 = color1.getRGBColorComponents(floatArray5);
        float[] floatArray7 = color0.getColorComponents(floatArray5);
        java.awt.Color color8 = java.awt.Color.RED;
        float[] floatArray12 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray13 = color8.getRGBColorComponents(floatArray12);
        float[] floatArray14 = color0.getColorComponents(floatArray12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) 0);
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        org.jfree.chart.plot.Plot plot8 = numberAxis3D6.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        numberAxis3D6.setRange(range10);
        java.text.NumberFormat numberFormat12 = numberAxis3D6.getNumberFormatOverride();
        java.text.NumberFormat numberFormat13 = null;
        numberAxis3D6.setNumberFormatOverride(numberFormat13);
        java.awt.Paint paint15 = numberAxis3D6.getLabelPaint();
        boolean boolean16 = columnArrangement5.equals((java.lang.Object) paint15);
        boolean boolean18 = columnArrangement5.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        org.jfree.chart.plot.Plot plot23 = numberAxis3D21.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        numberAxis3D21.setRange(range25);
        java.text.NumberFormat numberFormat27 = numberAxis3D21.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis3D21.getTickLabelInsets();
        java.awt.Shape shape29 = numberAxis3D21.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, xYItemRenderer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        xYPlot33.zoomRangeAxes(100.0d, plotRenderingInfo35, point2D38, false);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot33.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot33.getRangeAxis(100);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot33.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot33.getDomainAxisLocation();
        float float47 = xYPlot33.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot33);
        boolean boolean49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer19, (java.lang.Object) plotChangeEvent48);
        java.awt.Color color50 = java.awt.Color.RED;
        float[] floatArray54 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray55 = color50.getRGBColorComponents(floatArray54);
        flowArrangement4.add((org.jfree.chart.block.Block) blockContainer19, (java.lang.Object) color50);
        int int57 = color50.getTransparency();
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.5f + "'", float47 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis0.getTickMarkPosition();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        org.jfree.chart.plot.Plot plot11 = numberAxis3D9.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range13 = numberAxis3D12.getRange();
        numberAxis3D9.setRange(range13);
        java.text.NumberFormat numberFormat15 = numberAxis3D9.getNumberFormatOverride();
        java.text.NumberFormat numberFormat16 = null;
        numberAxis3D9.setNumberFormatOverride(numberFormat16);
        java.awt.Paint paint18 = numberAxis3D9.getLabelPaint();
        boolean boolean19 = columnArrangement8.equals((java.lang.Object) paint18);
        boolean boolean21 = columnArrangement8.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        org.jfree.chart.plot.Plot plot26 = numberAxis3D24.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range28 = numberAxis3D27.getRange();
        numberAxis3D24.setRange(range28);
        java.text.NumberFormat numberFormat30 = numberAxis3D24.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis3D24.getTickLabelInsets();
        java.awt.Shape shape32 = numberAxis3D24.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range34 = numberAxis3D33.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, xYItemRenderer35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = null;
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D39, rectangleAnchor40);
        xYPlot36.zoomRangeAxes(100.0d, plotRenderingInfo38, point2D41, false);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot36.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis46 = xYPlot36.getRangeAxis(100);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot36.setRangeCrosshairStroke(stroke47);
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot36.getDomainAxisLocation();
        float float50 = xYPlot36.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot36);
        boolean boolean52 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer22, (java.lang.Object) plotChangeEvent51);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double55 = rectangleConstraint54.getWidth();
        org.jfree.chart.util.Size2D size2D56 = blockContainer22.arrange(graphics2D53, rectangleConstraint54);
        java.awt.geom.Rectangle2D rectangle2D57 = blockContainer22.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.util.List list59 = dateAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D57, rectangleEdge58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(numberFormat30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.5f + "'", float50 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot13.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range28 = numberAxis3D27.getRange();
        org.jfree.chart.plot.Plot plot29 = numberAxis3D27.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        numberAxis3D27.setRange(range31);
        java.text.NumberFormat numberFormat33 = numberAxis3D27.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis3D27.getTickLabelInsets();
        java.awt.Shape shape35 = numberAxis3D27.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range37 = numberAxis3D36.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, xYItemRenderer38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = null;
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor43);
        xYPlot39.zoomRangeAxes(100.0d, plotRenderingInfo41, point2D44, false);
        org.jfree.chart.axis.AxisLocation axisLocation47 = xYPlot39.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot39.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot39.getDomainAxisLocation(0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range54 = numberAxis3D53.getRange();
        org.jfree.chart.plot.Plot plot55 = numberAxis3D53.getPlot();
        xYPlot39.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D53);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder57 = xYPlot39.getDatasetRenderingOrder();
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder57);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(numberFormat33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNull(plot55);
        org.junit.Assert.assertNotNull(datasetRenderingOrder57);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        double double25 = xYPlot24.getDomainCrosshairValue();
        boolean boolean26 = xYPlot24.isRangeZeroBaselineVisible();
        java.awt.Paint paint27 = xYPlot24.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(paint27);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        boolean boolean25 = xYPlot24.isRangeZeroBaselineVisible();
        java.lang.String str26 = xYPlot24.getPlotType();
        java.awt.Stroke stroke27 = xYPlot24.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        java.util.TimeZone timeZone5 = dateAxis0.getTimeZone();
        java.text.DateFormat dateFormat6 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(dateFormat6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        xYPlot14.zoomRangeAxes(100.0d, plotRenderingInfo16, point2D19, false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot14.getRangeAxis(100);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot14.setRangeCrosshairStroke(stroke25);
        xYPlot14.clearRangeMarkers((int) 'a');
        java.awt.Color color30 = java.awt.Color.green;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color30, stroke31);
        java.awt.Color color34 = java.awt.Color.green;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color34, stroke35);
        valueMarker32.setStroke(stroke35);
        valueMarker32.setValue(10.0d);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker32);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = valueMarker32.getLabelOffsetType();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color44 = java.awt.Color.getColor("ThreadContext", color43);
        valueMarker32.setOutlinePaint((java.awt.Paint) color43);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range50 = numberAxis3D49.getRange();
        org.jfree.chart.plot.Plot plot51 = numberAxis3D49.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range53 = numberAxis3D52.getRange();
        numberAxis3D49.setRange(range53);
        java.text.NumberFormat numberFormat55 = numberAxis3D49.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = numberAxis3D49.getTickLabelInsets();
        java.awt.Shape shape57 = numberAxis3D49.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range59 = numberAxis3D58.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) numberAxis3D49, (org.jfree.chart.axis.ValueAxis) numberAxis3D58, xYItemRenderer60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = null;
        java.awt.geom.Point2D point2D66 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D64, rectangleAnchor65);
        xYPlot61.zoomRangeAxes(100.0d, plotRenderingInfo63, point2D66, false);
        double double69 = xYPlot61.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace70 = null;
        xYPlot61.setFixedDomainAxisSpace(axisSpace70, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D73 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range74 = numberAxis3D73.getRange();
        org.jfree.chart.plot.Plot plot75 = numberAxis3D73.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D76 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range77 = numberAxis3D76.getRange();
        numberAxis3D73.setRange(range77);
        java.text.NumberFormat numberFormat79 = numberAxis3D73.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = numberAxis3D73.getTickLabelInsets();
        java.awt.Shape shape81 = numberAxis3D73.getRightArrow();
        int int82 = xYPlot61.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D73);
        java.awt.Font font83 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D73.setTickLabelFont(font83);
        org.jfree.chart.text.TextFragment textFragment85 = new org.jfree.chart.text.TextFragment("Range[0.0,1.0]", font83);
        java.awt.Paint paint86 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.text.TextFragment textFragment88 = new org.jfree.chart.text.TextFragment("ThreadContext", font83, paint86, (float) 1);
        valueMarker32.setLabelFont(font83);
        java.awt.Color color90 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.text.TextMeasurer textMeasurer92 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock93 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie 3D Plot", font83, (java.awt.Paint) color90, (float) '4', textMeasurer92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNull(plot51);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNull(numberFormat55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(point2D66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNull(plot75);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertNull(numberFormat79);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(font83);
        org.junit.Assert.assertNotNull(paint86);
        org.junit.Assert.assertNotNull(color90);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        piePlot3D0.setExplodePercent((java.lang.Comparable) date2, 1.0E-5d);
        java.awt.Stroke stroke6 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 0.0d);
        java.lang.Object obj7 = null;
        boolean boolean8 = piePlot3D0.equals(obj7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        org.jfree.chart.util.Rotation rotation2 = piePlot3D0.getDirection();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rotation2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.plot.Plot plot4 = jFreeChart3.getPlot();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D7.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        numberAxis3D7.setRange(range11);
        java.text.NumberFormat numberFormat13 = numberAxis3D7.getNumberFormatOverride();
        java.text.NumberFormat numberFormat14 = null;
        numberAxis3D7.setNumberFormatOverride(numberFormat14);
        java.awt.Paint paint16 = numberAxis3D7.getLabelPaint();
        boolean boolean17 = columnArrangement6.equals((java.lang.Object) paint16);
        boolean boolean19 = columnArrangement6.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement6);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range23 = numberAxis3D22.getRange();
        org.jfree.chart.plot.Plot plot24 = numberAxis3D22.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        numberAxis3D22.setRange(range26);
        java.text.NumberFormat numberFormat28 = numberAxis3D22.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = numberAxis3D22.getTickLabelInsets();
        java.awt.Shape shape30 = numberAxis3D22.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, xYItemRenderer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = null;
        java.awt.geom.Point2D point2D39 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D37, rectangleAnchor38);
        xYPlot34.zoomRangeAxes(100.0d, plotRenderingInfo36, point2D39, false);
        org.jfree.chart.axis.AxisLocation axisLocation42 = xYPlot34.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis44 = xYPlot34.getRangeAxis(100);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot34.setRangeCrosshairStroke(stroke45);
        org.jfree.chart.axis.AxisLocation axisLocation47 = xYPlot34.getDomainAxisLocation();
        float float48 = xYPlot34.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent49 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot34);
        boolean boolean50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer20, (java.lang.Object) plotChangeEvent49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double53 = rectangleConstraint52.getWidth();
        org.jfree.chart.util.Size2D size2D54 = blockContainer20.arrange(graphics2D51, rectangleConstraint52);
        java.awt.geom.Rectangle2D rectangle2D55 = blockContainer20.getBounds();
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range58 = numberAxis3D57.getRange();
        org.jfree.chart.plot.Plot plot59 = numberAxis3D57.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range61 = numberAxis3D60.getRange();
        numberAxis3D57.setRange(range61);
        java.text.NumberFormat numberFormat63 = numberAxis3D57.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = numberAxis3D57.getTickLabelInsets();
        java.awt.Shape shape65 = numberAxis3D57.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D66 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range67 = numberAxis3D66.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D66, xYItemRenderer68);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = null;
        java.awt.geom.Point2D point2D74 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D72, rectangleAnchor73);
        xYPlot69.zoomRangeAxes(100.0d, plotRenderingInfo71, point2D74, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = null;
        try {
            jFreeChart3.draw(graphics2D5, rectangle2D55, point2D74, chartRenderingInfo77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(numberFormat28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(point2D39);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.5f + "'", float48 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(size2D54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNull(plot59);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNull(numberFormat63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNotNull(point2D74);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Range[0.0,1.0]", graphics2D1, (float) (short) 1, (float) 0L, (double) (short) -1, (float) 0L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        org.jfree.chart.plot.Plot plot5 = numberAxis3D3.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        numberAxis3D3.setRange(range7);
        java.text.NumberFormat numberFormat9 = numberAxis3D3.getNumberFormatOverride();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis3D3.setNumberFormatOverride(numberFormat10);
        java.awt.Paint paint12 = numberAxis3D3.getLabelPaint();
        boolean boolean13 = columnArrangement2.equals((java.lang.Object) paint12);
        boolean boolean15 = columnArrangement2.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.chart.plot.Plot plot20 = numberAxis3D18.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        numberAxis3D18.setRange(range22);
        java.text.NumberFormat numberFormat24 = numberAxis3D18.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis3D18.getTickLabelInsets();
        java.awt.Shape shape26 = numberAxis3D18.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range28 = numberAxis3D27.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, xYItemRenderer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot30.zoomRangeAxes(100.0d, plotRenderingInfo32, point2D35, false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot30.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis40 = xYPlot30.getRangeAxis(100);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot30.setRangeCrosshairStroke(stroke41);
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot30.getDomainAxisLocation();
        float float44 = xYPlot30.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent45 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot30);
        boolean boolean46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer16, (java.lang.Object) plotChangeEvent45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double49 = rectangleConstraint48.getWidth();
        org.jfree.chart.util.Size2D size2D50 = blockContainer16.arrange(graphics2D47, rectangleConstraint48);
        java.awt.geom.Rectangle2D rectangle2D51 = blockContainer16.getBounds();
        textTitle0.draw(graphics2D1, rectangle2D51);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date54 = dateAxis53.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = null;
        dateAxis53.setTickUnit(dateTickUnit55);
        dateAxis53.setTickMarkInsideLength((float) (byte) 1);
        java.lang.Class<?> wildcardClass59 = dateAxis53.getClass();
        java.awt.Font font60 = dateAxis53.getLabelFont();
        textTitle0.setFont(font60);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(numberFormat24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.5f + "'", float44 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(font60);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot13.getDomainAxisLocation(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot13.getRenderer(8);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement31 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.plot.Plot plot34 = numberAxis3D32.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range36 = numberAxis3D35.getRange();
        numberAxis3D32.setRange(range36);
        java.text.NumberFormat numberFormat38 = numberAxis3D32.getNumberFormatOverride();
        java.text.NumberFormat numberFormat39 = null;
        numberAxis3D32.setNumberFormatOverride(numberFormat39);
        java.awt.Paint paint41 = numberAxis3D32.getLabelPaint();
        boolean boolean42 = columnArrangement31.equals((java.lang.Object) paint41);
        boolean boolean44 = columnArrangement31.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement31);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range48 = numberAxis3D47.getRange();
        org.jfree.chart.plot.Plot plot49 = numberAxis3D47.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range51 = numberAxis3D50.getRange();
        numberAxis3D47.setRange(range51);
        java.text.NumberFormat numberFormat53 = numberAxis3D47.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = numberAxis3D47.getTickLabelInsets();
        java.awt.Shape shape55 = numberAxis3D47.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range57 = numberAxis3D56.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) numberAxis3D47, (org.jfree.chart.axis.ValueAxis) numberAxis3D56, xYItemRenderer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = null;
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D62, rectangleAnchor63);
        xYPlot59.zoomRangeAxes(100.0d, plotRenderingInfo61, point2D64, false);
        org.jfree.chart.axis.AxisLocation axisLocation67 = xYPlot59.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis69 = xYPlot59.getRangeAxis(100);
        java.awt.Stroke stroke70 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot59.setRangeCrosshairStroke(stroke70);
        org.jfree.chart.axis.AxisLocation axisLocation72 = xYPlot59.getDomainAxisLocation();
        float float73 = xYPlot59.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent74 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot59);
        boolean boolean75 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer45, (java.lang.Object) plotChangeEvent74);
        java.awt.Graphics2D graphics2D76 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double78 = rectangleConstraint77.getWidth();
        org.jfree.chart.util.Size2D size2D79 = blockContainer45.arrange(graphics2D76, rectangleConstraint77);
        java.awt.geom.Rectangle2D rectangle2D80 = blockContainer45.getBounds();
        textTitle29.draw(graphics2D30, rectangle2D80);
        try {
            xYPlot13.drawOutline(graphics2D28, rectangle2D80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(plot49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNull(numberFormat53);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 0.5f + "'", float73 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(size2D79);
        org.junit.Assert.assertNotNull(rectangle2D80);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        java.awt.Stroke stroke25 = xYPlot24.getDomainZeroBaselineStroke();
        boolean boolean26 = xYPlot24.isRangeZeroBaselineVisible();
        xYPlot24.clearRangeAxes();
        xYPlot24.zoom(0.05d);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        float float27 = xYPlot13.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        java.awt.Paint paint29 = xYPlot13.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset11);
        try {
            org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset11, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        int int25 = xYPlot13.getDatasetCount();
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = color26.brighter();
        xYPlot13.setDomainCrosshairPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range33 = numberAxis3D32.getRange();
        org.jfree.chart.plot.Plot plot34 = numberAxis3D32.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range36 = numberAxis3D35.getRange();
        numberAxis3D32.setRange(range36);
        java.text.NumberFormat numberFormat38 = numberAxis3D32.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = numberAxis3D32.getTickLabelInsets();
        java.awt.Shape shape40 = numberAxis3D32.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range42 = numberAxis3D41.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, xYItemRenderer43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = null;
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D47, rectangleAnchor48);
        xYPlot44.zoomRangeAxes(100.0d, plotRenderingInfo46, point2D49, false);
        double double52 = xYPlot44.getRangeCrosshairValue();
        xYPlot44.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent58 = null;
        polarPlot57.datasetChanged(datasetChangeEvent58);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D61 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range62 = numberAxis3D61.getRange();
        org.jfree.chart.plot.Plot plot63 = numberAxis3D61.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range65 = numberAxis3D64.getRange();
        numberAxis3D61.setRange(range65);
        java.text.NumberFormat numberFormat67 = numberAxis3D61.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = numberAxis3D61.getTickLabelInsets();
        java.awt.Shape shape69 = numberAxis3D61.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D70 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range71 = numberAxis3D70.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = null;
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) numberAxis3D61, (org.jfree.chart.axis.ValueAxis) numberAxis3D70, xYItemRenderer72);
        java.text.NumberFormat numberFormat74 = numberAxis3D61.getNumberFormatOverride();
        polarPlot57.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D61);
        java.awt.Paint paint76 = polarPlot57.getAngleGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = null;
        java.awt.geom.Point2D point2D82 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D80, rectangleAnchor81);
        polarPlot57.zoomDomainAxes(10.0d, (double) 2, plotRenderingInfo79, point2D82);
        xYPlot44.zoomRangeAxes(1.0d, plotRenderingInfo56, point2D82);
        xYPlot13.zoomRangeAxes((double) (short) -1, plotRenderingInfo30, point2D82, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNull(plot63);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNull(numberFormat67);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertNull(numberFormat74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(point2D82);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.lang.Object obj15 = blockContainer14.clone();
        java.util.List list16 = blockContainer14.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer14.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range20 = numberAxis3D19.getRange();
        org.jfree.chart.plot.Plot plot21 = numberAxis3D19.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range23 = numberAxis3D22.getRange();
        numberAxis3D19.setRange(range23);
        java.lang.String str25 = range23.toString();
        boolean boolean26 = horizontalAlignment18.equals((java.lang.Object) str25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment27, 10.0d, (double) 1L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment31, (double) 10L, (double) 0.0f);
        blockContainer14.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement34);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Range[0.0,1.0]" + "'", str25.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        org.jfree.chart.plot.Plot plot7 = numberAxis3D5.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        numberAxis3D5.setRange(range9);
        java.text.NumberFormat numberFormat11 = numberAxis3D5.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis3D5.getTickLabelInsets();
        java.awt.Shape shape13 = numberAxis3D5.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        xYPlot17.zoomRangeAxes(100.0d, plotRenderingInfo19, point2D22, false);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot17.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot17.getRangeAxis(100);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot17.setRangeCrosshairStroke(stroke28);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.plot.Plot plot32 = numberAxis3D30.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range34 = numberAxis3D33.getRange();
        numberAxis3D30.setRange(range34);
        java.text.NumberFormat numberFormat36 = numberAxis3D30.getNumberFormatOverride();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis3D30.setNumberFormatOverride(numberFormat37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = null;
        numberAxis3D30.setStandardTickUnits(tickUnitSource39);
        int int41 = xYPlot17.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Paint paint42 = numberAxis3D30.getTickLabelPaint();
        jFreeChart3.setBackgroundPaint(paint42);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("ClassContext");
        double double46 = textTitle45.getContentXOffset();
        jFreeChart3.addSubtitle((org.jfree.chart.title.Title) textTitle45);
        java.awt.Paint paint48 = jFreeChart3.getBorderPaint();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(numberFormat36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range2, (double) (byte) 1, 1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(1.0d, range2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range11, (double) (byte) 1, 1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(1.0d, range11);
        org.jfree.data.Range range16 = rectangleConstraint15.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint6.toRangeHeight(range16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint6.toFixedHeight(0.2d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        xYPlot13.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        xYPlot37.zoomRangeAxes(100.0d, plotRenderingInfo39, point2D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot37.getDomainAxisLocation();
        xYPlot13.setRangeAxisLocation(axisLocation45);
        java.awt.Paint paint47 = xYPlot13.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        multiplePiePlot0.handleClick((int) (short) 10, 0, plotRenderingInfo4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable7 = multiplePiePlot6.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder8 = multiplePiePlot6.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot6.getPieChart();
        jFreeChart9.setTitle("Range[0.0,1.0]");
        multiplePiePlot0.setPieChart(jFreeChart9);
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "Other" + "'", comparable7.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertNotNull(jFreeChart9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSectionOutlinesVisible();
        boolean boolean2 = piePlot3D0.isCircular();
        java.awt.Color color3 = java.awt.Color.WHITE;
        piePlot3D0.setLabelOutlinePaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot3D0.getDataset();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D7.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        numberAxis3D7.setRange(range11);
        java.text.NumberFormat numberFormat13 = numberAxis3D7.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis3D7.getTickLabelInsets();
        java.awt.Shape shape15 = numberAxis3D7.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range17 = numberAxis3D16.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, xYItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor23);
        xYPlot19.zoomRangeAxes(100.0d, plotRenderingInfo21, point2D24, false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot19.getDomainAxisLocation();
        int int28 = xYPlot19.getWeight();
        java.awt.Stroke stroke29 = xYPlot19.getRangeGridlineStroke();
        piePlot3D0.setLabelLinkStroke(stroke29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis0.setTimeline(timeline5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D7.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        numberAxis3D7.setRange(range11);
        java.lang.String str13 = range11.toString();
        boolean boolean15 = range11.contains((double) ' ');
        dateAxis0.setRange(range11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke18 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date20 = dateAxis17.calculateLowestVisibleTickValue(dateTickUnit19);
        java.util.Date date21 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit19);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,1.0]" + "'", str13.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 500, 0.4d, (double) 255, (double) 0.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        boolean boolean4 = projectInfo0.equals((java.lang.Object) (byte) 10);
        projectInfo0.addOptionalLibrary("hi!");
        java.lang.String str7 = projectInfo0.getLicenceText();
        java.util.List list8 = projectInfo0.getContributors();
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        projectInfo10.addOptionalLibrary("");
        boolean boolean14 = projectInfo10.equals((java.lang.Object) (byte) 10);
        projectInfo10.addOptionalLibrary("hi!");
        java.lang.String str17 = projectInfo10.getLicenceText();
        java.util.List list18 = projectInfo10.getContributors();
        projectInfo9.setContributors(list18);
        projectInfo0.setContributors(list18);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(projectInfo9);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        xYPlot13.mapDatasetToRangeAxis(1, 0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot13.getDomainMarkers(layer40);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot13);
        java.awt.Paint paint43 = legendTitle42.getItemPaint();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray44 = legendTitle42.getSources();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range47 = numberAxis3D46.getRange();
        org.jfree.chart.plot.Plot plot48 = numberAxis3D46.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range50 = numberAxis3D49.getRange();
        numberAxis3D46.setRange(range50);
        java.lang.String str52 = range50.toString();
        boolean boolean53 = horizontalAlignment45.equals((java.lang.Object) str52);
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement57 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment45, verticalAlignment54, 10.0d, (double) 1L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement61 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment45, verticalAlignment58, (double) 10L, (double) 0.0f);
        legendTitle42.setHorizontalAlignment(horizontalAlignment45);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(legendItemSourceArray44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNull(plot48);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Range[0.0,1.0]" + "'", str52.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setTitle("Range[0.0,1.0]");
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.plot.Plot plot10 = numberAxis3D8.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        numberAxis3D8.setRange(range12);
        java.text.NumberFormat numberFormat14 = numberAxis3D8.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D8.getTickLabelInsets();
        java.awt.Shape shape16 = numberAxis3D8.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        xYPlot20.zoomRangeAxes(100.0d, plotRenderingInfo22, point2D25, false);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot20.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getRangeAxis(100);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke31);
        xYPlot20.clearRangeMarkers((int) 'a');
        java.awt.Color color36 = java.awt.Color.green;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color36, stroke37);
        java.awt.Color color40 = java.awt.Color.green;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color40, stroke41);
        valueMarker38.setStroke(stroke41);
        valueMarker38.setValue(10.0d);
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker38);
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = xYPlot20.getDomainMarkers(layer47);
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot20);
        java.awt.Paint paint50 = legendTitle49.getItemPaint();
        jFreeChart3.addSubtitle(0, (org.jfree.chart.title.Title) legendTitle49);
        org.jfree.chart.title.LegendTitle legendTitle53 = jFreeChart3.getLegend(8);
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(legendTitle53);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        xYPlot37.zoomRangeAxes(100.0d, plotRenderingInfo39, point2D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot37.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation45, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = null;
        xYPlot13.rendererChanged(rendererChangeEvent48);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent50 = null;
        xYPlot13.axisChanged(axisChangeEvent50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot13.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace53 = xYPlot13.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(valueAxis52);
        org.junit.Assert.assertNull(axisSpace53);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainZeroBaselineVisible();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color15);
        java.awt.Stroke stroke17 = xYPlot13.getRangeZeroBaselineStroke();
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color19, stroke20);
        boolean boolean23 = valueMarker21.equals((java.lang.Object) 0);
        xYPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean26 = piePlot3D25.getSectionOutlinesVisible();
        boolean boolean27 = piePlot3D25.isCircular();
        java.awt.Color color28 = java.awt.Color.WHITE;
        piePlot3D25.setLabelOutlinePaint((java.awt.Paint) color28);
        valueMarker21.setLabelPaint((java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        int int14 = xYPlot13.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot13.getDataset((int) (short) -1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        xYPlot13.datasetChanged(datasetChangeEvent17);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        org.jfree.chart.plot.Plot plot23 = numberAxis3D21.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        numberAxis3D21.setRange(range25);
        java.text.NumberFormat numberFormat27 = numberAxis3D21.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis3D21.getTickLabelInsets();
        java.awt.Shape shape29 = numberAxis3D21.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, xYItemRenderer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        xYPlot33.zoomRangeAxes(100.0d, plotRenderingInfo35, point2D38, false);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot33.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot33.getRangeAxis(100);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot33.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot33.getDomainAxisLocation();
        xYPlot13.setRangeAxisLocation((int) ' ', axisLocation46);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainZeroBaselineVisible();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot13);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType23 = rectangleInsets22.getUnitType();
        jFreeChart17.setPadding(rectangleInsets22);
        int int25 = jFreeChart17.getSubtitleCount();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
        double double2 = textTitle1.getContentXOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle1.setPosition(rectangleEdge3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot13.getDataset((-1));
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        org.jfree.chart.plot.Plot plot30 = numberAxis3D28.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        numberAxis3D28.setRange(range32);
        java.text.NumberFormat numberFormat34 = numberAxis3D28.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis3D28.getTickLabelInsets();
        java.awt.Shape shape36 = numberAxis3D28.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = null;
        java.awt.geom.Point2D point2D45 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D43, rectangleAnchor44);
        xYPlot40.zoomRangeAxes(100.0d, plotRenderingInfo42, point2D45, false);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot40.getDomainAxisLocation();
        int int49 = xYPlot40.getWeight();
        java.awt.Stroke stroke50 = xYPlot40.getRangeGridlineStroke();
        xYPlot13.setRangeGridlineStroke(stroke50);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(numberFormat34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(point2D45);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        xYPlot13.addChangeListener(plotChangeListener22);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D2.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        boolean boolean7 = categoryAxis3D2.equals((java.lang.Object) range6);
        categoryAxis3D2.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.plot.Plot plot13 = numberAxis3D11.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        numberAxis3D11.setRange(range15);
        java.text.NumberFormat numberFormat17 = numberAxis3D11.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis3D11.getTickLabelInsets();
        java.awt.Shape shape19 = numberAxis3D11.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range21 = numberAxis3D20.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot23.zoomRangeAxes(100.0d, plotRenderingInfo25, point2D28, false);
        double double31 = xYPlot23.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = xYPlot23.getAxisOffset();
        categoryAxis3D2.setLabelInsets(rectangleInsets32);
        piePlot0.setInsets(rectangleInsets32, false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.awt.Paint paint6 = numberAxis3D0.getLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D7.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        numberAxis3D7.setRange(range11);
        java.text.NumberFormat numberFormat13 = numberAxis3D7.getNumberFormatOverride();
        java.text.NumberFormat numberFormat14 = null;
        numberAxis3D7.setNumberFormatOverride(numberFormat14);
        java.awt.Shape shape16 = numberAxis3D7.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape16, "");
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape16, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.awt.Shape shape21 = chartEntity20.getArea();
        numberAxis3D0.setDownArrow(shape21);
        numberAxis3D0.setTickMarkOutsideLength(0.0f);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke1 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis3.setTickUnit(dateTickUnit4, false, true);
        java.util.TimeZone timeZone8 = dateAxis3.getTimeZone();
        dateAxis0.setTimeZone(timeZone8);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot13);
        xYPlot13.setRangeCrosshairValue(1.0E-5d, true);
        java.awt.Color color31 = java.awt.Color.green;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color31, stroke32);
        java.awt.Color color35 = java.awt.Color.green;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color35, stroke36);
        valueMarker33.setStroke(stroke36);
        java.awt.Font font39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        valueMarker33.setLabelFont(font39);
        try {
            boolean boolean41 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        float[] floatArray4 = new float[] { (short) 100 };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB((int) (short) 1, (-16711936), 0, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        blockContainer14.setPadding((double) (byte) 100, 0.0d, 0.05d, (double) 100);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = blockContainer14.arrange(graphics2D20);
        java.lang.Object obj22 = blockContainer14.clone();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range1 = numberAxis3D0.getRange();
        org.jfree.chart.plot.Plot plot2 = numberAxis3D0.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        numberAxis3D0.setRange(range4);
        java.text.NumberFormat numberFormat6 = numberAxis3D0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat7);
        java.awt.Shape shape9 = numberAxis3D0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape9, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape9, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "RectangleAnchor.TOP");
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        double double3 = multiplePiePlot0.getLimit();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 0.0f);
        double double9 = size2D8.getWidth();
        org.jfree.chart.util.Size2D size2D10 = rectangleConstraint5.calculateConstrainedSize(size2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, 0.0d, (double) 10L, rectangleAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str18 = rectangleAnchor17.toString();
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) 100.0f, (double) (-655360), rectangleAnchor17);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        org.jfree.chart.plot.Plot plot23 = numberAxis3D21.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        numberAxis3D21.setRange(range25);
        java.text.NumberFormat numberFormat27 = numberAxis3D21.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis3D21.getTickLabelInsets();
        java.awt.Shape shape29 = numberAxis3D21.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, xYItemRenderer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        xYPlot33.zoomRangeAxes(100.0d, plotRenderingInfo35, point2D38, false);
        double double41 = xYPlot33.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        xYPlot33.setFixedDomainAxisSpace(axisSpace42, true);
        java.awt.Paint paint45 = xYPlot33.getRangeCrosshairPaint();
        java.awt.Paint paint46 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
        xYPlot33.datasetChanged(datasetChangeEvent47);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range51 = numberAxis3D50.getRange();
        org.jfree.chart.plot.Plot plot52 = numberAxis3D50.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range54 = numberAxis3D53.getRange();
        numberAxis3D50.setRange(range54);
        java.text.NumberFormat numberFormat56 = numberAxis3D50.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = numberAxis3D50.getTickLabelInsets();
        java.awt.Shape shape58 = numberAxis3D50.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range60 = numberAxis3D59.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) numberAxis3D50, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = null;
        java.awt.geom.Point2D point2D67 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D65, rectangleAnchor66);
        xYPlot62.zoomRangeAxes(100.0d, plotRenderingInfo64, point2D67, false);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot62.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis72 = xYPlot62.getRangeAxis(100);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot62.setRangeCrosshairStroke(stroke73);
        org.jfree.chart.axis.AxisLocation axisLocation75 = xYPlot62.getDomainAxisLocation();
        float float76 = xYPlot62.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent77 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot62);
        int int78 = xYPlot62.getSeriesCount();
        xYPlot33.setParent((org.jfree.chart.plot.Plot) xYPlot62);
        java.awt.geom.Point2D point2D80 = xYPlot33.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState81 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        try {
            multiplePiePlot0.draw(graphics2D4, rectangle2D19, point2D80, plotState81, plotRenderingInfo82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleAnchor.LEFT" + "'", str18.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNull(plot52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNull(numberFormat56);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(point2D67);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNull(valueAxis72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertTrue("'" + float76 + "' != '" + 0.5f + "'", float76 == 0.5f);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(point2D80);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("WMAP_Plot", "WMAP_Plot", "WMAP_Plot", image3, "WMAP_Plot", "WMAP_Plot", "hi!");
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        org.jfree.chart.plot.Plot plot11 = numberAxis3D9.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range13 = numberAxis3D12.getRange();
        numberAxis3D9.setRange(range13);
        java.text.NumberFormat numberFormat15 = numberAxis3D9.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis3D9.getTickLabelInsets();
        java.awt.Shape shape17 = numberAxis3D9.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        xYPlot21.zoomRangeAxes(100.0d, plotRenderingInfo23, point2D26, false);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot21.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot21.getRangeAxis(100);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setRangeCrosshairStroke(stroke32);
        xYPlot21.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        xYPlot21.removeChangeListener(plotChangeListener35);
        boolean boolean37 = projectInfo7.equals((java.lang.Object) plotChangeListener35);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        int int22 = xYPlot13.getWeight();
        java.awt.Stroke stroke23 = xYPlot13.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D27.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        boolean boolean32 = categoryAxis3D27.equals((java.lang.Object) range31);
        numberAxis3D25.setRangeWithMargins(range31, false, false);
        xYPlot13.setRangeAxis(3, (org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.RIGHT", graphics2D1, 2.0d, (float) (byte) -1, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        int int25 = xYPlot13.getDatasetCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        xYPlot13.rendererChanged(rendererChangeEvent26);
        xYPlot13.clearDomainAxes();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color5, stroke6);
        valueMarker3.setStroke(stroke6);
        org.jfree.chart.ui.Library library13 = new org.jfree.chart.ui.Library("hi!", "ClassContext", "", "ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        boolean boolean16 = library13.equals((java.lang.Object) rectangleInsets14);
        valueMarker3.setLabelOffset(rectangleInsets14);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        valueMarker3.setOutlineStroke(stroke18);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 45.0d };
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke4 = dateAxis3.getAxisLineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date6 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit5);
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { "ThreadContext", dateTickUnit5, 10.0f, "", "RectangleAnchor.LEFT", 10.0d };
        double[] doubleArray13 = new double[] { (short) 1 };
        double[] doubleArray15 = new double[] { (short) 1 };
        double[] doubleArray17 = new double[] { (short) 1 };
        double[] doubleArray19 = new double[] { (short) 1 };
        double[][] doubleArray20 = new double[][] { doubleArray13, doubleArray15, doubleArray17, doubleArray19 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray11, doubleArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setTitle("Range[0.0,1.0]");
        java.lang.Object obj6 = jFreeChart3.clone();
        java.awt.Paint paint7 = jFreeChart3.getBorderPaint();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint2 = numberAxis3D1.getTickMarkPaint();
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot13.getDomainMarkers(layer40);
        xYPlot13.mapDatasetToDomainAxis(0, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = null;
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D47, rectangleAnchor48);
        xYPlot13.zoomRangeAxes((double) 10.0f, plotRenderingInfo46, point2D49);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(point2D49);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot13.getDomainMarkers(layer40);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot13);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = rectangleConstraint44.toFixedHeight((double) (byte) -1);
        org.jfree.chart.util.Size2D size2D47 = legendTitle42.arrange(graphics2D43, rectangleConstraint46);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(rectangleConstraint44);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertNotNull(size2D47);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color6 = java.awt.Color.GRAY;
        java.awt.Color color7 = java.awt.Color.RED;
        float[] floatArray11 = new float[] { (byte) 100, '#', (byte) 100 };
        float[] floatArray12 = color7.getRGBColorComponents(floatArray11);
        float[] floatArray13 = color6.getColorComponents(floatArray11);
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) '4', 0, (int) (short) -1, floatArray11);
        try {
            float[] floatArray15 = color0.getComponents(colorSpace2, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setAngleGridlineStroke(stroke3);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot0.datasetChanged(datasetChangeEvent5);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D2.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D2.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        org.jfree.chart.plot.Plot plot17 = numberAxis3D15.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        numberAxis3D15.setRange(range19);
        java.text.NumberFormat numberFormat21 = numberAxis3D15.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis3D15.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer23);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        xYPlot24.datasetChanged(datasetChangeEvent25);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.configure();
        double double3 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        piePlot3D0.setCircular(true, true);
        double double6 = piePlot3D0.getLabelLinkMargin();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.plot.Plot plot10 = numberAxis3D8.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        numberAxis3D8.setRange(range12);
        java.text.NumberFormat numberFormat14 = numberAxis3D8.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D8.getTickLabelInsets();
        java.awt.Shape shape16 = numberAxis3D8.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        xYPlot20.zoomRangeAxes(100.0d, plotRenderingInfo22, point2D25, false);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot20.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getRangeAxis(100);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke31);
        xYPlot20.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot20.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.plot.CrosshairState crosshairState40 = null;
        boolean boolean41 = xYPlot20.render(graphics2D36, rectangle2D37, 255, plotRenderingInfo39, crosshairState40);
        java.awt.Paint paint42 = xYPlot20.getDomainGridlinePaint();
        piePlot3D0.setLabelShadowPaint(paint42);
        java.awt.Stroke stroke45 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 15);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator46 = piePlot3D0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(stroke45);
        org.junit.Assert.assertNull(pieURLGenerator46);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        jFreeChart3.setTitle("Range[0.0,1.0]");
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color8 = java.awt.Color.green;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color8, stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets15.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke9, rectangleInsets15);
        int int18 = color6.getRGB();
        jFreeChart3.setBorderPaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-16711936) + "'", int18 == (-16711936));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 500 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 500 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        numberAxis3D0.setRange(0.12d, (double) (byte) 100);
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Range[0.0,1.0]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color1, stroke2);
        boolean boolean5 = valueMarker3.equals((java.lang.Object) 0);
        valueMarker3.setLabel("Other");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener4 = null;
        jFreeChart3.addProgressListener(chartProgressListener4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("ClassContext");
        double double8 = textTitle7.getContentXOffset();
        jFreeChart3.setTitle(textTitle7);
        java.lang.Object obj10 = textTitle7.clone();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        valueMarker1.notifyListeners(markerChangeEvent2);
        java.awt.Stroke stroke4 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleAnchor.LEFT", "ThreadContext");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.LEFT" + "'", str3.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Object obj16 = blockContainer15.clone();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis17.getTickMarkPosition();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) dateAxis17);
        blockContainer15.setPadding((double) 0L, (double) (short) 0, (double) 1L, 2000.0d);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis0.setTimeline(timeline5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D7.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        numberAxis3D7.setRange(range11);
        java.lang.String str13 = range11.toString();
        boolean boolean15 = range11.contains((double) ' ');
        dateAxis0.setRange(range11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke18 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.axis.Timeline timeline19 = dateAxis17.getTimeline();
        dateAxis0.setTimeline(timeline19);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,1.0]" + "'", str13.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(timeline19);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        waferMapPlot2.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        waferMapPlot2.setInsets(rectangleInsets9, false);
        java.awt.Font font14 = null;
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer19 = new org.jfree.chart.text.G2TextMeasurer(graphics2D18);
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, paint15, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer19);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, paint15);
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) '4', (float) 1, 10.0f);
        int int26 = color25.getRGB();
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color1, paint15, color25 };
        java.awt.Stroke[] strokeArray28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        org.jfree.chart.plot.Plot plot46 = numberAxis3D44.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range48 = numberAxis3D47.getRange();
        numberAxis3D44.setRange(range48);
        java.text.NumberFormat numberFormat50 = numberAxis3D44.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis3D44.getTickLabelInsets();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer52);
        java.awt.Stroke stroke54 = xYPlot53.getDomainZeroBaselineStroke();
        java.awt.Color color55 = java.awt.Color.green;
        java.awt.Color color57 = java.awt.Color.green;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color57, stroke58);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) (byte) 10, (double) '4');
        org.jfree.chart.util.UnitType unitType65 = rectangleInsets64.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder66 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color55, stroke58, rectangleInsets64);
        java.awt.Stroke[] strokeArray67 = new java.awt.Stroke[] { stroke54, stroke58 };
        java.awt.Shape[] shapeArray68 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier69 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray27, strokeArray28, strokeArray67, shapeArray68);
        java.lang.Object obj70 = defaultDrawingSupplier69.clone();
        org.jfree.data.xy.XYDataset xYDataset71 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D72 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range73 = numberAxis3D72.getRange();
        org.jfree.chart.plot.Plot plot74 = numberAxis3D72.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D75 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range76 = numberAxis3D75.getRange();
        numberAxis3D72.setRange(range76);
        java.text.NumberFormat numberFormat78 = numberAxis3D72.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = numberAxis3D72.getTickLabelInsets();
        java.awt.Shape shape80 = numberAxis3D72.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D81 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range82 = numberAxis3D81.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer83 = null;
        org.jfree.chart.plot.XYPlot xYPlot84 = new org.jfree.chart.plot.XYPlot(xYDataset71, (org.jfree.chart.axis.ValueAxis) numberAxis3D72, (org.jfree.chart.axis.ValueAxis) numberAxis3D81, xYItemRenderer83);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = null;
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = null;
        java.awt.geom.Point2D point2D89 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D87, rectangleAnchor88);
        xYPlot84.zoomRangeAxes(100.0d, plotRenderingInfo86, point2D89, false);
        org.jfree.chart.axis.AxisLocation axisLocation92 = xYPlot84.getDomainAxisLocation();
        boolean boolean93 = defaultDrawingSupplier69.equals((java.lang.Object) xYPlot84);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-655360) + "'", int26 == (-655360));
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(plot46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(numberFormat50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(unitType65);
        org.junit.Assert.assertNotNull(strokeArray67);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNull(plot74);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNull(numberFormat78);
        org.junit.Assert.assertNotNull(rectangleInsets79);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNotNull(range82);
        org.junit.Assert.assertNotNull(point2D89);
        org.junit.Assert.assertNotNull(axisLocation92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke7 = dateAxis6.getAxisLineStroke();
        dateAxis0.setAxisLineStroke(stroke7);
        dateAxis0.setLabelURL("RectangleAnchor.LEFT");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Stroke stroke3 = ringPlot1.getSectionOutlineStroke((java.lang.Comparable) "Pie 3D Plot");
        ringPlot1.setSectionDepth(0.0d);
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        polarPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        org.jfree.chart.plot.Plot plot6 = numberAxis3D4.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range8 = numberAxis3D7.getRange();
        numberAxis3D4.setRange(range8);
        java.text.NumberFormat numberFormat10 = numberAxis3D4.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D4.getTickLabelInsets();
        java.awt.Shape shape12 = numberAxis3D4.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range14 = numberAxis3D13.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer15);
        java.text.NumberFormat numberFormat17 = numberAxis3D4.getNumberFormatOverride();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        polarPlot0.setAngleLabelsVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        polarPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo22, point2D25);
        boolean boolean27 = polarPlot0.isRangeZoomable();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = null;
        polarPlot0.datasetChanged(datasetChangeEvent28);
        int int30 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        int int25 = xYPlot13.getDatasetCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        xYPlot13.rendererChanged(rendererChangeEvent26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot13.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener4 = null;
        jFreeChart3.addProgressListener(chartProgressListener4);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 255);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable5 = multiplePiePlot4.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder6 = multiplePiePlot4.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        org.jfree.chart.plot.Plot plot11 = numberAxis3D9.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range13 = numberAxis3D12.getRange();
        numberAxis3D9.setRange(range13);
        java.text.NumberFormat numberFormat15 = numberAxis3D9.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis3D9.getTickLabelInsets();
        java.awt.Shape shape17 = numberAxis3D9.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        xYPlot21.zoomRangeAxes(100.0d, plotRenderingInfo23, point2D26, false);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot21.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot21.getRangeAxis(100);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setRangeCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.plot.Plot plot36 = numberAxis3D34.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        numberAxis3D34.setRange(range38);
        java.text.NumberFormat numberFormat40 = numberAxis3D34.getNumberFormatOverride();
        java.text.NumberFormat numberFormat41 = null;
        numberAxis3D34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = null;
        numberAxis3D34.setStandardTickUnits(tickUnitSource43);
        int int45 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D34);
        java.awt.Paint paint46 = numberAxis3D34.getTickLabelPaint();
        jFreeChart7.setBackgroundPaint(paint46);
        multiplePiePlot0.setPieChart(jFreeChart7);
        multiplePiePlot0.setLimit((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder6);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D2.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke6 = dateAxis5.getAxisLineStroke();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis5.getTimeline();
        dateAxis5.setLabelToolTip("ThreadContext");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot11.getRangeAxis((-12517568));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ClassContext");
        java.awt.Font font2 = textFragment1.getFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D2.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        boolean boolean7 = categoryAxis3D2.equals((java.lang.Object) range6);
        numberAxis3D0.setRangeWithMargins(range6, false, false);
        boolean boolean12 = range6.equals((java.lang.Object) 9.0d);
        boolean boolean14 = range6.contains((double) 100.0f);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.lang.String str7 = range5.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, (double) (byte) 1, 1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(1.0d, range12);
        double double18 = range12.constrain(100.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range5, lengthConstraintType8, (double) 0, range12, lengthConstraintType19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint20.toFixedWidth((double) (byte) -1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,1.0]" + "'", str7.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        java.awt.Paint paint3 = piePlot3D0.getShadowPaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        piePlot3D0.setBaseSectionPaint((java.awt.Paint) color4);
        piePlot3D0.setCircular(true, false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot3D0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleLabelPaint();
        java.awt.Paint paint2 = polarPlot0.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0, (double) 1, (double) (-1L), 0.0d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        java.lang.String str6 = unitType5.toString();
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat8);
        java.awt.Paint paint10 = numberAxis3D1.getLabelPaint();
        boolean boolean11 = columnArrangement0.equals((java.lang.Object) paint10);
        boolean boolean13 = columnArrangement0.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.lang.Object obj15 = blockContainer14.clone();
        blockContainer14.setWidth((double) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        boolean boolean20 = blockContainer14.equals((java.lang.Object) rendererState19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        java.text.NumberFormat numberFormat32 = null;
        numberAxis3D25.setNumberFormatOverride(numberFormat32);
        java.awt.Paint paint34 = numberAxis3D25.getLabelPaint();
        boolean boolean35 = columnArrangement24.equals((java.lang.Object) paint34);
        boolean boolean37 = columnArrangement24.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer38 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement24);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.plot.Plot plot42 = numberAxis3D40.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range44 = numberAxis3D43.getRange();
        numberAxis3D40.setRange(range44);
        java.text.NumberFormat numberFormat46 = numberAxis3D40.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = numberAxis3D40.getTickLabelInsets();
        java.awt.Shape shape48 = numberAxis3D40.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range50 = numberAxis3D49.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis3D49, xYItemRenderer51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = null;
        java.awt.geom.Point2D point2D57 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D55, rectangleAnchor56);
        xYPlot52.zoomRangeAxes(100.0d, plotRenderingInfo54, point2D57, false);
        org.jfree.chart.axis.AxisLocation axisLocation60 = xYPlot52.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis62 = xYPlot52.getRangeAxis(100);
        java.awt.Stroke stroke63 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot52.setRangeCrosshairStroke(stroke63);
        org.jfree.chart.axis.AxisLocation axisLocation65 = xYPlot52.getDomainAxisLocation();
        float float66 = xYPlot52.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent67 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot52);
        boolean boolean68 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer38, (java.lang.Object) plotChangeEvent67);
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint70 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double71 = rectangleConstraint70.getWidth();
        org.jfree.chart.util.Size2D size2D72 = blockContainer38.arrange(graphics2D69, rectangleConstraint70);
        java.awt.geom.Rectangle2D rectangle2D73 = blockContainer38.getBounds();
        textTitle22.draw(graphics2D23, rectangle2D73);
        try {
            blockContainer14.draw(graphics2D21, rectangle2D73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(numberFormat46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(point2D57);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNull(valueAxis62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 0.5f + "'", float66 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(size2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener4 = null;
        jFreeChart3.addProgressListener(chartProgressListener4);
        org.jfree.chart.event.ChartProgressListener chartProgressListener6 = null;
        jFreeChart3.addProgressListener(chartProgressListener6);
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        int int27 = xYPlot13.getRangeAxisIndex(valueAxis26);
        java.util.List list28 = xYPlot13.getAnnotations();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range3 = numberAxis3D2.getRange();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D2.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        numberAxis3D2.setRange(range6);
        java.text.NumberFormat numberFormat8 = numberAxis3D2.getNumberFormatOverride();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis3D2.setNumberFormatOverride(numberFormat9);
        java.awt.Paint paint11 = numberAxis3D2.getLabelPaint();
        boolean boolean12 = columnArrangement1.equals((java.lang.Object) paint11);
        boolean boolean14 = columnArrangement1.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.plot.Plot plot19 = numberAxis3D17.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range21 = numberAxis3D20.getRange();
        numberAxis3D17.setRange(range21);
        java.text.NumberFormat numberFormat23 = numberAxis3D17.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis3D17.getTickLabelInsets();
        java.awt.Shape shape25 = numberAxis3D17.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range27 = numberAxis3D26.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        xYPlot29.zoomRangeAxes(100.0d, plotRenderingInfo31, point2D34, false);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot29.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot29.getRangeAxis(100);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot29.setRangeCrosshairStroke(stroke40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = xYPlot29.getDomainAxisLocation();
        float float43 = xYPlot29.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent44 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot29);
        boolean boolean45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer15, (java.lang.Object) plotChangeEvent44);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double48 = rectangleConstraint47.getWidth();
        org.jfree.chart.util.Size2D size2D49 = blockContainer15.arrange(graphics2D46, rectangleConstraint47);
        java.awt.geom.Rectangle2D rectangle2D50 = blockContainer15.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D52 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor51);
        boolean boolean53 = plotOrientation0.equals((java.lang.Object) rectangle2D50);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(numberFormat23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(size2D49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(point2D52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D2.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke6 = dateAxis5.getAxisLineStroke();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis5.getTimeline();
        dateAxis5.setLabelToolTip("ThreadContext");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot11.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.util.SortOrder sortOrder14 = null;
        try {
            categoryPlot11.setRowRenderingOrder(sortOrder14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        java.awt.Paint paint2 = numberAxis3D0.getTickLabelPaint();
        numberAxis3D0.setLabel("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        piePlot3D0.setExplodePercent((java.lang.Comparable) date2, 1.0E-5d);
        java.awt.Stroke stroke6 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 0.0d);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.plot.Plot plot10 = numberAxis3D8.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        numberAxis3D8.setRange(range12);
        java.text.NumberFormat numberFormat14 = numberAxis3D8.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D8.getTickLabelInsets();
        java.awt.Shape shape16 = numberAxis3D8.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        xYPlot20.zoomRangeAxes(100.0d, plotRenderingInfo22, point2D25, false);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot20.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getRangeAxis(100);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setRangeCrosshairStroke(stroke31);
        piePlot3D0.setLabelLinkStroke(stroke31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        xYPlot13.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        xYPlot37.zoomRangeAxes(100.0d, plotRenderingInfo39, point2D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot37.getDomainAxisLocation();
        xYPlot13.setRangeAxisLocation(axisLocation45);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        xYPlot13.setRenderer(xYItemRenderer47);
        double double49 = xYPlot13.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = null;
        polarPlot27.datasetChanged(datasetChangeEvent28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        java.text.NumberFormat numberFormat44 = numberAxis3D31.getNumberFormatOverride();
        polarPlot27.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        java.awt.Paint paint46 = polarPlot27.getAngleGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = null;
        java.awt.geom.Point2D point2D52 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor51);
        polarPlot27.zoomDomainAxes(10.0d, (double) 2, plotRenderingInfo49, point2D52);
        java.awt.Paint paint54 = polarPlot27.getOutlinePaint();
        xYPlot13.setParent((org.jfree.chart.plot.Plot) polarPlot27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = null;
        java.awt.geom.Point2D point2D61 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D59, rectangleAnchor60);
        polarPlot27.zoomDomainAxes((double) '4', 45.0d, plotRenderingInfo58, point2D61);
        int int63 = polarPlot27.getSeriesCount();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNull(numberFormat44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(point2D52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(point2D61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        java.awt.Paint paint3 = piePlot3D0.getLabelBackgroundPaint();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot4.datasetChanged(datasetChangeEvent5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.plot.Plot plot10 = numberAxis3D8.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        numberAxis3D8.setRange(range12);
        java.text.NumberFormat numberFormat14 = numberAxis3D8.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D8.getTickLabelInsets();
        java.awt.Shape shape16 = numberAxis3D8.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer19);
        java.text.NumberFormat numberFormat21 = numberAxis3D8.getNumberFormatOverride();
        polarPlot4.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D8);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot4.setAngleGridlineStroke(stroke23);
        piePlot3D0.setBaseSectionOutlineStroke(stroke23);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.lang.String str7 = range5.toString();
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) str7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment9, 10.0d, (double) 1L);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,1.0]" + "'", str7.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot13.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot13.setRenderers(xYItemRendererArray23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        int int26 = xYPlot13.indexOf(xYDataset25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = xYPlot13.getFixedDomainAxisSpace();
        xYPlot13.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace30 = xYPlot13.getFixedRangeAxisSpace();
        boolean boolean31 = xYPlot13.isRangeZoomable();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        piePlot3D0.setSimpleLabels(true);
        piePlot3D0.setSectionOutlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.plot.Plot plot10 = numberAxis3D8.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        numberAxis3D8.setRange(range12);
        java.text.NumberFormat numberFormat14 = numberAxis3D8.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D8.getTickLabelInsets();
        java.awt.Shape shape16 = numberAxis3D8.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer19);
        boolean boolean21 = xYPlot20.isDomainZeroBaselineVisible();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot20.setDomainTickBandPaint((java.awt.Paint) color22);
        java.awt.Stroke stroke24 = xYPlot20.getRangeZeroBaselineStroke();
        piePlot3D0.setBaseSectionOutlineStroke(stroke24);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainZeroBaselineVisible();
        int int15 = xYPlot13.getWeight();
        xYPlot13.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot13.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(axisSpace18);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator1);
        java.awt.Stroke stroke3 = piePlot3D0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        int int25 = xYPlot13.getDatasetCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = xYPlot13.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        org.jfree.chart.plot.Plot plot5 = numberAxis3D3.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        numberAxis3D3.setRange(range7);
        java.text.NumberFormat numberFormat9 = numberAxis3D3.getNumberFormatOverride();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis3D3.setNumberFormatOverride(numberFormat10);
        java.awt.Paint paint12 = numberAxis3D3.getLabelPaint();
        boolean boolean13 = columnArrangement2.equals((java.lang.Object) paint12);
        boolean boolean15 = columnArrangement2.equals((java.lang.Object) "WMAP_Plot");
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.chart.plot.Plot plot20 = numberAxis3D18.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        numberAxis3D18.setRange(range22);
        java.text.NumberFormat numberFormat24 = numberAxis3D18.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis3D18.getTickLabelInsets();
        java.awt.Shape shape26 = numberAxis3D18.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range28 = numberAxis3D27.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, xYItemRenderer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot30.zoomRangeAxes(100.0d, plotRenderingInfo32, point2D35, false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot30.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis40 = xYPlot30.getRangeAxis(100);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot30.setRangeCrosshairStroke(stroke41);
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot30.getDomainAxisLocation();
        float float44 = xYPlot30.getBackgroundImageAlpha();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent45 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot30);
        boolean boolean46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) blockContainer16, (java.lang.Object) plotChangeEvent45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double49 = rectangleConstraint48.getWidth();
        org.jfree.chart.util.Size2D size2D50 = blockContainer16.arrange(graphics2D47, rectangleConstraint48);
        java.awt.geom.Rectangle2D rectangle2D51 = blockContainer16.getBounds();
        textTitle0.draw(graphics2D1, rectangle2D51);
        boolean boolean53 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(numberFormat24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.5f + "'", float44 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range42 = numberAxis3D41.getRange();
        org.jfree.chart.plot.Plot plot43 = numberAxis3D41.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range45 = numberAxis3D44.getRange();
        numberAxis3D41.setRange(range45);
        java.text.NumberFormat numberFormat47 = numberAxis3D41.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = numberAxis3D41.getTickLabelInsets();
        java.awt.Shape shape49 = numberAxis3D41.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range51 = numberAxis3D50.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis3D50, xYItemRenderer52);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D50);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = xYPlot13.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(plot43);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(numberFormat47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = null;
        polarPlot27.datasetChanged(datasetChangeEvent28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range32 = numberAxis3D31.getRange();
        org.jfree.chart.plot.Plot plot33 = numberAxis3D31.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        numberAxis3D31.setRange(range35);
        java.text.NumberFormat numberFormat37 = numberAxis3D31.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis3D31.getTickLabelInsets();
        java.awt.Shape shape39 = numberAxis3D31.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range41 = numberAxis3D40.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer42);
        java.text.NumberFormat numberFormat44 = numberAxis3D31.getNumberFormatOverride();
        polarPlot27.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        java.awt.Paint paint46 = polarPlot27.getAngleGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = null;
        java.awt.geom.Point2D point2D52 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor51);
        polarPlot27.zoomDomainAxes(10.0d, (double) 2, plotRenderingInfo49, point2D52);
        java.awt.Paint paint54 = polarPlot27.getOutlinePaint();
        xYPlot13.setParent((org.jfree.chart.plot.Plot) polarPlot27);
        java.awt.Color color57 = java.awt.Color.green;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color57, stroke58);
        java.awt.Color color61 = java.awt.Color.green;
        java.awt.Stroke stroke62 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color61, stroke62);
        valueMarker59.setStroke(stroke62);
        org.jfree.chart.ui.Library library69 = new org.jfree.chart.ui.Library("hi!", "ClassContext", "", "ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType71 = rectangleInsets70.getUnitType();
        boolean boolean72 = library69.equals((java.lang.Object) rectangleInsets70);
        valueMarker59.setLabelOffset(rectangleInsets70);
        java.awt.Font font74 = valueMarker59.getLabelFont();
        polarPlot27.setNoDataMessageFont(font74);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNull(numberFormat44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(point2D52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(unitType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(font74);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range15 = numberAxis3D14.getRange();
        org.jfree.chart.plot.Plot plot16 = numberAxis3D14.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        numberAxis3D14.setRange(range18);
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        double double23 = numberAxis3D21.getUpperBound();
        double double24 = numberAxis3D21.getFixedAutoRange();
        numberAxis3D21.setPositiveArrowVisible(false);
        org.jfree.data.Range range27 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        boolean boolean28 = numberAxis3D21.isNegativeArrowVisible();
        numberAxis3D21.setAutoRangeMinimumSize((double) (short) 100, false);
        numberAxis3D21.setAutoRangeMinimumSize((double) 'a');
        java.awt.Paint paint34 = null;
        try {
            numberAxis3D21.setLabelPaint(paint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(plot16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot0.setDataset(waferMapDataset3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        waferMapPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        waferMapPlot0.setInsets(rectangleInsets7, false);
        java.awt.Font font12 = null;
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer17 = new org.jfree.chart.text.G2TextMeasurer(graphics2D16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, paint13, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer17);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, paint13);
        double double21 = rectangleInsets7.trimHeight((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 33.0d + "'", double21 == 33.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        double double21 = xYPlot13.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22, true);
        java.awt.Paint paint25 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint26 = xYPlot13.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        xYPlot13.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint31 = numberAxis3D30.getTickMarkPaint();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        xYPlot13.setDataset((int) (short) 10, xYDataset34);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.lang.String str7 = range5.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, (double) (byte) 1, 1.0E-5d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(1.0d, range12);
        double double18 = range12.constrain(100.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range5, lengthConstraintType8, (double) 0, range12, lengthConstraintType19);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = rectangleConstraint20.getHeightConstraintType();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,1.0]" + "'", str7.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot13.setRenderer(xYItemRenderer24);
        xYPlot13.clearRangeMarkers();
        int int27 = xYPlot13.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D1.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        boolean boolean6 = categoryAxis3D1.equals((java.lang.Object) range5);
        categoryAxis3D1.setUpperMargin((double) '#');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D10.setLabelAngle(0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = categoryAxis3D10.getCategoryLabelPositions();
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions13);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis3D1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        java.awt.Color color29 = java.awt.Color.green;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color29, stroke30);
        java.awt.Color color33 = java.awt.Color.green;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color33, stroke34);
        valueMarker31.setStroke(stroke34);
        valueMarker31.setValue(10.0d);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot13.getDomainMarkers(layer40);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot13);
        java.awt.Paint paint43 = legendTitle42.getItemPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle42.setLegendItemGraphicAnchor(rectangleAnchor44);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke24);
        xYPlot13.clearRangeMarkers((int) 'a');
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot13.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot13.render(graphics2D29, rectangle2D30, 255, plotRenderingInfo32, crosshairState33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot13.getLegendItems();
        org.jfree.chart.LegendItem legendItem36 = null;
        legendItemCollection35.add(legendItem36);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(legendItemCollection35);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        dateAxis0.setRange((double) 0.0f, (double) 10.0f);
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        boolean boolean6 = dateAxis0.isAutoRange();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range9 = numberAxis3D8.getRange();
        org.jfree.chart.plot.Plot plot10 = numberAxis3D8.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range12 = numberAxis3D11.getRange();
        numberAxis3D8.setRange(range12);
        java.text.NumberFormat numberFormat14 = numberAxis3D8.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D8.getTickLabelInsets();
        java.awt.Shape shape16 = numberAxis3D8.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range18 = numberAxis3D17.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        xYPlot20.zoomRangeAxes(100.0d, plotRenderingInfo22, point2D25, false);
        double double28 = xYPlot20.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace29, true);
        java.awt.Paint paint32 = xYPlot20.getRangeCrosshairPaint();
        java.awt.Paint paint33 = xYPlot20.getRangeZeroBaselinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = null;
        xYPlot20.datasetChanged(datasetChangeEvent34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("ClassContext");
        java.awt.Paint paint38 = numberAxis3D37.getTickMarkPaint();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D37);
        boolean boolean40 = xYPlot20.isRangeZoomable();
        boolean boolean41 = dateAxis0.equals((java.lang.Object) xYPlot20);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        java.text.NumberFormat numberFormat14 = numberAxis3D1.getNumberFormatOverride();
        numberAxis3D1.setLabelToolTip("WMAP_Plot");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot17 = new org.jfree.chart.plot.WaferMapPlot();
        waferMapPlot17.setBackgroundImageAlpha(0.0f);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot17);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(numberFormat14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D2.setLabelAngle(0.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range6 = numberAxis3D5.getRange();
        boolean boolean7 = categoryAxis3D2.equals((java.lang.Object) range6);
        numberAxis3D0.setRangeWithMargins(range6, false, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset11, valueAxis12, polarItemRenderer13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range16 = numberAxis3D15.getRange();
        double double17 = numberAxis3D15.getUpperBound();
        org.jfree.data.Range range18 = polarPlot14.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D15);
        java.awt.Font font19 = polarPlot14.getAngleLabelFont();
        numberAxis3D0.setLabelFont(font19);
        java.text.NumberFormat numberFormat21 = numberAxis3D0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(numberFormat21);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, 100.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock7.draw(graphics2D8, (float) (short) 1, (float) (byte) 1, textBlockAnchor11, (float) (short) 0, (float) (byte) -1, 0.2d);
        java.util.List list16 = textBlock7.getLines();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainZeroBaselineVisible();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot13);
        jFreeChart17.setBorderVisible(true);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range22 = numberAxis3D21.getRange();
        org.jfree.chart.plot.Plot plot23 = numberAxis3D21.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range25 = numberAxis3D24.getRange();
        numberAxis3D21.setRange(range25);
        java.text.NumberFormat numberFormat27 = numberAxis3D21.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis3D21.getTickLabelInsets();
        java.awt.Shape shape29 = numberAxis3D21.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range31 = numberAxis3D30.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, xYItemRenderer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        xYPlot33.zoomRangeAxes(100.0d, plotRenderingInfo35, point2D38, false);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot33.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot33.getRangeAxis(100);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot33.setRangeCrosshairStroke(stroke44);
        xYPlot33.clearRangeMarkers((int) 'a');
        java.awt.Color color49 = java.awt.Color.green;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color49, stroke50);
        java.awt.Color color53 = java.awt.Color.green;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color53, stroke54);
        valueMarker51.setStroke(stroke54);
        valueMarker51.setValue(10.0d);
        xYPlot33.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker51);
        org.jfree.chart.util.Layer layer60 = null;
        java.util.Collection collection61 = xYPlot33.getDomainMarkers(layer60);
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot33);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range65 = numberAxis3D64.getRange();
        org.jfree.chart.plot.Plot plot66 = numberAxis3D64.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D67 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range68 = numberAxis3D67.getRange();
        numberAxis3D64.setRange(range68);
        java.text.NumberFormat numberFormat70 = numberAxis3D64.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = numberAxis3D64.getTickLabelInsets();
        java.awt.Shape shape72 = numberAxis3D64.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D73 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range74 = numberAxis3D73.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer75 = null;
        org.jfree.chart.plot.XYPlot xYPlot76 = new org.jfree.chart.plot.XYPlot(xYDataset63, (org.jfree.chart.axis.ValueAxis) numberAxis3D64, (org.jfree.chart.axis.ValueAxis) numberAxis3D73, xYItemRenderer75);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D77 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range78 = numberAxis3D77.getRange();
        org.jfree.chart.plot.Plot plot79 = numberAxis3D77.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D80 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range81 = numberAxis3D80.getRange();
        numberAxis3D77.setRange(range81);
        xYPlot76.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D77);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D84 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range85 = numberAxis3D84.getRange();
        double double86 = numberAxis3D84.getUpperBound();
        double double87 = numberAxis3D84.getFixedAutoRange();
        numberAxis3D84.setPositiveArrowVisible(false);
        org.jfree.data.Range range90 = xYPlot76.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D84);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D91 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range92 = numberAxis3D91.getRange();
        double double93 = numberAxis3D91.getUpperBound();
        java.awt.Font font94 = numberAxis3D91.getLabelFont();
        numberAxis3D84.setLabelFont(font94);
        legendTitle62.setItemFont(font94);
        java.lang.Object obj97 = legendTitle62.clone();
        jFreeChart17.addLegend(legendTitle62);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNull(plot66);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertNull(numberFormat70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNull(plot79);
        org.junit.Assert.assertNotNull(range81);
        org.junit.Assert.assertNotNull(range85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.0d + "'", double86 == 1.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNull(range90);
        org.junit.Assert.assertNotNull(range92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.0d + "'", double93 == 1.0d);
        org.junit.Assert.assertNotNull(font94);
        org.junit.Assert.assertNotNull(obj97);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 255);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable5 = multiplePiePlot4.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder6 = multiplePiePlot4.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot4.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range10 = numberAxis3D9.getRange();
        org.jfree.chart.plot.Plot plot11 = numberAxis3D9.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range13 = numberAxis3D12.getRange();
        numberAxis3D9.setRange(range13);
        java.text.NumberFormat numberFormat15 = numberAxis3D9.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis3D9.getTickLabelInsets();
        java.awt.Shape shape17 = numberAxis3D9.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range19 = numberAxis3D18.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        xYPlot21.zoomRangeAxes(100.0d, plotRenderingInfo23, point2D26, false);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot21.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot21.getRangeAxis(100);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setRangeCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.plot.Plot plot36 = numberAxis3D34.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range38 = numberAxis3D37.getRange();
        numberAxis3D34.setRange(range38);
        java.text.NumberFormat numberFormat40 = numberAxis3D34.getNumberFormatOverride();
        java.text.NumberFormat numberFormat41 = null;
        numberAxis3D34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = null;
        numberAxis3D34.setStandardTickUnits(tickUnitSource43);
        int int45 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D34);
        java.awt.Paint paint46 = numberAxis3D34.getTickLabelPaint();
        jFreeChart7.setBackgroundPaint(paint46);
        multiplePiePlot0.setPieChart(jFreeChart7);
        java.awt.Stroke stroke49 = jFreeChart7.getBorderStroke();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder6);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.jfree.chart.plot.Plot plot3 = numberAxis3D1.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range5 = numberAxis3D4.getRange();
        numberAxis3D1.setRange(range5);
        java.text.NumberFormat numberFormat7 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range11 = numberAxis3D10.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot13.zoomRangeAxes(100.0d, plotRenderingInfo15, point2D18, false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot13.getRangeAxis(100);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        xYPlot37.zoomRangeAxes(100.0d, plotRenderingInfo39, point2D42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot37.getDomainAxisLocation();
        xYPlot13.setDomainAxisLocation(axisLocation45, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = null;
        xYPlot13.rendererChanged(rendererChangeEvent48);
        java.awt.Paint paint50 = xYPlot13.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range4 = numberAxis3D3.getRange();
        org.jfree.chart.plot.Plot plot5 = numberAxis3D3.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range7 = numberAxis3D6.getRange();
        numberAxis3D3.setRange(range7);
        java.text.NumberFormat numberFormat9 = numberAxis3D3.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3D3.getTickLabelInsets();
        java.awt.Shape shape11 = numberAxis3D3.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range13 = numberAxis3D12.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = null;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        xYPlot15.zoomRangeAxes(100.0d, plotRenderingInfo17, point2D20, false);
        double double23 = xYPlot15.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range26 = numberAxis3D25.getRange();
        org.jfree.chart.plot.Plot plot27 = numberAxis3D25.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range29 = numberAxis3D28.getRange();
        numberAxis3D25.setRange(range29);
        java.text.NumberFormat numberFormat31 = numberAxis3D25.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis3D25.getTickLabelInsets();
        java.awt.Shape shape33 = numberAxis3D25.getRightArrow();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range35 = numberAxis3D34.getRange();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range39 = numberAxis3D38.getRange();
        org.jfree.chart.plot.Plot plot40 = numberAxis3D38.getPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range42 = numberAxis3D41.getRange();
        numberAxis3D38.setRange(range42);
        xYPlot37.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D38);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.Range range46 = numberAxis3D45.getRange();
        double double47 = numberAxis3D45.getUpperBound();
        double double48 = numberAxis3D45.getFixedAutoRange();
        numberAxis3D45.setPositiveArrowVisible(false);
        org.jfree.data.Range range51 = xYPlot37.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D45);
        boolean boolean52 = numberAxis3D45.isNegativeArrowVisible();
        numberAxis3D45.setAutoRangeMinimumSize((double) (short) 100, false);
        org.jfree.data.Range range56 = xYPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D45);
        org.jfree.data.time.DateRange dateRange57 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis3D45.setRangeWithMargins((org.jfree.data.Range) dateRange57, true, true);
        int int61 = objectList0.indexOf((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(numberFormat31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(plot40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(range56);
        org.junit.Assert.assertNotNull(dateRange57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelLinkPaint();
        java.lang.String str2 = piePlot3D0.getPlotType();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot3D0.setDataset(pieDataset3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("ClassContext");
        categoryAxis3D2.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke6 = dateAxis5.getAxisLineStroke();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis5.getTimeline();
        dateAxis5.setLabelToolTip("ThreadContext");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot11.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }
}

