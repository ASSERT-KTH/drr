import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.setDescription("");
//        int int8 = timePeriodValues5.getMinMiddleIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        java.util.Date date12 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        int int15 = year13.compareTo((java.lang.Object) 100.0d);
//        int int17 = year13.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year13);
//        timePeriodValues18.setDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues18.addPropertyChangeListener(propertyChangeListener21);
//        int int23 = timePeriodValues18.getMinStartIndex();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 1L);
//        timePeriodValues18.add(timePeriodValue28);
//        boolean boolean30 = simpleTimePeriod11.equals((java.lang.Object) timePeriodValues18);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
//        int int34 = day31.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day31.previous();
//        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day31, (double) 0);
//        int int38 = day31.getMonth();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) (-1));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 13 + "'", int34 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues5.createCopy((int) (short) -1, 6);
        timePeriodValues8.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues8.clone();
        java.lang.Object obj11 = timePeriodValues8.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 13);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 13L + "'", long4 == 13L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getMonth();
        java.util.Date date3 = day1.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        int int12 = timePeriodValues5.getMinStartIndex();
        java.lang.String str13 = timePeriodValues5.getDomainDescription();
        int int14 = timePeriodValues5.getMaxStartIndex();
        timePeriodValues5.setNotify(true);
        int int17 = timePeriodValues5.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        java.lang.String str6 = timePeriodValues5.getRangeDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 1);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) (short) 1);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 4L);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod6, (double) 1530561599999L);
        int int9 = year0.compareTo((java.lang.Object) timePeriodValue8);
        timePeriodValue8.setValue((java.lang.Number) 1577865599999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, 7, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        timePeriodValues5.setNotify(true);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = timePeriodValues5.getDataItem(0);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues5.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timePeriodValue15);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener6);
//        int int8 = timePeriodValues5.getMinEndIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (byte) 1);
//        int int13 = day9.getDayOfMonth();
//        int int14 = day9.getYear();
//        java.util.Date date15 = day9.getStart();
//        int int16 = day9.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        java.lang.String str10 = timePeriodValue8.toString();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
        long long12 = simpleTimePeriod2.getEndMillis();
        long long13 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5L + "'", long13 == 5L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue4.getPeriod();
        java.lang.String str6 = timePeriodValue4.toString();
        java.lang.Object obj7 = timePeriodValue4.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(timePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,12]" + "'", str6.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertNotNull(obj7);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        int int22 = timePeriodValues19.getMaxStartIndex();
//        timePeriodValues19.setDescription("");
//        timePeriodValues19.setNotify(false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) 100.0d);
        int int15 = year11.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        boolean boolean17 = timePeriodValues5.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        int int22 = timePeriodValues19.getMaxStartIndex();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        int int25 = year23.compareTo((java.lang.Object) 100.0d);
//        int int27 = year23.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year23);
//        timePeriodValues28.setDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timePeriodValues28.addPropertyChangeListener(propertyChangeListener31);
//        int int33 = timePeriodValues28.getMinStartIndex();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        int int36 = year34.compareTo((java.lang.Object) 100.0d);
//        int int38 = year34.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year34, (double) '#');
//        timePeriodValues19.setKey((java.lang.Comparable) year34);
//        long long43 = year34.getFirstMillisecond();
//        int int44 = year34.getYear();
//        long long45 = year34.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        java.lang.Object obj22 = timePeriodValues19.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timePeriodValues19.addChangeListener(seriesChangeListener23);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertNotNull(obj22);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long1, "2019", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues4.isEmpty();
//        try {
//            timePeriodValues4.update(0, (java.lang.Number) 1546329600000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMinStartIndex();
        int int9 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        timePeriodValues5.setKey((java.lang.Comparable) "Value");
//        timePeriodValues5.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener11);
//        int int13 = timePeriodValues5.getMaxStartIndex();
//        boolean boolean14 = timePeriodValues5.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues5.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        int int20 = day17.getDayOfMonth();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long26 = simpleTimePeriod25.getEndMillis();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValue31.getPeriod();
//        java.lang.String str33 = timePeriodValue31.toString();
//        boolean boolean34 = simpleTimePeriod25.equals((java.lang.Object) timePeriodValue31);
//        boolean boolean36 = simpleTimePeriod25.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getLastMillisecond();
//        int int39 = day37.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int39, "", "13-June-2019");
//        boolean boolean43 = simpleTimePeriod25.equals((java.lang.Object) timePeriodValues42);
//        long long44 = simpleTimePeriod25.getEndMillis();
//        java.util.Date date45 = simpleTimePeriod25.getEnd();
//        java.util.Date date46 = simpleTimePeriod25.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date46);
//        int int48 = day17.compareTo((java.lang.Object) date46);
//        int int49 = day17.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(timePeriod32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,12]" + "'", str33.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560495599999L + "'", long38 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 5L + "'", long44 == 5L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.String str11 = timePeriodValues5.getDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long15 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        java.lang.String str22 = timePeriodValue20.toString();
        boolean boolean23 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValue20);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 5L);
        int int26 = timePeriodValues5.getMaxMiddleIndex();
        timePeriodValues5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,12]" + "'", str22.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 2019, 13L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        int int8 = timePeriodValues5.getMinMiddleIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) 100.0d);
        int int13 = year9.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        timePeriodValues14.fireSeriesChanged();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod17, (java.lang.Number) (byte) -1);
        timePeriodValues14.add(timePeriodValue19);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue19.getPeriod();
        timePeriodValues5.add(timePeriodValue19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (-1.0d));
        boolean boolean30 = timePeriodValue19.equals((java.lang.Object) timePeriodValue29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.String str11 = timePeriodValues5.getDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long15 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        java.lang.String str22 = timePeriodValue20.toString();
        boolean boolean23 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValue20);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 5L);
        long long26 = simpleTimePeriod14.getStartMillis();
        java.util.Date date27 = simpleTimePeriod14.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,12]" + "'", str22.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 4L + "'", long26 == 4L);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,0.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
//        java.lang.String str9 = timePeriodValue7.toString();
//        int int10 = day0.compareTo((java.lang.Object) str9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        long long13 = regularTimePeriod12.getMiddleMillisecond();
//        java.util.Date date14 = regularTimePeriod12.getEnd();
//        int int15 = day0.compareTo((java.lang.Object) date14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(timePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,12]" + "'", str9.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1530561599999L + "'", long13 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMaxStartIndex();
        boolean boolean7 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Value");
//        boolean boolean8 = timePeriodValues5.equals((java.lang.Object) "org.jfree.data.general.SeriesException: Value");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener9);
//        java.lang.Object obj11 = timePeriodValues5.clone();
//        java.lang.String str12 = timePeriodValues5.getDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNull(str12);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        java.lang.String str6 = year0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        int int10 = day8.getMonth();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 0.0d);
//        int int13 = day8.getMonth();
//        java.util.Calendar calendar14 = null;
//        try {
//            day8.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        java.lang.String str10 = timePeriodValue8.toString();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) (short) 100);
        java.lang.Object obj16 = null;
        boolean boolean17 = timePeriodValue15.equals(obj16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        int int8 = timePeriodValues5.getMinMiddleIndex();
        timePeriodValues5.setNotify(false);
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        java.util.Date date14 = day12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.util.Date date19 = day17.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14);
        boolean boolean22 = timePeriodValues5.equals((java.lang.Object) day21);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues5.createCopy(7, (-1));
        int int26 = timePeriodValues25.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getDayOfMonth();
//        java.lang.Number number4 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number4);
//        long long6 = day0.getSerialIndex();
//        int int7 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        java.lang.String str10 = timePeriodValue8.toString();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
        long long14 = simpleTimePeriod2.getEndMillis();
        long long15 = simpleTimePeriod2.getEndMillis();
        java.util.Date date16 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, 3, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        boolean boolean6 = timePeriodValues3.getNotify();
//        int int7 = timePeriodValues3.getMinStartIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getMonth();
//        java.util.Date date3 = day1.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        java.util.Date date8 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int13 = year11.compareTo((java.lang.Object) 1L);
//        java.util.Date date14 = year11.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.previous();
//        java.lang.Class<?> wildcardClass18 = regularTimePeriod17.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
//        long long22 = regularTimePeriod21.getMiddleMillisecond();
//        java.util.Date date23 = regularTimePeriod21.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date23, timeZone24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date14, timeZone24);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date3, timeZone24);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        int int30 = year28.compareTo((java.lang.Object) 100.0d);
//        int int32 = year28.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year28.previous();
//        java.lang.String str34 = year28.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        long long37 = day36.getLastMillisecond();
//        int int38 = day36.getMonth();
//        timePeriodValues35.add((org.jfree.data.time.TimePeriod) day36, (java.lang.Number) 0.0d);
//        int int41 = day36.getMonth();
//        java.util.Date date42 = day36.getEnd();
//        int int43 = year27.compareTo((java.lang.Object) date42);
//        long long44 = year27.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1530561599999L + "'", long22 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560495599999L + "'", long37 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1562097599999L + "'", long44 == 1562097599999L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int7 = year5.compareTo((java.lang.Object) 100.0d);
        int int8 = year5.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) int8);
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.Date date17 = year16.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod18, (java.lang.Number) 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        int int8 = year0.compareTo((java.lang.Object) day6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
        java.lang.String str10 = year0.toString();
        java.lang.String str11 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.setDescription("");
//        int int8 = timePeriodValues5.getMinMiddleIndex();
//        timePeriodValues5.setNotify(false);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        java.util.Date date14 = day12.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getMonth();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14);
//        boolean boolean22 = timePeriodValues5.equals((java.lang.Object) day21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues5.createCopy(7, (-1));
//        int int26 = timePeriodValues25.getItemCount();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        int int29 = year27.compareTo((java.lang.Object) 100.0d);
//        int int31 = year27.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year27);
//        timePeriodValues32.fireSeriesChanged();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) (byte) -1);
//        timePeriodValues32.add(timePeriodValue37);
//        int int39 = timePeriodValues32.getMinEndIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long43 = simpleTimePeriod42.getEndMillis();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        long long45 = year44.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year44.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year44, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod49 = timePeriodValue48.getPeriod();
//        java.lang.String str50 = timePeriodValue48.toString();
//        boolean boolean51 = simpleTimePeriod42.equals((java.lang.Object) timePeriodValue48);
//        timePeriodValues32.add(timePeriodValue48);
//        timePeriodValues25.add(timePeriodValue48);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        long long55 = day54.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day54.next();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        int int59 = year57.compareTo((java.lang.Object) 100.0d);
//        int int61 = year57.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year57.previous();
//        java.lang.String str63 = year57.toString();
//        int int64 = day54.compareTo((java.lang.Object) year57);
//        int int65 = day54.getYear();
//        java.lang.Object obj66 = null;
//        int int67 = day54.compareTo(obj66);
//        org.jfree.data.time.SerialDate serialDate68 = day54.getSerialDate();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(serialDate68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(serialDate68);
//        boolean boolean71 = timePeriodValue48.equals((java.lang.Object) day70);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 5L + "'", long43 == 5L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1562097599999L + "'", long45 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(timePeriod49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "TimePeriodValue[2019,12]" + "'", str50.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43629L + "'", long55 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2019" + "'", str63.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setNotify(false);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int28 = timePeriodValues27.getMaxStartIndex();
//        boolean boolean30 = timePeriodValues27.equals((java.lang.Object) 10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timePeriodValues27.removeChangeListener(seriesChangeListener31);
//        boolean boolean33 = timePeriodValues27.isEmpty();
//        boolean boolean34 = timePeriodValues19.equals((java.lang.Object) boolean33);
//        java.lang.Comparable comparable35 = timePeriodValues19.getKey();
//        int int36 = timePeriodValues19.getMinEndIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timePeriodValues19.addChangeListener(seriesChangeListener37);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 6 + "'", comparable35.equals(6));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        timePeriodValues5.setKey((java.lang.Comparable) "Value");
        timePeriodValues5.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues5.getMaxStartIndex();
        boolean boolean14 = timePeriodValues5.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        long long27 = regularTimePeriod26.getMiddleMillisecond();
        java.util.Date date28 = regularTimePeriod26.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        int int32 = day31.getMonth();
        java.util.Date date33 = day31.getStart();
        int int34 = day31.getMonth();
        java.util.Date date35 = day31.getStart();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date35, timeZone36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date19, date35);
        timePeriodValues5.setKey((java.lang.Comparable) date19);
        java.lang.Object obj40 = timePeriodValues5.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 5L + "'", long18 == 5L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1530561599999L + "'", long27 == 1530561599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(obj40);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        timePeriodValues5.setKey((java.lang.Comparable) "Value");
//        timePeriodValues5.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener11);
//        int int13 = timePeriodValues5.getMaxStartIndex();
//        boolean boolean14 = timePeriodValues5.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues5.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        int int20 = day17.getDayOfMonth();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long26 = simpleTimePeriod25.getEndMillis();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValue31.getPeriod();
//        java.lang.String str33 = timePeriodValue31.toString();
//        boolean boolean34 = simpleTimePeriod25.equals((java.lang.Object) timePeriodValue31);
//        boolean boolean36 = simpleTimePeriod25.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getLastMillisecond();
//        int int39 = day37.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int39, "", "13-June-2019");
//        boolean boolean43 = simpleTimePeriod25.equals((java.lang.Object) timePeriodValues42);
//        long long44 = simpleTimePeriod25.getEndMillis();
//        java.util.Date date45 = simpleTimePeriod25.getEnd();
//        java.util.Date date46 = simpleTimePeriod25.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date46);
//        int int48 = day17.compareTo((java.lang.Object) date46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int53 = timePeriodValues52.getMaxStartIndex();
//        boolean boolean55 = timePeriodValues52.equals((java.lang.Object) 10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
//        timePeriodValues52.removeChangeListener(seriesChangeListener56);
//        boolean boolean58 = timePeriodValues52.isEmpty();
//        boolean boolean59 = timePeriodValues52.isEmpty();
//        boolean boolean60 = day17.equals((java.lang.Object) timePeriodValues52);
//        int int61 = day17.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(timePeriod32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,12]" + "'", str33.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560495599999L + "'", long38 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 5L + "'", long44 == 5L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod22, (java.lang.Number) (byte) -1);
//        java.lang.String str25 = timePeriodValue24.toString();
//        java.lang.Number number26 = timePeriodValue24.getValue();
//        timePeriodValues19.add(timePeriodValue24);
//        java.lang.Object obj28 = timePeriodValues19.clone();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[2018,-1]" + "'", str25.equals("TimePeriodValue[2018,-1]"));
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) -1 + "'", number26.equals((byte) -1));
//        org.junit.Assert.assertNotNull(obj28);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = simpleTimePeriod2.equals(obj21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) (byte) -1);
//        boolean boolean30 = year23.equals((java.lang.Object) timePeriodValue29);
//        java.lang.String str31 = year23.toString();
//        long long32 = year23.getLastMillisecond();
//        boolean boolean33 = simpleTimePeriod2.equals((java.lang.Object) year23);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        int int36 = year34.compareTo((java.lang.Object) 100.0d);
//        int int38 = year34.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year34);
//        timePeriodValues39.setDescription("");
//        boolean boolean42 = timePeriodValues39.getNotify();
//        boolean boolean43 = year23.equals((java.lang.Object) timePeriodValues39);
//        java.lang.String str44 = year23.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
//        timePeriodValues5.add(timePeriodValue10);
//        int int12 = timePeriodValues5.getMaxMiddleIndex();
//        java.lang.String str13 = timePeriodValues5.getDomainDescription();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        boolean boolean17 = timePeriodValues5.equals((java.lang.Object) regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
//        timePeriodValues5.add(timePeriodValue10);
//        int int12 = timePeriodValues5.getMaxMiddleIndex();
//        java.lang.String str13 = timePeriodValues5.getDomainDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener14);
//        timePeriodValues5.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2018,-1]");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long21 = simpleTimePeriod20.getEndMillis();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValue26.getPeriod();
//        java.lang.String str28 = timePeriodValue26.toString();
//        boolean boolean29 = simpleTimePeriod20.equals((java.lang.Object) timePeriodValue26);
//        boolean boolean31 = simpleTimePeriod20.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        int int34 = day32.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int34, "", "13-June-2019");
//        boolean boolean38 = simpleTimePeriod20.equals((java.lang.Object) timePeriodValues37);
//        java.lang.String str39 = timePeriodValues37.getDomainDescription();
//        timePeriodValues37.setNotify(false);
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int46 = timePeriodValues45.getMaxStartIndex();
//        boolean boolean48 = timePeriodValues45.equals((java.lang.Object) 10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
//        timePeriodValues45.removeChangeListener(seriesChangeListener49);
//        boolean boolean51 = timePeriodValues45.isEmpty();
//        boolean boolean52 = timePeriodValues37.equals((java.lang.Object) boolean51);
//        boolean boolean53 = timePeriodValues5.equals((java.lang.Object) boolean52);
//        try {
//            org.jfree.data.time.TimePeriodValues timePeriodValues56 = timePeriodValues5.createCopy((int) (byte) 10, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 5L + "'", long21 == 5L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timePeriod27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TimePeriodValue[2019,12]" + "'", str28.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 10);
        java.lang.Class class3 = null;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        java.util.Date date6 = day4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getMonth();
        java.util.Date date11 = day9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date6, date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int15 = year13.compareTo((java.lang.Object) 100.0d);
        int int17 = year13.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year13);
        timePeriodValues18.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener21);
        java.lang.Comparable comparable23 = timePeriodValues18.getKey();
        int int24 = simpleTimePeriod12.compareTo((java.lang.Object) comparable23);
        boolean boolean25 = simpleTimePeriod2.equals((java.lang.Object) int24);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(comparable23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getMonth();
//        java.util.Date date3 = day1.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
//        java.lang.String str11 = year7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        int int15 = year7.compareTo((java.lang.Object) day13);
//        java.util.Date date16 = year7.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long20 = simpleTimePeriod19.getEndMillis();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        long long22 = year21.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
//        java.lang.String str27 = timePeriodValue25.toString();
//        boolean boolean28 = simpleTimePeriod19.equals((java.lang.Object) timePeriodValue25);
//        boolean boolean30 = simpleTimePeriod19.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        int int33 = day31.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int33, "", "13-June-2019");
//        boolean boolean37 = simpleTimePeriod19.equals((java.lang.Object) timePeriodValues36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = simpleTimePeriod19.equals(obj38);
//        java.util.Date date40 = simpleTimePeriod19.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40, timeZone41);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getMonth();
//        java.util.Date date46 = day44.getStart();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date46, timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        int int50 = day49.getMonth();
//        java.util.Date date51 = day49.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date46, date51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date51);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        int int57 = day56.getMonth();
//        java.util.Date date58 = day56.getStart();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date58, timeZone59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date51, timeZone59);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date40, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date16, timeZone59);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date3, timeZone59);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 5L + "'", long20 == 5L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1562097599999L + "'", long22 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timePeriod26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TimePeriodValue[2019,12]" + "'", str27.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        boolean boolean8 = timePeriodValues5.getNotify();
        java.lang.String str9 = timePeriodValues5.getDomainDescription();
        int int10 = timePeriodValues5.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long1, "2019", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        int int7 = timePeriodValues4.getMinEndIndex();
//        java.lang.Object obj8 = timePeriodValues4.clone();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(obj8);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
//        timePeriodValues5.add(timePeriodValue10);
//        int int12 = timePeriodValues5.getMaxMiddleIndex();
//        java.lang.String str13 = timePeriodValues5.getDomainDescription();
//        timePeriodValues5.setRangeDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        int int18 = day16.getMonth();
//        long long19 = day16.getFirstMillisecond();
//        long long20 = day16.getSerialIndex();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day16, (double) 2);
//        long long23 = day16.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int6 = year4.compareTo((java.lang.Object) 100.0d);
        int int8 = year4.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year4);
        timePeriodValues9.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues9.getMinStartIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 1L);
        timePeriodValues9.add(timePeriodValue19);
        boolean boolean21 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues9);
        timePeriodValues9.setNotify(true);
        java.lang.String str24 = timePeriodValues9.getDescription();
        boolean boolean25 = timePeriodValues9.isEmpty();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        int int12 = timePeriodValues5.getMinStartIndex();
        java.lang.String str13 = timePeriodValues5.getDomainDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int16 = year14.compareTo((java.lang.Object) 100.0d);
        int int18 = year14.compareTo((java.lang.Object) (byte) 0);
        long long19 = year14.getFirstMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 1L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Object obj23 = seriesChangeEvent22.getSource();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + obj23 + "' != '" + 1L + "'", obj23.equals(1L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        int int8 = year0.compareTo((java.lang.Object) day6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        int int8 = timePeriodValues5.getMinMiddleIndex();
        timePeriodValues5.setNotify(false);
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        java.util.Date date14 = day12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.util.Date date19 = day17.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14);
        boolean boolean22 = timePeriodValues5.equals((java.lang.Object) day21);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues5.createCopy(7, (-1));
        int int26 = timePeriodValues25.getItemCount();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int29 = year27.compareTo((java.lang.Object) 100.0d);
        int int31 = year27.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year27);
        timePeriodValues32.fireSeriesChanged();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod35, (java.lang.Number) (byte) -1);
        timePeriodValues32.add(timePeriodValue37);
        int int39 = timePeriodValues32.getMinEndIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long43 = simpleTimePeriod42.getEndMillis();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year44.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year44, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod49 = timePeriodValue48.getPeriod();
        java.lang.String str50 = timePeriodValue48.toString();
        boolean boolean51 = simpleTimePeriod42.equals((java.lang.Object) timePeriodValue48);
        timePeriodValues32.add(timePeriodValue48);
        timePeriodValues25.add(timePeriodValue48);
        timePeriodValues25.setDomainDescription("Time");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 5L + "'", long43 == 5L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1562097599999L + "'", long45 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(timePeriod49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "TimePeriodValue[2019,12]" + "'", str50.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
//        long long7 = regularTimePeriod6.getMiddleMillisecond();
//        java.util.Date date8 = regularTimePeriod6.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        int int14 = year12.compareTo((java.lang.Object) 1L);
//        java.util.Date date15 = year12.getStart();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
//        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        long long23 = regularTimePeriod22.getMiddleMillisecond();
//        java.util.Date date24 = regularTimePeriod22.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date15, timeZone25);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date15, timeZone28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        int int32 = year30.compareTo((java.lang.Object) 1L);
//        java.util.Date date33 = year30.getStart();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
//        java.lang.Class<?> wildcardClass37 = regularTimePeriod36.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
//        long long41 = regularTimePeriod40.getMiddleMillisecond();
//        java.util.Date date42 = regularTimePeriod40.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date42, timeZone43);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        int int48 = year46.compareTo((java.lang.Object) 1L);
//        java.util.Date date49 = year46.getStart();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        java.lang.Class<?> wildcardClass53 = regularTimePeriod52.getClass();
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year55.previous();
//        long long57 = regularTimePeriod56.getMiddleMillisecond();
//        java.util.Date date58 = regularTimePeriod56.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date58, timeZone59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date49, timeZone59);
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date49, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date33, timeZone62);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long68 = simpleTimePeriod67.getEndMillis();
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
//        long long70 = year69.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year69.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year69, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod74 = timePeriodValue73.getPeriod();
//        java.lang.String str75 = timePeriodValue73.toString();
//        boolean boolean76 = simpleTimePeriod67.equals((java.lang.Object) timePeriodValue73);
//        boolean boolean78 = simpleTimePeriod67.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        long long80 = day79.getLastMillisecond();
//        int int81 = day79.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues84 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int81, "", "13-June-2019");
//        boolean boolean85 = simpleTimePeriod67.equals((java.lang.Object) timePeriodValues84);
//        java.lang.Object obj86 = null;
//        boolean boolean87 = simpleTimePeriod67.equals(obj86);
//        java.util.Date date88 = simpleTimePeriod67.getEnd();
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date88, timeZone89);
//        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date33, timeZone89);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1530561599999L + "'", long7 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1530561599999L + "'", long23 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1530561599999L + "'", long41 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1530561599999L + "'", long57 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 5L + "'", long68 == 5L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1562097599999L + "'", long70 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(timePeriod74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "TimePeriodValue[2019,12]" + "'", str75.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560495599999L + "'", long80 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 6 + "'", int81 == 6);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(timeZone89);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str8 = seriesException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) seriesException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,12]");
        seriesException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "org.jfree.data.general.SeriesChangeEvent[source=2020]", "");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int19 = year17.compareTo((java.lang.Object) 100.0d);
        int int21 = year17.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year17);
        timePeriodValues22.setDescription("");
        int int25 = timePeriodValues22.getMinMiddleIndex();
        timePeriodValues22.setNotify(false);
        java.lang.Class class28 = null;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        int int30 = day29.getMonth();
        java.util.Date date31 = day29.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date31, timeZone32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        int int35 = day34.getMonth();
        java.util.Date date36 = day34.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date31, date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date31);
        boolean boolean39 = timePeriodValues22.equals((java.lang.Object) day38);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = timePeriodValues22.createCopy(7, (-1));
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.removePropertyChangeListener(propertyChangeListener43);
        try {
            int int45 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues42);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(timePeriodValues42);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getMonth();
//        java.util.Date date3 = day1.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        java.util.Date date8 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3);
//        int int12 = day10.compareTo((java.lang.Object) 1577865599999L);
//        long long13 = day10.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        java.lang.String str10 = timePeriodValue8.toString();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
        java.lang.String str12 = timePeriodValue8.toString();
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue8.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue(timePeriod13, 0.0d);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod19);
        java.lang.String str21 = seriesChangeEvent20.toString();
        java.lang.String str22 = seriesChangeEvent20.toString();
        java.lang.Object obj23 = seriesChangeEvent20.getSource();
        java.lang.Object obj24 = seriesChangeEvent20.getSource();
        boolean boolean25 = timePeriodValue15.equals((java.lang.Object) seriesChangeEvent20);
        java.lang.String str26 = timePeriodValue15.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[2019,12]" + "'", str12.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2018]" + "'", str21.equals("org.jfree.data.general.SeriesChangeEvent[source=2018]"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2018]" + "'", str22.equals("org.jfree.data.general.SeriesChangeEvent[source=2018]"));
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str26.equals("TimePeriodValue[2019,0.0]"));
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
//        boolean boolean7 = day0.equals((java.lang.Object) day4);
//        long long8 = day4.getSerialIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long8);
//        java.lang.String str10 = seriesChangeEvent9.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=43629]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=43629]"));
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = simpleTimePeriod2.equals(obj21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) (byte) -1);
//        boolean boolean30 = year23.equals((java.lang.Object) timePeriodValue29);
//        java.lang.String str31 = year23.toString();
//        long long32 = year23.getLastMillisecond();
//        boolean boolean33 = simpleTimePeriod2.equals((java.lang.Object) year23);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        int int36 = year34.compareTo((java.lang.Object) 100.0d);
//        int int38 = year34.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year34);
//        timePeriodValues39.setDescription("");
//        boolean boolean42 = timePeriodValues39.getNotify();
//        boolean boolean43 = year23.equals((java.lang.Object) timePeriodValues39);
//        long long44 = year23.getSerialIndex();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.next();
//        long long47 = day45.getSerialIndex();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        long long49 = day48.getLastMillisecond();
//        int int50 = day48.getMonth();
//        long long51 = day48.getFirstMillisecond();
//        int int52 = day45.compareTo((java.lang.Object) long51);
//        boolean boolean53 = year23.equals((java.lang.Object) day45);
//        java.util.Calendar calendar54 = null;
//        try {
//            long long55 = day45.getMiddleMillisecond(calendar54);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 43629L + "'", long47 == 43629L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560495599999L + "'", long49 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560409200000L + "'", long51 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str7 = seriesException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: hi!");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: hi!");
        java.lang.String str18 = timePeriodFormatException17.toString();
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Class<?> wildcardClass21 = seriesException20.getClass();
        java.lang.String str22 = seriesException20.toString();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) seriesException20);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str7.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str22.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        int int5 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        long long21 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date22 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        int int28 = year26.compareTo((java.lang.Object) 100.0d);
//        int int30 = year26.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year26.previous();
//        java.lang.String str32 = year26.toString();
//        int int33 = day23.compareTo((java.lang.Object) year26);
//        int int34 = day23.getYear();
//        int int35 = simpleTimePeriod2.compareTo((java.lang.Object) day23);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 5L + "'", long21 == 5L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43629L + "'", long24 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Date date2 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        boolean boolean9 = day0.equals((java.lang.Object) wildcardClass7);
        java.lang.Class class10 = null;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getMonth();
        java.util.Date date13 = day11.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int18 = year16.compareTo((java.lang.Object) 1L);
        java.util.Date date19 = year16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        long long27 = regularTimePeriod26.getMiddleMillisecond();
        java.util.Date date28 = regularTimePeriod26.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date19, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long36 = simpleTimePeriod35.getEndMillis();
        java.util.Date date37 = simpleTimePeriod35.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod35, (java.lang.Number) 0L);
        java.util.Date date40 = simpleTimePeriod35.getEnd();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date13, date40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1530561599999L + "'", long27 == 1530561599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 5L + "'", long36 == 5L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int5 = year3.compareTo((java.lang.Object) 100.0d);
//        int int7 = year3.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.previous();
//        java.lang.String str9 = year3.toString();
//        int int10 = day0.compareTo((java.lang.Object) year3);
//        int int11 = day0.getYear();
//        long long12 = day0.getSerialIndex();
//        long long13 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.previous();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
//        int int19 = year16.getYear();
//        boolean boolean20 = day15.equals((java.lang.Object) year16);
//        java.util.Date date21 = year16.getStart();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
//        java.util.Date date25 = day22.getStart();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getMonth();
//        java.util.Date date29 = day27.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date29, timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getMonth();
//        java.util.Date date34 = day32.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date29, date34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date34);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        int int40 = day39.getMonth();
//        java.util.Date date41 = day39.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date41, timeZone42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date34, timeZone42);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date25, timeZone42);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date21, timeZone42);
//        boolean boolean47 = day0.equals((java.lang.Object) timeZone42);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year49.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.next();
//        int int52 = year49.getYear();
//        boolean boolean53 = day48.equals((java.lang.Object) year49);
//        java.util.Date date54 = year49.getStart();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        long long56 = day55.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day55.next();
//        java.util.Date date58 = day55.getStart();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        int int61 = day60.getMonth();
//        java.util.Date date62 = day60.getStart();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date62, timeZone63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int66 = day65.getMonth();
//        java.util.Date date67 = day65.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date62, date67);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date67);
//        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date67);
//        java.lang.Class class71 = null;
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getMonth();
//        java.util.Date date74 = day72.getStart();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date74, timeZone75);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date67, timeZone75);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date58, timeZone75);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date54, timeZone75);
//        boolean boolean80 = day0.equals((java.lang.Object) timeZone75);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560495599999L + "'", long23 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560495599999L + "'", long56 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 6 + "'", int73 == 6);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        java.lang.String str6 = year0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        int int10 = day8.getMonth();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 0.0d);
//        java.lang.Number number14 = timePeriodValues7.getValue(0);
//        int int15 = timePeriodValues7.getMinEndIndex();
//        boolean boolean16 = timePeriodValues7.isEmpty();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        java.lang.String str6 = year0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        int int10 = day8.getMonth();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Value");
        java.lang.String str5 = seriesException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str5.equals("org.jfree.data.general.SeriesException: Value"));
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = simpleTimePeriod2.equals(obj21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) (byte) -1);
//        boolean boolean30 = year23.equals((java.lang.Object) timePeriodValue29);
//        java.lang.String str31 = year23.toString();
//        long long32 = year23.getLastMillisecond();
//        boolean boolean33 = simpleTimePeriod2.equals((java.lang.Object) year23);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        int int36 = year34.compareTo((java.lang.Object) 100.0d);
//        int int38 = year34.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year34);
//        timePeriodValues39.setDescription("");
//        boolean boolean42 = timePeriodValues39.getNotify();
//        boolean boolean43 = year23.equals((java.lang.Object) timePeriodValues39);
//        int int44 = timePeriodValues39.getMaxStartIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        int int8 = timePeriodValues5.getMinMiddleIndex();
        timePeriodValues5.setNotify(false);
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        java.util.Date date14 = day12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.util.Date date19 = day17.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14);
        boolean boolean22 = timePeriodValues5.equals((java.lang.Object) day21);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues5.createCopy(7, (-1));
        int int26 = timePeriodValues25.getItemCount();
        timePeriodValues25.setDescription("TimePeriodValue[2019,0.0]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener6);
//        int int8 = timePeriodValues5.getMinEndIndex();
//        org.jfree.data.time.TimePeriod timePeriod9 = null;
//        try {
//            timePeriodValues5.add(timePeriod9, (double) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod4, (java.lang.Number) (byte) -1);
        boolean boolean7 = year0.equals((java.lang.Object) timePeriodValue6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 1L);
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date3, timeZone13);
        java.lang.Class class16 = null;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.util.Date date19 = day17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date19, timeZone20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        int int23 = day22.getMonth();
        java.util.Date date24 = day22.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date19, date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date24, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date3, timeZone28);
        int int31 = year30.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1530561599999L + "'", long11 == 1530561599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        int int12 = timePeriodValues5.getMaxMiddleIndex();
        java.lang.String str13 = timePeriodValues5.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        int int21 = timePeriodValues19.getMaxStartIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.String str11 = timePeriodValues5.getDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long15 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        java.lang.String str22 = timePeriodValue20.toString();
        boolean boolean23 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValue20);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 5L);
        int int26 = timePeriodValues5.getMaxMiddleIndex();
        java.lang.String str27 = timePeriodValues5.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,12]" + "'", str22.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 13);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int6 = year4.compareTo((java.lang.Object) 1L);
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        long long15 = regularTimePeriod14.getMiddleMillisecond();
        java.util.Date date16 = regularTimePeriod14.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date7, timeZone17);
        java.lang.Class class20 = null;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        int int22 = day21.getMonth();
        java.util.Date date23 = day21.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date23, timeZone24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getMonth();
        java.util.Date date28 = day26.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date23, date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date28, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date7, timeZone32);
        try {
            int int35 = simpleTimePeriod2.compareTo((java.lang.Object) date7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1530561599999L + "'", long15 == 1530561599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone32);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.String str11 = timePeriodValues5.getDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long15 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        java.lang.String str22 = timePeriodValue20.toString();
        boolean boolean23 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValue20);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 5L);
        java.util.Date date26 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        java.util.TimeZone timeZone28 = null;
        try {
            org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,12]" + "'", str22.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long9 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        java.lang.String str16 = timePeriodValue14.toString();
        boolean boolean17 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValue14);
        java.lang.String str18 = timePeriodValue14.toString();
        timePeriodValues3.add(timePeriodValue14);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValue14.equals(obj20);
        java.lang.String str22 = timePeriodValue14.toString();
        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue14.getPeriod();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5L + "'", long9 == 5L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[2019,12]" + "'", str16.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,12]" + "'", str18.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,12]" + "'", str22.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertNotNull(timePeriod23);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        timePeriodValues5.setKey((java.lang.Comparable) "Value");
        timePeriodValues5.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues5.createCopy((int) (byte) 1, 5);
        java.lang.Class class16 = null;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.util.Date date19 = day17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date19, timeZone20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        int int23 = day22.getMonth();
        java.util.Date date24 = day22.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date19, date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day26, (double) 100);
        int int30 = timePeriodValues5.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int2 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int7 = timePeriodValues6.getMaxStartIndex();
        timePeriodValues6.fireSeriesChanged();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long12 = simpleTimePeriod11.getEndMillis();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue17.getPeriod();
        java.lang.String str19 = timePeriodValue17.toString();
        boolean boolean20 = simpleTimePeriod11.equals((java.lang.Object) timePeriodValue17);
        java.lang.String str21 = timePeriodValue17.toString();
        timePeriodValues6.add(timePeriodValue17);
        java.lang.Object obj23 = null;
        boolean boolean24 = timePeriodValue17.equals(obj23);
        java.lang.Number number25 = timePeriodValue17.getValue();
        boolean boolean26 = day0.equals((java.lang.Object) number25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,12]" + "'", str19.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TimePeriodValue[2019,12]" + "'", str21.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 12 + "'", number25.equals(12));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener6);
//        int int8 = timePeriodValues5.getMinEndIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        java.util.Date date15 = day14.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getMonth();
        java.util.Date date3 = day1.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.String str6 = timePeriodValues5.getRangeDescription();
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy(1, (int) (byte) 1);
        int int11 = timePeriodValues5.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2018,-1]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str6 = seriesException5.toString();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException1);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: hi!]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: hi!]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: hi!]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: hi!]"));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setNotify(false);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int28 = timePeriodValues27.getMaxStartIndex();
//        boolean boolean30 = timePeriodValues27.equals((java.lang.Object) 10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timePeriodValues27.removeChangeListener(seriesChangeListener31);
//        boolean boolean33 = timePeriodValues27.isEmpty();
//        boolean boolean34 = timePeriodValues19.equals((java.lang.Object) boolean33);
//        java.lang.Comparable comparable35 = timePeriodValues19.getKey();
//        int int36 = timePeriodValues19.getMinEndIndex();
//        timePeriodValues19.setDescription("org.jfree.data.general.SeriesException: Value");
//        timePeriodValues19.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=2018]");
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 6 + "'", comparable35.equals(6));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Date date2 = day0.getStart();
        int int3 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        java.util.Date date8 = regularTimePeriod6.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getMonth();
        java.util.Date date13 = day11.getStart();
        int int14 = day11.getMonth();
        java.util.Date date15 = day11.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1530561599999L + "'", long7 == 1530561599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        long long5 = year0.getFirstMillisecond();
        java.lang.Class class6 = null;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        java.util.Date date9 = day7.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date9, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        java.util.Date date14 = day12.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date9, date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date14, timeZone18);
        boolean boolean20 = year0.equals((java.lang.Object) day19);
        long long21 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy(100, 0);
        boolean boolean12 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.String str11 = timePeriodValues5.getDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long15 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        java.lang.String str22 = timePeriodValue20.toString();
        boolean boolean23 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValue20);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 5L);
        java.lang.Class<?> wildcardClass26 = simpleTimePeriod14.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,12]" + "'", str22.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int9 = timePeriodValues8.getMaxStartIndex();
        boolean boolean11 = timePeriodValues8.equals((java.lang.Object) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues8.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timePeriodValues8.isEmpty();
        boolean boolean15 = year0.equals((java.lang.Object) boolean14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean15);
        java.lang.Object obj17 = seriesChangeEvent16.getSource();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + false + "'", obj17.equals(false));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod4, (java.lang.Number) (byte) -1);
        boolean boolean7 = year0.equals((java.lang.Object) timePeriodValue6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int13 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.fireSeriesChanged();
        int int15 = timePeriodValues12.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues12.createCopy(0, (int) (byte) 1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getMiddleMillisecond();
        long long21 = year19.getFirstMillisecond();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year19, (double) 'a');
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.next();
        int int28 = year25.getYear();
        boolean boolean29 = day24.equals((java.lang.Object) year25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year25.previous();
        boolean boolean31 = year19.equals((java.lang.Object) year25);
        boolean boolean32 = year0.equals((java.lang.Object) year25);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues5.createCopy((int) (short) -1, 6);
        timePeriodValues5.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Date date2 = day0.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException1);
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str13 = seriesException12.toString();
        seriesException10.addSuppressed((java.lang.Throwable) seriesException12);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("hi!");
        seriesException10.addSuppressed((java.lang.Throwable) seriesException16);
        seriesException7.addSuppressed((java.lang.Throwable) seriesException16);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray20 = seriesException7.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str13.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        timePeriodValues5.setNotify(true);
        try {
            org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues5.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        java.lang.String str6 = year0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        int int10 = day8.getMonth();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 0.0d);
//        int int13 = day8.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1.0d));
//        java.lang.Number number16 = timePeriodValue15.getValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener6);
//        int int8 = timePeriodValues5.getMinEndIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate13 = day9.getSerialDate();
//        long long14 = day9.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (byte) 0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.util.Date date21 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.util.Date date23 = year22.getEnd();
//        long long24 = year22.getFirstMillisecond();
//        int int25 = simpleTimePeriod2.compareTo((java.lang.Object) year22);
//        java.util.Date date26 = simpleTimePeriod2.getStart();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(date26);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day3.getMonth();
//        long long6 = day3.getFirstMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) long6);
//        java.lang.Object obj8 = null;
//        int int9 = day0.compareTo(obj8);
//        int int10 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int5 = year3.compareTo((java.lang.Object) 100.0d);
//        int int7 = year3.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.previous();
//        java.lang.String str9 = year3.toString();
//        int int10 = day0.compareTo((java.lang.Object) year3);
//        java.util.Calendar calendar11 = null;
//        try {
//            year3.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Date date2 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        boolean boolean9 = day0.equals((java.lang.Object) wildcardClass7);
        java.lang.Class class10 = null;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getMonth();
        java.util.Date date13 = day11.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int18 = year16.compareTo((java.lang.Object) 1L);
        java.util.Date date19 = year16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        long long27 = regularTimePeriod26.getMiddleMillisecond();
        java.util.Date date28 = regularTimePeriod26.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date19, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone29);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1530561599999L + "'", long27 == 1530561599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int7 = year5.compareTo((java.lang.Object) 100.0d);
        int int8 = year5.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) int8);
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) 100.0d);
        int int15 = year11.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year11);
        timePeriodValues16.fireSeriesChanged();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod19, (java.lang.Number) (byte) -1);
        java.lang.String str22 = timePeriodValue21.toString();
        timePeriodValues16.add(timePeriodValue21);
        java.lang.Object obj24 = timePeriodValue21.clone();
        java.lang.Object obj25 = timePeriodValue21.clone();
        timePeriodValues3.add(timePeriodValue21);
        int int27 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
        boolean boolean31 = timePeriodValues3.equals((java.lang.Object) year28);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2018,-1]" + "'", str22.equals("TimePeriodValue[2018,-1]"));
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int5 = year3.compareTo((java.lang.Object) 100.0d);
//        int int7 = year3.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.previous();
//        java.lang.String str9 = year3.toString();
//        int int10 = day0.compareTo((java.lang.Object) year3);
//        int int11 = day0.getYear();
//        java.lang.Object obj12 = null;
//        int int13 = day0.compareTo(obj12);
//        org.jfree.data.time.SerialDate serialDate14 = day0.getSerialDate();
//        long long15 = day0.getSerialIndex();
//        int int16 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        boolean boolean8 = timePeriodValues5.getNotify();
        java.lang.String str9 = timePeriodValues5.getDomainDescription();
        timePeriodValues5.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) (byte) -1);
        boolean boolean19 = year12.equals((java.lang.Object) timePeriodValue18);
        java.lang.String str20 = year12.toString();
        boolean boolean22 = year12.equals((java.lang.Object) 5L);
        timePeriodValues5.setKey((java.lang.Comparable) boolean22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year3);
        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues8);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.String str11 = timePeriodValues5.getDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long15 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        java.lang.String str22 = timePeriodValue20.toString();
        boolean boolean23 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValue20);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 5L);
        int int26 = timePeriodValues5.getMaxMiddleIndex();
        java.lang.Comparable comparable27 = timePeriodValues5.getKey();
        timePeriodValues5.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=2018]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,12]" + "'", str22.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(comparable27);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        boolean boolean8 = timePeriodValues5.getNotify();
        java.lang.String str9 = timePeriodValues5.getDomainDescription();
        timePeriodValues5.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues5.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener6);
//        int int8 = timePeriodValues5.getMinEndIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (byte) 1);
//        long long13 = day9.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = regularTimePeriod7.getMiddleMillisecond();
        java.util.Date date9 = regularTimePeriod7.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        boolean boolean11 = year0.equals((java.lang.Object) date9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int14 = year12.compareTo((java.lang.Object) 1L);
        java.util.Date date15 = year12.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        long long23 = regularTimePeriod22.getMiddleMillisecond();
        java.util.Date date24 = regularTimePeriod22.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date15, timeZone25);
        java.lang.Class class28 = null;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        int int30 = day29.getMonth();
        java.util.Date date31 = day29.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date31, timeZone32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        int int35 = day34.getMonth();
        java.util.Date date36 = day34.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date31, date36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date36, timeZone40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date15, timeZone40);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date9, timeZone40);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1530561599999L + "'", long8 == 1530561599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1530561599999L + "'", long23 == 1530561599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone40);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        timePeriodValues5.setKey((java.lang.Comparable) "Value");
//        timePeriodValues5.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener11);
//        int int13 = timePeriodValues5.getMaxStartIndex();
//        boolean boolean14 = timePeriodValues5.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues5.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        int int20 = day17.getDayOfMonth();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day17.next();
//        long long24 = day17.getFirstMillisecond();
//        int int25 = day17.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        long long21 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date22 = simpleTimePeriod2.getEnd();
//        java.util.Date date23 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date23, "org.jfree.data.general.SeriesException: Value", "org.jfree.data.general.SeriesException: Value");
//        try {
//            org.jfree.data.time.TimePeriod timePeriod29 = timePeriodValues27.getTimePeriod(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 5L + "'", long21 == 5L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) '#', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 12);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        int int8 = year0.compareTo((java.lang.Object) year5);
        long long9 = year5.getLastMillisecond();
        int int10 = year5.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        int int19 = year11.compareTo((java.lang.Object) year16);
        long long20 = year11.getSerialIndex();
        int int21 = year5.compareTo((java.lang.Object) year11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Date date2 = day0.getStart();
        int int3 = day0.getMonth();
        java.util.Date date4 = day0.getEnd();
        java.util.Date date5 = day0.getEnd();
        int int6 = day0.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        java.lang.String str11 = year7.toString();
        long long12 = year7.getLastMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        long long15 = regularTimePeriod14.getMiddleMillisecond();
        java.util.Date date16 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        boolean boolean18 = year7.equals((java.lang.Object) date16);
        int int19 = day0.compareTo((java.lang.Object) date16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1530561599999L + "'", long15 == 1530561599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod3);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
        java.lang.Object obj7 = seriesChangeEvent4.getSource();
        java.lang.String str8 = seriesChangeEvent4.toString();
        java.lang.Object obj9 = seriesChangeEvent4.getSource();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2018]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=2018]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2018]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=2018]"));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2018]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=2018]"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getMonth();
        java.util.Date date3 = day1.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int7 = day6.getMonth();
        java.util.Date date8 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        boolean boolean6 = timePeriodValues3.getNotify();
//        timePeriodValues3.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
//        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
//        int int12 = timePeriodValues3.getMaxStartIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 6 + "'", comparable11.equals(6));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        timePeriodValues5.setKey((java.lang.Comparable) "Value");
        timePeriodValues5.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues5.getMaxStartIndex();
        boolean boolean14 = timePeriodValues5.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        long long27 = regularTimePeriod26.getMiddleMillisecond();
        java.util.Date date28 = regularTimePeriod26.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        int int32 = day31.getMonth();
        java.util.Date date33 = day31.getStart();
        int int34 = day31.getMonth();
        java.util.Date date35 = day31.getStart();
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date35, timeZone36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date19, date35);
        timePeriodValues5.setKey((java.lang.Comparable) date19);
        java.lang.Class class40 = null;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getMonth();
        java.util.Date date43 = day41.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date43, timeZone44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        int int47 = day46.getMonth();
        java.util.Date date48 = day46.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date43, date48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
        int int52 = day50.getYear();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day50, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 5L + "'", long18 == 5L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1530561599999L + "'", long27 == 1530561599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod4, (java.lang.Number) (byte) -1);
        boolean boolean7 = year0.equals((java.lang.Object) timePeriodValue6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        long long9 = year0.getFirstMillisecond();
        int int10 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
//        boolean boolean7 = day0.equals((java.lang.Object) day4);
//        long long8 = day4.getSerialIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long8);
//        java.lang.Object obj10 = seriesChangeEvent9.getSource();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + 43629L + "'", obj10.equals(43629L));
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getSerialIndex();
//        java.util.Date date4 = day0.getStart();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        java.lang.String str6 = year0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        int int10 = day8.getMonth();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 0.0d);
//        java.lang.Number number14 = timePeriodValues7.getValue(0);
//        int int15 = timePeriodValues7.getMaxMiddleIndex();
//        boolean boolean16 = timePeriodValues7.isEmpty();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getDayOfMonth();
//        java.lang.Number number4 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number4);
//        timePeriodValue5.setValue((java.lang.Number) 0L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2);
//        timePeriodValues3.delete(10, (int) (short) -1);
//        int int7 = timePeriodValues3.getMinEndIndex();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Date date2 = day0.getStart();
        int int3 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "Time", "org.jfree.data.general.SeriesException: Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        java.util.Date date5 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = simpleTimePeriod2.equals(obj21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) (byte) -1);
//        boolean boolean30 = year23.equals((java.lang.Object) timePeriodValue29);
//        java.lang.String str31 = year23.toString();
//        long long32 = year23.getLastMillisecond();
//        boolean boolean33 = simpleTimePeriod2.equals((java.lang.Object) year23);
//        long long34 = year23.getSerialIndex();
//        int int35 = year23.getYear();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getMonth();
//        java.util.Date date3 = day1.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        java.util.Date date8 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3);
//        int int12 = day10.compareTo((java.lang.Object) 1577865599999L);
//        long long13 = day10.getMiddleMillisecond();
//        int int14 = day10.getDayOfMonth();
//        java.util.Date date15 = day10.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day10.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        int int22 = timePeriodValues19.getMaxStartIndex();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
//        int int27 = year24.getYear();
//        boolean boolean28 = day23.equals((java.lang.Object) year24);
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year24, (double) (byte) 1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 100.0f);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        int int12 = timePeriodValues5.getMinStartIndex();
        java.lang.String str13 = timePeriodValues5.getDomainDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int16 = year14.compareTo((java.lang.Object) 100.0d);
        int int18 = year14.compareTo((java.lang.Object) (byte) 0);
        long long19 = year14.getFirstMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 1L);
        java.lang.String str22 = year14.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue4.getPeriod();
        java.lang.Object obj6 = timePeriodValue4.clone();
        java.lang.String str7 = timePeriodValue4.toString();
        timePeriodValue4.setValue((java.lang.Number) 1.0d);
        boolean boolean11 = timePeriodValue4.equals((java.lang.Object) "13-June-2019");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(timePeriod5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,12]" + "'", str7.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) 100.0d);
        int int15 = year11.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        boolean boolean17 = timePeriodValues5.equals((java.lang.Object) year11);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues5.getMaxStartIndex();
        timePeriodValues5.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues5.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=43629]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
//        java.lang.String str4 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        int int8 = year0.compareTo((java.lang.Object) day6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
//        java.lang.String str10 = year0.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
//        int int14 = day11.getDayOfMonth();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, number15);
//        long long17 = day11.getSerialIndex();
//        java.lang.String str18 = day11.toString();
//        boolean boolean19 = year0.equals((java.lang.Object) day11);
//        java.lang.String str20 = day11.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str4 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        int int8 = timePeriodValues5.getMinMiddleIndex();
        timePeriodValues5.setNotify(false);
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        java.util.Date date14 = day12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.util.Date date19 = day17.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14);
        boolean boolean22 = timePeriodValues5.equals((java.lang.Object) day21);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues5.createCopy(7, (-1));
        timePeriodValues25.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
        java.lang.String str28 = timePeriodValues25.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2020]" + "'", str28.equals("org.jfree.data.general.SeriesChangeEvent[source=2020]"));
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day3.getMonth();
//        long long6 = day3.getFirstMillisecond();
//        long long7 = day3.getLastMillisecond();
//        int int8 = year0.compareTo((java.lang.Object) day3);
//        long long9 = day3.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560452399999L + "'", long9 == 1560452399999L);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int5 = year3.compareTo((java.lang.Object) 100.0d);
//        int int7 = year3.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.previous();
//        java.lang.String str9 = year3.toString();
//        int int10 = day0.compareTo((java.lang.Object) year3);
//        int int11 = day0.getYear();
//        long long12 = day0.getSerialIndex();
//        long long13 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.previous();
//        long long15 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int6 = timePeriodValues5.getMaxStartIndex();
//        timePeriodValues5.fireSeriesChanged();
//        int int8 = timePeriodValues5.getMaxStartIndex();
//        timePeriodValues5.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues5);
//        boolean boolean11 = day0.equals((java.lang.Object) timePeriodValues5);
//        long long12 = day0.getFirstMillisecond();
//        java.lang.String str13 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        java.lang.String str10 = timePeriodValue8.toString();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
        long long12 = simpleTimePeriod2.getEndMillis();
        java.util.Date date13 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getMonth();
        java.util.Date date16 = day14.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        long long24 = regularTimePeriod23.getMiddleMillisecond();
        java.util.Date date25 = regularTimePeriod23.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date16, timeZone26);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date16, timeZone29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date13, date16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1530561599999L + "'", long24 == 1530561599999L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone29);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.util.Date date2 = day0.getStart();
//        long long3 = day0.getSerialIndex();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
//        timePeriodValues5.add(timePeriodValue10);
//        int int12 = timePeriodValues5.getMaxMiddleIndex();
//        java.lang.String str13 = timePeriodValues5.getDomainDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener14);
//        timePeriodValues5.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2018,-1]");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long21 = simpleTimePeriod20.getEndMillis();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValue26.getPeriod();
//        java.lang.String str28 = timePeriodValue26.toString();
//        boolean boolean29 = simpleTimePeriod20.equals((java.lang.Object) timePeriodValue26);
//        boolean boolean31 = simpleTimePeriod20.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        int int34 = day32.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int34, "", "13-June-2019");
//        boolean boolean38 = simpleTimePeriod20.equals((java.lang.Object) timePeriodValues37);
//        java.lang.String str39 = timePeriodValues37.getDomainDescription();
//        timePeriodValues37.setNotify(false);
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int46 = timePeriodValues45.getMaxStartIndex();
//        boolean boolean48 = timePeriodValues45.equals((java.lang.Object) 10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
//        timePeriodValues45.removeChangeListener(seriesChangeListener49);
//        boolean boolean51 = timePeriodValues45.isEmpty();
//        boolean boolean52 = timePeriodValues37.equals((java.lang.Object) boolean51);
//        boolean boolean53 = timePeriodValues5.equals((java.lang.Object) boolean52);
//        int int54 = timePeriodValues5.getMinMiddleIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 5L + "'", long21 == 5L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timePeriod27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TimePeriodValue[2019,12]" + "'", str28.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
//        long long7 = day4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
//        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        boolean boolean9 = day0.equals((java.lang.Object) wildcardClass7);
//        long long10 = day0.getSerialIndex();
//        int int11 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues5.createCopy((int) (short) -1, 6);
        timePeriodValues8.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues8.clone();
        java.lang.String str11 = timePeriodValues8.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        long long6 = year0.getFirstMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        boolean boolean10 = year0.equals((java.lang.Object) year7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        timePeriodValues5.setKey((java.lang.Comparable) "Value");
//        timePeriodValues5.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener11);
//        int int13 = timePeriodValues5.getMaxStartIndex();
//        boolean boolean14 = timePeriodValues5.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues5.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        int int20 = day17.getDayOfMonth();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long26 = simpleTimePeriod25.getEndMillis();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValue31.getPeriod();
//        java.lang.String str33 = timePeriodValue31.toString();
//        boolean boolean34 = simpleTimePeriod25.equals((java.lang.Object) timePeriodValue31);
//        boolean boolean36 = simpleTimePeriod25.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getLastMillisecond();
//        int int39 = day37.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int39, "", "13-June-2019");
//        boolean boolean43 = simpleTimePeriod25.equals((java.lang.Object) timePeriodValues42);
//        long long44 = simpleTimePeriod25.getEndMillis();
//        java.util.Date date45 = simpleTimePeriod25.getEnd();
//        java.util.Date date46 = simpleTimePeriod25.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date46);
//        int int48 = day17.compareTo((java.lang.Object) date46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int53 = timePeriodValues52.getMaxStartIndex();
//        boolean boolean55 = timePeriodValues52.equals((java.lang.Object) 10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
//        timePeriodValues52.removeChangeListener(seriesChangeListener56);
//        boolean boolean58 = timePeriodValues52.isEmpty();
//        boolean boolean59 = timePeriodValues52.isEmpty();
//        boolean boolean60 = day17.equals((java.lang.Object) timePeriodValues52);
//        long long61 = day17.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(timePeriod32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,12]" + "'", str33.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560495599999L + "'", long38 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 5L + "'", long44 == 5L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560409200000L + "'", long61 == 1560409200000L);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) 100.0d);
        int int15 = year11.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        boolean boolean17 = timePeriodValues5.equals((java.lang.Object) year11);
        int int18 = timePeriodValues5.getMinStartIndex();
        java.lang.Class<?> wildcardClass19 = timePeriodValues5.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        java.lang.String str10 = timePeriodValue8.toString();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue8.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timePeriod12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int6 = year4.compareTo((java.lang.Object) 100.0d);
        int int8 = year4.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year4);
        timePeriodValues9.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues9.getMinStartIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 1L);
        timePeriodValues9.add(timePeriodValue19);
        boolean boolean21 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues9);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener22);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4L + "'", long4 == 4L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long1, "2019", "hi!");
//        java.lang.String str5 = timePeriodValues4.getDescription();
//        java.lang.String str6 = timePeriodValues4.getDomainDescription();
//        int int7 = timePeriodValues4.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        int int8 = timePeriodValues5.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues5.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.lang.String str6 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str6);
        int int8 = timePeriodValues7.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        java.util.Date date14 = day12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.util.Date date19 = day17.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) 1L);
        java.util.Date date25 = year22.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        long long33 = regularTimePeriod32.getMiddleMillisecond();
        java.util.Date date34 = regularTimePeriod32.getEnd();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date34, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date25, timeZone35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date14, timeZone35);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year38, (double) 2);
        long long41 = year38.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year38.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1530561599999L + "'", long33 == 1530561599999L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.String str6 = timePeriodValues5.getRangeDescription();
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy(1, (int) (byte) 1);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues10.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener6);
//        int int8 = timePeriodValues5.getMinEndIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
//        int int11 = day9.getMonth();
//        long long12 = day9.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
//        timePeriodValues5.setKey((java.lang.Comparable) regularTimePeriod13);
//        int int15 = timePeriodValues5.getMaxEndIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long4 = simpleTimePeriod3.getEndMillis();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
//        java.lang.String str11 = timePeriodValue9.toString();
//        boolean boolean12 = simpleTimePeriod3.equals((java.lang.Object) timePeriodValue9);
//        boolean boolean14 = simpleTimePeriod3.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        int int17 = day15.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int17, "", "13-June-2019");
//        boolean boolean21 = simpleTimePeriod3.equals((java.lang.Object) timePeriodValues20);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = simpleTimePeriod3.equals(obj22);
//        java.util.Date date24 = simpleTimePeriod3.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getMonth();
//        java.util.Date date30 = day28.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        java.util.Date date35 = day33.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date30, date35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        int int41 = day40.getMonth();
//        java.util.Date date42 = day40.getStart();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date42, timeZone43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date35, timeZone43);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date24, timeZone43);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year47.previous();
//        java.lang.Class<?> wildcardClass50 = regularTimePeriod49.getClass();
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year54.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year54.next();
//        int int57 = year54.getYear();
//        boolean boolean58 = day53.equals((java.lang.Object) year54);
//        java.util.Date date59 = year54.getStart();
//        java.util.Date date60 = year54.getStart();
//        java.lang.Class class61 = null;
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        int int63 = day62.getMonth();
//        java.util.Date date64 = day62.getStart();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date64, timeZone65);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        int int68 = day67.getMonth();
//        java.util.Date date69 = day67.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date64, date69);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date69);
//        java.lang.Class class73 = null;
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        int int75 = day74.getMonth();
//        java.util.Date date76 = day74.getStart();
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class73, date76, timeZone77);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date69, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date60, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date24, timeZone77);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5L + "'", long4 == 5L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(timePeriod10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,12]" + "'", str11.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 6 + "'", int68 == 6);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 6 + "'", int75 == 6);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        java.lang.String str10 = timePeriodValue8.toString();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
        java.lang.String str12 = timePeriodValue8.toString();
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue8.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue(timePeriod13, 0.0d);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod19);
        java.lang.String str21 = seriesChangeEvent20.toString();
        java.lang.String str22 = seriesChangeEvent20.toString();
        java.lang.Object obj23 = seriesChangeEvent20.getSource();
        java.lang.Object obj24 = seriesChangeEvent20.getSource();
        boolean boolean25 = timePeriodValue15.equals((java.lang.Object) seriesChangeEvent20);
        java.lang.Object obj26 = null;
        boolean boolean27 = timePeriodValue15.equals(obj26);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[2019,12]" + "'", str12.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2018]" + "'", str21.equals("org.jfree.data.general.SeriesChangeEvent[source=2018]"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2018]" + "'", str22.equals("org.jfree.data.general.SeriesChangeEvent[source=2018]"));
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.setDescription("");
//        int int8 = timePeriodValues5.getMinMiddleIndex();
//        timePeriodValues5.setNotify(false);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        java.util.Date date14 = day12.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getMonth();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14);
//        boolean boolean22 = timePeriodValues5.equals((java.lang.Object) day21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues5.createCopy(7, (-1));
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.removePropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long31 = simpleTimePeriod30.getEndMillis();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod37 = timePeriodValue36.getPeriod();
//        java.lang.String str38 = timePeriodValue36.toString();
//        boolean boolean39 = simpleTimePeriod30.equals((java.lang.Object) timePeriodValue36);
//        boolean boolean41 = simpleTimePeriod30.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getLastMillisecond();
//        int int44 = day42.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int44, "", "13-June-2019");
//        boolean boolean48 = simpleTimePeriod30.equals((java.lang.Object) timePeriodValues47);
//        java.lang.Object obj49 = null;
//        boolean boolean50 = simpleTimePeriod30.equals(obj49);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year51.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year51.next();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year54.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod55, (java.lang.Number) (byte) -1);
//        boolean boolean58 = year51.equals((java.lang.Object) timePeriodValue57);
//        java.lang.String str59 = year51.toString();
//        long long60 = year51.getLastMillisecond();
//        boolean boolean61 = simpleTimePeriod30.equals((java.lang.Object) year51);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
//        int int64 = year62.compareTo((java.lang.Object) 100.0d);
//        int int66 = year62.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year62);
//        timePeriodValues67.setDescription("");
//        boolean boolean70 = timePeriodValues67.getNotify();
//        boolean boolean71 = year51.equals((java.lang.Object) timePeriodValues67);
//        timePeriodValues25.setKey((java.lang.Comparable) year51);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod75 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long76 = simpleTimePeriod75.getEndMillis();
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
//        long long78 = year77.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year77.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue81 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year77, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod82 = timePeriodValue81.getPeriod();
//        java.lang.String str83 = timePeriodValue81.toString();
//        boolean boolean84 = simpleTimePeriod75.equals((java.lang.Object) timePeriodValue81);
//        boolean boolean86 = simpleTimePeriod75.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day();
//        long long88 = day87.getLastMillisecond();
//        int int89 = day87.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues92 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int89, "", "13-June-2019");
//        boolean boolean93 = simpleTimePeriod75.equals((java.lang.Object) timePeriodValues92);
//        long long94 = simpleTimePeriod75.getEndMillis();
//        java.util.Date date95 = simpleTimePeriod75.getEnd();
//        java.util.Date date96 = simpleTimePeriod75.getEnd();
//        int int97 = year51.compareTo((java.lang.Object) simpleTimePeriod75);
//        long long98 = year51.getFirstMillisecond();
//        int int99 = year51.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 5L + "'", long31 == 5L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1562097599999L + "'", long33 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(timePeriod37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "TimePeriodValue[2019,12]" + "'", str38.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560495599999L + "'", long43 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019" + "'", str59.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 5L + "'", long76 == 5L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1562097599999L + "'", long78 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(timePeriod82);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "TimePeriodValue[2019,12]" + "'", str83.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1560495599999L + "'", long88 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 6 + "'", int89 == 6);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 5L + "'", long94 == 5L);
//        org.junit.Assert.assertNotNull(date95);
//        org.junit.Assert.assertNotNull(date96);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1 + "'", int97 == 1);
//        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 1546329600000L + "'", long98 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 2019 + "'", int99 == 2019);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        int int4 = year1.getYear();
        boolean boolean5 = day0.equals((java.lang.Object) year1);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (java.lang.Number) 11);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
//        java.lang.String str4 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        int int8 = year0.compareTo((java.lang.Object) day6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
//        java.lang.String str10 = year0.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
//        int int14 = day11.getDayOfMonth();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, number15);
//        long long17 = day11.getSerialIndex();
//        java.lang.String str18 = day11.toString();
//        boolean boolean19 = year0.equals((java.lang.Object) day11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues5.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Object obj9 = timePeriodValues5.clone();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        int int12 = year10.compareTo((java.lang.Object) 100.0d);
//        int int14 = year10.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year10);
//        timePeriodValues15.fireSeriesChanged();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod18, (java.lang.Number) (byte) -1);
//        java.lang.String str21 = timePeriodValue20.toString();
//        timePeriodValues15.add(timePeriodValue20);
//        int int23 = timePeriodValues15.getMaxEndIndex();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getLastMillisecond();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int26, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues29.removeChangeListener(seriesChangeListener30);
//        int int32 = timePeriodValues29.getMinEndIndex();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getSerialIndex();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate37 = day33.getSerialDate();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
//        timePeriodValues15.setKey((java.lang.Comparable) serialDate37);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate37);
//        timePeriodValues5.setKey((java.lang.Comparable) serialDate37);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate37);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TimePeriodValue[2018,-1]" + "'", str21.equals("TimePeriodValue[2018,-1]"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560495599999L + "'", long25 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43629L + "'", long34 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate37);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
//        java.lang.String str9 = timePeriodValue7.toString();
//        int int10 = day0.compareTo((java.lang.Object) str9);
//        long long11 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(timePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,12]" + "'", str9.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 10);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Object obj9 = timePeriodValues5.clone();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        java.lang.Object obj16 = timePeriodValue14.clone();
        java.lang.String str17 = timePeriodValue14.toString();
        timePeriodValue14.setValue((java.lang.Number) 1.0d);
        timePeriodValues5.add(timePeriodValue14);
        java.lang.Number number21 = timePeriodValue14.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TimePeriodValue[2019,12]" + "'", str17.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.0d + "'", number21.equals(1.0d));
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int5 = year3.compareTo((java.lang.Object) 100.0d);
//        int int7 = year3.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.previous();
//        java.lang.String str9 = year3.toString();
//        int int10 = day0.compareTo((java.lang.Object) year3);
//        int int11 = day0.getYear();
//        java.lang.Object obj12 = null;
//        int int13 = day0.compareTo(obj12);
//        org.jfree.data.time.SerialDate serialDate14 = day0.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate14);
//        long long18 = day17.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: hi!");
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        int int12 = timePeriodValues5.getMinStartIndex();
        java.lang.String str13 = timePeriodValues5.getDomainDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int16 = year14.compareTo((java.lang.Object) 100.0d);
        int int18 = year14.compareTo((java.lang.Object) (byte) 0);
        long long19 = year14.getFirstMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 1L);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = timePeriodValues5.getDataItem((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(timePeriodValue23);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        int int2 = day1.getMonth();
//        java.util.Date date3 = day1.getStart();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        java.util.Date date8 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8, timeZone12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
//        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        long long21 = regularTimePeriod20.getMiddleMillisecond();
//        java.util.Date date22 = regularTimePeriod20.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date8, timeZone23);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getMonth();
//        java.util.Date date29 = day27.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date29, timeZone30);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
//        int int37 = year34.getYear();
//        boolean boolean38 = day33.equals((java.lang.Object) year34);
//        java.util.Date date39 = year34.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day40.next();
//        java.util.Date date43 = day40.getStart();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int46 = day45.getMonth();
//        java.util.Date date47 = day45.getStart();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date47, timeZone48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        int int51 = day50.getMonth();
//        java.util.Date date52 = day50.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date47, date52);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date52);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date52);
//        java.lang.Class class56 = null;
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        int int58 = day57.getMonth();
//        java.util.Date date59 = day57.getStart();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date59, timeZone60);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date52, timeZone60);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date43, timeZone60);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date39, timeZone60);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date29, timeZone60);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date8, timeZone60);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date8);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1530561599999L + "'", long21 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560495599999L + "'", long41 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        java.util.Date date8 = regularTimePeriod6.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getMonth();
        java.util.Date date13 = day11.getStart();
        int int14 = day11.getMonth();
        java.util.Date date15 = day11.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        int int19 = day18.getMonth();
        java.util.Date date20 = day18.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        long long28 = regularTimePeriod27.getMiddleMillisecond();
        java.util.Date date29 = regularTimePeriod27.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date20, timeZone30);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date20, timeZone33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date15, timeZone33);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1530561599999L + "'", long7 == 1530561599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1530561599999L + "'", long28 == 1530561599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeZone33);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.fireSeriesChanged();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
//        timePeriodValues5.add(timePeriodValue10);
//        int int12 = timePeriodValues5.getMinStartIndex();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        int int15 = year13.compareTo((java.lang.Object) 100.0d);
//        int int17 = year13.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.previous();
//        java.lang.String str19 = year13.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        int int23 = day21.getMonth();
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) 0.0d);
//        int int26 = day21.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, 1.0d);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day21, (double) 1530561599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        int int4 = year0.compareTo((java.lang.Object) 4L);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod6, (double) 1530561599999L);
        int int9 = year0.compareTo((java.lang.Object) timePeriodValue8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int12 = year10.compareTo((java.lang.Object) 100.0d);
        int int14 = year10.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.previous();
        int int16 = year0.compareTo((java.lang.Object) year10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int19 = year17.compareTo((java.lang.Object) 100.0d);
        int int21 = year17.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year17);
        timePeriodValues22.fireSeriesChanged();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod25, (java.lang.Number) (byte) -1);
        java.lang.String str28 = timePeriodValue27.toString();
        timePeriodValues22.add(timePeriodValue27);
        java.lang.Object obj30 = timePeriodValue27.clone();
        java.lang.String str31 = timePeriodValue27.toString();
        boolean boolean32 = year10.equals((java.lang.Object) str31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TimePeriodValue[2018,-1]" + "'", str28.equals("TimePeriodValue[2018,-1]"));
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "TimePeriodValue[2018,-1]" + "'", str31.equals("TimePeriodValue[2018,-1]"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        java.lang.String str6 = year0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        int int10 = day8.getMonth();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 0.0d);
//        int int13 = day8.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        int int18 = day8.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        long long5 = year0.getFirstMillisecond();
        java.lang.Class class6 = null;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getMonth();
        java.util.Date date9 = day7.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date9, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getMonth();
        java.util.Date date14 = day12.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date9, date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date14, timeZone18);
        boolean boolean20 = year0.equals((java.lang.Object) day19);
        long long21 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setRangeDescription("13-June-2019");
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues19.addPropertyChangeListener(propertyChangeListener24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 0L);
//        java.util.Date date7 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long11 = simpleTimePeriod10.getEndMillis();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue16.getPeriod();
//        java.lang.String str18 = timePeriodValue16.toString();
//        boolean boolean19 = simpleTimePeriod10.equals((java.lang.Object) timePeriodValue16);
//        boolean boolean21 = simpleTimePeriod10.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getLastMillisecond();
//        int int24 = day22.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int24, "", "13-June-2019");
//        boolean boolean28 = simpleTimePeriod10.equals((java.lang.Object) timePeriodValues27);
//        long long29 = simpleTimePeriod10.getEndMillis();
//        java.util.Date date30 = simpleTimePeriod10.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
//        java.util.Date date34 = day31.getStart();
//        int int35 = simpleTimePeriod10.compareTo((java.lang.Object) day31);
//        long long36 = simpleTimePeriod10.getEndMillis();
//        boolean boolean37 = simpleTimePeriod2.equals((java.lang.Object) long36);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(timePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,12]" + "'", str18.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560495599999L + "'", long23 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 5L + "'", long29 == 5L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 5L + "'", long36 == 5L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = simpleTimePeriod2.equals(obj21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) (byte) -1);
//        boolean boolean30 = year23.equals((java.lang.Object) timePeriodValue29);
//        java.lang.String str31 = year23.toString();
//        long long32 = year23.getLastMillisecond();
//        boolean boolean33 = simpleTimePeriod2.equals((java.lang.Object) year23);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        int int36 = year34.compareTo((java.lang.Object) 100.0d);
//        int int38 = year34.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year34);
//        timePeriodValues39.setDescription("");
//        boolean boolean42 = timePeriodValues39.getNotify();
//        boolean boolean43 = year23.equals((java.lang.Object) timePeriodValues39);
//        long long44 = year23.getSerialIndex();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.next();
//        long long47 = day45.getSerialIndex();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        long long49 = day48.getLastMillisecond();
//        int int50 = day48.getMonth();
//        long long51 = day48.getFirstMillisecond();
//        int int52 = day45.compareTo((java.lang.Object) long51);
//        boolean boolean53 = year23.equals((java.lang.Object) day45);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        long long55 = day54.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long55, "2019", "hi!");
//        java.lang.String str59 = timePeriodValues58.getDescription();
//        int int60 = day45.compareTo((java.lang.Object) str59);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 43629L + "'", long47 == 43629L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560495599999L + "'", long49 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560409200000L + "'", long51 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560495599999L + "'", long55 == 1560495599999L);
//        org.junit.Assert.assertNull(str59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        timePeriodValues19.setNotify(false);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int28 = timePeriodValues27.getMaxStartIndex();
//        boolean boolean30 = timePeriodValues27.equals((java.lang.Object) 10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timePeriodValues27.removeChangeListener(seriesChangeListener31);
//        boolean boolean33 = timePeriodValues27.isEmpty();
//        boolean boolean34 = timePeriodValues19.equals((java.lang.Object) boolean33);
//        java.lang.Comparable comparable35 = timePeriodValues19.getKey();
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue37 = timePeriodValues19.getDataItem(2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 6 + "'", comparable35.equals(6));
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.Comparable comparable11 = timePeriodValues5.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(comparable11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        timePeriodValues5.setKey((java.lang.Comparable) "Value");
        timePeriodValues5.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2020]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues5.createCopy((int) (byte) 1, 5);
        java.lang.Class class16 = null;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        int int18 = day17.getMonth();
        java.util.Date date19 = day17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date19, timeZone20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        int int23 = day22.getMonth();
        java.util.Date date24 = day22.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date19, date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day26, (double) 100);
        int int30 = day26.getYear();
        java.util.Calendar calendar31 = null;
        try {
            long long32 = day26.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int6 = year4.compareTo((java.lang.Object) 100.0d);
        int int8 = year4.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year4);
        timePeriodValues9.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues9.getMinStartIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 1L);
        timePeriodValues9.add(timePeriodValue19);
        boolean boolean21 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues9);
        timePeriodValues9.delete((int) '4', 3);
        java.lang.Object obj25 = timePeriodValues9.clone();
        java.lang.Comparable comparable26 = timePeriodValues9.getKey();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(comparable26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        int int12 = timePeriodValues5.getMinStartIndex();
        java.lang.String str13 = timePeriodValues5.getDomainDescription();
        int int14 = timePeriodValues5.getMaxStartIndex();
        timePeriodValues5.setNotify(true);
        int int17 = timePeriodValues5.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 13);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.String str6 = timePeriodValues5.getRangeDescription();
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues5.createCopy(1, (int) (byte) 1);
        timePeriodValues5.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(0, (int) (byte) 1);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getMiddleMillisecond();
        long long12 = year10.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (double) 'a');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year10);
        java.lang.String str16 = seriesChangeEvent15.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str16.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(0, (int) (byte) 1);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        int int18 = year10.compareTo((java.lang.Object) year15);
        timePeriodValues3.setKey((java.lang.Comparable) int18);
        boolean boolean20 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int2 = year0.compareTo((java.lang.Object) 100.0d);
//        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
//        timePeriodValues5.setDescription("");
//        int int8 = timePeriodValues5.getMinMiddleIndex();
//        timePeriodValues5.setNotify(false);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        java.util.Date date14 = day12.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getMonth();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date14);
//        boolean boolean22 = timePeriodValues5.equals((java.lang.Object) day21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.previous();
//        long long24 = day21.getFirstMillisecond();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getLastMillisecond();
//        int int27 = day25.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int27, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timePeriodValues30.removeChangeListener(seriesChangeListener31);
//        int int33 = timePeriodValues30.getMinEndIndex();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getSerialIndex();
//        timePeriodValues30.add((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) (byte) 1);
//        int int38 = day34.getDayOfMonth();
//        int int39 = day34.getYear();
//        java.util.Date date40 = day34.getStart();
//        boolean boolean41 = day21.equals((java.lang.Object) date40);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560495599999L + "'", long26 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43629L + "'", long35 == 43629L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 13 + "'", int38 == 13);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = simpleTimePeriod2.equals(obj21);
//        java.util.Date date23 = simpleTimePeriod2.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getMonth();
//        java.util.Date date29 = day27.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date29, timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getMonth();
//        java.util.Date date34 = day32.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date29, date34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date34);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        int int40 = day39.getMonth();
//        java.util.Date date41 = day39.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date41, timeZone42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date34, timeZone42);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date23, timeZone42);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.next();
//        int int48 = day46.getDayOfMonth();
//        java.util.Date date49 = day46.getEnd();
//        boolean boolean50 = day45.equals((java.lang.Object) date49);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 13 + "'", int48 == 13);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long9 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        java.lang.String str16 = timePeriodValue14.toString();
        boolean boolean17 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValue14);
        java.lang.String str18 = timePeriodValue14.toString();
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues3.createCopy(9, (int) (byte) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener26);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5L + "'", long9 == 5L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[2019,12]" + "'", str16.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,12]" + "'", str18.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues25);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        long long21 = simpleTimePeriod2.getStartMillis();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 4L + "'", long21 == 4L);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int2, "", "13-June-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.removeChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timePeriodValues5.getKey();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        int int14 = year12.compareTo((java.lang.Object) 100.0d);
//        int int16 = year12.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.previous();
//        java.lang.String str18 = year12.toString();
//        int int19 = day9.compareTo((java.lang.Object) year12);
//        int int20 = day9.getYear();
//        java.lang.Object obj21 = null;
//        int int22 = day9.compareTo(obj21);
//        int int23 = day9.getMonth();
//        long long24 = day9.getFirstMillisecond();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) (short) 0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 6 + "'", comparable8.equals(6));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        java.lang.String str10 = timePeriodValue8.toString();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
        java.util.Date date12 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        java.util.Date date8 = regularTimePeriod6.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class13 = null;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getMonth();
        java.util.Date date16 = day14.getStart();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date16, timeZone17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        java.util.Date date21 = day19.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date16, date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        long long31 = regularTimePeriod30.getMiddleMillisecond();
        java.util.Date date32 = regularTimePeriod30.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date32, timeZone33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int38 = year36.compareTo((java.lang.Object) 1L);
        java.util.Date date39 = year36.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        java.lang.Class<?> wildcardClass43 = regularTimePeriod42.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.previous();
        long long47 = regularTimePeriod46.getMiddleMillisecond();
        java.util.Date date48 = regularTimePeriod46.getEnd();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date48, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date39, timeZone49);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date39, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date16, timeZone52);
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date16, timeZone55);
        java.lang.Class class57 = null;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        int int59 = day58.getMonth();
        java.util.Date date60 = day58.getStart();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date60, timeZone61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
        int int64 = day63.getMonth();
        java.util.Date date65 = day63.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date60, date65);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date65);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date65);
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date65, timeZone69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year71.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year71.previous();
        java.lang.Class<?> wildcardClass74 = regularTimePeriod73.getClass();
        java.lang.Class class75 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass74);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year76.previous();
        long long78 = regularTimePeriod77.getMiddleMillisecond();
        java.util.Date date79 = regularTimePeriod77.getEnd();
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date79, timeZone80);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date65, timeZone80);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date16, timeZone80);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1530561599999L + "'", long7 == 1530561599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1530561599999L + "'", long31 == 1530561599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1530561599999L + "'", long47 == 1530561599999L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(class75);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1530561599999L + "'", long78 == 1530561599999L);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        int int8 = timePeriodValues5.getMinMiddleIndex();
        timePeriodValues5.setNotify(false);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getMonth();
        java.util.Date date13 = day11.getStart();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        int int8 = year0.compareTo((java.lang.Object) day6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod9);
        boolean boolean11 = timePeriodValues10.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Date date2 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        boolean boolean9 = day0.equals((java.lang.Object) wildcardClass7);
        int int10 = day0.getMonth();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) 100.0d);
        int int15 = year11.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year11);
        timePeriodValues16.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getMinStartIndex();
        java.lang.String str22 = timePeriodValues16.getDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
        long long26 = simpleTimePeriod25.getEndMillis();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValue31.getPeriod();
        java.lang.String str33 = timePeriodValue31.toString();
        boolean boolean34 = simpleTimePeriod25.equals((java.lang.Object) timePeriodValue31);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, (double) 5L);
        int int37 = day0.compareTo((java.lang.Object) timePeriodValues16);
        java.lang.String str38 = timePeriodValues16.getDescription();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timePeriod32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,12]" + "'", str33.equals("TimePeriodValue[2019,12]"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str3);
        int int5 = timePeriodValues4.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getSerialIndex();
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int10 = timePeriodValues9.getMaxStartIndex();
//        timePeriodValues9.fireSeriesChanged();
//        int int12 = timePeriodValues9.getMaxStartIndex();
//        timePeriodValues9.fireSeriesChanged();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
//        timePeriodValues9.setKey((java.lang.Comparable) day14);
//        boolean boolean17 = day0.equals((java.lang.Object) timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        java.util.Date date8 = regularTimePeriod6.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1530561599999L + "'", long7 == 1530561599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        int int6 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        timePeriodValues5.setKey((java.lang.Comparable) "Value");
        int int9 = timePeriodValues5.getMaxMiddleIndex();
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues5);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.fireSeriesChanged();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (byte) -1);
        timePeriodValues5.add(timePeriodValue10);
        timePeriodValues5.setNotify(true);
        boolean boolean14 = timePeriodValues5.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.Class<?> wildcardClass11 = timePeriodValues5.getClass();
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues5.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=2018]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
//        int int4 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long9 = simpleTimePeriod8.getEndMillis();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
//        java.lang.String str16 = timePeriodValue14.toString();
//        boolean boolean17 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValue14);
//        java.lang.String str18 = timePeriodValue14.toString();
//        timePeriodValues3.add(timePeriodValue14);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getLastMillisecond();
//        int int22 = day20.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int22);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timePeriodValues23.addChangeListener(seriesChangeListener24);
//        java.lang.Comparable comparable26 = timePeriodValues23.getKey();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long30 = simpleTimePeriod29.getEndMillis();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod36 = timePeriodValue35.getPeriod();
//        java.lang.String str37 = timePeriodValue35.toString();
//        boolean boolean38 = simpleTimePeriod29.equals((java.lang.Object) timePeriodValue35);
//        boolean boolean40 = simpleTimePeriod29.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getLastMillisecond();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int43, "", "13-June-2019");
//        boolean boolean47 = simpleTimePeriod29.equals((java.lang.Object) timePeriodValues46);
//        java.lang.Object obj48 = null;
//        boolean boolean49 = simpleTimePeriod29.equals(obj48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.next();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod54, (java.lang.Number) (byte) -1);
//        boolean boolean57 = year50.equals((java.lang.Object) timePeriodValue56);
//        java.lang.String str58 = year50.toString();
//        long long59 = year50.getLastMillisecond();
//        boolean boolean60 = simpleTimePeriod29.equals((java.lang.Object) year50);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        int int63 = year61.compareTo((java.lang.Object) 100.0d);
//        int int65 = year61.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year61);
//        timePeriodValues66.setDescription("");
//        boolean boolean69 = timePeriodValues66.getNotify();
//        boolean boolean70 = year50.equals((java.lang.Object) timePeriodValues66);
//        long long71 = year50.getSerialIndex();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = day72.next();
//        long long74 = day72.getSerialIndex();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        long long76 = day75.getLastMillisecond();
//        int int77 = day75.getMonth();
//        long long78 = day75.getFirstMillisecond();
//        int int79 = day72.compareTo((java.lang.Object) long78);
//        boolean boolean80 = year50.equals((java.lang.Object) day72);
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day72, (double) 13);
//        boolean boolean83 = timePeriodValue14.equals((java.lang.Object) day72);
//        java.lang.Number number84 = timePeriodValue14.getValue();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5L + "'", long9 == 5L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(timePeriod15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[2019,12]" + "'", str16.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,12]" + "'", str18.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 6 + "'", comparable26.equals(6));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 5L + "'", long30 == 5L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1562097599999L + "'", long32 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(timePeriod36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TimePeriodValue[2019,12]" + "'", str37.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560495599999L + "'", long42 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "2019" + "'", str58.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2019L + "'", long71 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 43629L + "'", long74 == 43629L);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560495599999L + "'", long76 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560409200000L + "'", long78 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + number84 + "' != '" + 12 + "'", number84.equals(12));
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0, "", "2019");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) 10);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setRangeDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) 100.0d);
        int int15 = year11.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year11, (double) '#');
        int int19 = timePeriodValues5.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, (long) 5);
//        long long3 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 12);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        java.lang.String str10 = timePeriodValue8.toString();
//        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue8);
//        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int16, "", "13-June-2019");
//        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues19);
//        java.lang.String str21 = timePeriodValues19.getDomainDescription();
//        int int22 = timePeriodValues19.getMaxStartIndex();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
//        int int27 = year24.getYear();
//        boolean boolean28 = day23.equals((java.lang.Object) year24);
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year24, (double) (byte) 1);
//        java.lang.String str31 = timePeriodValues19.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,12]" + "'", str10.equals("TimePeriodValue[2019,12]"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
//        java.lang.String str4 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        int int8 = year0.compareTo((java.lang.Object) day6);
//        java.lang.String str9 = day6.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
//        java.lang.Object obj11 = timePeriodValues10.clone();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.String str14 = timePeriodValues10.getRangeDescription();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 1L);
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date3, timeZone13);
        java.lang.Object obj16 = null;
        int int17 = year15.compareTo(obj16);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str20 = seriesException19.toString();
        java.lang.String str21 = seriesException19.toString();
        boolean boolean22 = year15.equals((java.lang.Object) str21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1530561599999L + "'", long11 == 1530561599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str20.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str21.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day3.getMonth();
//        long long6 = day3.getFirstMillisecond();
//        int int7 = day0.compareTo((java.lang.Object) long6);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 100.0d);
        int int4 = year0.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues5.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getMinStartIndex();
        java.lang.Class<?> wildcardClass11 = timePeriodValues5.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        long long19 = regularTimePeriod18.getMiddleMillisecond();
        java.util.Date date20 = regularTimePeriod18.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class25 = null;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getMonth();
        java.util.Date date28 = day26.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        int int32 = day31.getMonth();
        java.util.Date date33 = day31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date28, date33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.previous();
        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year41.previous();
        long long43 = regularTimePeriod42.getMiddleMillisecond();
        java.util.Date date44 = regularTimePeriod42.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date44, timeZone45);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        int int50 = year48.compareTo((java.lang.Object) 1L);
        java.util.Date date51 = year48.getStart();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year52.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.previous();
        java.lang.Class<?> wildcardClass55 = regularTimePeriod54.getClass();
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.previous();
        long long59 = regularTimePeriod58.getMiddleMillisecond();
        java.util.Date date60 = regularTimePeriod58.getEnd();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date60, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date51, timeZone61);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date51, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date28, timeZone64);
        java.util.TimeZone timeZone67 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date28, timeZone67);
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date28, timeZone69);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1530561599999L + "'", long19 == 1530561599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1530561599999L + "'", long43 == 1530561599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1530561599999L + "'", long59 == 1530561599999L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
    }
}

