import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries4);
        java.lang.Class<?> wildcardClass8 = timeSeries4.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.previous();
        long long13 = regularTimePeriod12.getMiddleMillisecond();
        java.util.Date date14 = regularTimePeriod12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1530561599999L + "'", long13 == 1530561599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str2 = fixedMillisecond1.toString();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        long long7 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5L + "'", long7 == 5L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
        java.lang.Comparable comparable15 = timeSeries3.getKey();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getFirstMillisecond();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year21 = month16.getYear();
        org.jfree.data.time.Year year22 = month16.getYear();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year22.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0d + "'", comparable15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(year22);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test005");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str10 = fixedMillisecond9.toString();
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond9.peg(calendar11);
//        java.lang.String str13 = fixedMillisecond9.toString();
//        boolean boolean14 = timeSeries7.equals((java.lang.Object) str13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Object obj16 = null;
//        int int17 = month15.compareTo(obj16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        int int21 = year20.getYear();
//        int int22 = day19.compareTo((java.lang.Object) year20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        java.lang.String str25 = day19.toString();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str29 = fixedMillisecond28.toString();
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond28.peg(calendar30);
//        java.lang.String str32 = fixedMillisecond28.toString();
//        boolean boolean33 = timeSeries26.equals((java.lang.Object) str32);
//        timeSeries26.removeAgedItems((long) (short) 0, false);
//        boolean boolean37 = month15.equals((java.lang.Object) (short) 0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str10.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str32.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        int int8 = year7.getYear();
//        int int9 = day6.compareTo((java.lang.Object) year7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 10.0f);
//        java.lang.String str12 = day6.toString();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        boolean boolean16 = year14.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.previous();
//        long long18 = regularTimePeriod17.getMiddleMillisecond();
//        java.util.Date date19 = regularTimePeriod17.getEnd();
//        timeSeries13.add(regularTimePeriod17, (java.lang.Number) (-1L), true);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
//        int int32 = month23.compareTo((java.lang.Object) long31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        long long35 = fixedMillisecond34.getMiddleMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond34.getFirstMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        int int39 = fixedMillisecond1.compareTo((java.lang.Object) month23);
//        java.util.Calendar calendar40 = null;
//        fixedMillisecond1.peg(calendar40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond1.previous();
//        long long43 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month48, (double) (-9999), true);
//        java.lang.Object obj52 = null;
//        boolean boolean53 = month48.equals(obj52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month48.previous();
//        boolean boolean55 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1530561599999L + "'", long18 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 5L + "'", long29 == 5L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 5L + "'", long31 == 5L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 5L + "'", long35 == 5L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 5L + "'", long37 == 5L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 5L + "'", long43 == 5L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, "Wed Dec 31 16:00:00 PST 1969", "10-June-2019");
        java.util.List list4 = timeSeries3.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str7 = fixedMillisecond6.toString();
        java.util.Date date8 = fixedMillisecond6.getTime();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        timeSeries3.setKey((java.lang.Comparable) month9);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.removeChangeListener(seriesChangeListener12);
        timeSeries3.setDescription("June 2019");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "June 2019", seriesChangeInfo16);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str2 = fixedMillisecond1.toString();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, "", "");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str10 = fixedMillisecond9.toString();
        java.util.Calendar calendar11 = null;
        fixedMillisecond9.peg(calendar11);
        java.lang.String str13 = fixedMillisecond9.toString();
        long long14 = fixedMillisecond9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Calendar calendar18 = null;
        fixedMillisecond9.peg(calendar18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5L + "'", long4 == 5L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str10.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.lang.String str5 = fixedMillisecond1.toString();
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5L + "'", long4 == 5L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str5.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries4);
        timeSeries1.removeAgedItems((long) '#', true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test013");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str10 = fixedMillisecond9.toString();
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond9.peg(calendar11);
//        java.lang.String str13 = fixedMillisecond9.toString();
//        boolean boolean14 = timeSeries7.equals((java.lang.Object) str13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Object obj16 = null;
//        int int17 = month15.compareTo(obj16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
//        double double19 = timeSeries7.getMinY();
//        java.lang.String str20 = timeSeries7.getRangeDescription();
//        java.lang.String str21 = timeSeries7.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str10.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        java.lang.String str9 = timeSeries3.getDescription();
        timeSeries3.setRangeDescription("hi!");
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        int int8 = timeSeries3.getItemCount();
        timeSeries3.setMaximumItemAge(1559372400000L);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month15, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        timeSeries14.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = year28.getYear();
        int int30 = day27.compareTo((java.lang.Object) year28);
        long long31 = year28.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        boolean boolean36 = timeSeriesDataItem33.equals((java.lang.Object) timeSeries35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.next();
        int int39 = timeSeriesDataItem33.compareTo((java.lang.Object) regularTimePeriod38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries3.addOrUpdate(timeSeriesDataItem33);
        java.lang.Number number42 = timeSeries3.getValue(0);
        timeSeries3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (-9999.0d) + "'", number42.equals((-9999.0d)));
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test016");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        int int6 = year5.getYear();
//        int int7 = day4.compareTo((java.lang.Object) year5);
//        long long8 = year5.getSerialIndex();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond10.getLastMillisecond(calendar12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        int int17 = day14.compareTo((java.lang.Object) year15);
//        long long18 = day14.getFirstMillisecond();
//        long long19 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) (-1));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) 11);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month28, (double) (-9999), true);
//        java.lang.Class class32 = timeSeries27.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str35 = fixedMillisecond34.toString();
//        java.util.Date date36 = fixedMillisecond34.getTime();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date36, timeZone37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class32);
//        int int40 = day14.compareTo((java.lang.Object) class39);
//        int int41 = fixedMillisecond10.compareTo((java.lang.Object) int40);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185942484L + "'", long13 == 1560185942484L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560150000000L + "'", long18 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str35.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        long long6 = month3.getSerialIndex();
        java.util.Date date7 = month3.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        java.lang.Class class11 = timeSeries2.getTimePeriodClass();
        double double12 = timeSeries2.getMaxY();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        int int16 = day13.compareTo((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 10.0f);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.lang.Object obj20 = null;
        int int21 = month19.compareTo(obj20);
        long long22 = month19.getSerialIndex();
        boolean boolean23 = timeSeriesDataItem18.equals((java.lang.Object) long22);
        timeSeriesDataItem18.setValue((java.lang.Number) 1.0d);
        java.lang.Number number26 = timeSeriesDataItem18.getValue();
        try {
            timeSeries2.add(timeSeriesDataItem18, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.0d + "'", number26.equals(1.0d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        int int8 = timeSeries3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener9);
        double double11 = timeSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month16, (double) (-9999), true);
        int int20 = timeSeries15.getItemCount();
        timeSeries15.setMaximumItemAge(1559372400000L);
        timeSeries15.clear();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month24);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries26.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        int int32 = day29.compareTo((java.lang.Object) year30);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo33 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day29, seriesChangeInfo33);
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day29);
        int int36 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-9999.0d) + "'", double11 == (-9999.0d));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        int int19 = day16.compareTo((java.lang.Object) year17);
        long long20 = year17.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.String str23 = timeSeries3.getDescription();
        int int24 = timeSeries3.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.createCopy(0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        boolean boolean10 = year8.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
//        long long12 = regularTimePeriod11.getMiddleMillisecond();
//        java.util.Date date13 = regularTimePeriod11.getEnd();
//        timeSeries7.add(regularTimePeriod11, (java.lang.Number) (-1L), true);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.lang.Object obj18 = null;
//        int int19 = month17.compareTo(obj18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getLastMillisecond(calendar24);
//        int int26 = month17.compareTo((java.lang.Object) long25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        long long29 = fixedMillisecond28.getMiddleMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond28.getFirstMillisecond(calendar30);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        int int39 = year38.getYear();
//        int int40 = day37.compareTo((java.lang.Object) year38);
//        long long41 = year38.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 1);
//        boolean boolean45 = fixedMillisecond28.equals((java.lang.Object) year38);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year38, "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=#]", "org.jfree.data.event.SeriesChangeEvent[source=#]");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1530561599999L + "'", long12 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5L + "'", long23 == 5L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 5L + "'", long25 == 5L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 5L + "'", long29 == 5L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 5L + "'", long31 == 5L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar1 = null;
        fixedMillisecond0.peg(calendar1);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test023");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = year11.getYear();
//        int int13 = day10.compareTo((java.lang.Object) year11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
//        boolean boolean16 = timeSeries3.getNotify();
//        double double17 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems(true);
//        int int20 = timeSeries3.getMaximumItemCount();
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        int int26 = year25.getYear();
//        int int27 = day24.compareTo((java.lang.Object) year25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 10.0f);
//        java.lang.String str30 = day24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day24.previous();
//        timeSeries3.update(regularTimePeriod31, (java.lang.Number) (-2649600000L));
//        long long34 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str37 = fixedMillisecond36.toString();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond36.getFirstMillisecond(calendar38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond36.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod40, (java.lang.Number) 1549007999999L);
//        try {
//            timeSeries3.add(timeSeriesDataItem42, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9999.0d) + "'", double17 == (-9999.0d));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str37.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 5L + "'", long39 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        int int19 = day16.compareTo((java.lang.Object) year17);
        long long20 = year17.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        boolean boolean25 = timeSeriesDataItem22.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.Year year28 = month26.getYear();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year28, (double) 10L, false);
        boolean boolean32 = timeSeries24.isEmpty();
        double double33 = timeSeries24.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str36 = fixedMillisecond35.toString();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond35.getFirstMillisecond(calendar37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond35.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod39, (java.lang.Number) 1549007999999L);
        timeSeriesDataItem41.setValue((java.lang.Number) 2019.0d);
        java.lang.Object obj44 = null;
        boolean boolean45 = timeSeriesDataItem41.equals(obj44);
        boolean boolean46 = timeSeries24.equals((java.lang.Object) timeSeriesDataItem41);
        java.lang.Number number47 = timeSeriesDataItem41.getValue();
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str36.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 5L + "'", long38 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 2019.0d + "'", number47.equals(2019.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, 2018);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        int int10 = day7.compareTo((java.lang.Object) year8);
        long long11 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        int int13 = month2.compareTo((java.lang.Object) timeSeries6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, 0.0d);
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getMiddleMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
        boolean boolean16 = timeSeries3.getNotify();
        double double17 = timeSeries3.getMaxY();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        int int22 = day19.compareTo((java.lang.Object) year20);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year20);
        double double24 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9999.0d) + "'", double17 == (-9999.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-9999.0d) + "'", double18 == (-9999.0d));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries2.removeChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str9 = fixedMillisecond8.toString();
        java.util.Calendar calendar10 = null;
        fixedMillisecond8.peg(calendar10);
        java.lang.String str12 = fixedMillisecond8.toString();
        long long13 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 'a');
        java.util.List list16 = timeSeries2.getItems();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str9.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str12.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5L + "'", long13 == 5L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(list16);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test030");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        timeSeries3.setDomainDescription("June 2019");
//        int int12 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month17, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener21);
//        timeSeries16.setDomainDescription("June 2019");
//        timeSeries16.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//        java.lang.Class<?> wildcardClass27 = timeSeries16.getClass();
//        java.lang.Comparable comparable28 = timeSeries16.getKey();
//        timeSeries16.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        int int37 = year36.getYear();
//        int int38 = day35.compareTo((java.lang.Object) year36);
//        long long39 = year36.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year36, (double) (short) 100);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) month48, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries47.removeChangeListener(seriesChangeListener52);
//        timeSeries47.setDomainDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        int int62 = year61.getYear();
//        int int63 = day60.compareTo((java.lang.Object) year61);
//        long long64 = year61.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries59.getDataItem((org.jfree.data.time.RegularTimePeriod) year61);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) year61);
//        long long67 = year61.getSerialIndex();
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (short) 1, year61);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        java.lang.String str70 = day69.toString();
//        int int71 = day69.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day69.previous();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month68, (org.jfree.data.time.RegularTimePeriod) day69);
//        timeSeries3.setKey((java.lang.Comparable) day69);
//        timeSeries3.setMaximumItemCount((int) ' ');
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 1.0d + "'", comparable28.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 2019L + "'", long64 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10-June-2019" + "'", str70.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 6 + "'", int71 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        java.util.Date date5 = regularTimePeriod3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        long long8 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1530561599999L + "'", long4 == 1530561599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329599999L + "'", long8 == 1546329599999L);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test032");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        boolean boolean6 = timeSeriesDataItem5.isSelected();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem5.getPeriod();
//        timeSeriesDataItem5.setValue((java.lang.Number) 24234L);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(2, 2018);
//        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) 2018);
//        java.lang.Number number14 = timeSeriesDataItem5.getValue();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month22, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries21.removeChangeListener(seriesChangeListener26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        int int30 = year29.getYear();
//        int int31 = day28.compareTo((java.lang.Object) year29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) year29, (org.jfree.data.time.RegularTimePeriod) year32);
//        boolean boolean34 = timeSeries21.getNotify();
//        double double35 = timeSeries21.getMaxY();
//        timeSeries21.removeAgedItems(true);
//        boolean boolean38 = day15.equals((java.lang.Object) timeSeries21);
//        int int39 = day15.getDayOfMonth();
//        long long40 = day15.getLastMillisecond();
//        java.lang.Object obj41 = null;
//        int int42 = day15.compareTo(obj41);
//        int int43 = timeSeriesDataItem5.compareTo(obj41);
//        java.lang.Number number44 = timeSeriesDataItem5.getValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 24234L + "'", number14.equals(24234L));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-9999.0d) + "'", double35 == (-9999.0d));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 24234L + "'", number44.equals(24234L));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str18 = fixedMillisecond17.toString();
        timeSeries15.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 9999);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
        long long27 = fixedMillisecond24.getLastMillisecond();
        java.util.Calendar calendar28 = null;
        fixedMillisecond24.peg(calendar28);
        boolean boolean30 = year21.equals((java.lang.Object) fixedMillisecond24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem31.getPeriod();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str18.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 5L + "'", long27 == 5L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        int int19 = day16.compareTo((java.lang.Object) year17);
        long long20 = year17.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        boolean boolean25 = timeSeriesDataItem22.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.Year year28 = month26.getYear();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year28, (double) 10L, false);
        boolean boolean32 = timeSeries24.isEmpty();
        double double33 = timeSeries24.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str36 = fixedMillisecond35.toString();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond35.getFirstMillisecond(calendar37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond35.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod39, (java.lang.Number) 1549007999999L);
        timeSeriesDataItem41.setValue((java.lang.Number) 2019.0d);
        java.lang.Object obj44 = null;
        boolean boolean45 = timeSeriesDataItem41.equals(obj44);
        boolean boolean46 = timeSeries24.equals((java.lang.Object) timeSeriesDataItem41);
        double double47 = timeSeries24.getMinY();
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str36.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 5L + "'", long38 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.0d + "'", double47 == 10.0d);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test035");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, "Wed Dec 31 16:00:00 PST 1969", "10-June-2019");
//        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (short) -1);
//        timeSeries3.add(timeSeriesDataItem10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener12);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        int int20 = year19.getYear();
//        int int21 = day18.compareTo((java.lang.Object) year19);
//        long long22 = year19.getSerialIndex();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) year19);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year19, "10-June-2019", "");
//        java.lang.String str27 = year19.toString();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, 1.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.previous();
        long long20 = regularTimePeriod19.getMiddleMillisecond();
        java.util.Date date21 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 5);
        long long26 = fixedMillisecond25.getMiddleMillisecond();
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond25.getFirstMillisecond(calendar27);
        long long29 = fixedMillisecond25.getFirstMillisecond();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) long29);
        long long31 = fixedMillisecond23.getMiddleMillisecond();
        java.lang.Number number32 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        timeSeries3.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1530561599999L + "'", long20 == 1530561599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 5L + "'", long28 == 5L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 5L + "'", long29 == 5L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329599999L + "'", long31 == 1546329599999L);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-9999.0d) + "'", number32.equals((-9999.0d)));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        long long3 = month0.getLastMillisecond();
        long long4 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str2 = fixedMillisecond1.toString();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        boolean boolean12 = timeSeries3.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.Year year16 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=9223372036854775807]");
        timeSeries3.clear();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        int int8 = timeSeries3.getItemCount();
        timeSeries3.setMaximumItemAge(1559372400000L);
        timeSeries3.clear();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = year18.getYear();
        int int20 = day17.compareTo((java.lang.Object) year18);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day17, seriesChangeInfo21);
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day17);
        int int24 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day17.next();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        int int3 = year1.compareTo((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test043");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        timeSeries3.setDomainDescription("June 2019");
//        java.lang.Class class12 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        long long15 = day13.getFirstMillisecond();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        boolean boolean18 = year16.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.previous();
//        long long20 = regularTimePeriod19.getMiddleMillisecond();
//        java.util.Date date21 = regularTimePeriod19.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        boolean boolean23 = day13.equals((java.lang.Object) date21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date21);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date21, timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        boolean boolean30 = year28.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year28.previous();
//        long long32 = regularTimePeriod31.getMiddleMillisecond();
//        java.util.Date date33 = regularTimePeriod31.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33);
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date33, timeZone37);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1530561599999L + "'", long20 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1530561599999L + "'", long32 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = year11.getYear();
//        int int13 = day10.compareTo((java.lang.Object) year11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str18 = fixedMillisecond17.toString();
//        timeSeries15.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 9999);
//        boolean boolean21 = timeSeries15.isEmpty();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        int int24 = year23.getYear();
//        int int25 = day22.compareTo((java.lang.Object) year23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.String str28 = day22.toString();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str32 = fixedMillisecond31.toString();
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond31.peg(calendar33);
//        java.lang.String str35 = fixedMillisecond31.toString();
//        boolean boolean36 = timeSeries29.equals((java.lang.Object) str35);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        java.lang.Object obj38 = null;
//        int int39 = month37.compareTo(obj38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
//        long long42 = timeSeries15.getMaximumItemAge();
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
//        long long44 = month43.getFirstMillisecond();
//        java.util.Date date45 = month43.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month43.previous();
//        java.lang.Number number47 = null;
//        try {
//            timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month43, number47);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str18.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str32.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str35.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1559372400000L + "'", long44 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        int int8 = day5.compareTo((java.lang.Object) year6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day5, seriesChangeInfo9);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day5);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener12);
        java.lang.Object obj14 = timeSeries2.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560185942484L);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month7, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener11);
//        timeSeries6.setDomainDescription("June 2019");
//        timeSeries6.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//        java.lang.Class<?> wildcardClass17 = timeSeries6.getClass();
//        java.util.List list18 = timeSeries6.getItems();
//        java.lang.Number number20 = timeSeries6.getValue(0);
//        int int21 = day0.compareTo((java.lang.Object) number20);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(list18);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-9999.0d) + "'", number20.equals((-9999.0d)));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
        boolean boolean16 = timeSeries3.getNotify();
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.previous();
        long long25 = regularTimePeriod24.getMiddleMillisecond();
        java.util.Date date26 = regularTimePeriod24.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 28799999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1530561599999L + "'", long25 == 1530561599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        boolean boolean12 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy(1, 9999);
        double double18 = timeSeries17.getMinY();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        int int8 = day5.compareTo((java.lang.Object) year6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day5, seriesChangeInfo9);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day5);
        java.lang.String str12 = timeSeries2.getDescription();
        int int13 = timeSeries2.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
        java.lang.Comparable comparable15 = timeSeries3.getKey();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getFirstMillisecond();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year21 = month16.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = month16.compareTo((java.lang.Object) year22);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0d + "'", comparable15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        long long4 = day0.getFirstMillisecond();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        int int7 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 10.0f);
        java.lang.Class<?> wildcardClass7 = timeSeriesDataItem6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem6.getPeriod();
        boolean boolean9 = timeSeriesDataItem6.isSelected();
        java.lang.Number number10 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0d + "'", number10.equals(10.0d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        long long6 = month3.getSerialIndex();
        java.util.Date date7 = month3.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month15, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        int int24 = day21.compareTo((java.lang.Object) year22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year25);
        java.util.Date date27 = year22.getStart();
        boolean boolean28 = month8.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27);
        int int31 = day30.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test057");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getMonth();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) '#', seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent2.getSummary();
        java.lang.String str5 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=#]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=#]"));
        org.junit.Assert.assertNull(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=#]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=#]"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str2 = fixedMillisecond1.toString();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        java.lang.String str6 = month4.toString();
        java.lang.Object obj7 = null;
        boolean boolean8 = month4.equals(obj7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month4.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "December 1969" + "'", str6.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        int int3 = day0.compareTo((java.lang.Object) year1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0f + "'", number6.equals(10.0f));
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test061");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        timeSeries3.setDomainDescription("10-June-2019");
//        java.lang.String str12 = timeSeries3.getDomainDescription();
//        timeSeries3.removeAgedItems(false);
//        boolean boolean15 = timeSeries3.getNotify();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        long long17 = month16.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16);
//        int int19 = timeSeries18.getMaximumItemCount();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        int int22 = year21.getYear();
//        int int23 = day20.compareTo((java.lang.Object) year21);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day20, seriesChangeInfo24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day20.previous();
//        int int27 = day20.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.previous();
//        long long33 = regularTimePeriod32.getMiddleMillisecond();
//        java.util.Date date34 = regularTimePeriod32.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond37.next();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
//        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) month43, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
//        timeSeries42.removeChangeListener(seriesChangeListener47);
//        timeSeries42.setDomainDescription("June 2019");
//        timeSeries42.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//        java.lang.Class<?> wildcardClass53 = timeSeries42.getClass();
//        java.lang.Comparable comparable54 = timeSeries42.getKey();
//        timeSeries42.setMaximumItemCount((int) (short) 0);
//        int int57 = fixedMillisecond37.compareTo((java.lang.Object) timeSeries42);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        int int60 = year59.getYear();
//        int int61 = day58.compareTo((java.lang.Object) year59);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo62 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent63 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day58, seriesChangeInfo62);
//        java.lang.String str64 = day58.toString();
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
//        timeSeries68.add((org.jfree.data.time.RegularTimePeriod) month69, (double) (-9999), true);
//        java.util.Date date73 = month69.getStart();
//        boolean boolean74 = day58.equals((java.lang.Object) month69);
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day58);
//        timeSeries3.setKey((java.lang.Comparable) day58);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1530561599999L + "'", long33 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + 1.0d + "'", comparable54.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10-June-2019" + "'", str64.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(timeSeries75);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test062");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        timeSeries3.setDomainDescription("June 2019");
//        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
//        java.lang.Comparable comparable15 = timeSeries3.getKey();
//        timeSeries3.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month22, (double) (-9999), true);
//        int int26 = month22.getYearValue();
//        int int27 = month22.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener36);
//        timeSeries31.setDomainDescription("10-June-2019");
//        timeSeries31.setNotify(false);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        int int45 = month22.compareTo((java.lang.Object) day42);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener54 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener54);
//        timeSeries49.setDomainDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
//        int int64 = year63.getYear();
//        int int65 = day62.compareTo((java.lang.Object) year63);
//        long long66 = year63.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries61.getDataItem((org.jfree.data.time.RegularTimePeriod) year63);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) year63);
//        java.lang.Object obj69 = timeSeriesDataItem68.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = timeSeriesDataItem68.getPeriod();
//        java.lang.Object obj71 = timeSeriesDataItem68.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = timeSeriesDataItem68.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day42, regularTimePeriod72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = day42.previous();
//        long long75 = day42.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0d + "'", comparable15.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(obj69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(obj71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560236399999L + "'", long75 == 1560236399999L);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month20, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries19.removeChangeListener(seriesChangeListener24);
        timeSeries19.setDomainDescription("June 2019");
        timeSeries19.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass30 = timeSeries19.getClass();
        java.lang.Comparable comparable31 = timeSeries19.getKey();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        long long33 = month32.getFirstMillisecond();
        java.util.Date date34 = month32.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) month32, (org.jfree.data.time.RegularTimePeriod) year35);
        org.jfree.data.time.Year year37 = month32.getYear();
        timeSeries15.setKey((java.lang.Comparable) year37);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 1.0d + "'", comparable31.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1559372400000L + "'", long33 == 1559372400000L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(year37);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        int int19 = day16.compareTo((java.lang.Object) year17);
        long long20 = year17.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        boolean boolean25 = timeSeriesDataItem22.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.Year year28 = month26.getYear();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year28, (double) 10L, false);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        int int38 = year37.getYear();
        int int39 = day36.compareTo((java.lang.Object) year37);
        long long40 = year37.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year37);
        long long42 = year37.getSerialIndex();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year37, (org.jfree.data.time.RegularTimePeriod) day45);
        int int47 = year37.getYear();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month52, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries51.removeChangeListener(seriesChangeListener56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        int int60 = year59.getYear();
        int int61 = day58.compareTo((java.lang.Object) year59);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) year59, (org.jfree.data.time.RegularTimePeriod) year62);
        int int64 = timeSeries51.getItemCount();
        int int65 = year37.compareTo((java.lang.Object) int64);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str10 = fixedMillisecond9.toString();
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond9.peg(calendar11);
//        java.lang.String str13 = fixedMillisecond9.toString();
//        boolean boolean14 = timeSeries7.equals((java.lang.Object) str13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Object obj16 = null;
//        int int17 = month15.compareTo(obj16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries7.setDescription("");
//        timeSeries7.setNotify(true);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str10.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, "Wed Dec 31 16:00:00 PST 1969", "10-June-2019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day4, 100.0d);
//        long long8 = day4.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day4.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = year11.getYear();
//        int int13 = day10.compareTo((java.lang.Object) year11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str18 = fixedMillisecond17.toString();
//        timeSeries15.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 9999);
//        boolean boolean21 = timeSeries15.isEmpty();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        int int24 = year23.getYear();
//        int int25 = day22.compareTo((java.lang.Object) year23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        java.lang.String str28 = day22.toString();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str32 = fixedMillisecond31.toString();
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond31.peg(calendar33);
//        java.lang.String str35 = fixedMillisecond31.toString();
//        boolean boolean36 = timeSeries29.equals((java.lang.Object) str35);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        java.lang.Object obj38 = null;
//        int int39 = month37.compareTo(obj38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
//        boolean boolean43 = timeSeriesDataItem41.equals((java.lang.Object) 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str18.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str32.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str35.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        int int2 = year1.getYear();
        int int3 = year1.getYear();
        java.util.Date date4 = year1.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        int int3 = day0.compareTo((java.lang.Object) year1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.Object obj7 = null;
        int int8 = month6.compareTo(obj7);
        long long9 = month6.getSerialIndex();
        boolean boolean10 = timeSeriesDataItem5.equals((java.lang.Object) long9);
        timeSeriesDataItem5.setValue((java.lang.Number) 1.0d);
        java.lang.Number number13 = timeSeriesDataItem5.getValue();
        java.lang.Number number14 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24234L + "'", long9 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        long long6 = month3.getSerialIndex();
        java.util.Date date7 = month3.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        int int14 = day11.compareTo((java.lang.Object) year12);
        int int15 = month8.compareTo((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
        java.lang.Comparable comparable15 = timeSeries3.getKey();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getFirstMillisecond();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year21 = month16.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        long long23 = month22.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = year28.getYear();
        int int30 = day27.compareTo((java.lang.Object) year28);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo31 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day27, seriesChangeInfo31);
        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day27);
        boolean boolean34 = year21.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getFirstMillisecond(calendar37);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond36.getFirstMillisecond(calendar39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond36.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries24.addOrUpdate(regularTimePeriod41, (double) (byte) 0);
        timeSeries24.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getFirstMillisecond(calendar48);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getFirstMillisecond(calendar50);
        long long52 = fixedMillisecond47.getFirstMillisecond();
        java.lang.String str53 = fixedMillisecond47.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) (-62167363200000L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond47.previous();
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0d + "'", comparable15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 5L + "'", long38 == 5L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 5L + "'", long40 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 5L + "'", long49 == 5L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 5L + "'", long51 == 5L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 5L + "'", long52 == 5L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str53.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test072");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        int int8 = month4.getYearValue();
//        int int9 = month4.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries13.removeChangeListener(seriesChangeListener18);
//        timeSeries13.setDomainDescription("10-June-2019");
//        timeSeries13.setNotify(false);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day24);
//        int int27 = month4.compareTo((java.lang.Object) day24);
//        int int28 = day24.getDayOfMonth();
//        int int29 = day24.getDayOfMonth();
//        java.util.Date date30 = day24.getEnd();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(date30);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        java.lang.String str9 = timeSeries3.getDescription();
        java.util.List list10 = timeSeries3.getItems();
        java.lang.String str11 = timeSeries3.getDomainDescription();
        timeSeries3.setMaximumItemAge((long) 8);
        java.lang.Comparable comparable14 = timeSeries3.getKey();
        java.util.List list15 = timeSeries3.getItems();
        boolean boolean16 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 1.0d + "'", comparable14.equals(1.0d));
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(3, 1969);
        java.util.Date date3 = month2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.previous();
        int int16 = year12.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.previous();
        timeSeries3.delete(regularTimePeriod19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) month25, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries24.removeChangeListener(seriesChangeListener29);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries24.addChangeListener(seriesChangeListener31);
        java.lang.Number number34 = timeSeries24.getValue((int) (byte) 0);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=#]");
        boolean boolean37 = timeSeries24.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=#]");
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries41.removeChangeListener(seriesChangeListener46);
        timeSeries41.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int56 = year55.getYear();
        int int57 = day54.compareTo((java.lang.Object) year55);
        long long58 = year55.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries53.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
        java.lang.Object obj61 = null;
        boolean boolean62 = timeSeriesDataItem60.equals(obj61);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries24.addOrUpdate(timeSeriesDataItem60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries3.addOrUpdate(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-9999.0d) + "'", number34.equals((-9999.0d)));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        int int7 = day4.compareTo((java.lang.Object) year5);
        long long8 = year5.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year5);
        java.lang.Object obj10 = null;
        int int11 = year5.compareTo(obj10);
        long long12 = year5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str10 = fixedMillisecond9.toString();
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond9.peg(calendar11);
//        java.lang.String str13 = fixedMillisecond9.toString();
//        boolean boolean14 = timeSeries7.equals((java.lang.Object) str13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Object obj16 = null;
//        int int17 = month15.compareTo(obj16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries7.setDescription("");
//        java.lang.String str21 = timeSeries7.getDescription();
//        int int22 = timeSeries7.getItemCount();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        long long24 = month23.getMiddleMillisecond();
//        long long25 = month23.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
//        int int27 = timeSeries7.getMaximumItemCount();
//        int int28 = timeSeries7.getItemCount();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str10.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
        java.lang.Comparable comparable15 = timeSeries3.getKey();
        int int16 = timeSeries3.getMaximumItemCount();
        java.lang.String str17 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int20 = year19.getYear();
        int int21 = day18.compareTo((java.lang.Object) year19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 10.0f);
        boolean boolean24 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem23.getPeriod();
        timeSeriesDataItem23.setValue((java.lang.Number) 24234L);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries3.addOrUpdate(timeSeriesDataItem23);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0d + "'", comparable15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month22, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries21.removeChangeListener(seriesChangeListener26);
        timeSeries21.setDomainDescription("10-June-2019");
        java.lang.String str30 = timeSeries21.getDomainDescription();
        java.lang.Class class31 = timeSeries21.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str34 = fixedMillisecond33.toString();
        java.util.Date date35 = fixedMillisecond33.getTime();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date35, timeZone37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date35);
        long long40 = fixedMillisecond39.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond39.previous();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str34.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 5L + "'", long40 == 5L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        int int8 = timeSeries3.getItemCount();
        timeSeries3.setMaximumItemAge(1559372400000L);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month15, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        timeSeries14.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = year28.getYear();
        int int30 = day27.compareTo((java.lang.Object) year28);
        long long31 = year28.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        boolean boolean36 = timeSeriesDataItem33.equals((java.lang.Object) timeSeries35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.next();
        int int39 = timeSeriesDataItem33.compareTo((java.lang.Object) regularTimePeriod38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries3.addOrUpdate(timeSeriesDataItem33);
        long long41 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, "Wed Dec 31 16:00:00 PST 1969", "10-June-2019");
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate47 = day46.getSerialDate();
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) day46, 100.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond51.getMiddleMillisecond(calendar52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond51.next();
        int int55 = timeSeries45.getIndex(regularTimePeriod54);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries45.removeChangeListener(seriesChangeListener56);
        timeSeries45.removeAgedItems(1560150000000L, false);
        java.util.Collection collection61 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries45);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1559372400000L + "'", long41 == 1559372400000L);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 5L + "'", long53 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(collection61);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month16, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries15.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        int int25 = day22.compareTo((java.lang.Object) year23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) year26);
        boolean boolean28 = timeSeries15.getNotify();
        timeSeries15.setDescription("");
        timeSeries15.setDomainDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month37, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries36.removeChangeListener(seriesChangeListener41);
        timeSeries36.setDomainDescription("June 2019");
        timeSeries36.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass47 = timeSeries36.getClass();
        java.lang.Comparable comparable48 = timeSeries36.getKey();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        long long50 = month49.getFirstMillisecond();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) month49, (org.jfree.data.time.RegularTimePeriod) year52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar56 = null;
        long long57 = fixedMillisecond55.getFirstMillisecond(calendar56);
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year52, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar61 = null;
        long long62 = fixedMillisecond60.getMiddleMillisecond(calendar61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        boolean boolean65 = year63.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year63.previous();
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (org.jfree.data.time.RegularTimePeriod) year63);
        java.util.Collection collection68 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries67);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
        timeSeries72.add((org.jfree.data.time.RegularTimePeriod) month73, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener77 = null;
        timeSeries72.removeChangeListener(seriesChangeListener77);
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        int int81 = year80.getYear();
        int int82 = day79.compareTo((java.lang.Object) year80);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries72.createCopy((org.jfree.data.time.RegularTimePeriod) year80, (org.jfree.data.time.RegularTimePeriod) year83);
        java.util.Date date85 = year80.getStart();
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date85);
        org.jfree.data.time.Month month87 = new org.jfree.data.time.Month();
        long long88 = month87.getFirstMillisecond();
        org.jfree.data.time.Year year89 = month87.getYear();
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day86, (org.jfree.data.time.RegularTimePeriod) month87);
        java.lang.Number number92 = timeSeries90.getValue(0);
        java.lang.Class class93 = timeSeries90.getTimePeriodClass();
        try {
            java.lang.Number number95 = timeSeries90.getValue(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + 1.0d + "'", comparable48.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 5L + "'", long57 == 5L);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 5L + "'", long62 == 5L);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertNotNull(collection68);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2019 + "'", int81 == 2019);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1559372400000L + "'", long88 == 1559372400000L);
        org.junit.Assert.assertNotNull(year89);
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertTrue("'" + number92 + "' != '" + (-9999.0d) + "'", number92.equals((-9999.0d)));
        org.junit.Assert.assertNotNull(class93);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        long long6 = month3.getSerialIndex();
        java.util.Date date7 = month3.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        java.lang.Class class11 = timeSeries2.getTimePeriodClass();
        double double12 = timeSeries2.getMaxY();
        java.lang.String str13 = timeSeries2.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
        long long18 = fixedMillisecond15.getLastMillisecond();
        java.util.Calendar calendar19 = null;
        fixedMillisecond15.peg(calendar19);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond15.getFirstMillisecond(calendar21);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond15.getMiddleMillisecond(calendar23);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond15.getMiddleMillisecond(calendar25);
        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 5L + "'", long18 == 5L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 5L + "'", long22 == 5L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, "Wed Dec 31 16:00:00 PST 1969", "10-June-2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day4, 100.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        int int13 = timeSeries3.getIndex(regularTimePeriod12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.addChangeListener(seriesChangeListener14);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = year11.getYear();
//        int int13 = day10.compareTo((java.lang.Object) year11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
//        boolean boolean16 = timeSeries3.getNotify();
//        double double17 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems(true);
//        int int20 = timeSeries3.getMaximumItemCount();
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        int int26 = year25.getYear();
//        int int27 = day24.compareTo((java.lang.Object) year25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 10.0f);
//        java.lang.String str30 = day24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day24.previous();
//        timeSeries3.update(regularTimePeriod31, (java.lang.Number) (-2649600000L));
//        java.util.List list34 = timeSeries3.getItems();
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9999.0d) + "'", double17 == (-9999.0d));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(list34);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        int int2 = year1.getYear();
        int int3 = year1.getYear();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
        java.lang.Comparable comparable15 = timeSeries3.getKey();
        int int16 = timeSeries3.getMaximumItemCount();
        java.lang.String str17 = timeSeries3.getDomainDescription();
        java.lang.Number number19 = timeSeries3.getValue(0);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0d + "'", comparable15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-9999.0d) + "'", number19.equals((-9999.0d)));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        boolean boolean12 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemCount(0);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries3.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.lang.Object obj21 = null;
        int int22 = month20.compareTo(obj21);
        long long23 = month20.getSerialIndex();
        java.util.Date date24 = month20.getEnd();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month25, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries31.removeChangeListener(seriesChangeListener36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int40 = year39.getYear();
        int int41 = day38.compareTo((java.lang.Object) year39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year42);
        java.util.Date date44 = year39.getStart();
        boolean boolean45 = month25.equals((java.lang.Object) date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month49, (double) 31);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 24234L + "'", long23 == 24234L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        int int19 = day16.compareTo((java.lang.Object) year17);
        long long20 = year17.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        boolean boolean25 = timeSeriesDataItem22.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
        int int28 = timeSeriesDataItem22.compareTo((java.lang.Object) regularTimePeriod27);
        java.lang.Number number29 = timeSeriesDataItem22.getValue();
        boolean boolean30 = timeSeriesDataItem22.isSelected();
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-9999.0d) + "'", number29.equals((-9999.0d)));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries4);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        long long4 = year1.getSerialIndex();
//        long long5 = year1.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month10, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries9.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        boolean boolean20 = year18.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.previous();
//        int int22 = year18.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) 10.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year18.previous();
//        timeSeries9.delete(regularTimePeriod25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month31);
//        int int34 = timeSeries33.getMaximumItemCount();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        int int37 = year36.getYear();
//        int int38 = day35.compareTo((java.lang.Object) year36);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo39 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day35, seriesChangeInfo39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day35.previous();
//        int int42 = day35.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        boolean boolean46 = year44.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year44.previous();
//        long long48 = regularTimePeriod47.getMiddleMillisecond();
//        java.util.Date date49 = regularTimePeriod47.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond52.next();
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
//        timeSeries57.add((org.jfree.data.time.RegularTimePeriod) month58, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener62 = null;
//        timeSeries57.removeChangeListener(seriesChangeListener62);
//        timeSeries57.setDomainDescription("June 2019");
//        timeSeries57.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//        java.lang.Class<?> wildcardClass68 = timeSeries57.getClass();
//        java.lang.Comparable comparable69 = timeSeries57.getKey();
//        timeSeries57.setMaximumItemCount((int) (short) 0);
//        int int72 = fixedMillisecond52.compareTo((java.lang.Object) timeSeries57);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
//        int int75 = year74.getYear();
//        int int76 = day73.compareTo((java.lang.Object) year74);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo77 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent78 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day73, seriesChangeInfo77);
//        java.lang.String str79 = day73.toString();
//        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month();
//        timeSeries83.add((org.jfree.data.time.RegularTimePeriod) month84, (double) (-9999), true);
//        java.util.Date date88 = month84.getStart();
//        boolean boolean89 = day73.equals((java.lang.Object) month84);
//        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day73);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day73, (double) (-9999));
//        int int93 = year1.compareTo((java.lang.Object) timeSeries9);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560185946530L + "'", long29 == 1560185946530L);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1559372400000L + "'", long32 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2147483647 + "'", int34 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1530561599999L + "'", long48 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 1.0d + "'", comparable69.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "10-June-2019" + "'", str79.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(timeSeries90);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        timeSeries3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener14);
        java.lang.Comparable comparable16 = timeSeries3.getKey();
        java.util.Collection collection17 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1.0d + "'", comparable16.equals(1.0d));
        org.junit.Assert.assertNotNull(collection17);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getLastMillisecond();
//        int int5 = day3.getYear();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 8);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]", "org.jfree.data.general.SeriesException: ");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.Object obj6 = null;
        int int7 = month5.compareTo(obj6);
        long long8 = month5.getSerialIndex();
        java.util.Date date9 = month5.getEnd();
        org.jfree.data.time.Year year10 = month5.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1560668399999L);
        boolean boolean13 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.lang.String str3 = month0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560185901614L, "June 2019", "31-December-1969");
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        timeSeries3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener14);
        int int16 = timeSeries3.getItemCount();
        java.util.List list17 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getLastMillisecond();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5L + "'", long4 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5L + "'", long7 == 5L);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6);
//        timeSeries7.setMaximumItemAge(24234L);
//        timeSeries7.removeAgedItems(1559372400000L, true);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = timeSeries7.equals(obj13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        long long6 = month3.getSerialIndex();
        java.util.Date date7 = month3.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month15, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        int int24 = day21.compareTo((java.lang.Object) year22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year25);
        java.util.Date date27 = year22.getStart();
        boolean boolean28 = month8.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date27);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = day31.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test101");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, "Wed Dec 31 16:00:00 PST 1969", "10-June-2019");
//        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (short) -1);
//        timeSeries3.add(timeSeriesDataItem10);
//        timeSeriesDataItem10.setValue((java.lang.Number) 1560185904515L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        boolean boolean12 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemCount(0);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod16, 0.0d);
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        timeSeries3.add(timeSeriesDataItem18, false);
        boolean boolean22 = timeSeriesDataItem18.isSelected();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test103");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.String str10 = fixedMillisecond9.toString();
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond9.peg(calendar11);
//        java.lang.String str13 = fixedMillisecond9.toString();
//        boolean boolean14 = timeSeries7.equals((java.lang.Object) str13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Object obj16 = null;
//        int int17 = month15.compareTo(obj16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries7.setDescription("");
//        java.lang.String str21 = timeSeries7.getDescription();
//        int int22 = timeSeries7.getItemCount();
//        timeSeries7.setRangeDescription("Value");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str10.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test104");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = year11.getYear();
//        int int13 = day10.compareTo((java.lang.Object) year11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
//        boolean boolean16 = timeSeries3.getNotify();
//        double double17 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems(true);
//        int int20 = timeSeries3.getMaximumItemCount();
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        int int26 = year25.getYear();
//        int int27 = day24.compareTo((java.lang.Object) year25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 10.0f);
//        java.lang.String str30 = day24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day24.previous();
//        timeSeries3.update(regularTimePeriod31, (java.lang.Number) (-2649600000L));
//        long long34 = timeSeries3.getMaximumItemAge();
//        timeSeries3.setMaximumItemAge(100L);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener37);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9999.0d) + "'", double17 == (-9999.0d));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        long long4 = day0.getFirstMillisecond();
//        long long5 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1));
//        java.lang.Object obj8 = timeSeriesDataItem7.clone();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent(obj8, seriesChangeInfo9);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertNotNull(obj8);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        java.util.Date date2 = year1.getStart();
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test108");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        timeSeries3.setDomainDescription("10-June-2019");
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        timeSeries3.setKey((java.lang.Comparable) str13);
//        java.lang.Class<?> wildcardClass15 = timeSeries3.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener16);
//        java.lang.Comparable comparable18 = timeSeries3.getKey();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        long long20 = month19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        java.lang.Object obj23 = null;
//        int int24 = month22.compareTo(obj23);
//        long long25 = month22.getSerialIndex();
//        java.util.Date date26 = month22.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month34, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries33.removeChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = year41.getYear();
//        int int43 = day40.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) year41, (org.jfree.data.time.RegularTimePeriod) year44);
//        java.util.Date date46 = year41.getStart();
//        boolean boolean47 = month27.equals((java.lang.Object) date46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date46);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 1549007999999L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "10-June-2019" + "'", comparable18.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond3.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        fixedMillisecond3.peg(calendar7);
        boolean boolean9 = year0.equals((java.lang.Object) fixedMillisecond3);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
        boolean boolean16 = timeSeriesDataItem15.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem15.getPeriod();
        int int18 = fixedMillisecond3.compareTo((java.lang.Object) regularTimePeriod17);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        int int26 = day23.compareTo((java.lang.Object) year24);
        long long27 = year24.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.String str29 = year24.toString();
        java.util.Date date30 = year24.getStart();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int37 = year36.getYear();
        int int38 = day35.compareTo((java.lang.Object) year36);
        long long39 = year36.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) year36);
        long long41 = year36.getLastMillisecond();
        int int42 = year36.getYear();
        long long43 = year36.getLastMillisecond();
        int int44 = year24.compareTo((java.lang.Object) long43);
        int int45 = fixedMillisecond3.compareTo((java.lang.Object) long43);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
        java.lang.Comparable comparable15 = timeSeries3.getKey();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getFirstMillisecond();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year21 = month16.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        long long23 = month22.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = year28.getYear();
        int int30 = day27.compareTo((java.lang.Object) year28);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo31 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day27, seriesChangeInfo31);
        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day27);
        boolean boolean34 = year21.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getFirstMillisecond(calendar37);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond36.getFirstMillisecond(calendar39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond36.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries24.addOrUpdate(regularTimePeriod41, (double) (byte) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond44.next();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) (-62167363200000L), true);
        boolean boolean49 = timeSeries24.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeries24.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0d + "'", comparable15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 5L + "'", long38 == 5L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 5L + "'", long40 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener8);
        timeSeries3.setNotify(false);
        java.lang.Object obj12 = timeSeries3.clone();
        java.lang.Class class13 = timeSeries3.getTimePeriodClass();
        double double14 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-9999.0d) + "'", double14 == (-9999.0d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
        boolean boolean16 = timeSeries3.getNotify();
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) month25, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries24.removeChangeListener(seriesChangeListener29);
        timeSeries24.setDomainDescription("June 2019");
        timeSeries24.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        java.lang.Class<?> wildcardClass35 = timeSeries24.getClass();
        java.lang.Comparable comparable36 = timeSeries24.getKey();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        long long38 = month37.getFirstMillisecond();
        java.util.Date date39 = month37.getEnd();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) year40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getFirstMillisecond(calendar44);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str49 = fixedMillisecond48.toString();
        java.util.Date date50 = fixedMillisecond48.getTime();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date50);
        long long52 = month51.getFirstMillisecond();
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month51, (double) 2147483647, false);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month((int) (byte) 1, (int) (short) 0);
        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) month58);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 1.0d + "'", comparable36.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 5L + "'", long45 == 5L);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str49.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2649600000L) + "'", long52 == (-2649600000L));
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        int int3 = day0.compareTo((java.lang.Object) year1);
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getMonth();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        boolean boolean5 = year3.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
//        long long7 = regularTimePeriod6.getMiddleMillisecond();
//        java.util.Date date8 = regularTimePeriod6.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        boolean boolean10 = day0.equals((java.lang.Object) date8);
//        int int11 = day0.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month16, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        int int24 = year23.getYear();
//        int int25 = day22.compareTo((java.lang.Object) year23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) year26);
//        boolean boolean28 = timeSeries15.getNotify();
//        double double29 = timeSeries15.getMaxY();
//        timeSeries15.removeAgedItems(true);
//        java.util.Collection collection32 = timeSeries15.getTimePeriods();
//        timeSeries15.setNotify(true);
//        boolean boolean35 = day0.equals((java.lang.Object) true);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1530561599999L + "'", long7 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-9999.0d) + "'", double29 == (-9999.0d));
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
        boolean boolean16 = timeSeries3.getNotify();
        double double17 = timeSeries3.getMaxY();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.previous();
        long long22 = regularTimePeriod21.getMiddleMillisecond();
        java.util.Date date23 = regularTimePeriod21.getEnd();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 2019.0d, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9999.0d) + "'", double17 == (-9999.0d));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1530561599999L + "'", long22 == 1530561599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test116");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        timeSeries3.setDomainDescription("10-June-2019");
//        java.lang.String str12 = timeSeries3.getDomainDescription();
//        java.lang.Class class13 = timeSeries3.getTimePeriodClass();
//        java.lang.Object obj14 = timeSeries3.clone();
//        boolean boolean15 = timeSeries3.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        long long18 = fixedMillisecond17.getMiddleMillisecond();
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond17.peg(calendar19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = day21.toString();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) day21);
//        java.util.Date date25 = fixedMillisecond17.getEnd();
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 5L + "'", long18 == 5L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month8, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries7.removeChangeListener(seriesChangeListener12);
        timeSeries7.setDomainDescription("10-June-2019");
        java.lang.String str16 = timeSeries7.getDomainDescription();
        java.lang.Class class17 = timeSeries7.getTimePeriodClass();
        boolean boolean18 = month0.equals((java.lang.Object) timeSeries7);
        boolean boolean19 = timeSeries7.getNotify();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        int int3 = year1.compareTo((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        java.lang.String str5 = regularTimePeriod4.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 09:58:27 PDT 2019");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Mon Jun 10 09:58:27 PDT 2019" + "'", str2.equals("org.jfree.data.general.SeriesException: Mon Jun 10 09:58:27 PDT 2019"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("June 2019");
        boolean boolean12 = timeSeries3.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.Year year16 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        long long18 = month14.getFirstMillisecond();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month14.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        int int3 = day0.compareTo((java.lang.Object) year1);
        long long4 = year1.getSerialIndex();
        long long5 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("10-June-2019");
        boolean boolean12 = timeSeries3.getNotify();
        timeSeries3.setNotify(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries3.getTimePeriod(0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 10.0f);
        timeSeriesDataItem6.setValue((java.lang.Number) (short) 10);
        java.lang.Object obj9 = timeSeriesDataItem6.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        long long6 = month3.getSerialIndex();
        java.util.Date date7 = month3.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month15, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        int int24 = day21.compareTo((java.lang.Object) year22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year25);
        java.util.Date date27 = year22.getStart();
        boolean boolean28 = month8.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date27);
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date34);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test125");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        timeSeries3.setDomainDescription("June 2019");
//        timeSeries3.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
//        java.lang.Comparable comparable15 = timeSeries3.getKey();
//        timeSeries3.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month22, (double) (-9999), true);
//        int int26 = month22.getYearValue();
//        int int27 = month22.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month32, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener36);
//        timeSeries31.setDomainDescription("10-June-2019");
//        timeSeries31.setNotify(false);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        int int45 = month22.compareTo((java.lang.Object) day42);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month50, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener54 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener54);
//        timeSeries49.setDomainDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
//        int int64 = year63.getYear();
//        int int65 = day62.compareTo((java.lang.Object) year63);
//        long long66 = year63.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries61.getDataItem((org.jfree.data.time.RegularTimePeriod) year63);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) year63);
//        java.lang.Object obj69 = timeSeriesDataItem68.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = timeSeriesDataItem68.getPeriod();
//        java.lang.Object obj71 = timeSeriesDataItem68.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = timeSeriesDataItem68.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day42, regularTimePeriod72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = day42.previous();
//        long long75 = day42.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1.0d + "'", comparable15.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(obj69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(obj71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560193199999L + "'", long75 == 1560193199999L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5L + "'", long8 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test127");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        int int12 = year11.getYear();
//        int int13 = day10.compareTo((java.lang.Object) year11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
//        boolean boolean16 = timeSeries3.getNotify();
//        double double17 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems(true);
//        int int20 = timeSeries3.getMaximumItemCount();
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        int int28 = year27.getYear();
//        int int29 = day26.compareTo((java.lang.Object) year27);
//        long long30 = year27.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) year27);
//        long long32 = year27.getSerialIndex();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        int int35 = year34.getYear();
//        int int36 = day33.compareTo((java.lang.Object) year34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 10.0f);
//        java.lang.String str39 = day33.toString();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str39);
//        timeSeries40.setMaximumItemAge(24234L);
//        int int43 = year27.compareTo((java.lang.Object) 24234L);
//        long long44 = year27.getSerialIndex();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        int int46 = year45.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getFirstMillisecond(calendar49);
//        long long51 = fixedMillisecond48.getLastMillisecond();
//        java.util.Calendar calendar52 = null;
//        fixedMillisecond48.peg(calendar52);
//        boolean boolean54 = year45.equals((java.lang.Object) fixedMillisecond48);
//        boolean boolean55 = year27.equals((java.lang.Object) fixedMillisecond48);
//        java.lang.Number number56 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9999.0d) + "'", double17 == (-9999.0d));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 5L + "'", long50 == 5L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 5L + "'", long51 == 5L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-9999.0d) + "'", number56.equals((-9999.0d)));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = day10.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.String str18 = fixedMillisecond17.toString();
        timeSeries15.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 9999);
        timeSeries15.setMaximumItemAge((long) 2019);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month28, (double) (-9999), true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries27.removeChangeListener(seriesChangeListener32);
        timeSeries27.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "10-June-2019", "");
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        int int43 = day40.compareTo((java.lang.Object) year41);
        long long44 = year41.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries39.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
        long long47 = year41.getSerialIndex();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month((int) (short) 1, year41);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        int int50 = year49.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getFirstMillisecond(calendar53);
        long long55 = fixedMillisecond52.getLastMillisecond();
        java.util.Calendar calendar56 = null;
        fixedMillisecond52.peg(calendar56);
        boolean boolean58 = year49.equals((java.lang.Object) fixedMillisecond52);
        long long59 = year49.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) year49);
        java.lang.String str61 = timeSeries15.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener62 = null;
        timeSeries15.addChangeListener(seriesChangeListener62);
        java.lang.String str64 = timeSeries15.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar67 = null;
        long long68 = fixedMillisecond66.getFirstMillisecond(calendar67);
        java.util.Calendar calendar69 = null;
        long long70 = fixedMillisecond66.getFirstMillisecond(calendar69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond66.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = fixedMillisecond66.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = fixedMillisecond66.previous();
        boolean boolean74 = timeSeries15.equals((java.lang.Object) regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str18.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 5L + "'", long54 == 5L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 5L + "'", long55 == 5L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2019L + "'", long59 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "10-June-2019" + "'", str61.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 5L + "'", long68 == 5L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 5L + "'", long70 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }
}

