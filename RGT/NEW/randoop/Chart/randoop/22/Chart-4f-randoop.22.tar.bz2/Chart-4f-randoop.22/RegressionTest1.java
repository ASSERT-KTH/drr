import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Range[0.0,1.0]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer2);
        boolean boolean4 = xYLineAndShapeRenderer2.getBaseItemLabelsVisible();
        xYLineAndShapeRenderer2.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        java.awt.Paint paint11 = xYLineAndShapeRenderer2.getItemFillPaint(9999, 8, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("series", "", "", "series");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot5.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint16 = xYLineAndShapeRenderer14.getLegendTextPaint(0);
        combinedRangeXYPlot5.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer14);
        java.util.List list18 = combinedRangeXYPlot5.getSubplots();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = combinedRangeXYPlot5.getRangeAxisEdge(3);
        boolean boolean21 = basicProjectInfo4.equals((java.lang.Object) 3);
        basicProjectInfo4.setName("Range[0.0,1.0]");
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker15.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer18 = null;
        combinedRangeXYPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker15, layer18, false);
        boolean boolean21 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        combinedRangeXYPlot0.setDomainZeroBaselineStroke(stroke25);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        boolean boolean8 = polarPlot6.isAngleLabelsVisible();
        polarPlot6.setAngleLabelsVisible(false);
        boolean boolean11 = polarPlot6.isAngleGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isDomainZoomable();
        categoryPlot13.clearDomainMarkers();
        boolean boolean16 = categoryPlot13.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot13.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        java.awt.geom.Point2D point2D23 = null;
        try {
            polarPlot6.zoomRangeAxes(34.0d, plotRenderingInfo19, point2D23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        piePlot3D8.setAutoPopulateSectionOutlinePaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot12.setRangeMinorGridlineStroke(stroke13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot12.setRangeAxis(valueAxis15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot12.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo19, point2D20);
        categoryPlot12.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D23 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        barRenderer3D23.setGradientPaintTransformer(gradientPaintTransformer24);
        categoryPlot12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState31 = null;
        boolean boolean32 = categoryPlot12.render(graphics2D27, rectangle2D28, 3, plotRenderingInfo30, categoryCrosshairState31);
        boolean boolean33 = piePlot3D8.equals((java.lang.Object) plotRenderingInfo30);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        legendTitle4.setID("RectangleInsets[t=1.0,l=32.0,b=35.0,r=0.0]");
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        java.lang.Object obj2 = xYBarRenderer1.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        xYBarRenderer1.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot9.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot9.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint20 = xYLineAndShapeRenderer18.getLegendTextPaint(0);
        combinedRangeXYPlot9.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer18);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        boolean boolean25 = timeSeriesCollection23.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = null;
        timeSeriesCollection23.seriesChanged(seriesChangeEvent26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState29 = xYAreaRenderer6.initialise(graphics2D7, rectangle2D8, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.data.xy.XYDataset) timeSeriesCollection23, plotRenderingInfo28);
        xYItemRendererState29.setProcessVisibleItemsOnly(true);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType34 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(10);
        boolean boolean39 = periodAxis36.equals((java.lang.Object) 10);
        boolean boolean40 = dateTickUnitType34.equals((java.lang.Object) periodAxis36);
        periodAxis36.setRangeWithMargins(35.0d, 35.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = periodAxis36.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis46 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(10);
        boolean boolean49 = periodAxis46.equals((java.lang.Object) 10);
        boolean boolean50 = periodAxis46.isMinorTickMarksVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) periodAxis46);
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(10);
        periodAxis53.setFirst((org.jfree.data.time.RegularTimePeriod) year55);
        java.awt.Font font57 = periodAxis53.getLabelFont();
        periodAxis53.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range60 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis53.setRange(range60, false, false);
        periodAxis46.setDefaultAutoRange(range60);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot65 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image66 = null;
        combinedRangeXYPlot65.setBackgroundImage(image66);
        java.awt.Paint paint68 = combinedRangeXYPlot65.getDomainCrosshairPaint();
        org.jfree.data.time.TimeSeries timeSeries69 = null;
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection71 = new org.jfree.data.time.TimeSeriesCollection(timeSeries69, timeZone70);
        int int72 = combinedRangeXYPlot65.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection71);
        try {
            xYBarRenderer1.drawItem(graphics2D5, xYItemRendererState29, rectangle2D32, xYPlot33, (org.jfree.chart.axis.ValueAxis) periodAxis36, (org.jfree.chart.axis.ValueAxis) periodAxis46, (org.jfree.data.xy.XYDataset) timeSeriesCollection71, 0, 1900, false, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState29);
        org.junit.Assert.assertNotNull(dateTickUnitType34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        combinedRangeXYPlot22.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        java.util.List list35 = combinedRangeXYPlot22.getSubplots();
        combinedRangeXYPlot22.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(10);
        periodAxis43.setFirst((org.jfree.data.time.RegularTimePeriod) year45);
        java.awt.Font font47 = periodAxis43.getLabelFont();
        combinedRangeXYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis43);
        combinedRangeXYPlot22.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis43, true);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        periodAxis52.setFirst((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.String str56 = periodAxis52.getLabelURL();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean60 = timeSeriesCollection58.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, valueAxis61, polarItemRenderer62);
        xYLineAndShapeRenderer2.drawItem(graphics2D12, xYItemRendererState13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.axis.ValueAxis) periodAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, 0, (int) (short) 100, true, (int) '4');
        org.jfree.chart.plot.Plot plot69 = periodAxis43.getPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(plot69);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = null;
        boolean boolean9 = jFreeChart6.equals(obj8);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart6.getTitle();
        jFreeChart6.setAntiAlias(true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer16);
        jFreeChart6.addSubtitle((int) (short) 1, (org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart6.getLegend(3);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(textTitle10);
        org.junit.Assert.assertNull(legendTitle20);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 100, (double) 10L, (double) ' ', (double) '#', (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            blockBorder5.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset12, (double) ' ');
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        multiplePiePlot1.setLimit((double) 0L);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) chartChangeEventType4);
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot1.getPieChart();
        java.awt.Paint paint7 = null;
        jFreeChart6.setBorderPaint(paint7);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jFreeChart6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getSeriesItemLabelPaint(0);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = xYLineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        java.awt.geom.GeneralPath generalPath10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedRangeXYPlot0.select(generalPath10, rectangle2D11, renderingSource12);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.LegendItem legendItem8 = xYLineAndShapeRenderer2.getLegendItem((-1), (-1));
        java.awt.Paint paint9 = xYLineAndShapeRenderer2.getBaseOutlinePaint();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
//        org.junit.Assert.assertNull(timeZone0);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries2.add((double) (short) 0, (double) (short) 0);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone6);
        boolean boolean9 = timeSeriesCollection7.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = null;
        timeSeriesCollection7.seriesChanged(seriesChangeEvent10);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = combinedRangeXYPlot0.getDomainAxisEdge();
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Font font4 = xYAreaRenderer0.getItemLabelFont(2, (int) (byte) 1, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean9 = xYLineAndShapeRenderer8.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer13);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getDomainCrosshairPaint();
        xYLineAndShapeRenderer13.setSeriesOutlinePaint((int) 'a', paint17);
        xYLineAndShapeRenderer8.setSeriesFillPaint((int) '#', paint17);
        xYAreaRenderer0.setSeriesPaint((int) 'a', paint17, false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        combinedRangeXYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean12 = combinedRangeXYPlot0.isDomainZoomable();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        combinedRangeXYPlot0.setRangeMinorGridlineStroke(stroke13);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getSerialIndex();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState4 = new org.jfree.chart.plot.XYCrosshairState();
        int int5 = month2.compareTo((java.lang.Object) xYCrosshairState4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-11L) + "'", long3 == (-11L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Stroke stroke1 = barRenderer3D0.getBaseOutlineStroke();
        java.lang.Object obj2 = null;
        boolean boolean3 = barRenderer3D0.equals(obj2);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYLineAndShapeRenderer9.setBaseShape(shape13, false);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.entity.XYItemEntity xYItemEntity26 = new org.jfree.chart.entity.XYItemEntity(shape13, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, (int) ' ', (int) (byte) 1, "series", "");
        int int27 = xYItemEntity26.getItem();
        java.lang.String str28 = xYItemEntity26.toString();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = textBlockAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = null;
        boolean boolean9 = jFreeChart6.equals(obj8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            jFreeChart6.draw(graphics2D10, rectangle2D11, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        combinedRangeXYPlot22.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        java.util.List list35 = combinedRangeXYPlot22.getSubplots();
        combinedRangeXYPlot22.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(10);
        periodAxis43.setFirst((org.jfree.data.time.RegularTimePeriod) year45);
        java.awt.Font font47 = periodAxis43.getLabelFont();
        combinedRangeXYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis43);
        combinedRangeXYPlot22.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis43, true);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        periodAxis52.setFirst((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.String str56 = periodAxis52.getLabelURL();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean60 = timeSeriesCollection58.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, valueAxis61, polarItemRenderer62);
        xYLineAndShapeRenderer2.drawItem(graphics2D12, xYItemRendererState13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.axis.ValueAxis) periodAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, 0, (int) (short) 100, true, (int) '4');
        periodAxis43.setMinorTickMarkOutsideLength((float) (short) 100);
        boolean boolean71 = periodAxis43.isMinorTickMarksVisible();
        boolean boolean72 = periodAxis43.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getDomainCrosshairPaint();
        periodAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainCrosshairPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot11.setDomainAxisLocation(axisLocation13);
        combinedRangeXYPlot9.setRangeAxisLocation(axisLocation13, true);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image19 = null;
        combinedRangeXYPlot18.setBackgroundImage(image19);
        java.awt.Stroke stroke21 = combinedRangeXYPlot18.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset23 = combinedRangeXYPlot18.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint29 = xYLineAndShapeRenderer27.getLegendTextPaint(0);
        combinedRangeXYPlot18.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer27);
        java.util.List list31 = combinedRangeXYPlot18.getSubplots();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = combinedRangeXYPlot18.getRangeAxisEdge(3);
        org.jfree.chart.axis.AxisSpace axisSpace34 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace35 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str36 = axisSpace35.toString();
        axisSpace34.ensureAtLeast(axisSpace35);
        double double38 = axisSpace35.getLeft();
        double double39 = axisSpace35.getLeft();
        java.lang.String str40 = axisSpace35.toString();
        axisSpace35.setTop((double) 2.0f);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace43 = periodAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) combinedRangeXYPlot9, rectangle2D17, rectangleEdge33, axisSpace35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1900, (double) 900000L, (double) (-9999), (double) 6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.lang.String str4 = categoryPlot0.getNoDataMessage();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean6 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setDrawSharedDomainAxis(true);
        categoryPlot0.setAnchorValue((double) (short) 0);
        boolean boolean11 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint3 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Paint paint4 = standardChartTheme1.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        combinedRangeXYPlot1.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        categoryPlot12.setRangeZeroBaselinePaint(paint16);
        xYLineAndShapeRenderer10.setBaseFillPaint(paint16, true);
        int int20 = xYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.addOrUpdate((java.lang.Number) 8, (java.lang.Number) 8);
        org.junit.Assert.assertNull(xYDataItem5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        boolean boolean5 = periodAxis1.isMinorTickMarksVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) periodAxis1);
        org.jfree.chart.JFreeChart jFreeChart7 = axisChangeEvent6.getChart();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jFreeChart7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        java.lang.Object obj2 = xYBarRenderer1.clone();
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) (byte) 0, (-1.0d), 3.0d, paint7);
        xYBarRenderer1.setBaseItemLabelPaint(paint7, false);
        double double11 = xYBarRenderer1.getMargin();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot5.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot11 = combinedRangeXYPlot5.getParent();
        combinedRangeXYPlot5.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = combinedRangeXYPlot5.getDomainMarkers((int) (byte) 100, layer15);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        boolean boolean22 = periodAxis18.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getDomainCrosshairPaint();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot25.setRangeZeroBaselinePaint(paint27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.drawDomainLine(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.chart.axis.ValueAxis) periodAxis18, rectangle2D23, (double) (byte) 1, paint27, stroke29);
        java.awt.Paint paint31 = periodAxis18.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getDomainCrosshairPaint();
        periodAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis1.getFirst();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeriesCollection10.getSeries((java.lang.Comparable) 1);
        boolean boolean14 = periodAxis1.hasListener((java.util.EventListener) timeSeriesCollection10);
        try {
            timeSeriesCollection10.removeSeries(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2019).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        int int7 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke9 = defaultDrawingSupplier8.getNextStroke();
        combinedRangeXYPlot0.setDomainGridlineStroke(stroke9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries2.add((double) (short) 0, (double) (short) 0);
        xYSeries2.setNotify(true);
        int int9 = xYSeries2.indexOf((java.lang.Number) 3);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        xYSeries2.removePropertyChangeListener(propertyChangeListener10);
        try {
            xYSeries2.updateByIndex((-9999), (java.lang.Number) 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2) + "'", int9 == (-2));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.DomainOrder domainOrder3 = defaultXYDataset2.getDomainOrder();
        boolean boolean4 = xYSeriesCollection1.equals((java.lang.Object) defaultXYDataset2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean8 = timeSeriesCollection6.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis9, polarItemRenderer10);
        int int13 = timeSeriesCollection6.indexOf((java.lang.Comparable) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image15 = null;
        combinedRangeXYPlot14.setBackgroundImage(image15);
        java.awt.Paint paint17 = combinedRangeXYPlot14.getDomainCrosshairPaint();
        combinedRangeXYPlot14.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = combinedRangeXYPlot14.getSeriesRenderingOrder();
        java.util.List list20 = combinedRangeXYPlot14.getSubplots();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(10);
        periodAxis22.setFirst((org.jfree.data.time.RegularTimePeriod) year24);
        java.awt.Font font26 = periodAxis22.getLabelFont();
        periodAxis22.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis22.setRange(range29, false, false);
        org.jfree.data.Range range34 = timeSeriesCollection6.getRangeBounds(list20, range29, false);
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(10);
        periodAxis36.setFirst((org.jfree.data.time.RegularTimePeriod) year38);
        java.awt.Font font40 = periodAxis36.getLabelFont();
        periodAxis36.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range43 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis36.setRange(range43, false, false);
        boolean boolean48 = range43.contains((double) (byte) 10);
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(10);
        periodAxis50.setFirst((org.jfree.data.time.RegularTimePeriod) year52);
        java.awt.Font font54 = periodAxis50.getLabelFont();
        periodAxis50.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range57 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis50.setRange(range57, false, false);
        java.lang.String str61 = range57.toString();
        org.jfree.data.Range range62 = org.jfree.data.Range.combine(range43, range57);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, list20, range43, false);
        try {
            org.jfree.data.Range range67 = org.jfree.data.Range.expand(range64, (double) (byte) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Range[0.0,1.0]" + "'", str61.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNull(range64);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = color1.darker();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("index.html", (java.awt.Paint) color1);
        legendItem4.setDescription("RectangleConstraint[LengthConstraintType.FIXED: width=-11.0, height=0.0]");
        legendItem4.setToolTipText("PieLabelLinkStyle.QUAD_CURVE");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        java.awt.Paint paint8 = xYLineAndShapeRenderer2.getSeriesOutlinePaint((int) (byte) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYLineAndShapeRenderer2.getToolTipGenerator(7, 0, true);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot0.setDomainMinorGridlinePaint(paint4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedRangeXYPlot0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem8 = legendItemCollection6.get((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj1 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date0, obj1);
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) date0, false);
        int int5 = xYSeries4.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        combinedRangeXYPlot1.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYLineAndShapeRenderer3.getPositiveItemLabelPosition((-1), 3, true);
        boolean boolean11 = strokeList0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        java.awt.Stroke stroke13 = strokeList0.getStroke(9999);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        java.lang.Class class9 = periodAxis7.getAutoRangeTimePeriodClass();
        categoryPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) periodAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRenderer();
        java.awt.Paint paint12 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray18, numberArray21, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray25);
        categoryPlot13.setDataset(categoryDataset26);
        int int28 = categoryPlot0.indexOf(categoryDataset26);
        org.jfree.chart.util.SortOrder sortOrder29 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendGraphic5.setShapeAnchor(rectangleAnchor6);
        java.lang.Object obj8 = null;
        boolean boolean9 = rectangleAnchor6.equals(obj8);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        java.util.List list2 = axisState0.getTicks();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Paint paint5 = combinedRangeXYPlot2.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity6 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer9);
        org.jfree.chart.entity.TitleEntity titleEntity12 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle10, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = legendTitle10.getHorizontalAlignment();
        double double14 = legendTitle10.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = legendTitle10.getHorizontalAlignment();
        textTitle0.setTextAlignment(horizontalAlignment15);
        textTitle0.setURLText("");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo18, categoryCrosshairState19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setCategoryLabelPositionOffset((int) (short) 10);
        categoryPlot0.setDomainAxis((int) '4', categoryAxis22, false);
        categoryPlot0.setRangePannable(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        combinedRangeXYPlot0.setDataset(9, xYDataset4);
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Range[0.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        axisSpace4.ensureAtLeast(0.0d, rectangleEdge6);
        try {
            double double9 = dateAxis1.valueToJava2D((double) 60000L, rectangle2D3, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, false);
        xYLineAndShapeRenderer2.clearSeriesStrokes(true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 3.0d);
        java.util.Date date3 = year0.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot6.zoomRangeAxes((double) (byte) 1, plotRenderingInfo10, point2D11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.SortOrder sortOrder5 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long16 = month15.getSerialIndex();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState17 = new org.jfree.chart.plot.XYCrosshairState();
        int int18 = month15.compareTo((java.lang.Object) xYCrosshairState17);
        int int19 = month15.getYearValue();
        try {
            org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset12, (java.lang.Comparable) month15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-11L) + "'", long16 == (-11L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot6);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = legendTitle10.arrange(graphics2D11);
        boolean boolean13 = color4.equals((java.lang.Object) graphics2D11);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataItem xYDataItem13 = new org.jfree.data.xy.XYDataItem((double) (short) -1, (double) 9999);
        xYDataItem13.setSelected(true);
        try {
            java.lang.Object obj16 = labelBlock7.draw(graphics2D9, rectangle2D10, (java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 6, (float) 2, (float) (-9999));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        combinedRangeXYPlot5.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedRangeXYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.removeProgressListener(chartProgressListener12);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity16 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart11, "", "ClassContext");
        jFreeChart11.setTitle("ClassContext");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        jFreeChart6.removeLegend();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent14);
        java.awt.Stroke stroke16 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        try {
            double double4 = xYSeriesCollection1.getEndYValue(0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord11 = abstractPieLabelDistributor9.getPieLabelRecord(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot5.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot11 = combinedRangeXYPlot5.getParent();
        combinedRangeXYPlot5.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = combinedRangeXYPlot5.getDomainMarkers((int) (byte) 100, layer15);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        boolean boolean22 = periodAxis18.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getDomainCrosshairPaint();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot25.setRangeZeroBaselinePaint(paint27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.drawDomainLine(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.chart.axis.ValueAxis) periodAxis18, rectangle2D23, (double) (byte) 1, paint27, stroke29);
        boolean boolean31 = periodAxis18.isVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        legendGraphic5.setLine(shape7);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 6, (float) 2, (float) (-9999));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        combinedRangeXYPlot5.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedRangeXYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.removeProgressListener(chartProgressListener12);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity16 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart11, "", "ClassContext");
        try {
            org.jfree.chart.title.Title title18 = jFreeChart11.getSubtitle((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        java.awt.Graphics2D graphics2D9 = null;
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj12 = null;
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date11, obj12);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(date10, date11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toFixedWidth((double) (-11L));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint16.toFixedHeight(0.0d);
        try {
            org.jfree.chart.util.Size2D size2D21 = labelBlock7.arrange(graphics2D9, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.setBaseStroke(stroke7, false);
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(10);
        periodAxis15.setFirst((org.jfree.data.time.RegularTimePeriod) year17);
        java.awt.Font font19 = periodAxis15.getLabelFont();
        periodAxis15.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYLineAndShapeRenderer2.drawRangeMarker(graphics2D12, xYPlot13, (org.jfree.chart.axis.ValueAxis) periodAxis15, marker22, rectangle2D23);
        java.awt.Paint paint26 = xYLineAndShapeRenderer2.getSeriesPaint((int) (short) 0);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        java.awt.Paint paint8 = xYLineAndShapeRenderer2.getSeriesOutlinePaint((int) (byte) -1);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYLineAndShapeRenderer2.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font13 = textFragment12.getFont();
        boolean boolean14 = standardXYURLGenerator9.equals((java.lang.Object) font13);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        double double5 = periodAxis1.getFixedDimension();
        periodAxis1.setTickMarkInsideLength((float) 9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        try {
            double double4 = xYSeriesCollection1.getYValue(2147483647, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.DomainOrder domainOrder3 = defaultXYDataset2.getDomainOrder();
        org.jfree.data.xy.XYSeries xYSeries7 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries7.add((double) (short) 0, (double) (short) 0);
        xYSeries7.setNotify(true);
        double[][] doubleArray13 = xYSeries7.toArray();
        defaultXYDataset2.addSeries((java.lang.Comparable) 4, doubleArray13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Oct", doubleArray13);
        org.junit.Assert.assertNotNull(domainOrder3);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint9 = periodAxis8.getTickMarkPaint();
        periodAxis8.setInverted(true);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(10);
        boolean boolean16 = periodAxis13.equals((java.lang.Object) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer19.setAutoPopulateSeriesPaint(false);
        java.awt.Color color23 = java.awt.Color.gray;
        int int24 = color23.getTransparency();
        xYLineAndShapeRenderer19.setBaseItemLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer19);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.Plot plot28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image31 = null;
        combinedRangeXYPlot30.setBackgroundImage(image31);
        java.awt.Stroke stroke33 = combinedRangeXYPlot30.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset35 = combinedRangeXYPlot30.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint41 = xYLineAndShapeRenderer39.getLegendTextPaint(0);
        combinedRangeXYPlot30.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer39);
        java.util.List list43 = combinedRangeXYPlot30.getSubplots();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = combinedRangeXYPlot30.getRangeAxisEdge(3);
        org.jfree.chart.axis.AxisSpace axisSpace46 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str47 = axisSpace46.toString();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace48 = periodAxis13.reserveSpace(graphics2D27, plot28, rectangle2D29, rectangleEdge45, axisSpace46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, 0);
        boolean boolean4 = numberFormat1.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        java.lang.Class class9 = periodAxis7.getAutoRangeTimePeriodClass();
        categoryPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) periodAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke12 = categoryPlot0.getRangeMinorGridlineStroke();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot0.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeriesCollection1.getSeries((java.lang.Comparable) (-1));
        java.util.List list6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean10 = timeSeriesCollection8.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, valueAxis11, polarItemRenderer12);
        int int15 = timeSeriesCollection8.indexOf((java.lang.Comparable) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image17 = null;
        combinedRangeXYPlot16.setBackgroundImage(image17);
        java.awt.Paint paint19 = combinedRangeXYPlot16.getDomainCrosshairPaint();
        combinedRangeXYPlot16.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder21 = combinedRangeXYPlot16.getSeriesRenderingOrder();
        java.util.List list22 = combinedRangeXYPlot16.getSubplots();
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(10);
        periodAxis24.setFirst((org.jfree.data.time.RegularTimePeriod) year26);
        java.awt.Font font28 = periodAxis24.getLabelFont();
        periodAxis24.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis24.setRange(range31, false, false);
        org.jfree.data.Range range36 = timeSeriesCollection8.getRangeBounds(list22, range31, false);
        try {
            org.jfree.data.Range range38 = timeSeriesCollection1.getRangeBounds(list6, range36, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(timeSeries5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(seriesRenderingOrder21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(range36);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        categoryPlot0.clearDomainMarkers();
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addDomainMarker(3, categoryMarker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale7);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getCurrencyInstance(locale7);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ItemLabelAnchor.OUTSIDE1", numberFormat9, numberFormat10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeZone12);
        boolean boolean15 = timeSeriesCollection13.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection13, valueAxis16, polarItemRenderer17);
        try {
            java.lang.String str21 = standardXYToolTipGenerator11.generateLabelString((org.jfree.data.xy.XYDataset) timeSeriesCollection13, 2147483647, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2147483647).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer3D11.getItemLabelGenerator((int) (short) 10, 7, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint24 = xYLineAndShapeRenderer22.getLegendTextPaint(0);
        java.lang.Boolean boolean26 = xYLineAndShapeRenderer22.getSeriesCreateEntities(0);
        boolean boolean27 = xYLineAndShapeRenderer22.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean31 = xYLineAndShapeRenderer30.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYLineAndShapeRenderer30.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = xYLineAndShapeRenderer30.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer22.setBasePositiveItemLabelPosition(itemLabelPosition37);
        barRenderer3D11.setSeriesPositiveItemLabelPosition(100, itemLabelPosition37);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer40 = barRenderer3D11.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNull(gradientPaintTransformer40);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat4, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat2, numberFormat4);
        boolean boolean8 = numberFormat2.isGroupingUsed();
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        boolean boolean15 = periodAxis11.isMinorTickMarksVisible();
        java.util.Locale locale16 = periodAxis11.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale16);
        java.text.NumberFormat numberFormat18 = java.text.NumberFormat.getCurrencyInstance(locale16);
        java.text.NumberFormat numberFormat19 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator20 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ItemLabelAnchor.OUTSIDE1", numberFormat18, numberFormat19);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined Range XYPlot", numberFormat2, numberFormat19);
        java.text.NumberFormat numberFormat22 = standardPieSectionLabelGenerator21.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertNotNull(numberFormat18);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberFormat22);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("CONTRACT");
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        combinedRangeXYPlot0.setDomainCrosshairValue(45.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        xYLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.plot.XYPlot xYPlot22 = xYLineAndShapeRenderer2.getPlot();
        org.jfree.chart.plot.XYPlot xYPlot23 = xYLineAndShapeRenderer2.getPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(xYPlot22);
        org.junit.Assert.assertNull(xYPlot23);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        boolean boolean8 = polarPlot6.isAngleLabelsVisible();
        polarPlot6.setRadiusGridlinesVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image12 = null;
        combinedRangeXYPlot11.setBackgroundImage(image12);
        boolean boolean14 = polarPlot6.equals((java.lang.Object) combinedRangeXYPlot11);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType15 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(10);
        boolean boolean20 = periodAxis17.equals((java.lang.Object) 10);
        boolean boolean21 = dateTickUnitType15.equals((java.lang.Object) periodAxis17);
        org.jfree.data.Range range22 = polarPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) periodAxis17);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTickUnitType15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.removeAnnotations();
        java.awt.Paint paint6 = barRenderer3D0.getSeriesOutlinePaint(8);
        java.awt.Stroke stroke7 = barRenderer3D0.getBaseOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] { stroke4, stroke5, stroke6 };
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke8 };
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray7, strokeArray9, shapeArray10);
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextFillPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shapeArray10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        xYSeriesCollection1.setIntervalWidth((double) (byte) 10);
        xYSeriesCollection1.setAutoWidth(false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int9 = xYSeriesCollection1.indexOf((java.lang.Comparable) (byte) 1);
        try {
            xYSeriesCollection1.setIntervalPositionFactor((double) 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        try {
            java.math.RoundingMode roundingMode1 = logFormat0.getRoundingMode();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset9 = polarPlot6.getDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate10 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset9);
        intervalXYDelegate10.setFixedIntervalWidth(0.0d);
        java.lang.Object obj13 = intervalXYDelegate10.clone();
        try {
            java.lang.Number number16 = intervalXYDelegate10.getStartX((int) (byte) 100, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset9);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.Range range2 = new org.jfree.data.Range(5.0d, (double) 9999);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(range2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean10 = xYLineAndShapeRenderer9.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYLineAndShapeRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYLineAndShapeRenderer9.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer9.setBaseCreateEntities(true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = barRenderer3D19.removeAnnotation(categoryAnnotation20);
        java.lang.Object obj22 = barRenderer3D19.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer3D19.setSeriesURLGenerator(0, categoryURLGenerator24);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(10);
        boolean boolean40 = periodAxis37.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint42 = categoryPlot41.getDomainCrosshairPaint();
        periodAxis37.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot41);
        java.awt.Color color44 = java.awt.Color.GREEN;
        categoryPlot41.setRangeZeroBaselinePaint((java.awt.Paint) color44);
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape30, (java.awt.Paint) color44);
        java.awt.Paint paint47 = legendItem46.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image49 = null;
        combinedRangeXYPlot48.setBackgroundImage(image49);
        java.awt.Paint paint51 = combinedRangeXYPlot48.getDomainCrosshairPaint();
        java.awt.Paint paint52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot48.setDomainMinorGridlinePaint(paint52);
        legendItem46.setOutlinePaint(paint52);
        barRenderer3D19.setBaseOutlinePaint(paint52);
        xYLineAndShapeRenderer9.setBaseFillPaint(paint52);
        boolean boolean57 = legendGraphic5.equals((java.lang.Object) xYLineAndShapeRenderer9);
        java.awt.Shape shape58 = legendGraphic5.getShape();
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        try {
            legendGraphic5.draw(graphics2D59, rectangle2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(shape58);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean11 = xYLineAndShapeRenderer9.getSeriesVisible(2);
        int int12 = xYLineAndShapeRenderer9.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint15 = periodAxis14.getTickMarkPaint();
        xYLineAndShapeRenderer9.setBaseFillPaint(paint15, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYLineAndShapeRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYLineAndShapeRenderer9.setSeriesNegativeItemLabelPosition(0, itemLabelPosition24);
        java.awt.Shape shape29 = xYLineAndShapeRenderer9.getItemShape(2, (-1), true);
        xYLineAndShapeRenderer2.setLegendLine(shape29);
        xYLineAndShapeRenderer2.setBaseShapesFilled(true);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font4 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("Polar Plot", font4);
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(10);
        periodAxis7.setFirst((org.jfree.data.time.RegularTimePeriod) year9);
        java.awt.Font font11 = periodAxis7.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(10);
        periodAxis13.setFirst((org.jfree.data.time.RegularTimePeriod) year15);
        java.awt.Font font17 = periodAxis13.getLabelFont();
        periodAxis13.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis13.setRange(range20, false, false);
        periodAxis7.setRange(range20, true, true);
        boolean boolean27 = textTitle5.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        double double2 = xYCrosshairState0.getAnchorY();
        org.junit.Assert.assertNull(point2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font4 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("Polar Plot", font4);
        textTitle5.setText("index.html");
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        periodAxis3.setFirst((org.jfree.data.time.RegularTimePeriod) year5);
        java.awt.Font font7 = periodAxis3.getLabelFont();
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis3);
        org.jfree.data.Range range9 = periodAxis3.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TimePeriodAnchor.END", graphics2D1, (double) (-2), 0.0f, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        float float7 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean10 = xYLineAndShapeRenderer9.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYLineAndShapeRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYLineAndShapeRenderer9.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer9.setBaseCreateEntities(true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = barRenderer3D19.removeAnnotation(categoryAnnotation20);
        java.lang.Object obj22 = barRenderer3D19.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer3D19.setSeriesURLGenerator(0, categoryURLGenerator24);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(10);
        boolean boolean40 = periodAxis37.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint42 = categoryPlot41.getDomainCrosshairPaint();
        periodAxis37.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot41);
        java.awt.Color color44 = java.awt.Color.GREEN;
        categoryPlot41.setRangeZeroBaselinePaint((java.awt.Paint) color44);
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape30, (java.awt.Paint) color44);
        java.awt.Paint paint47 = legendItem46.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image49 = null;
        combinedRangeXYPlot48.setBackgroundImage(image49);
        java.awt.Paint paint51 = combinedRangeXYPlot48.getDomainCrosshairPaint();
        java.awt.Paint paint52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot48.setDomainMinorGridlinePaint(paint52);
        legendItem46.setOutlinePaint(paint52);
        barRenderer3D19.setBaseOutlinePaint(paint52);
        xYLineAndShapeRenderer9.setBaseFillPaint(paint52);
        boolean boolean57 = legendGraphic5.equals((java.lang.Object) xYLineAndShapeRenderer9);
        java.awt.Paint paint58 = legendGraphic5.getFillPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.setCrosshairDistance((double) 9999);
        org.junit.Assert.assertNull(point2D1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker15.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer18 = null;
        combinedRangeXYPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker15, layer18, false);
        combinedRangeXYPlot0.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image24 = null;
        combinedRangeXYPlot23.setBackgroundImage(image24);
        java.awt.Paint paint26 = combinedRangeXYPlot23.getDomainCrosshairPaint();
        combinedRangeXYPlot23.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder28 = combinedRangeXYPlot23.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot23);
        java.awt.Paint paint30 = jFreeChart29.getBackgroundPaint();
        java.lang.Object obj31 = null;
        boolean boolean32 = jFreeChart29.equals(obj31);
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart29.getTitle();
        java.awt.Stroke stroke34 = jFreeChart29.getBorderStroke();
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke34);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean40 = xYLineAndShapeRenderer38.getSeriesVisible(2);
        int int41 = xYLineAndShapeRenderer38.getPassCount();
        java.awt.Stroke stroke42 = xYLineAndShapeRenderer38.getBaseStroke();
        combinedRangeXYPlot0.setRangeGridlineStroke(stroke42);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(textTitle33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(boolean40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot0.getDomainAxis();
        java.awt.Paint paint7 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        combinedRangeXYPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = combinedRangeXYPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        periodAxis3.setFirst((org.jfree.data.time.RegularTimePeriod) year5);
        java.awt.Font font7 = periodAxis3.getLabelFont();
        periodAxis3.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis3.setRange(range10, false, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image15 = null;
        combinedRangeXYPlot14.setBackgroundImage(image15);
        java.awt.Stroke stroke17 = combinedRangeXYPlot14.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = combinedRangeXYPlot14.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot20 = combinedRangeXYPlot14.getParent();
        combinedRangeXYPlot14.setDomainCrosshairVisible(true);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image25 = null;
        combinedRangeXYPlot24.setBackgroundImage(image25);
        java.awt.Paint paint27 = combinedRangeXYPlot24.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity28 = new org.jfree.chart.entity.PlotEntity(shape23, (org.jfree.chart.plot.Plot) combinedRangeXYPlot24);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer31);
        org.jfree.chart.entity.TitleEntity titleEntity34 = new org.jfree.chart.entity.TitleEntity(shape23, (org.jfree.chart.title.Title) legendTitle32, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = legendTitle32.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle32.getItemLabelPadding();
        combinedRangeXYPlot14.setInsets(rectangleInsets36);
        double double39 = rectangleInsets36.calculateBottomInset((double) (byte) 10);
        double double41 = rectangleInsets36.calculateTopInset((double) 'a');
        periodAxis3.setLabelInsets(rectangleInsets36);
        combinedRangeXYPlot0.setInsets(rectangleInsets36);
        combinedRangeXYPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        combinedRangeXYPlot22.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        java.util.List list35 = combinedRangeXYPlot22.getSubplots();
        combinedRangeXYPlot22.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(10);
        periodAxis43.setFirst((org.jfree.data.time.RegularTimePeriod) year45);
        java.awt.Font font47 = periodAxis43.getLabelFont();
        combinedRangeXYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis43);
        combinedRangeXYPlot22.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis43, true);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        periodAxis52.setFirst((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.String str56 = periodAxis52.getLabelURL();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean60 = timeSeriesCollection58.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, valueAxis61, polarItemRenderer62);
        xYLineAndShapeRenderer2.drawItem(graphics2D12, xYItemRendererState13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.axis.ValueAxis) periodAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, 0, (int) (short) 100, true, (int) '4');
        org.jfree.chart.axis.TickUnits tickUnits69 = new org.jfree.chart.axis.TickUnits();
        periodAxis43.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits69);
        org.jfree.chart.axis.TickUnitSource tickUnitSource71 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        boolean boolean72 = tickUnits69.equals((java.lang.Object) tickUnitSource71);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset73 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset73.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit78 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType79 = dateTickUnit78.getRollUnitType();
        org.jfree.data.general.PieDataset pieDataset81 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset73, (java.lang.Comparable) dateTickUnit78, 1.0d);
        java.lang.Object obj82 = null;
        boolean boolean83 = dateTickUnit78.equals(obj82);
        double double84 = dateTickUnit78.getSize();
        try {
            org.jfree.chart.axis.TickUnit tickUnit85 = tickUnits69.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit78);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(tickUnitSource71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTickUnit78);
        org.junit.Assert.assertNotNull(dateTickUnitType79);
        org.junit.Assert.assertNotNull(pieDataset81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 8.64E7d + "'", double84 == 8.64E7d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleInsets[t=1.0,l=32.0,b=35.0,r=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        java.lang.Object obj2 = xYSeriesCollection1.clone();
        java.lang.Object obj3 = xYSeriesCollection1.clone();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        xYSeriesCollection1.setAutoWidth(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle4.getLegendItemGraphicLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot7.setRangeMinorGridlineStroke(stroke8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot7.setRangeAxis(valueAxis10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot7.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo14, point2D15);
        categoryPlot7.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer3D18.setGradientPaintTransformer(gradientPaintTransformer19);
        categoryPlot7.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D18);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = barRenderer3D18.getItemLabelGenerator((int) (short) 10, 7, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint31 = xYLineAndShapeRenderer29.getLegendTextPaint(0);
        java.lang.Boolean boolean33 = xYLineAndShapeRenderer29.getSeriesCreateEntities(0);
        boolean boolean34 = xYLineAndShapeRenderer29.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean38 = xYLineAndShapeRenderer37.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = xYLineAndShapeRenderer37.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = xYLineAndShapeRenderer37.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer29.setBasePositiveItemLabelPosition(itemLabelPosition44);
        barRenderer3D18.setSeriesPositiveItemLabelPosition(100, itemLabelPosition44);
        boolean boolean47 = legendTitle4.equals((java.lang.Object) itemLabelPosition44);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator25);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            java.lang.Number number3 = xYSeriesCollection0.getStartX(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj1 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date0, obj1);
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) date0, false);
        org.jfree.data.xy.XYDataItem xYDataItem5 = null;
        try {
            xYSeries4.add(xYDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "", "PieLabelLinkStyle.QUAD_CURVE", false);
        java.text.ParsePosition parsePosition6 = null;
        java.lang.Number number7 = logFormat4.parse("Polar Plot", parsePosition6);
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Number number10 = logFormat4.parse("NOID", parsePosition9);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 1L);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator((int) '#', xYItemLabelGenerator3);
        xYBarRenderer1.setUseYInterval(true);
        xYBarRenderer1.setBarAlignmentFactor(0.0d);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke12 = xYAreaRenderer10.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot15.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = combinedRangeXYPlot15.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot21 = combinedRangeXYPlot15.getParent();
        combinedRangeXYPlot15.setDomainCrosshairVisible(true);
        combinedRangeXYPlot15.configureDomainAxes();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection(timeZone25);
        boolean boolean28 = timeSeriesCollection26.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection26, valueAxis29, polarItemRenderer30);
        polarPlot31.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset34 = polarPlot31.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState37 = xYAreaRenderer10.initialise(graphics2D13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, xYDataset34, plotRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean43 = xYLineAndShapeRenderer41.getSeriesVisible(2);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image46 = null;
        combinedRangeXYPlot45.setBackgroundImage(image46);
        java.awt.Stroke stroke48 = combinedRangeXYPlot45.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset50 = combinedRangeXYPlot45.getDataset((int) (short) -1);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.Color color55 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image57 = null;
        combinedRangeXYPlot56.setBackgroundImage(image57);
        java.awt.Stroke stroke59 = combinedRangeXYPlot56.getRangeGridlineStroke();
        xYLineAndShapeRenderer41.drawRangeLine(graphics2D44, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis52, rectangle2D53, (double) 100, (java.awt.Paint) color55, stroke59);
        boolean boolean61 = combinedRangeXYPlot45.isDomainZoomable();
        boolean boolean62 = combinedRangeXYPlot45.canSelectByPoint();
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(10);
        boolean boolean67 = periodAxis64.equals((java.lang.Object) 10);
        periodAxis64.setAxisLineVisible(false);
        java.awt.Font font70 = periodAxis64.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis72 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(10);
        boolean boolean75 = periodAxis72.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint77 = categoryPlot76.getDomainCrosshairPaint();
        periodAxis72.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot76);
        org.jfree.data.xy.XYDataset xYDataset79 = null;
        try {
            xYBarRenderer1.drawItem(graphics2D9, xYItemRendererState37, rectangle2D38, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis64, (org.jfree.chart.axis.ValueAxis) periodAxis72, xYDataset79, (int) (byte) -1, 15, false, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(xYDataset34);
        org.junit.Assert.assertNotNull(xYItemRendererState37);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYDataset50);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot2.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint13 = xYLineAndShapeRenderer11.getLegendTextPaint(0);
        combinedRangeXYPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer11);
        java.util.List list15 = combinedRangeXYPlot2.getSubplots();
        combinedRangeXYPlot2.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot2.panRangeAxes((double) 6, plotRenderingInfo20, point2D21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        boolean boolean26 = timeSeriesCollection24.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis27, polarItemRenderer28);
        java.awt.Stroke stroke30 = polarPlot29.getRadiusGridlineStroke();
        combinedRangeXYPlot2.setDomainMinorGridlineStroke(stroke30);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 9, stroke30);
        double double33 = piePlot3D0.getLabelGap();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.025d + "'", double33 == 0.025d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        boolean boolean9 = piePlot3D8.getAutoPopulateSectionPaint();
        int int10 = piePlot3D8.getPieIndex();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        piePlot3D8.setAutoPopulateSectionOutlinePaint(true);
        java.lang.String str12 = piePlot3D8.getPlotType();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie 3D Plot" + "'", str12.equals("Pie 3D Plot"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat4, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat2, numberFormat4);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat11, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat9, numberFormat11);
        java.text.NumberFormat numberFormat15 = standardXYToolTipGenerator14.getYFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator16 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!", numberFormat2, numberFormat15);
        java.lang.Object obj17 = standardPieToolTipGenerator16.clone();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberFormat15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo18, categoryCrosshairState19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setCategoryLabelPositionOffset((int) (short) 10);
        categoryPlot0.setDomainAxis((int) '4', categoryAxis22, false);
        java.awt.Font font28 = categoryAxis22.getTickLabelFont((java.lang.Comparable) 34.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.DomainOrder domainOrder3 = defaultXYDataset2.getDomainOrder();
        boolean boolean4 = xYSeriesCollection1.equals((java.lang.Object) defaultXYDataset2);
        double double6 = xYSeriesCollection1.getDomainUpperBound(true);
        org.junit.Assert.assertNotNull(domainOrder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray12);
        categoryPlot0.setDataset(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset13);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate19.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        try {
            org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset13, (java.lang.Comparable) serialDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0d + "'", number15.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        java.lang.Object obj9 = labelBlock7.clone();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            labelBlock7.draw(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long5 = month4.getSerialIndex();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState6 = new org.jfree.chart.plot.XYCrosshairState();
        int int7 = month4.compareTo((java.lang.Object) xYCrosshairState6);
        int int8 = month4.getYearValue();
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("NOID", regularTimePeriod1, (org.jfree.data.time.RegularTimePeriod) month4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-11L) + "'", long5 == (-11L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(10);
        boolean boolean13 = periodAxis10.equals((java.lang.Object) 10);
        boolean boolean14 = periodAxis10.isMinorTickMarksVisible();
        java.util.Locale locale15 = periodAxis10.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale15);
        java.text.NumberFormat numberFormat17 = java.text.NumberFormat.getCurrencyInstance(locale15);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale15);
        java.lang.Object obj19 = standardPieSectionLabelGenerator18.clone();
        piePlot3D8.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator18);
        java.text.AttributedString attributedString22 = standardPieSectionLabelGenerator18.getAttributedLabel(0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertNotNull(numberFormat17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(attributedString22);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (short) -1, (int) (short) 0, (int) (byte) 1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = dateTickUnit5.getRollUnitType();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) dateTickUnit5, 1.0d);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate12.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        try {
            defaultPieDataset0.insertValue(9999, (java.lang.Comparable) serialDate18, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        boolean boolean2 = categoryPlot0.getDrawSharedDomainAxis();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        double double3 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj1 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date0, obj1);
        java.util.TimeZone timeZone3 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date0, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10, 7, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        java.lang.Object obj7 = null;
        boolean boolean8 = combinedRangeXYPlot0.equals(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        boolean boolean10 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "", "PieLabelLinkStyle.QUAD_CURVE", false);
        int int5 = logFormat4.getMaximumFractionDigits();
        java.lang.StringBuffer stringBuffer7 = null;
        java.text.FieldPosition fieldPosition8 = null;
        java.lang.StringBuffer stringBuffer9 = logFormat4.format((double) (byte) 1, stringBuffer7, fieldPosition8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(stringBuffer9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray12);
        categoryPlot0.setDataset(categoryDataset13);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        piePlot3D8.setAutoPopulateSectionOutlinePaint(true);
        boolean boolean12 = piePlot3D8.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset22 = combinedRangeXYPlot17.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint28 = xYLineAndShapeRenderer26.getLegendTextPaint(0);
        combinedRangeXYPlot17.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer26);
        java.util.List list30 = combinedRangeXYPlot17.getSubplots();
        combinedRangeXYPlot17.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedRangeXYPlot17.panRangeAxes((double) 6, plotRenderingInfo35, point2D36);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeZone38);
        boolean boolean41 = timeSeriesCollection39.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer43 = null;
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection39, valueAxis42, polarItemRenderer43);
        java.awt.Stroke stroke45 = polarPlot44.getRadiusGridlineStroke();
        combinedRangeXYPlot17.setDomainMinorGridlineStroke(stroke45);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean50 = categoryPlot49.isDomainZoomable();
        categoryPlot49.clearDomainMarkers();
        boolean boolean52 = categoryPlot49.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo54);
        java.awt.geom.Point2D point2D56 = null;
        categoryPlot49.zoomRangeAxes(0.0d, plotRenderingInfo55, point2D56, false);
        combinedRangeXYPlot17.handleClick(7, (-2), plotRenderingInfo55);
        try {
            piePlot3D8.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("MINOR");
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) "Polar Plot");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            java.lang.Number number3 = defaultXYDataset0.getY((int) (short) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        boolean boolean2 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setWeight(100);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Paint paint9 = combinedRangeXYPlot6.getDomainCrosshairPaint();
        combinedRangeXYPlot6.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedRangeXYPlot6.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = combinedRangeXYPlot6.getDomainMarkers(layer16);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker21.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer24 = null;
        combinedRangeXYPlot6.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker21, layer24, false);
        double double27 = intervalMarker21.getStartValue();
        double double28 = intervalMarker21.getEndValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = intervalMarker21.getLabelOffsetType();
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot0.removeRangeMarker((int) '4', (org.jfree.chart.plot.Marker) intervalMarker21, layer30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-11.0d) + "'", double28 == (-11.0d));
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation2);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer4.setBaseShape(shape5, false);
        java.awt.Color color8 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color8);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendGraphic9.getFillPaintTransformer();
        java.awt.Paint paint11 = legendGraphic9.getFillPaint();
        combinedRangeXYPlot0.setNoDataMessagePaint(paint11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        java.awt.geom.Line2D line2D24 = xYItemRendererState23.workingLine;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            boolean boolean26 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D24, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNotNull(line2D24);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        xYLineAndShapeRenderer2.setDrawSeriesLineAsPath(false);
        boolean boolean10 = xYLineAndShapeRenderer2.getItemLineVisible(4, 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        double double14 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str16 = axisSpace15.toString();
        double double17 = axisSpace15.getRight();
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace15, false);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace20, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font3 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        java.lang.String str4 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean9 = xYLineAndShapeRenderer8.getAutoPopulateSeriesShape();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer8.setBaseLegendTextFont(font10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("", font10);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) (short) 0, 0.5d, (double) 10, (double) 5, font10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer16);
        boolean boolean21 = xYLineAndShapeRenderer16.isItemLabelVisible((int) (short) 10, (int) '#', true);
        boolean boolean22 = markerAxisBand13.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        boolean boolean7 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYLineAndShapeRenderer10.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYLineAndShapeRenderer10.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image21 = null;
        combinedRangeXYPlot20.setBackgroundImage(image21);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot23);
        boolean boolean25 = combinedRangeXYPlot20.isDomainPannable();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image27 = null;
        combinedRangeXYPlot26.setBackgroundImage(image27);
        combinedRangeXYPlot20.remove((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot26);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType30 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(10);
        boolean boolean35 = periodAxis32.equals((java.lang.Object) 10);
        boolean boolean36 = dateTickUnitType30.equals((java.lang.Object) periodAxis32);
        java.lang.Object obj37 = periodAxis32.clone();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            xYLineAndShapeRenderer2.fillRangeGridBand(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D38, (double) '#', 0.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTickUnitType30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, false);
        boolean boolean11 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        xYLineAndShapeRenderer2.setBaseSeriesVisible(true, false);
        try {
            xYLineAndShapeRenderer2.setSeriesLinesVisible(2147483647, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        combinedRangeXYPlot22.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        java.util.List list35 = combinedRangeXYPlot22.getSubplots();
        combinedRangeXYPlot22.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(10);
        periodAxis43.setFirst((org.jfree.data.time.RegularTimePeriod) year45);
        java.awt.Font font47 = periodAxis43.getLabelFont();
        combinedRangeXYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis43);
        combinedRangeXYPlot22.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis43, true);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        periodAxis52.setFirst((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.String str56 = periodAxis52.getLabelURL();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean60 = timeSeriesCollection58.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, valueAxis61, polarItemRenderer62);
        xYLineAndShapeRenderer2.drawItem(graphics2D12, xYItemRendererState13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.axis.ValueAxis) periodAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, 0, (int) (short) 100, true, (int) '4');
        java.awt.Paint paint70 = xYLineAndShapeRenderer2.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(paint70);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = xYAreaRenderer0.getGradientTransformer();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        try {
            java.lang.String str6 = standardXYSeriesLabelGenerator1.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj2 = null;
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date1, obj2);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (-11L));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint6.toFixedHeight(0.0d);
        org.jfree.data.Range range11 = rectangleConstraint10.getWidthRange();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        java.lang.String str1 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.MILLISECOND" + "'", str1.equals("DateTickUnitType.MILLISECOND"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        java.util.List list7 = categoryPlot0.getCategories();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNull(legendItemCollection8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("WMAP_Plot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 1L);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator((int) '#', xYItemLabelGenerator3);
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter5 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        xYBarRenderer1.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Font font2 = standardChartTheme1.getLargeFont();
        standardChartTheme1.setShadowVisible(true);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj2 = null;
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date1, obj2);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (-11L));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint6.toFixedHeight(0.0d);
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = textBlock11.calculateDimensions(graphics2D12);
        org.jfree.chart.util.Size2D size2D14 = rectangleConstraint6.calculateConstrainedSize(size2D13);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(size2D14);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = dateTickUnit5.getRollUnitType();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) dateTickUnit5, 1.0d);
        double double9 = dateTickUnit5.getSize();
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.64E7d + "'", double9 == 8.64E7d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("series", "", "", "series");
        basicProjectInfo4.setCopyright("{0}");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo("series", "", "", "series");
        basicProjectInfo11.setCopyright("{0}");
        java.lang.String str14 = basicProjectInfo11.getName();
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo11);
        org.jfree.chart.ui.Library[] libraryArray16 = basicProjectInfo11.getLibraries();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "series" + "'", str14.equals("series"));
        org.junit.Assert.assertNotNull(libraryArray16);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot9.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot9.getDataset((int) (short) -1);
        org.jfree.data.xy.XYDataset xYDataset16 = combinedRangeXYPlot9.getDataset(1);
        try {
            java.lang.Object obj17 = legendGraphic5.draw(graphics2D7, rectangle2D8, (java.lang.Object) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNull(xYDataset16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        int int2 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = combinedRangeXYPlot0.getDomainAxisEdge();
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = combinedRangeXYPlot0.getRangeAxis();
        double double5 = valueAxis4.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-8d + "'", double5 == 1.0E-8d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = timeSeriesCollection1.getSelectionState();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(10);
        boolean boolean10 = periodAxis7.equals((java.lang.Object) 10);
        boolean boolean11 = periodAxis7.isMinorTickMarksVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) periodAxis7);
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(10);
        periodAxis14.setFirst((org.jfree.data.time.RegularTimePeriod) year16);
        java.awt.Font font18 = periodAxis14.getLabelFont();
        periodAxis14.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis14.setRange(range21, false, false);
        periodAxis7.setDefaultAutoRange(range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint5.toRangeWidth(range21);
        try {
            org.jfree.chart.util.Size2D size2D27 = textTitle0.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot2.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint13 = xYLineAndShapeRenderer11.getLegendTextPaint(0);
        combinedRangeXYPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer11);
        java.util.List list15 = combinedRangeXYPlot2.getSubplots();
        combinedRangeXYPlot2.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot2.panRangeAxes((double) 6, plotRenderingInfo20, point2D21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        boolean boolean26 = timeSeriesCollection24.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis27, polarItemRenderer28);
        java.awt.Stroke stroke30 = polarPlot29.getRadiusGridlineStroke();
        combinedRangeXYPlot2.setDomainMinorGridlineStroke(stroke30);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 9, stroke30);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate36.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate36);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate36);
        serialDate40.setDescription("");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset43 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme45 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint46 = standardChartTheme45.getLabelLinkPaint();
        java.awt.Paint paint47 = standardChartTheme45.getPlotOutlinePaint();
        java.awt.Paint paint48 = standardChartTheme45.getGridBandAlternatePaint();
        java.awt.Paint paint49 = standardChartTheme45.getSubtitlePaint();
        boolean boolean50 = defaultXYDataset43.equals((java.lang.Object) paint49);
        piePlot3D0.setSectionPaint((java.lang.Comparable) "", paint49);
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(10);
        periodAxis53.setFirst((org.jfree.data.time.RegularTimePeriod) year55);
        java.awt.Font font57 = periodAxis53.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis59 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(10);
        periodAxis59.setFirst((org.jfree.data.time.RegularTimePeriod) year61);
        java.awt.Font font63 = periodAxis59.getLabelFont();
        periodAxis59.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range66 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis59.setRange(range66, false, false);
        periodAxis53.setRange(range66, true, true);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        periodAxis53.setAxisLineStroke(stroke73);
        piePlot3D0.setLabelLinkStroke(stroke73);
        java.awt.Stroke stroke76 = piePlot3D0.getBaseSectionOutlineStroke();
        java.awt.Paint paint77 = piePlot3D0.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font3 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot9 = combinedRangeXYPlot3.getParent();
        combinedRangeXYPlot3.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = combinedRangeXYPlot3.getDomainMarkers((int) (byte) 100, layer13);
        boolean boolean15 = combinedRangeXYPlot3.isDomainPannable();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str19 = axisSpace18.toString();
        double double20 = axisSpace18.getRight();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace21 = categoryAxis3D1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot3, rectangle2D16, rectangleEdge17, axisSpace18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke3 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image5 = null;
        combinedRangeXYPlot4.setBackgroundImage(image5);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        combinedRangeXYPlot4.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = combinedRangeXYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = combinedRangeXYPlot4.getRangeAxisIndex(valueAxis11);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot4);
        java.awt.Paint paint14 = categoryPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image17 = null;
        combinedRangeXYPlot16.setBackgroundImage(image17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = combinedRangeXYPlot19.getDomainAxisLocation((int) (short) 1);
        try {
            categoryPlot0.setRangeAxisLocation((-9999), axisLocation22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendGraphic5.setShapeAnchor(rectangleAnchor6);
        boolean boolean8 = legendGraphic5.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        try {
            int[] intArray6 = timeSeriesCollection1.getSurroundingItems((int) (short) 10, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        boolean boolean8 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint3 = standardChartTheme1.getPlotOutlinePaint();
        java.awt.Paint paint4 = standardChartTheme1.getGridBandAlternatePaint();
        java.awt.Paint paint5 = standardChartTheme1.getSubtitlePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        try {
            standardChartTheme1.apply(jFreeChart6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle9.getItemLabelPadding();
        java.awt.Paint paint14 = legendTitle9.getBackgroundPaint();
        double double15 = legendTitle9.getContentXOffset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setBaseCreateEntities(true);
        xYStepAreaRenderer0.setPlotArea(false);
        double double5 = xYStepAreaRenderer0.getRangeBase();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries2.add((double) (short) 0, (double) (short) 0);
        xYSeries2.setNotify(true);
        org.jfree.data.xy.XYDataItem xYDataItem8 = null;
        try {
            xYSeries2.add(xYDataItem8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getDomainCrosshairPaint();
        categoryPlot7.setRangeZeroBaselinePaint(paint11);
        xYLineAndShapeRenderer5.setBaseFillPaint(paint11, true);
        java.text.NumberFormat numberFormat16 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat18 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat18, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat16, numberFormat18);
        xYLineAndShapeRenderer5.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator21);
        java.lang.Object obj23 = standardXYToolTipGenerator21.clone();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator25 = new org.jfree.chart.urls.StandardXYURLGenerator("Range[0.0,1.0]");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer(15, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator21, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator25);
        boolean boolean27 = dateAxis0.equals((java.lang.Object) standardXYToolTipGenerator21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(numberFormat16);
        org.junit.Assert.assertNotNull(numberFormat18);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        int int2 = categoryAxis3D1.getMaximumCategoryLabelLines();
        java.lang.Object obj3 = categoryAxis3D1.clone();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = combinedRangeXYPlot8.getDomainAxisEdge();
        try {
            double double10 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (byte) 10, (int) (byte) 0, rectangle2D7, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = combinedRangeXYPlot6.getDataset((int) (short) -1);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getRangeGridlineStroke();
        xYLineAndShapeRenderer2.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.chart.axis.ValueAxis) periodAxis13, rectangle2D14, (double) 100, (java.awt.Paint) color16, stroke20);
        boolean boolean22 = combinedRangeXYPlot6.isDomainZoomable();
        boolean boolean23 = combinedRangeXYPlot6.canSelectByPoint();
        combinedRangeXYPlot6.mapDatasetToDomainAxis(1900, 2147483647);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.setDatasetIndex(7);
        xYCrosshairState0.setAnchorY((double) '4');
        org.junit.Assert.assertNull(point2D1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent4);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor6 = org.jfree.data.time.TimePeriodAnchor.END;
        java.lang.String str7 = timePeriodAnchor6.toString();
        timeSeriesCollection1.setXPosition(timePeriodAnchor6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodAnchor.END" + "'", str7.equals("TimePeriodAnchor.END"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        combinedRangeXYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean12 = combinedRangeXYPlot0.isDomainZoomable();
        boolean boolean13 = combinedRangeXYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = null;
        try {
            combinedRangeXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot0.getDataset(1);
        java.awt.Paint paint8 = combinedRangeXYPlot0.getDomainGridlinePaint();
        java.awt.Paint paint9 = combinedRangeXYPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image15 = null;
        combinedRangeXYPlot14.setBackgroundImage(image15);
        java.awt.Paint paint17 = combinedRangeXYPlot14.getDomainCrosshairPaint();
        combinedRangeXYPlot14.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot14.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21, false);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = combinedRangeXYPlot14.getDomainMarkers(layer24);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker29.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer32 = null;
        combinedRangeXYPlot14.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker29, layer32, false);
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean37 = combinedRangeXYPlot0.removeDomainMarker(5, (org.jfree.chart.plot.Marker) intervalMarker29, layer35, true);
        java.awt.Stroke stroke38 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        java.lang.Object obj2 = xYBarRenderer1.clone();
        boolean boolean3 = xYBarRenderer1.isDrawBarOutline();
        boolean boolean4 = xYBarRenderer1.getShadowsVisible();
        java.awt.Paint paint6 = xYBarRenderer1.getSeriesFillPaint((-2));
        boolean boolean7 = xYBarRenderer1.isDrawBarOutline();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint3 = standardChartTheme1.getPlotOutlinePaint();
        java.awt.Paint paint4 = null;
        try {
            standardChartTheme1.setBaselinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot5.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot11 = combinedRangeXYPlot5.getParent();
        combinedRangeXYPlot5.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = combinedRangeXYPlot5.getDomainMarkers((int) (byte) 100, layer15);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        boolean boolean22 = periodAxis18.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getDomainCrosshairPaint();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot25.setRangeZeroBaselinePaint(paint27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.drawDomainLine(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.chart.axis.ValueAxis) periodAxis18, rectangle2D23, (double) (byte) 1, paint27, stroke29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = combinedRangeXYPlot5.getRenderer(2019);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYItemRenderer32);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.StandardChartTheme standardChartTheme11 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint12 = standardChartTheme11.getLabelLinkPaint();
        java.awt.Paint paint13 = standardChartTheme11.getPlotOutlinePaint();
        java.awt.Paint paint14 = standardChartTheme11.getGridBandAlternatePaint();
        java.awt.Paint paint15 = standardChartTheme11.getBaselinePaint();
        combinedRangeXYPlot0.setDomainTickBandPaint(paint15);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font3 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        java.lang.String str4 = categoryAxis1.getLabelURL();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 1.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        boolean boolean5 = periodAxis1.isMinorTickMarksVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) periodAxis1);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(10);
        periodAxis8.setFirst((org.jfree.data.time.RegularTimePeriod) year10);
        java.awt.Font font12 = periodAxis8.getLabelFont();
        periodAxis8.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis8.setRange(range15, false, false);
        periodAxis1.setDefaultAutoRange(range15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) month20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        int int7 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean12 = xYLineAndShapeRenderer11.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYLineAndShapeRenderer11.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = itemLabelPosition14.getItemLabelAnchor();
        xYLineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition14);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        org.jfree.chart.StandardChartTheme standardChartTheme4 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint5 = standardChartTheme4.getLabelLinkPaint();
        java.awt.Paint paint6 = standardChartTheme4.getPlotOutlinePaint();
        java.awt.Paint paint7 = standardChartTheme4.getGridBandAlternatePaint();
        java.awt.Paint paint8 = standardChartTheme4.getSubtitlePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter9 = standardChartTheme4.getBarPainter();
        boolean boolean10 = multiplePiePlot1.equals((java.lang.Object) standardChartTheme4);
        java.awt.Paint paint11 = standardChartTheme4.getLegendBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(barPainter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        java.lang.Object obj3 = barRenderer3D0.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image13 = null;
        combinedRangeXYPlot12.setBackgroundImage(image13);
        java.awt.Paint paint15 = combinedRangeXYPlot12.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint23 = categoryPlot22.getDomainCrosshairPaint();
        periodAxis18.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        java.awt.Color color25 = java.awt.Color.GREEN;
        categoryPlot22.setRangeZeroBaselinePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape11, (java.awt.Paint) color25);
        java.awt.Paint paint28 = legendItem27.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image30 = null;
        combinedRangeXYPlot29.setBackgroundImage(image30);
        java.awt.Paint paint32 = combinedRangeXYPlot29.getDomainCrosshairPaint();
        java.awt.Paint paint33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot29.setDomainMinorGridlinePaint(paint33);
        legendItem27.setOutlinePaint(paint33);
        barRenderer3D0.setBaseOutlinePaint(paint33);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D0.setBaseOutlinePaint((java.awt.Paint) color37);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint41 = categoryPlot40.getDomainCrosshairPaint();
        java.awt.Paint paint42 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot40.setRangeZeroBaselinePaint(paint42);
        java.lang.String str44 = categoryPlot40.getNoDataMessage();
        java.awt.Stroke stroke45 = categoryPlot40.getDomainGridlineStroke();
        boolean boolean46 = categoryPlot40.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font50 = categoryAxis48.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        java.lang.String str51 = categoryAxis48.getLabelURL();
        int int52 = categoryAxis48.getCategoryLabelPositionOffset();
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        try {
            barRenderer3D0.drawDomainMarker(graphics2D39, categoryPlot40, categoryAxis48, categoryMarker53, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(0, (-9999), 0, (int) (short) 0, (double) 0L, rectangle2D7, rectangleEdge8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.util.Date date13 = month12.getEnd();
        java.awt.Font font14 = categoryAxis1.getTickLabelFont((java.lang.Comparable) month12);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        java.awt.Shape shape9 = null;
        xYLineAndShapeRenderer2.setSeriesShape(9999, shape9);
        java.awt.Shape shape11 = xYLineAndShapeRenderer2.getBaseShape();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint16 = xYLineAndShapeRenderer14.getLegendTextPaint(0);
        java.lang.Boolean boolean18 = xYLineAndShapeRenderer14.getSeriesCreateEntities(0);
        boolean boolean19 = xYLineAndShapeRenderer14.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean23 = xYLineAndShapeRenderer22.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYLineAndShapeRenderer22.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYLineAndShapeRenderer22.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer14.setBasePositiveItemLabelPosition(itemLabelPosition29);
        xYLineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition29, true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setSeriesPositiveItemLabelPosition(0, itemLabelPosition4, false);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(10);
        periodAxis8.setFirst((org.jfree.data.time.RegularTimePeriod) year10);
        java.lang.Class class12 = periodAxis8.getAutoRangeTimePeriodClass();
        periodAxis8.resizeRange((double) (short) 100);
        int int15 = periodAxis8.getMinorTickCount();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint19 = periodAxis18.getTickMarkPaint();
        periodAxis18.setInverted(true);
        org.jfree.chart.entity.AxisEntity axisEntity22 = new org.jfree.chart.entity.AxisEntity(shape16, (org.jfree.chart.axis.Axis) periodAxis18);
        periodAxis8.setDownArrow(shape16);
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape16, "ClassContext", "Polar Plot");
        xYBarRenderer1.setBaseShape(shape16, false);
        xYBarRenderer1.setBaseCreateEntities(false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint4 = periodAxis3.getTickMarkPaint();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot7.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = combinedRangeXYPlot7.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint18 = xYLineAndShapeRenderer16.getLegendTextPaint(0);
        combinedRangeXYPlot7.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer16);
        java.util.List list20 = combinedRangeXYPlot7.getSubplots();
        combinedRangeXYPlot7.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        combinedRangeXYPlot7.panRangeAxes((double) 6, plotRenderingInfo25, point2D26);
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeZone28);
        boolean boolean31 = timeSeriesCollection29.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection29, valueAxis32, polarItemRenderer33);
        java.awt.Stroke stroke35 = polarPlot34.getRadiusGridlineStroke();
        combinedRangeXYPlot7.setDomainMinorGridlineStroke(stroke35);
        piePlot3D5.setSectionOutlineStroke((java.lang.Comparable) 9, stroke35);
        java.awt.Paint paint38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot39.setRangeMinorGridlineStroke(stroke40);
        java.lang.Comparable comparable42 = null;
        categoryPlot39.setDomainCrosshairColumnKey(comparable42);
        java.awt.Paint paint44 = categoryPlot39.getRangeMinorGridlinePaint();
        int int45 = categoryPlot39.getCrosshairDatasetIndex();
        java.awt.Stroke stroke46 = categoryPlot39.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker48 = new org.jfree.chart.plot.IntervalMarker((double) 86400000L, 0.0d, paint4, stroke35, paint38, stroke46, (float) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate10.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate10);
        boolean boolean15 = spreadsheetDate4.isOn(serialDate10);
        boolean boolean16 = textAnchor0.equals((java.lang.Object) serialDate10);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale7);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getCurrencyInstance(locale7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieLabelLinkStyle.QUAD_CURVE", locale7);
        java.lang.Object obj13 = null;
        boolean boolean14 = standardPieSectionLabelGenerator12.equals(obj13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        java.util.List list3 = xYSeries2.getItems();
        boolean boolean4 = xYSeries2.getAllowDuplicateXValues();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries2.getDataItem(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { "WMAP_Plot" };
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getMiddleMillisecond();
        int int4 = year2.getYear();
        org.jfree.data.xy.XYDataItem xYDataItem7 = new org.jfree.data.xy.XYDataItem((double) (short) -1, (double) 9999);
        xYDataItem7.setSelected(true);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Comparable[] comparableArray12 = new java.lang.Comparable[] { int4, true, false, month11 };
        org.jfree.data.xy.XYSeries xYSeries15 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries15.add((double) (short) 0, (double) (short) 0);
        xYSeries15.setNotify(true);
        double[][] doubleArray21 = xYSeries15.toArray();
        try {
            org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray12, doubleArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer3D11.getItemLabelGenerator((int) (short) 10, 7, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint24 = xYLineAndShapeRenderer22.getLegendTextPaint(0);
        java.lang.Boolean boolean26 = xYLineAndShapeRenderer22.getSeriesCreateEntities(0);
        boolean boolean27 = xYLineAndShapeRenderer22.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean31 = xYLineAndShapeRenderer30.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYLineAndShapeRenderer30.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = xYLineAndShapeRenderer30.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer22.setBasePositiveItemLabelPosition(itemLabelPosition37);
        barRenderer3D11.setSeriesPositiveItemLabelPosition(100, itemLabelPosition37);
        barRenderer3D11.setShadowYOffset((double) 0.0f);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        double double3 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.setRangePannable(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, plotRenderingInfo7, point2D8);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        piePlot3D8.setAutoPopulateSectionOutlinePaint(true);
        boolean boolean12 = piePlot3D8.getIgnoreZeroValues();
        boolean boolean13 = piePlot3D8.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        java.awt.Stroke stroke7 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        categoryPlot12.setRangeZeroBaselinePaint(paint16);
        xYLineAndShapeRenderer10.setBaseFillPaint(paint16, true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYLineAndShapeRenderer10.getURLGenerator(9999, (-9999), false);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer10);
        combinedRangeXYPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(xYURLGenerator23);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYLineAndShapeRenderer3.getPositiveItemLabelPosition((-1), 3, true);
        boolean boolean11 = strokeList0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        boolean boolean14 = xYBarRenderer13.getShadowsVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer13.setSeriesPositiveItemLabelPosition(0, itemLabelPosition16, false);
        xYLineAndShapeRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition16);
        double double20 = itemLabelPosition16.getAngle();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        java.awt.Paint paint8 = xYLineAndShapeRenderer2.getSeriesOutlinePaint((int) (byte) -1);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYLineAndShapeRenderer2.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint19 = categoryPlot18.getDomainCrosshairPaint();
        categoryPlot15.setRangeZeroBaselinePaint(paint19);
        xYLineAndShapeRenderer13.setBaseFillPaint(paint19, true);
        java.text.NumberFormat numberFormat24 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat26 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat26, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator29 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat24, numberFormat26);
        xYLineAndShapeRenderer13.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator29);
        java.lang.Object obj31 = standardXYToolTipGenerator29.clone();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType32 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(10);
        boolean boolean37 = periodAxis34.equals((java.lang.Object) 10);
        boolean boolean38 = dateTickUnitType32.equals((java.lang.Object) periodAxis34);
        java.awt.Shape shape39 = periodAxis34.getUpArrow();
        boolean boolean40 = standardXYToolTipGenerator29.equals((java.lang.Object) shape39);
        boolean boolean41 = standardXYURLGenerator9.equals((java.lang.Object) shape39);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(numberFormat24);
        org.junit.Assert.assertNotNull(numberFormat26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(dateTickUnitType32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        int int8 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Paint paint12 = combinedRangeXYPlot9.getDomainCrosshairPaint();
        combinedRangeXYPlot9.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = combinedRangeXYPlot9.getSeriesRenderingOrder();
        java.util.List list15 = combinedRangeXYPlot9.getSubplots();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(10);
        periodAxis17.setFirst((org.jfree.data.time.RegularTimePeriod) year19);
        java.awt.Font font21 = periodAxis17.getLabelFont();
        periodAxis17.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis17.setRange(range24, false, false);
        org.jfree.data.Range range29 = timeSeriesCollection1.getRangeBounds(list15, range24, false);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNull(number30);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        boolean boolean18 = categoryPlot15.removeDomainMarker(marker16, layer17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image20 = null;
        combinedRangeXYPlot19.setBackgroundImage(image20);
        java.awt.Paint paint22 = combinedRangeXYPlot19.getDomainCrosshairPaint();
        combinedRangeXYPlot19.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        combinedRangeXYPlot19.zoomRangeAxes(0.0d, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = combinedRangeXYPlot19.getDomainMarkers(layer29);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker34.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer37 = null;
        combinedRangeXYPlot19.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker34, layer37, false);
        double double40 = intervalMarker34.getStartValue();
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean42 = categoryPlot15.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker34, layer41);
        java.awt.Stroke stroke43 = intervalMarker34.getOutlineStroke();
        java.awt.Paint paint44 = intervalMarker34.getPaint();
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker34, layer45);
        org.jfree.chart.axis.AxisSpace axisSpace47 = new org.jfree.chart.axis.AxisSpace();
        double double48 = axisSpace47.getLeft();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace47, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean53 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge52);
        axisSpace47.ensureAtLeast(0.0d, rectangleEdge52);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Font font16 = barRenderer3D11.getSeriesItemLabelFont(1);
        java.awt.Paint paint18 = barRenderer3D11.getSeriesFillPaint((int) '4');
        double double19 = barRenderer3D11.getBase();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        barRenderer3D11.setSeriesToolTipGenerator(3, categoryToolTipGenerator21);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            barRenderer3D11.addAnnotation(categoryAnnotation23, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(layer24);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int3 = dateTickUnit2.getRollMultiple();
        dateAxis0.setTickUnit(dateTickUnit2);
        org.junit.Assert.assertNotNull(timeline1);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean10 = xYLineAndShapeRenderer9.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYLineAndShapeRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYLineAndShapeRenderer9.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer9.setBaseCreateEntities(true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = barRenderer3D19.removeAnnotation(categoryAnnotation20);
        java.lang.Object obj22 = barRenderer3D19.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer3D19.setSeriesURLGenerator(0, categoryURLGenerator24);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(10);
        boolean boolean40 = periodAxis37.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint42 = categoryPlot41.getDomainCrosshairPaint();
        periodAxis37.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot41);
        java.awt.Color color44 = java.awt.Color.GREEN;
        categoryPlot41.setRangeZeroBaselinePaint((java.awt.Paint) color44);
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape30, (java.awt.Paint) color44);
        java.awt.Paint paint47 = legendItem46.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image49 = null;
        combinedRangeXYPlot48.setBackgroundImage(image49);
        java.awt.Paint paint51 = combinedRangeXYPlot48.getDomainCrosshairPaint();
        java.awt.Paint paint52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot48.setDomainMinorGridlinePaint(paint52);
        legendItem46.setOutlinePaint(paint52);
        barRenderer3D19.setBaseOutlinePaint(paint52);
        xYLineAndShapeRenderer9.setBaseFillPaint(paint52);
        boolean boolean57 = legendGraphic5.equals((java.lang.Object) xYLineAndShapeRenderer9);
        java.awt.Shape shape58 = legendGraphic5.getShape();
        boolean boolean59 = legendGraphic5.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] { stroke4, stroke5, stroke6 };
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke8 };
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray7, strokeArray9, shapeArray10);
        java.awt.Stroke stroke12 = defaultDrawingSupplier11.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shapeArray10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj2 = null;
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date1, obj2);
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(10);
        boolean boolean9 = periodAxis6.equals((java.lang.Object) 10);
        boolean boolean10 = periodAxis6.isMinorTickMarksVisible();
        java.util.Locale locale11 = periodAxis6.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale11);
        java.text.NumberFormat numberFormat13 = java.text.NumberFormat.getCurrencyInstance(locale11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date1, timeZone4, locale11);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("DateTickUnitType.MILLISECOND", timeZone4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(locale11);
        org.junit.Assert.assertNotNull(tickUnitSource12);
        org.junit.Assert.assertNotNull(numberFormat13);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        piePlot3D8.clearSectionOutlineStrokes(false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot3D8.getLabelDistributor();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.DomainOrder domainOrder3 = defaultXYDataset2.getDomainOrder();
        boolean boolean4 = xYSeriesCollection1.equals((java.lang.Object) defaultXYDataset2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean8 = timeSeriesCollection6.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis9, polarItemRenderer10);
        int int13 = timeSeriesCollection6.indexOf((java.lang.Comparable) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image15 = null;
        combinedRangeXYPlot14.setBackgroundImage(image15);
        java.awt.Paint paint17 = combinedRangeXYPlot14.getDomainCrosshairPaint();
        combinedRangeXYPlot14.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = combinedRangeXYPlot14.getSeriesRenderingOrder();
        java.util.List list20 = combinedRangeXYPlot14.getSubplots();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(10);
        periodAxis22.setFirst((org.jfree.data.time.RegularTimePeriod) year24);
        java.awt.Font font26 = periodAxis22.getLabelFont();
        periodAxis22.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis22.setRange(range29, false, false);
        org.jfree.data.Range range34 = timeSeriesCollection6.getRangeBounds(list20, range29, false);
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(10);
        periodAxis36.setFirst((org.jfree.data.time.RegularTimePeriod) year38);
        java.awt.Font font40 = periodAxis36.getLabelFont();
        periodAxis36.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range43 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis36.setRange(range43, false, false);
        boolean boolean48 = range43.contains((double) (byte) 10);
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(10);
        periodAxis50.setFirst((org.jfree.data.time.RegularTimePeriod) year52);
        java.awt.Font font54 = periodAxis50.getLabelFont();
        periodAxis50.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range57 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis50.setRange(range57, false, false);
        java.lang.String str61 = range57.toString();
        org.jfree.data.Range range62 = org.jfree.data.Range.combine(range43, range57);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, list20, range43, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate66 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection1, false);
        org.junit.Assert.assertNotNull(domainOrder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Range[0.0,1.0]" + "'", str61.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNull(range64);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        boolean boolean22 = legendItem20.isShapeVisible();
        java.lang.String str23 = legendItem20.getLabel();
        legendItem20.setSeriesIndex(100);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Range[0.0,1.0]" + "'", str23.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries2.add((double) (short) 0, (double) (short) 0);
        xYSeries2.setNotify(true);
        int int9 = xYSeries2.indexOf((java.lang.Number) 3);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        xYSeries2.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2) + "'", int9 == (-2));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker15.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer18 = null;
        combinedRangeXYPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker15, layer18, false);
        double double21 = intervalMarker15.getStartValue();
        double double22 = intervalMarker15.getEndValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker15);
        org.jfree.chart.plot.Marker marker24 = markerChangeEvent23.getMarker();
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        marker24.setLabelTextAnchor(textAnchor25);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-11.0d) + "'", double22 == (-11.0d));
        org.junit.Assert.assertNotNull(marker24);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.lang.String str4 = categoryPlot0.getNoDataMessage();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean6 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setDrawSharedDomainAxis(true);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        java.lang.String str22 = legendItem20.getToolTipText();
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint25 = standardChartTheme24.getLabelLinkPaint();
        java.awt.Paint paint26 = standardChartTheme24.getPlotOutlinePaint();
        java.awt.Paint paint27 = standardChartTheme24.getGridBandAlternatePaint();
        java.awt.Paint paint28 = standardChartTheme24.getBaselinePaint();
        boolean boolean29 = legendItem20.equals((java.lang.Object) paint28);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodAnchor.END" + "'", str22.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        boolean boolean4 = timeSeriesCollection2.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis5, polarItemRenderer6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = timeSeriesCollection2.getGroup();
        boolean boolean9 = gradientPaintTransformType0.equals((java.lang.Object) datasetGroup8);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Font font16 = barRenderer3D11.getSeriesItemLabelFont(1);
        java.awt.Paint paint18 = barRenderer3D11.getSeriesFillPaint((int) '4');
        double double19 = barRenderer3D11.getBase();
        boolean boolean23 = barRenderer3D11.getItemCreateEntity(8, (int) (byte) 10, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 9999, (double) (-9999), (int) (short) 100, (java.lang.Comparable) Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        xYLineAndShapeRenderer2.setSeriesShapesFilled(3, (java.lang.Boolean) false);
        xYLineAndShapeRenderer2.setUseOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(1);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean9 = xYLineAndShapeRenderer2.getItemCreateEntity(0, 100, true);
        xYLineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        double double2 = axisState0.getCursor();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent14);
        java.awt.Paint paint16 = combinedRangeXYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        boolean boolean22 = periodAxis18.isMinorTickMarksVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) periodAxis18);
        combinedRangeXYPlot0.axisChanged(axisChangeEvent23);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.removeAnnotations();
        java.awt.Paint paint6 = barRenderer3D0.getSeriesOutlinePaint(8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D0.getURLGenerator(9999, 500, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYLineAndShapeRenderer9.setBaseShape(shape13, false);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.entity.XYItemEntity xYItemEntity26 = new org.jfree.chart.entity.XYItemEntity(shape13, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, (int) ' ', (int) (byte) 1, "series", "");
        int int27 = xYItemEntity26.getItem();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeZone28);
        boolean boolean31 = timeSeriesCollection29.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeriesCollection29.getSeries((java.lang.Comparable) (-1));
        double double35 = timeSeriesCollection29.getDomainUpperBound(true);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor36 = timeSeriesCollection29.getXPosition();
        xYItemEntity26.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        double double39 = timeSeriesCollection29.getDomainUpperBound(false);
        int int40 = timeSeriesCollection29.getSeriesCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(timeSeries33);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor36);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.DomainOrder domainOrder1 = defaultXYDataset0.getDomainOrder();
        java.lang.Comparable comparable2 = null;
        double[] doubleArray4 = new double[] { 35.0d };
        double[] doubleArray6 = new double[] { 35.0d };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        try {
            defaultXYDataset0.addSeries(comparable2, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'seriesKey' cannot be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) '4', (double) 3, 0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 1L);
        java.awt.geom.RectangularShape rectangularShape10 = null;
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image15 = null;
        combinedRangeXYPlot14.setBackgroundImage(image15);
        java.awt.Paint paint17 = combinedRangeXYPlot14.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape13, (org.jfree.chart.plot.Plot) combinedRangeXYPlot14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer21);
        org.jfree.chart.entity.TitleEntity titleEntity24 = new org.jfree.chart.entity.TitleEntity(shape13, (org.jfree.chart.title.Title) legendTitle22, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = legendTitle22.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle22.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle22.setLegendItemGraphicEdge(rectangleEdge27);
        axisSpace11.add((double) (byte) -1, rectangleEdge27);
        try {
            gradientXYBarPainter3.paintBar(graphics2D4, xYBarRenderer6, (-9999), (int) (byte) 100, false, rectangularShape10, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.updateCrosshairY((double) 0L, 100);
        xYCrosshairState0.setCrosshairX((double) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isDomainZoomable();
        categoryPlot13.clearDomainMarkers();
        java.util.List list16 = categoryPlot13.getCategories();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot13.getOrientation();
        xYCrosshairState0.updateCrosshairPoint(0.0d, 0.5d, 1900, 5, (double) 5, 10.0d, plotOrientation17);
        org.junit.Assert.assertNull(point2D1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertNotNull(plotOrientation17);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(0, (-9999), 0, (int) (short) 0, (double) 0L, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.util.Date date18 = month17.getEnd();
        java.awt.Font font19 = categoryAxis6.getTickLabelFont((java.lang.Comparable) month17);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = categoryAxis21.getCategoryLabelPositions();
        int int23 = categoryAxis21.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setCategoryLabelPositionOffset((int) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis28.getCategorySeriesMiddle(0, (-9999), 0, (int) (short) 0, (double) 0L, rectangle2D34, rectangleEdge35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        int int39 = categoryAxis3D38.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray40 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis6, categoryAxis21, categoryAxis24, categoryAxis28, categoryAxis3D38 };
        categoryPlot0.setDomainAxes(categoryAxisArray40);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray40);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset9 = polarPlot6.getDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate10 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset9);
        intervalXYDelegate10.setFixedIntervalWidth(0.0d);
        try {
            double double15 = intervalXYDelegate10.getStartXValue(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getDomainCrosshairPaint();
        periodAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = periodAxis1.getFirst();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeriesCollection10.getSeries((java.lang.Comparable) 1);
        boolean boolean14 = periodAxis1.hasListener((java.util.EventListener) timeSeriesCollection10);
        timeSeriesCollection10.validateObject();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot1.getRangeMarkers(layer4);
        defaultXYDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot1);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart6.removeProgressListener(chartProgressListener7);
        org.jfree.chart.plot.Plot plot9 = jFreeChart6.getPlot();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean12 = xYLineAndShapeRenderer11.getAutoPopulateSeriesShape();
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer11.setBaseLegendTextFont(font13);
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font13);
        xYLineAndShapeRenderer2.setLegendTextFont(1, font13);
        boolean boolean19 = xYLineAndShapeRenderer2.getItemShapeVisible(3, (int) (byte) 0);
        boolean boolean20 = xYLineAndShapeRenderer2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer14);
        org.jfree.chart.entity.TitleEntity titleEntity17 = new org.jfree.chart.entity.TitleEntity(shape6, (org.jfree.chart.title.Title) legendTitle15, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = legendTitle15.getHorizontalAlignment();
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle15, "MINOR", "RectangleInsets[t=1.0,l=32.0,b=35.0,r=0.0]");
        org.jfree.chart.title.Title title22 = titleEntity21.getTitle();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(title22);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        periodAxis1.setMinorTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(10);
        boolean boolean13 = periodAxis10.equals((java.lang.Object) 10);
        boolean boolean14 = periodAxis10.isMinorTickMarksVisible();
        java.util.Locale locale15 = periodAxis10.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale15);
        java.text.NumberFormat numberFormat17 = java.text.NumberFormat.getCurrencyInstance(locale15);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale15);
        java.lang.Object obj19 = standardPieSectionLabelGenerator18.clone();
        piePlot3D8.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator18);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int27 = spreadsheetDate25.getYYYY();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate31.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate31);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate31);
        boolean boolean36 = spreadsheetDate25.isOn(serialDate31);
        try {
            java.text.AttributedString attributedString37 = standardPieSectionLabelGenerator18.generateAttributedSectionLabel(pieDataset21, (java.lang.Comparable) boolean36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertNotNull(numberFormat17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1900 + "'", int27 == 1900);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        multiplePiePlot1.setLimit((double) 0L);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) chartChangeEventType4);
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot1.getPieChart();
        jFreeChart6.setAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            java.awt.image.BufferedImage bufferedImage13 = jFreeChart6.createBufferedImage(9999, 0, (int) (byte) 100, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jFreeChart6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        boolean boolean7 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYLineAndShapeRenderer10.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYLineAndShapeRenderer10.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image22 = null;
        combinedRangeXYPlot21.setBackgroundImage(image22);
        java.awt.Stroke stroke24 = combinedRangeXYPlot21.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset26 = combinedRangeXYPlot21.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot27 = combinedRangeXYPlot21.getParent();
        combinedRangeXYPlot21.setDomainCrosshairVisible(true);
        combinedRangeXYPlot21.configureDomainAxes();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeZone31);
        boolean boolean34 = timeSeriesCollection32.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection32, valueAxis35, polarItemRenderer36);
        org.jfree.data.Range range39 = timeSeriesCollection32.getDomainBounds(true);
        org.jfree.data.xy.XYDataItem xYDataItem42 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem42.setY((double) 100.0f);
        int int45 = timeSeriesCollection32.indexOf((java.lang.Comparable) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState47 = xYLineAndShapeRenderer2.initialise(graphics2D19, rectangle2D20, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot21, (org.jfree.data.xy.XYDataset) timeSeriesCollection32, plotRenderingInfo46);
        boolean boolean48 = xYItemRendererState47.getProcessVisibleItemsOnly();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.DomainOrder domainOrder9 = org.jfree.data.DomainOrder.NONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.util.Date date13 = month12.getEnd();
        boolean boolean14 = domainOrder9.equals((java.lang.Object) month12);
        java.util.Date date15 = month12.getEnd();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) month12, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(domainOrder9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.RenderingHints renderingHints9 = jFreeChart6.getRenderingHints();
        jFreeChart6.fireChartChanged();
        int int11 = jFreeChart6.getBackgroundImageAlignment();
        jFreeChart6.clearSubtitles();
        java.util.List list13 = jFreeChart6.getSubtitles();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart6.getPadding();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Point2D point2D17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            jFreeChart6.draw(graphics2D15, rectangle2D16, point2D17, chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYLineAndShapeRenderer9.setBaseShape(shape13, false);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.entity.XYItemEntity xYItemEntity26 = new org.jfree.chart.entity.XYItemEntity(shape13, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, (int) ' ', (int) (byte) 1, "series", "");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer27.setBaseShape(shape28, false);
        java.awt.Color color31 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape28, (java.awt.Paint) color31);
        boolean boolean33 = org.jfree.chart.util.ShapeUtilities.equal(shape13, shape28);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Paint paint25 = combinedRangeXYPlot22.getDomainCrosshairPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot22.setDomainMinorGridlinePaint(paint26);
        legendItem20.setOutlinePaint(paint26);
        org.jfree.data.general.Dataset dataset29 = legendItem20.getDataset();
        java.awt.Paint paint30 = legendItem20.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(dataset29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setVisible(true);
        textTitle0.setToolTipText("Polar Plot");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        java.awt.Font font9 = labelBlock7.getFont();
        java.awt.Color color10 = java.awt.Color.black;
        labelBlock7.setPaint((java.awt.Paint) color10);
        labelBlock7.setHeight(2.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = labelBlock7.getTextAnchor();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries2.add((double) (short) 0, (double) (short) 0);
        xYSeries2.setNotify(true);
        int int9 = xYSeries2.indexOf((java.lang.Number) 3);
        java.lang.String str10 = xYSeries2.getDescription();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2) + "'", int9 == (-2));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Font font16 = barRenderer3D11.getSeriesItemLabelFont(1);
        java.awt.Paint paint18 = barRenderer3D11.getSeriesFillPaint((int) '4');
        double double19 = barRenderer3D11.getBase();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        barRenderer3D11.setSeriesToolTipGenerator(3, categoryToolTipGenerator21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot24.setRangeMinorGridlineStroke(stroke25);
        java.lang.Comparable comparable27 = null;
        categoryPlot24.setDomainCrosshairColumnKey(comparable27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot24.getDomainAxisEdge((int) 'a');
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis31);
        java.text.DateFormat dateFormat33 = null;
        dateAxis31.setDateFormatOverride(dateFormat33);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.Paint paint37 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeZone38);
        boolean boolean41 = timeSeriesCollection39.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer43 = null;
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection39, valueAxis42, polarItemRenderer43);
        java.awt.Stroke stroke45 = polarPlot44.getRadiusGridlineStroke();
        try {
            barRenderer3D11.drawRangeLine(graphics2D23, categoryPlot24, (org.jfree.chart.axis.ValueAxis) dateAxis31, rectangle2D35, 0.2d, paint37, stroke45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        java.awt.Paint paint6 = legendTitle4.getBackgroundPaint();
        legendTitle4.setID("");
        java.awt.Paint paint9 = legendTitle4.getItemPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.setBaseStroke(stroke7, false);
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) (short) 1);
        xYLineAndShapeRenderer2.setBaseShape(shape14);
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYLineAndShapeRenderer2.setBaseItemLabelPaint(paint16);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset9 = polarPlot6.getDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate10 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset9);
        intervalXYDelegate10.setFixedIntervalWidth(0.0d);
        java.lang.Object obj13 = intervalXYDelegate10.clone();
        double double15 = intervalXYDelegate10.getDomainUpperBound(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        boolean boolean5 = periodAxis1.isMinorTickMarksVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) periodAxis1);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(10);
        periodAxis8.setFirst((org.jfree.data.time.RegularTimePeriod) year10);
        java.awt.Font font12 = periodAxis8.getLabelFont();
        periodAxis8.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis8.setRange(range15, false, false);
        periodAxis1.setDefaultAutoRange(range15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis1);
        periodAxis1.setRangeAboutValue(0.4d, 0.4d);
        periodAxis1.setUpperMargin(0.4d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.lang.String str4 = categoryPlot0.getNoDataMessage();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean6 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str13 = axisSpace12.toString();
        axisSpace11.ensureAtLeast(axisSpace12);
        categoryPlot0.setFixedDomainAxisSpace(axisSpace11, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        barRenderer3D0.setIncludeBaseInRange(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator9, false);
        java.awt.Paint paint12 = barRenderer3D0.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Color color2 = java.awt.Color.getColor("PieLabelLinkStyle.QUAD_CURVE", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Pie 3D Plot", graphics2D1, (float) 3, 2.0f, (double) 2.0f, (float) (-1), (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 1L);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator((int) '#', xYItemLabelGenerator3);
        double double5 = xYBarRenderer1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle4.setVerticalAlignment(verticalAlignment6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle4.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Range[0.0,1.0]");
        try {
            dateAxis1.zoomRange(8.64E7d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8.64E7) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate10.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate10);
        boolean boolean15 = spreadsheetDate4.isOn(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        boolean boolean5 = periodAxis1.isMinorTickMarksVisible();
        java.util.Locale locale6 = periodAxis1.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale6);
        java.text.NumberFormat numberFormat8 = java.text.NumberFormat.getCurrencyInstance(locale6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale6);
        java.lang.Object obj10 = standardPieSectionLabelGenerator9.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = dateTickUnit5.getRollUnitType();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) dateTickUnit5, 1.0d);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.util.Date date12 = month11.getEnd();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj15 = null;
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date14, obj15);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(date13, date14);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(date12, date14);
        try {
            defaultPieDataset0.remove((java.lang.Comparable) date12);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (Tue Jan 31 23:59:59 PST 2) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        dateAxis0.configure();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean4 = xYBarRenderer0.getItemCreateEntity((int) (short) 100, 6, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo18, categoryCrosshairState19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot0.getLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        int int23 = categoryPlot0.getIndexOf(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.panDomainAxes(0.05d, plotRenderingInfo4, point2D5);
        boolean boolean7 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        categoryPlot0.handleClick((int) ' ', (int) (byte) 10, plotRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = plotRenderingInfo11.getSubplotInfo(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem2.setY((double) 100.0f);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        boolean boolean6 = xYDataItem2.equals((java.lang.Object) stroke5);
        xYDataItem2.setY((double) (short) 100);
        xYDataItem2.setY(0.0d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot13.setRangeMinorGridlineStroke(stroke14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot13.panDomainAxes(0.05d, plotRenderingInfo17, point2D18);
        boolean boolean20 = categoryPlot13.isRangeZeroBaselineVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        categoryPlot13.handleClick((int) ' ', (int) (byte) 10, plotRenderingInfo24);
        org.jfree.chart.renderer.RendererState rendererState26 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo24);
        java.awt.geom.Point2D point2D27 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot28 = combinedRangeXYPlot0.findSubplot(plotRenderingInfo24, point2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke4 = categoryPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getMargin();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke4, rectangleInsets10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets10.createInsetRectangle(rectangle2D12, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer3D2.removeAnnotation(categoryAnnotation3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = barRenderer3D2.getPlot();
        barRenderer3D2.setShadowXOffset((double) 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer3D2.getLegendItemURLGenerator();
        java.awt.geom.RectangularShape rectangularShape12 = null;
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean16 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge15);
        axisSpace13.ensureAtLeast(0.0d, rectangleEdge15);
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D2, 10, (int) (short) 1, false, rectangularShape12, rectangleEdge15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryPlot5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        xYLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        xYLineAndShapeRenderer2.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        java.awt.Stroke stroke26 = xYLineAndShapeRenderer2.getSeriesStroke((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(stroke26);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate1.setDescription("MINOR");
        java.lang.String str4 = serialDate1.getDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MINOR" + "'", str4.equals("MINOR"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation3);
        boolean boolean5 = categoryPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Paint paint1 = barRenderer3D0.getBaseLegendTextPaint();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getDomainCrosshairPaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot5.setRangeZeroBaselinePaint(paint7);
        java.lang.String str9 = categoryPlot5.getNoDataMessage();
        java.awt.Stroke stroke10 = categoryPlot5.getDomainGridlineStroke();
        boolean boolean11 = categoryPlot5.isRangeZeroBaselineVisible();
        categoryPlot5.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot5.getDomainAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis17.getCategorySeriesMiddle(0, (-9999), 0, (int) (short) 0, (double) 0L, rectangle2D23, rectangleEdge24);
        categoryAxis17.setCategoryMargin((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image29 = null;
        combinedRangeXYPlot28.setBackgroundImage(image29);
        java.awt.Stroke stroke31 = combinedRangeXYPlot28.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset33 = combinedRangeXYPlot28.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint39 = xYLineAndShapeRenderer37.getLegendTextPaint(0);
        combinedRangeXYPlot28.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer37);
        java.util.List list41 = combinedRangeXYPlot28.getSubplots();
        combinedRangeXYPlot28.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot46 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint47 = combinedRangeXYPlot46.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis49 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(10);
        periodAxis49.setFirst((org.jfree.data.time.RegularTimePeriod) year51);
        java.awt.Font font53 = periodAxis49.getLabelFont();
        combinedRangeXYPlot46.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis49);
        combinedRangeXYPlot28.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis49, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray69 = new java.lang.Number[][] { numberArray62, numberArray65, numberArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray69);
        categoryPlot57.setDataset(categoryDataset70);
        java.lang.Number number72 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset70);
        boolean boolean73 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset70);
        try {
            barRenderer3D0.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D4, categoryPlot5, categoryAxis17, (org.jfree.chart.axis.ValueAxis) periodAxis49, categoryDataset70, 0, 6, true, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 0.0d + "'", number72.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot2.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint13 = xYLineAndShapeRenderer11.getLegendTextPaint(0);
        combinedRangeXYPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer11);
        java.util.List list15 = combinedRangeXYPlot2.getSubplots();
        combinedRangeXYPlot2.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot2.panRangeAxes((double) 6, plotRenderingInfo20, point2D21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        boolean boolean26 = timeSeriesCollection24.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis27, polarItemRenderer28);
        java.awt.Stroke stroke30 = polarPlot29.getRadiusGridlineStroke();
        combinedRangeXYPlot2.setDomainMinorGridlineStroke(stroke30);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 9, stroke30);
        double double33 = piePlot3D0.getInteriorGap();
        piePlot3D0.setLabelGap((double) (short) 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.08d + "'", double33 == 0.08d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle9.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle9.setLegendItemGraphicEdge(rectangleEdge14);
        boolean boolean16 = legendTitle9.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle9.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYLineAndShapeRenderer3.getPositiveItemLabelPosition((-1), 3, true);
        boolean boolean11 = strokeList0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        xYLineAndShapeRenderer3.setSeriesShapesVisible((int) '#', (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Stroke stroke1 = barRenderer3D0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = barRenderer3D0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(itemLabelPosition4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        java.awt.Color color9 = java.awt.Color.orange;
        labelBlock7.setPaint((java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.RenderingHints renderingHints9 = jFreeChart6.getRenderingHints();
        jFreeChart6.fireChartChanged();
        int int11 = jFreeChart6.getBackgroundImageAlignment();
        jFreeChart6.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart6.getLegend((int) (byte) 1);
        java.lang.Object obj15 = null;
        boolean boolean16 = jFreeChart6.equals(obj15);
        java.lang.Object obj17 = jFreeChart6.getTextAntiAlias();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        boolean boolean9 = piePlot3D8.getAutoPopulateSectionPaint();
        piePlot3D8.setShadowXOffset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        multiplePiePlot1.setLimit((double) 0L);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) chartChangeEventType4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        java.awt.Color color8 = color6.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        int int1 = strokeList0.size();
        java.lang.Object obj2 = strokeList0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean11 = xYLineAndShapeRenderer9.getSeriesVisible(2);
        int int12 = xYLineAndShapeRenderer9.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint15 = periodAxis14.getTickMarkPaint();
        xYLineAndShapeRenderer9.setBaseFillPaint(paint15, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYLineAndShapeRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYLineAndShapeRenderer9.setSeriesNegativeItemLabelPosition(0, itemLabelPosition24);
        java.awt.Shape shape29 = xYLineAndShapeRenderer9.getItemShape(2, (-1), true);
        xYLineAndShapeRenderer2.setLegendLine(shape29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        combinedRangeXYPlot31.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = combinedRangeXYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        java.awt.Paint paint38 = jFreeChart37.getBackgroundPaint();
        java.lang.Object obj39 = jFreeChart37.getTextAntiAlias();
        java.awt.RenderingHints renderingHints40 = jFreeChart37.getRenderingHints();
        jFreeChart37.fireChartChanged();
        int int42 = jFreeChart37.getBackgroundImageAlignment();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity44 = new org.jfree.chart.entity.JFreeChartEntity(shape29, jFreeChart37, "hi!");
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection46 = new org.jfree.data.time.TimeSeriesCollection(timeZone45);
        boolean boolean48 = timeSeriesCollection46.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection46, valueAxis49, polarItemRenderer50);
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint54 = periodAxis53.getTickMarkPaint();
        periodAxis53.setInverted(true);
        org.jfree.chart.axis.PeriodAxis periodAxis58 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(10);
        boolean boolean61 = periodAxis58.equals((java.lang.Object) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer64 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean65 = xYLineAndShapeRenderer64.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer64.setAutoPopulateSeriesPaint(false);
        java.awt.Color color68 = java.awt.Color.gray;
        int int69 = color68.getTransparency();
        xYLineAndShapeRenderer64.setBaseItemLabelPaint((java.awt.Paint) color68);
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection46, (org.jfree.chart.axis.ValueAxis) periodAxis53, (org.jfree.chart.axis.ValueAxis) periodAxis58, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer64);
        org.jfree.chart.entity.AxisEntity axisEntity72 = new org.jfree.chart.entity.AxisEntity(shape29, (org.jfree.chart.axis.Axis) periodAxis53);
        java.lang.String str73 = axisEntity72.getShapeCoords();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNotNull(renderingHints40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "-3,-3,3,3" + "'", str73.equals("-3,-3,3,3"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("DateTickUnitType.MILLISECOND");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key DateTickUnitType.MILLISECOND");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        java.util.List list2 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = null;
        boolean boolean2 = defaultDrawingSupplier0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        piePlot3D8.setAutoPopulateSectionOutlinePaint(true);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset12 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset12.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset12.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset12);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor21 = piePlot3D20.getLabelDistributor();
        piePlot3D8.setLabelDistributor(abstractPieLabelDistributor21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor21);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Font font16 = barRenderer3D11.getSeriesItemLabelFont(1);
        java.awt.Paint paint18 = barRenderer3D11.getSeriesFillPaint((int) '4');
        double double19 = barRenderer3D11.getBase();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        barRenderer3D11.setSeriesToolTipGenerator(3, categoryToolTipGenerator21);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        barRenderer3D11.setBaseToolTipGenerator(categoryToolTipGenerator23, false);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot27.setRangeMinorGridlineStroke(stroke28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        categoryPlot27.setRangeAxis(valueAxis30);
        boolean boolean32 = categoryPlot27.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = categoryAxis34.getCategoryLabelPositions();
        categoryPlot27.setDomainAxis(categoryAxis34);
        categoryPlot27.setRangePannable(true);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot27.setRangeZeroBaselinePaint((java.awt.Paint) color39);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        try {
            barRenderer3D11.drawBackground(graphics2D26, categoryPlot27, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem2.setY((double) 100.0f);
        xYDataItem2.setY((double) (byte) 1);
        java.lang.Object obj7 = xYDataItem2.clone();
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        combinedRangeXYPlot0.panRangeAxes((double) 6, plotRenderingInfo18, point2D19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        boolean boolean24 = timeSeriesCollection22.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, valueAxis25, polarItemRenderer26);
        java.awt.Stroke stroke28 = polarPlot27.getRadiusGridlineStroke();
        combinedRangeXYPlot0.setDomainMinorGridlineStroke(stroke28);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean33 = categoryPlot32.isDomainZoomable();
        categoryPlot32.clearDomainMarkers();
        boolean boolean35 = categoryPlot32.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot32.zoomRangeAxes(0.0d, plotRenderingInfo38, point2D39, false);
        combinedRangeXYPlot0.handleClick(7, (-2), plotRenderingInfo38);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo38);
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection45 = new org.jfree.data.time.TimeSeriesCollection(timeZone44);
        boolean boolean47 = timeSeriesCollection45.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer49 = null;
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection45, valueAxis48, polarItemRenderer49);
        org.jfree.data.Range range52 = timeSeriesCollection45.getDomainBounds(true);
        try {
            state43.startSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection45, 6, (-1), 5, 5, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(range52);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("JFreeChartEntity: tooltip = hi!");
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        boolean boolean22 = legendItem20.isShapeVisible();
        java.lang.String str23 = legendItem20.getLabel();
        java.awt.Paint paint24 = legendItem20.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Range[0.0,1.0]" + "'", str23.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("ClassContext");
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = java.awt.Color.getColor("Oct", color4);
        textTitle0.setPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot0.getDomainMarkers(5, layer18);
        categoryPlot0.setCrosshairDatasetIndex(1, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot0.getRenderer(2);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(categoryItemRenderer24);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        categoryPlot0.setRangePannable(true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color12);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        combinedRangeXYPlot15.zoomRangeAxes(0.0d, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = combinedRangeXYPlot15.getDomainMarkers(layer25);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker30.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer33 = null;
        combinedRangeXYPlot15.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker30, layer33, false);
        double double36 = intervalMarker30.getStartValue();
        double double37 = intervalMarker30.getEndValue();
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str39 = layer38.toString();
        boolean boolean41 = categoryPlot0.removeDomainMarker(9, (org.jfree.chart.plot.Marker) intervalMarker30, layer38, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-11.0d) + "'", double37 == (-11.0d));
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.BACKGROUND" + "'", str39.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot14.removeDomainMarker(marker15, layer16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image19 = null;
        combinedRangeXYPlot18.setBackgroundImage(image19);
        java.awt.Paint paint21 = combinedRangeXYPlot18.getDomainCrosshairPaint();
        combinedRangeXYPlot18.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        combinedRangeXYPlot18.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = combinedRangeXYPlot18.getDomainMarkers(layer28);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker33.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer36 = null;
        combinedRangeXYPlot18.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker33, layer36, false);
        double double39 = intervalMarker33.getStartValue();
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean41 = categoryPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker33, layer40);
        combinedRangeXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker33);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) seriesRenderingOrder0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        java.util.List list6 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(10);
        periodAxis9.setFirst((org.jfree.data.time.RegularTimePeriod) year11);
        java.awt.Font font13 = periodAxis9.getLabelFont();
        periodAxis9.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis9.setRange(range16, false, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image21 = null;
        combinedRangeXYPlot20.setBackgroundImage(image21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot20.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = combinedRangeXYPlot20.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot26 = combinedRangeXYPlot20.getParent();
        combinedRangeXYPlot20.setDomainCrosshairVisible(true);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image31 = null;
        combinedRangeXYPlot30.setBackgroundImage(image31);
        java.awt.Paint paint33 = combinedRangeXYPlot30.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity34 = new org.jfree.chart.entity.PlotEntity(shape29, (org.jfree.chart.plot.Plot) combinedRangeXYPlot30);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer37);
        org.jfree.chart.entity.TitleEntity titleEntity40 = new org.jfree.chart.entity.TitleEntity(shape29, (org.jfree.chart.title.Title) legendTitle38, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = legendTitle38.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle38.getItemLabelPadding();
        combinedRangeXYPlot20.setInsets(rectangleInsets42);
        double double45 = rectangleInsets42.calculateBottomInset((double) (byte) 10);
        double double47 = rectangleInsets42.calculateTopInset((double) 'a');
        periodAxis9.setLabelInsets(rectangleInsets42);
        combinedRangeXYPlot0.setRangeAxis(8, (org.jfree.chart.axis.ValueAxis) periodAxis9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint3 = standardChartTheme1.getPlotOutlinePaint();
        java.awt.Paint paint4 = standardChartTheme1.getGridBandAlternatePaint();
        java.awt.Paint paint5 = standardChartTheme1.getBaselinePaint();
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        standardChartTheme1.setExtraLargeFont(font6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        axisSpace5.ensureAtLeast(0.0d, rectangleEdge7);
        try {
            double double10 = numberAxis1.lengthToJava2D((double) 6, rectangle2D4, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        boolean boolean4 = timeSeriesCollection2.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis5, polarItemRenderer6);
        int int8 = polarPlot7.getSeriesCount();
        polarPlot7.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.axis.TickUnit tickUnit11 = polarPlot7.getAngleTickUnit();
        try {
            org.jfree.chart.axis.TickUnit tickUnit12 = tickUnits0.getLargerTickUnit(tickUnit11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(tickUnit11);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot0.getDomainMarkers(5, layer18);
        boolean boolean20 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean11 = xYLineAndShapeRenderer9.getSeriesVisible(2);
        int int12 = xYLineAndShapeRenderer9.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint15 = periodAxis14.getTickMarkPaint();
        xYLineAndShapeRenderer9.setBaseFillPaint(paint15, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYLineAndShapeRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYLineAndShapeRenderer9.setSeriesNegativeItemLabelPosition(0, itemLabelPosition24);
        java.awt.Shape shape29 = xYLineAndShapeRenderer9.getItemShape(2, (-1), true);
        xYLineAndShapeRenderer2.setLegendLine(shape29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        combinedRangeXYPlot31.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = combinedRangeXYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        java.awt.Paint paint38 = jFreeChart37.getBackgroundPaint();
        java.lang.Object obj39 = jFreeChart37.getTextAntiAlias();
        java.awt.RenderingHints renderingHints40 = jFreeChart37.getRenderingHints();
        jFreeChart37.fireChartChanged();
        int int42 = jFreeChart37.getBackgroundImageAlignment();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity44 = new org.jfree.chart.entity.JFreeChartEntity(shape29, jFreeChart37, "hi!");
        org.jfree.chart.JFreeChart jFreeChart45 = jFreeChartEntity44.getChart();
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        jFreeChart45.setBorderPaint((java.awt.Paint) color46);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNotNull(renderingHints40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
        org.junit.Assert.assertNotNull(jFreeChart45);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem2.setY((double) 100.0f);
        double double5 = xYDataItem2.getYValue();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        xYLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.plot.XYPlot xYPlot22 = xYLineAndShapeRenderer2.getPlot();
        boolean boolean23 = xYLineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(xYPlot22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) categoryPlot0, false);
        java.lang.Object obj4 = rendererChangeEvent3.getRenderer();
        java.lang.Object obj5 = rendererChangeEvent3.getRenderer();
        org.junit.Assert.assertNotNull(drawingSupplier1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.lang.String str7 = combinedRangeXYPlot0.getPlotType();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Combined Range XYPlot" + "'", str7.equals("Combined Range XYPlot"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.awt.Font font5 = periodAxis1.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(10);
        periodAxis7.setFirst((org.jfree.data.time.RegularTimePeriod) year9);
        java.awt.Font font11 = periodAxis7.getLabelFont();
        periodAxis7.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis7.setRange(range14, false, false);
        periodAxis1.setRange(range14, true, true);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        periodAxis1.setAxisLineStroke(stroke21);
        periodAxis1.setRangeWithMargins((double) (-2), 0.05d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNull(categoryItemRenderer3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        boolean boolean9 = polarPlot6.isRadiusGridlinesVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        polarPlot6.notifyListeners(plotChangeEvent10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        combinedRangeXYPlot22.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        java.util.List list35 = combinedRangeXYPlot22.getSubplots();
        combinedRangeXYPlot22.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(10);
        periodAxis43.setFirst((org.jfree.data.time.RegularTimePeriod) year45);
        java.awt.Font font47 = periodAxis43.getLabelFont();
        combinedRangeXYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis43);
        combinedRangeXYPlot22.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis43, true);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        periodAxis52.setFirst((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.String str56 = periodAxis52.getLabelURL();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean60 = timeSeriesCollection58.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, valueAxis61, polarItemRenderer62);
        xYLineAndShapeRenderer2.drawItem(graphics2D12, xYItemRendererState13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.axis.ValueAxis) periodAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, 0, (int) (short) 100, true, (int) '4');
        boolean boolean69 = xYLineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator73 = xYLineAndShapeRenderer2.getItemLabelGenerator((int) 'a', 0, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNull(xYItemLabelGenerator73);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        java.lang.Object obj3 = barRenderer3D0.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image13 = null;
        combinedRangeXYPlot12.setBackgroundImage(image13);
        java.awt.Paint paint15 = combinedRangeXYPlot12.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint23 = categoryPlot22.getDomainCrosshairPaint();
        periodAxis18.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        java.awt.Color color25 = java.awt.Color.GREEN;
        categoryPlot22.setRangeZeroBaselinePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape11, (java.awt.Paint) color25);
        java.awt.Paint paint28 = legendItem27.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image30 = null;
        combinedRangeXYPlot29.setBackgroundImage(image30);
        java.awt.Paint paint32 = combinedRangeXYPlot29.getDomainCrosshairPaint();
        java.awt.Paint paint33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot29.setDomainMinorGridlinePaint(paint33);
        legendItem27.setOutlinePaint(paint33);
        barRenderer3D0.setBaseOutlinePaint(paint33);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D0.setBaseOutlinePaint((java.awt.Paint) color37);
        java.awt.Color color39 = java.awt.Color.GREEN;
        barRenderer3D0.setWallPaint((java.awt.Paint) color39);
        java.awt.Paint paint41 = barRenderer3D0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYLineAndShapeRenderer9.setBaseShape(shape13, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image17 = null;
        combinedRangeXYPlot16.setBackgroundImage(image17);
        java.awt.Stroke stroke19 = combinedRangeXYPlot16.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset21 = combinedRangeXYPlot16.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint27 = xYLineAndShapeRenderer25.getLegendTextPaint(0);
        combinedRangeXYPlot16.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer25);
        java.util.List list29 = combinedRangeXYPlot16.getSubplots();
        combinedRangeXYPlot16.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        combinedRangeXYPlot16.panRangeAxes((double) 6, plotRenderingInfo34, point2D35);
        org.jfree.chart.entity.PlotEntity plotEntity39 = new org.jfree.chart.entity.PlotEntity(shape13, (org.jfree.chart.plot.Plot) combinedRangeXYPlot16, "hi!", "");
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale7);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getCurrencyInstance(locale7);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ItemLabelAnchor.OUTSIDE1", numberFormat9, numberFormat10);
        numberFormat10.setGroupingUsed(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 100, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 100L, 45.0d);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset3 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset3.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset3.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset3);
        piePlot3D11.clearSectionOutlineStrokes(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image15 = null;
        combinedRangeXYPlot14.setBackgroundImage(image15);
        java.awt.Stroke stroke17 = combinedRangeXYPlot14.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = combinedRangeXYPlot14.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint25 = xYLineAndShapeRenderer23.getLegendTextPaint(0);
        combinedRangeXYPlot14.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer23);
        java.util.List list27 = combinedRangeXYPlot14.getSubplots();
        combinedRangeXYPlot14.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        combinedRangeXYPlot14.panRangeAxes((double) 6, plotRenderingInfo32, point2D33);
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection36 = new org.jfree.data.time.TimeSeriesCollection(timeZone35);
        boolean boolean38 = timeSeriesCollection36.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer40 = null;
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection36, valueAxis39, polarItemRenderer40);
        java.awt.Stroke stroke42 = polarPlot41.getRadiusGridlineStroke();
        combinedRangeXYPlot14.setDomainMinorGridlineStroke(stroke42);
        piePlot3D11.setBaseSectionOutlineStroke(stroke42);
        boolean boolean45 = size2D2.equals((java.lang.Object) piePlot3D11);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.geom.Point2D point2D48 = null;
        org.jfree.chart.plot.PlotState plotState49 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot50 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image51 = null;
        combinedRangeXYPlot50.setBackgroundImage(image51);
        java.awt.Stroke stroke53 = combinedRangeXYPlot50.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset55 = combinedRangeXYPlot50.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer59 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint61 = xYLineAndShapeRenderer59.getLegendTextPaint(0);
        combinedRangeXYPlot50.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer59);
        java.util.List list63 = combinedRangeXYPlot50.getSubplots();
        combinedRangeXYPlot50.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean69 = categoryPlot68.isDomainZoomable();
        categoryPlot68.clearDomainMarkers();
        boolean boolean71 = categoryPlot68.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo73);
        java.awt.geom.Point2D point2D75 = null;
        categoryPlot68.zoomRangeAxes(0.0d, plotRenderingInfo74, point2D75, false);
        java.awt.geom.Point2D point2D78 = null;
        combinedRangeXYPlot50.panRangeAxes((double) ' ', plotRenderingInfo74, point2D78);
        try {
            piePlot3D11.draw(graphics2D46, rectangle2D47, point2D48, plotState49, plotRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(xYDataset55);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot5.setRangeAxis(valueAxis8);
        boolean boolean10 = categoryPlot5.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = categoryAxis12.getCategoryLabelPositions();
        categoryPlot5.setDomainAxis(categoryAxis12);
        categoryPlot5.setRangeCrosshairValue((double) 10.0f, false);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot5.getDomainAxisLocation();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation18);
        boolean boolean20 = combinedRangeXYPlot0.canSelectByRegion();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        xYBarRenderer1.setAutoPopulateSeriesShape(false);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint3 = standardChartTheme1.getPlotOutlinePaint();
        java.awt.Paint paint4 = standardChartTheme1.getGridBandAlternatePaint();
        java.awt.Paint paint5 = standardChartTheme1.getSubtitlePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image12 = null;
        combinedRangeXYPlot11.setBackgroundImage(image12);
        java.awt.Paint paint14 = combinedRangeXYPlot11.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(10);
        boolean boolean20 = periodAxis17.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint22 = categoryPlot21.getDomainCrosshairPaint();
        periodAxis17.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot21);
        java.awt.Color color24 = java.awt.Color.GREEN;
        categoryPlot21.setRangeZeroBaselinePaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape10, (java.awt.Paint) color24);
        java.awt.Paint paint27 = legendItem26.getFillPaint();
        java.lang.String str28 = legendItem26.getToolTipText();
        boolean boolean29 = legendItem26.isShapeVisible();
        legendItem26.setDatasetIndex((int) ' ');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer32.setBaseShape(shape33, false);
        java.awt.Color color36 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape33, (java.awt.Paint) color36);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer38 = legendGraphic37.getFillPaintTransformer();
        legendItem26.setFillPaintTransformer(gradientPaintTransformer38);
        boolean boolean40 = standardChartTheme1.equals((java.lang.Object) gradientPaintTransformer38);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TimePeriodAnchor.END" + "'", str28.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(gradientPaintTransformer38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat3, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat1, numberFormat3);
        boolean boolean7 = numberFormat1.isGroupingUsed();
        boolean boolean8 = numberFormat1.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        java.lang.Class class9 = periodAxis7.getAutoRangeTimePeriodClass();
        categoryPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) periodAxis7);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker14.setEndValue((double) (-11L));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = intervalMarker14.getLabelOffsetType();
        org.jfree.chart.util.Layer layer18 = null;
        categoryPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker14, layer18, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image9 = null;
        combinedRangeXYPlot8.setBackgroundImage(image9);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer15);
        org.jfree.chart.entity.TitleEntity titleEntity18 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) legendTitle16, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = legendTitle16.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle16.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle16.setLegendItemGraphicEdge(rectangleEdge21);
        boolean boolean23 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge21);
        try {
            double double24 = numberAxis1.java2DToValue((double) 0, rectangle2D6, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYLineAndShapeRenderer9.setBaseShape(shape13, false);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.entity.XYItemEntity xYItemEntity26 = new org.jfree.chart.entity.XYItemEntity(shape13, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, (int) ' ', (int) (byte) 1, "series", "");
        int int27 = xYItemEntity26.getItem();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeZone28);
        boolean boolean31 = timeSeriesCollection29.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeriesCollection29.getSeries((java.lang.Comparable) (-1));
        double double35 = timeSeriesCollection29.getDomainUpperBound(true);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor36 = timeSeriesCollection29.getXPosition();
        xYItemEntity26.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        double double39 = timeSeriesCollection29.getDomainUpperBound(false);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = null;
        timeSeriesCollection29.seriesChanged(seriesChangeEvent40);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(timeSeries33);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor36);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle4.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle4.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset((int) ' ');
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryDataset16);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart6.removeProgressListener(chartProgressListener7);
        boolean boolean9 = jFreeChart6.isNotify();
        org.jfree.chart.event.ChartChangeListener chartChangeListener10 = null;
        try {
            jFreeChart6.removeChangeListener(chartChangeListener10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image11 = null;
        combinedRangeXYPlot10.setBackgroundImage(image11);
        java.awt.Paint paint13 = combinedRangeXYPlot10.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) combinedRangeXYPlot10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer17);
        org.jfree.chart.entity.TitleEntity titleEntity20 = new org.jfree.chart.entity.TitleEntity(shape9, (org.jfree.chart.title.Title) legendTitle18, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle18.getItemLabelPadding();
        combinedRangeXYPlot0.setInsets(rectangleInsets22);
        double double25 = rectangleInsets22.calculateLeftInset((double) 0.5f);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets22.createOutsetRectangle(rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        boolean boolean5 = periodAxis1.isMinorTickMarksVisible();
        java.util.Locale locale6 = periodAxis1.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale6);
        java.text.NumberFormat numberFormat8 = java.text.NumberFormat.getCurrencyInstance(locale6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale6);
        java.lang.Object obj10 = standardPieSectionLabelGenerator9.clone();
        java.text.AttributedString attributedString12 = standardPieSectionLabelGenerator9.getAttributedLabel(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(attributedString12);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke8 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot9.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle13.getMargin();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke8, rectangleInsets14);
        java.awt.Paint paint16 = lineBorder15.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(1.0d, (double) 1.0f, (double) 9, 34.0d, paint16);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat5 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat5, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat3, numberFormat5);
        numberAxis1.setNumberFormatOverride(numberFormat5);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNull(markerAxisBand10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart6.removeProgressListener(chartProgressListener7);
        boolean boolean9 = jFreeChart6.isNotify();
        int int10 = jFreeChart6.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Paint paint9 = combinedRangeXYPlot6.getDomainCrosshairPaint();
        combinedRangeXYPlot6.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedRangeXYPlot6.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = combinedRangeXYPlot6.getDomainMarkers(layer16);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker21.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer24 = null;
        combinedRangeXYPlot6.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker21, layer24, false);
        double double27 = intervalMarker21.getStartValue();
        org.jfree.chart.util.Layer layer28 = null;
        categoryPlot0.addRangeMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) intervalMarker21, layer28, true);
        org.jfree.chart.plot.Marker marker32 = null;
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot0.addRangeMarker(8, marker32, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(layer33);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        boolean boolean18 = categoryPlot15.removeDomainMarker(marker16, layer17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image20 = null;
        combinedRangeXYPlot19.setBackgroundImage(image20);
        java.awt.Paint paint22 = combinedRangeXYPlot19.getDomainCrosshairPaint();
        combinedRangeXYPlot19.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        combinedRangeXYPlot19.zoomRangeAxes(0.0d, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = combinedRangeXYPlot19.getDomainMarkers(layer29);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker34.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer37 = null;
        combinedRangeXYPlot19.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker34, layer37, false);
        double double40 = intervalMarker34.getStartValue();
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean42 = categoryPlot15.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker34, layer41);
        java.awt.Stroke stroke43 = intervalMarker34.getOutlineStroke();
        java.awt.Paint paint44 = intervalMarker34.getPaint();
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker34, layer45);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent47 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker34);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, 0);
        java.util.Currency currency4 = numberFormat1.getCurrency();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(currency4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint9 = periodAxis8.getTickMarkPaint();
        periodAxis8.setInverted(true);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(10);
        boolean boolean16 = periodAxis13.equals((java.lang.Object) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer19.setAutoPopulateSeriesPaint(false);
        java.awt.Color color23 = java.awt.Color.gray;
        int int24 = color23.getTransparency();
        xYLineAndShapeRenderer19.setBaseItemLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer19);
        double double27 = periodAxis8.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.RenderingHints renderingHints9 = jFreeChart6.getRenderingHints();
        jFreeChart6.fireChartChanged();
        int int11 = jFreeChart6.getBackgroundImageAlignment();
        jFreeChart6.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart6.getLegend((int) (byte) 1);
        java.lang.Object obj15 = null;
        boolean boolean16 = jFreeChart6.equals(obj15);
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart6.removeProgressListener(chartProgressListener17);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape(0);
        java.awt.Shape shape4 = shapeList0.getShape(4);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer21 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot22 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset20, waferMapRenderer21);
        org.jfree.data.general.WaferMapDataset waferMapDataset23 = null;
        waferMapPlot22.setDataset(waferMapDataset23);
        periodAxis15.setPlot((org.jfree.chart.plot.Plot) waferMapPlot22);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.plot.PlotState plotState29 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image31 = null;
        combinedRangeXYPlot30.setBackgroundImage(image31);
        java.awt.Stroke stroke33 = combinedRangeXYPlot30.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset35 = combinedRangeXYPlot30.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint41 = xYLineAndShapeRenderer39.getLegendTextPaint(0);
        combinedRangeXYPlot30.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer39);
        java.util.List list43 = combinedRangeXYPlot30.getSubplots();
        combinedRangeXYPlot30.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        combinedRangeXYPlot30.panRangeAxes((double) 6, plotRenderingInfo48, point2D49);
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection52 = new org.jfree.data.time.TimeSeriesCollection(timeZone51);
        boolean boolean54 = timeSeriesCollection52.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection52, valueAxis55, polarItemRenderer56);
        java.awt.Stroke stroke58 = polarPlot57.getRadiusGridlineStroke();
        combinedRangeXYPlot30.setDomainMinorGridlineStroke(stroke58);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean63 = categoryPlot62.isDomainZoomable();
        categoryPlot62.clearDomainMarkers();
        boolean boolean65 = categoryPlot62.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo67);
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot62.zoomRangeAxes(0.0d, plotRenderingInfo68, point2D69, false);
        combinedRangeXYPlot30.handleClick(7, (-2), plotRenderingInfo68);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state73 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo68);
        try {
            waferMapPlot22.draw(graphics2D26, rectangle2D27, point2D28, plotState29, plotRenderingInfo68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        polarPlot6.setAngleGridlinesVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        polarPlot6.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = categoryPlot12.getDrawingSupplier();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) categoryPlot12, false);
        java.lang.Object obj16 = rendererChangeEvent15.getRenderer();
        polarPlot6.rendererChanged(rendererChangeEvent15);
        boolean boolean18 = polarPlot6.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint3 = standardChartTheme1.getAxisLabelPaint();
        org.jfree.chart.block.CenterArrangement centerArrangement4 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot5.setDomainAxisLocation(axisLocation7);
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean12 = timeSeriesCollection10.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, valueAxis13, polarItemRenderer14);
        polarPlot15.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        polarPlot15.rendererChanged(rendererChangeEvent18);
        java.awt.Color color20 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color20 };
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke24, stroke25, stroke26 };
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke28 };
        java.awt.Shape[] shapeArray30 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray23, strokeArray27, strokeArray29, shapeArray30);
        polarPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31, true);
        combinedRangeXYPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31);
        java.lang.Object obj35 = defaultDrawingSupplier31.clone();
        boolean boolean36 = centerArrangement4.equals((java.lang.Object) defaultDrawingSupplier31);
        java.awt.Paint paint37 = defaultDrawingSupplier31.getNextPaint();
        standardChartTheme1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shapeArray30);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        java.lang.String str22 = legendItem20.getToolTipText();
        boolean boolean23 = legendItem20.isShapeVisible();
        java.awt.Font font24 = legendItem20.getLabelFont();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodAnchor.END" + "'", str22.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(font24);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        boolean boolean5 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean6 = combinedRangeXYPlot0.isDomainPannable();
        int int7 = combinedRangeXYPlot0.getDatasetCount();
        int int8 = combinedRangeXYPlot0.getDomainAxisCount();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot0.getDataset((-2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(34.0d, "WMAP_Plot", true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16777088) + "'", int1 == (-16777088));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        double double14 = combinedRangeXYPlot0.getRangeCrosshairValue();
        boolean boolean15 = combinedRangeXYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = null;
        boolean boolean9 = jFreeChart6.equals(obj8);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart6.getTitle();
        java.awt.Stroke stroke11 = jFreeChart6.getBorderStroke();
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(textTitle10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.data.Range range8 = new org.jfree.data.Range(5.0d, (double) 9999);
        boolean boolean9 = plotEntity5.equals((java.lang.Object) range8);
        java.lang.String str10 = plotEntity5.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PlotEntity: tooltip = null" + "'", str10.equals("PlotEntity: tooltip = null"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator6 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator7 = null;
        java.lang.String str8 = plotEntity5.getImageMapAreaTag(toolTipTagFragmentGenerator6, uRLTagFragmentGenerator7);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        double double10 = piePlot3D8.getDepthFactor();
        boolean boolean11 = piePlot3D8.isCircular();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor12 = piePlot3D8.getLabelDistributor();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.12d + "'", double10 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.resizeRange((double) (short) 100);
        int int8 = periodAxis1.getMinorTickCount();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint12 = periodAxis11.getTickMarkPaint();
        periodAxis11.setInverted(true);
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape9, (org.jfree.chart.axis.Axis) periodAxis11);
        periodAxis1.setDownArrow(shape9);
        int int17 = periodAxis1.getMinorTickCount();
        double double18 = periodAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        combinedRangeXYPlot0.clearDomainMarkers((-1));
        boolean boolean6 = combinedRangeXYPlot0.isDomainPannable();
        java.awt.Stroke stroke7 = combinedRangeXYPlot0.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot9.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot9.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint20 = xYLineAndShapeRenderer18.getLegendTextPaint(0);
        combinedRangeXYPlot9.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer18);
        java.util.List list22 = combinedRangeXYPlot9.getSubplots();
        combinedRangeXYPlot9.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        combinedRangeXYPlot9.panRangeAxes((double) 6, plotRenderingInfo27, point2D28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeZone30);
        boolean boolean33 = timeSeriesCollection31.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection31, valueAxis34, polarItemRenderer35);
        java.awt.Stroke stroke37 = polarPlot36.getRadiusGridlineStroke();
        combinedRangeXYPlot9.setDomainMinorGridlineStroke(stroke37);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean42 = categoryPlot41.isDomainZoomable();
        categoryPlot41.clearDomainMarkers();
        boolean boolean44 = categoryPlot41.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot41.zoomRangeAxes(0.0d, plotRenderingInfo47, point2D48, false);
        combinedRangeXYPlot9.handleClick(7, (-2), plotRenderingInfo47);
        java.awt.geom.Point2D point2D52 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 8, plotRenderingInfo47, point2D52);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace14 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str15 = axisSpace14.toString();
        axisSpace13.ensureAtLeast(axisSpace14);
        double double17 = axisSpace14.getLeft();
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace14);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries2.add((double) (short) 0, (double) (short) 0);
        xYSeries2.setNotify(true);
        double[][] doubleArray8 = xYSeries2.toArray();
        org.jfree.data.xy.XYDataItem xYDataItem11 = xYSeries2.addOrUpdate((double) 5, (double) 2019);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNull(xYDataItem11);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        boolean boolean7 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYLineAndShapeRenderer10.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYLineAndShapeRenderer10.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image22 = null;
        combinedRangeXYPlot21.setBackgroundImage(image22);
        java.awt.Stroke stroke24 = combinedRangeXYPlot21.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset26 = combinedRangeXYPlot21.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot27 = combinedRangeXYPlot21.getParent();
        combinedRangeXYPlot21.setDomainCrosshairVisible(true);
        combinedRangeXYPlot21.configureDomainAxes();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeZone31);
        boolean boolean34 = timeSeriesCollection32.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection32, valueAxis35, polarItemRenderer36);
        org.jfree.data.Range range39 = timeSeriesCollection32.getDomainBounds(true);
        org.jfree.data.xy.XYDataItem xYDataItem42 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem42.setY((double) 100.0f);
        int int45 = timeSeriesCollection32.indexOf((java.lang.Comparable) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState47 = xYLineAndShapeRenderer2.initialise(graphics2D19, rectangle2D20, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot21, (org.jfree.data.xy.XYDataset) timeSeriesCollection32, plotRenderingInfo46);
        timeSeriesCollection32.validateObject();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState47);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        boolean boolean9 = piePlot3D8.getAutoPopulateSectionPaint();
        try {
            piePlot3D8.setInteriorGap((double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        java.lang.Class class9 = periodAxis7.getAutoRangeTimePeriodClass();
        categoryPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) periodAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke12 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryPlot0);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getRangeAxisLocation(9999);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYLineAndShapeRenderer19.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYLineAndShapeRenderer19.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image33 = null;
        combinedRangeXYPlot32.setBackgroundImage(image33);
        java.awt.Paint paint35 = combinedRangeXYPlot32.getDomainCrosshairPaint();
        combinedRangeXYPlot32.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder37 = combinedRangeXYPlot32.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot32);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image40 = null;
        combinedRangeXYPlot39.setBackgroundImage(image40);
        java.awt.Stroke stroke42 = combinedRangeXYPlot39.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset44 = combinedRangeXYPlot39.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint50 = xYLineAndShapeRenderer48.getLegendTextPaint(0);
        combinedRangeXYPlot39.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer48);
        java.util.List list52 = combinedRangeXYPlot39.getSubplots();
        combinedRangeXYPlot39.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint58 = combinedRangeXYPlot57.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis60 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(10);
        periodAxis60.setFirst((org.jfree.data.time.RegularTimePeriod) year62);
        java.awt.Font font64 = periodAxis60.getLabelFont();
        combinedRangeXYPlot57.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis60);
        combinedRangeXYPlot39.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis60, true);
        org.jfree.chart.axis.PeriodAxis periodAxis69 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(10);
        periodAxis69.setFirst((org.jfree.data.time.RegularTimePeriod) year71);
        java.lang.String str73 = periodAxis69.getLabelURL();
        java.util.TimeZone timeZone74 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection75 = new org.jfree.data.time.TimeSeriesCollection(timeZone74);
        boolean boolean77 = timeSeriesCollection75.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer79 = null;
        org.jfree.chart.plot.PolarPlot polarPlot80 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection75, valueAxis78, polarItemRenderer79);
        xYLineAndShapeRenderer19.drawItem(graphics2D29, xYItemRendererState30, rectangle2D31, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot32, (org.jfree.chart.axis.ValueAxis) periodAxis60, (org.jfree.chart.axis.ValueAxis) periodAxis69, (org.jfree.data.xy.XYDataset) timeSeriesCollection75, 0, (int) (short) 100, true, (int) '4');
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) periodAxis69);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(seriesRenderingOrder37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(xYDataset44);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getDomainCrosshairPaint();
        periodAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        double double8 = periodAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        categoryAxis7.setTickMarksVisible(false);
        int int12 = categoryAxis7.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint9 = periodAxis8.getTickMarkPaint();
        periodAxis8.setInverted(true);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(10);
        boolean boolean16 = periodAxis13.equals((java.lang.Object) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer19.setAutoPopulateSeriesPaint(false);
        java.awt.Color color23 = java.awt.Color.gray;
        int int24 = color23.getTransparency();
        xYLineAndShapeRenderer19.setBaseItemLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image28 = null;
        combinedRangeXYPlot27.setBackgroundImage(image28);
        java.awt.Paint paint30 = combinedRangeXYPlot27.getDomainCrosshairPaint();
        combinedRangeXYPlot27.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = combinedRangeXYPlot27.getSeriesRenderingOrder();
        java.util.List list33 = combinedRangeXYPlot27.getSubplots();
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list33, false);
        org.jfree.data.Range range37 = timeSeriesCollection1.getDomainBounds(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNull(range37);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = dateTickUnit0.getRollUnitType();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset2 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset2.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType8 = dateTickUnit7.getRollUnitType();
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset2, (java.lang.Comparable) dateTickUnit7, 1.0d);
        java.lang.Object obj11 = null;
        boolean boolean12 = dateTickUnit7.equals(obj11);
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj15 = null;
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date14, obj15);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(date13, date14);
        java.util.Date date18 = dateTickUnit7.rollDate(date13);
        java.util.Date date19 = dateTickUnit0.rollDate(date13);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(dateTickUnitType8);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 1L);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator((int) '#', xYItemLabelGenerator3);
        xYBarRenderer1.setUseYInterval(true);
        xYBarRenderer1.setBaseSeriesVisibleInLegend(false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYLineAndShapeRenderer9.setBaseShape(shape13, false);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.entity.XYItemEntity xYItemEntity26 = new org.jfree.chart.entity.XYItemEntity(shape13, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, (int) ' ', (int) (byte) 1, "series", "");
        int int27 = xYItemEntity26.getSeriesIndex();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 32 + "'", int27 == 32);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = combinedRangeXYPlot0.getRangeAxisIndex(valueAxis7);
        combinedRangeXYPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo18, categoryCrosshairState19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot0.getLegendItems();
        int int22 = legendItemCollection21.getItemCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer5);
        boolean boolean7 = xYLineAndShapeRenderer5.getBaseItemLabelsVisible();
        boolean boolean8 = dateTickMarkPosition2.equals((java.lang.Object) xYLineAndShapeRenderer5);
        dateAxis0.setTickMarkPosition(dateTickMarkPosition2);
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj11 = null;
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date10, obj11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisSpace axisSpace14 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        java.awt.Paint paint20 = combinedRangeXYPlot17.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity21 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) combinedRangeXYPlot17);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer24);
        org.jfree.chart.entity.TitleEntity titleEntity27 = new org.jfree.chart.entity.TitleEntity(shape16, (org.jfree.chart.title.Title) legendTitle25, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = legendTitle25.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle25.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle25.setLegendItemGraphicEdge(rectangleEdge30);
        axisSpace14.add((double) (byte) -1, rectangleEdge30);
        try {
            double double33 = dateAxis0.dateToJava2D(date10, rectangle2D13, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeline1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
        org.jfree.chart.text.TextFragment textFragment3 = textLine2.getFirstTextFragment();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeZone4);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        boolean boolean7 = textLine2.equals((java.lang.Object) timeSeriesCollection5);
        org.jfree.chart.text.TextFragment textFragment8 = textLine2.getFirstTextFragment();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Paint paint12 = combinedRangeXYPlot9.getDomainCrosshairPaint();
        combinedRangeXYPlot9.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedRangeXYPlot9.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D16, false);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = combinedRangeXYPlot9.getDomainMarkers(layer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker24.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer27 = null;
        combinedRangeXYPlot9.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        double double30 = intervalMarker24.getStartValue();
        boolean boolean31 = textLine2.equals((java.lang.Object) double30);
        org.jfree.chart.text.TextFragment textFragment32 = null;
        textLine2.addFragment(textFragment32);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textFragment3);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textFragment8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image15 = null;
        combinedRangeXYPlot14.setBackgroundImage(image15);
        java.awt.Stroke stroke17 = combinedRangeXYPlot14.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = combinedRangeXYPlot14.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint25 = xYLineAndShapeRenderer23.getLegendTextPaint(0);
        combinedRangeXYPlot14.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer23);
        java.util.List list27 = combinedRangeXYPlot14.getSubplots();
        combinedRangeXYPlot14.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean33 = categoryPlot32.isDomainZoomable();
        categoryPlot32.clearDomainMarkers();
        boolean boolean35 = categoryPlot32.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot32.zoomRangeAxes(0.0d, plotRenderingInfo38, point2D39, false);
        java.awt.geom.Point2D point2D42 = null;
        combinedRangeXYPlot14.panRangeAxes((double) ' ', plotRenderingInfo38, point2D42);
        java.awt.geom.Point2D point2D44 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 'a', plotRenderingInfo38, point2D44, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image5 = null;
        combinedRangeXYPlot4.setBackgroundImage(image5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot4.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint15 = xYLineAndShapeRenderer13.getLegendTextPaint(0);
        combinedRangeXYPlot4.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer13);
        java.util.List list17 = combinedRangeXYPlot4.getSubplots();
        combinedRangeXYPlot4.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        combinedRangeXYPlot4.panRangeAxes((double) 6, plotRenderingInfo22, point2D23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection(timeZone25);
        boolean boolean28 = timeSeriesCollection26.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection26, valueAxis29, polarItemRenderer30);
        java.awt.Stroke stroke32 = polarPlot31.getRadiusGridlineStroke();
        combinedRangeXYPlot4.setDomainMinorGridlineStroke(stroke32);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.isDomainZoomable();
        categoryPlot36.clearDomainMarkers();
        boolean boolean39 = categoryPlot36.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot36.zoomRangeAxes(0.0d, plotRenderingInfo42, point2D43, false);
        combinedRangeXYPlot4.handleClick(7, (-2), plotRenderingInfo42);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo42);
        combinedDomainXYPlot1.handleClick((int) (byte) 0, (int) (short) 0, plotRenderingInfo42);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("DatasetRenderingOrder.REVERSE");
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat3, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat1, numberFormat3);
        try {
            java.lang.Number number8 = numberFormat1.parse("JFreeChartEntity: tooltip = hi!");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"JFreeChartEntity: tooltip = hi!\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint5 = categoryPlot4.getDomainCrosshairPaint();
        categoryPlot1.setRangeZeroBaselinePaint(paint5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot1.getDataset();
        java.util.List list8 = categoryPlot1.getCategories();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean13 = xYLineAndShapeRenderer11.getSeriesVisible(2);
        int int14 = xYLineAndShapeRenderer11.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis16 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint17 = periodAxis16.getTickMarkPaint();
        xYLineAndShapeRenderer11.setBaseFillPaint(paint17, false);
        boolean boolean20 = xYLineAndShapeRenderer11.getUseOutlinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint22 = combinedRangeXYPlot21.getDomainCrosshairPaint();
        xYLineAndShapeRenderer11.setBaseFillPaint(paint22);
        categoryPlot1.setRangeMinorGridlinePaint(paint22);
        java.awt.Paint paint25 = categoryPlot1.getDomainCrosshairPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("", paint25);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale7);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getCurrencyInstance(locale7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieLabelLinkStyle.QUAD_CURVE", locale7);
        java.text.NumberFormat numberFormat13 = java.text.NumberFormat.getCurrencyInstance(locale7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(numberFormat13);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale7);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getCurrencyInstance(locale7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieLabelLinkStyle.QUAD_CURVE", locale7);
        java.text.NumberFormat numberFormat13 = standardPieSectionLabelGenerator12.getPercentFormat();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(numberFormat13);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("MINOR");
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Font font16 = barRenderer3D11.getSeriesItemLabelFont(1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = barRenderer3D11.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator17);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        barRenderer3D0.setIncludeBaseInRange(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator9, false);
        barRenderer3D0.setDefaultEntityRadius(1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        java.awt.geom.Point2D point2D2 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.updateCrosshairX((double) 10.0f);
        org.junit.Assert.assertNull(point2D1);
        org.junit.Assert.assertNull(point2D2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) 100L, (double) (short) 1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) (short) 1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis3.getTickMarkPosition();
        org.jfree.chart.entity.AxisEntity axisEntity5 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) dateAxis3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot6.setRangeMinorGridlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot6.setRangeAxis(valueAxis9);
        boolean boolean11 = categoryPlot6.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = categoryAxis13.getCategoryLabelPositions();
        categoryPlot6.setDomainAxis(categoryAxis13);
        categoryAxis13.setTickMarksVisible(false);
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis13);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot11.setDomainAxisLocation(axisLocation13);
        try {
            combinedRangeXYPlot0.setRangeAxisLocation((-1), axisLocation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        java.awt.Paint paint10 = categoryAxis7.getLabelPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer3);
        boolean boolean5 = xYLineAndShapeRenderer3.getBaseItemLabelsVisible();
        boolean boolean6 = dateTickMarkPosition0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        java.awt.Shape shape8 = xYLineAndShapeRenderer3.getSeriesShape(3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        crosshairState1.updateCrosshairPoint((double) (-9999), 34.0d, (double) 0L, (double) 500, plotOrientation6);
        crosshairState1.setAnchorX(0.2d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Font font16 = barRenderer3D11.getSeriesItemLabelFont(1);
        java.awt.Paint paint18 = barRenderer3D11.getSeriesFillPaint((int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = barRenderer3D11.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        boolean boolean6 = periodAxis3.equals((java.lang.Object) 10);
        boolean boolean7 = periodAxis3.isMinorTickMarksVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) periodAxis3);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(10);
        periodAxis10.setFirst((org.jfree.data.time.RegularTimePeriod) year12);
        java.awt.Font font14 = periodAxis10.getLabelFont();
        periodAxis10.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis10.setRange(range17, false, false);
        periodAxis3.setDefaultAutoRange(range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint1.toRangeWidth(range17);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(10);
        periodAxis24.setFirst((org.jfree.data.time.RegularTimePeriod) year26);
        java.awt.Font font28 = periodAxis24.getLabelFont();
        periodAxis24.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis24.setRange(range31, false, false);
        boolean boolean36 = range31.contains((double) (byte) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint(range17, range31);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, range31);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = combinedRangeXYPlot6.getDataset((int) (short) -1);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getRangeGridlineStroke();
        xYLineAndShapeRenderer2.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.chart.axis.ValueAxis) periodAxis13, rectangle2D14, (double) 100, (java.awt.Paint) color16, stroke20);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = combinedRangeXYPlot6.getOrientation();
        combinedRangeXYPlot6.setRangePannable(true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(plotOrientation22);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        pieLabelDistributor1.distributeLabels(0.0d, (double) (-9999));
        pieLabelDistributor1.distributeLabels((double) (-11L), (double) 9999);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        boolean boolean5 = combinedRangeXYPlot0.isDomainPannable();
        double double6 = combinedRangeXYPlot0.getGap();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot0.getDataset();
        boolean boolean8 = combinedRangeXYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        java.lang.Object obj2 = xYSeriesCollection1.clone();
        java.lang.Object obj3 = xYSeriesCollection1.clone();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Font font4 = xYAreaRenderer0.getItemLabelFont(2, (int) (byte) 1, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = xYAreaRenderer0.getGradientTransformer();
        boolean boolean6 = xYAreaRenderer0.getPlotShapes();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean14 = xYLineAndShapeRenderer13.getAutoPopulateSeriesShape();
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer13.setBaseLegendTextFont(font15);
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font15);
        labelBlock7.setFont(font15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.DomainOrder domainOrder3 = defaultXYDataset2.getDomainOrder();
        boolean boolean4 = xYSeriesCollection1.equals((java.lang.Object) defaultXYDataset2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean8 = timeSeriesCollection6.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis9, polarItemRenderer10);
        int int13 = timeSeriesCollection6.indexOf((java.lang.Comparable) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image15 = null;
        combinedRangeXYPlot14.setBackgroundImage(image15);
        java.awt.Paint paint17 = combinedRangeXYPlot14.getDomainCrosshairPaint();
        combinedRangeXYPlot14.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = combinedRangeXYPlot14.getSeriesRenderingOrder();
        java.util.List list20 = combinedRangeXYPlot14.getSubplots();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(10);
        periodAxis22.setFirst((org.jfree.data.time.RegularTimePeriod) year24);
        java.awt.Font font26 = periodAxis22.getLabelFont();
        periodAxis22.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis22.setRange(range29, false, false);
        org.jfree.data.Range range34 = timeSeriesCollection6.getRangeBounds(list20, range29, false);
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(10);
        periodAxis36.setFirst((org.jfree.data.time.RegularTimePeriod) year38);
        java.awt.Font font40 = periodAxis36.getLabelFont();
        periodAxis36.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range43 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis36.setRange(range43, false, false);
        boolean boolean48 = range43.contains((double) (byte) 10);
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(10);
        periodAxis50.setFirst((org.jfree.data.time.RegularTimePeriod) year52);
        java.awt.Font font54 = periodAxis50.getLabelFont();
        periodAxis50.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range57 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis50.setRange(range57, false, false);
        java.lang.String str61 = range57.toString();
        org.jfree.data.Range range62 = org.jfree.data.Range.combine(range43, range57);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, list20, range43, false);
        org.jfree.data.xy.XYSeries xYSeries67 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeriesCollection1.addSeries(xYSeries67);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState69 = xYSeriesCollection1.getSelectionState();
        org.junit.Assert.assertNotNull(domainOrder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Range[0.0,1.0]" + "'", str61.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState69);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.DomainOrder domainOrder1 = defaultXYDataset0.getDomainOrder();
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries5.add((double) (short) 0, (double) (short) 0);
        xYSeries5.setNotify(true);
        double[][] doubleArray11 = xYSeries5.toArray();
        defaultXYDataset0.addSeries((java.lang.Comparable) 4, doubleArray11);
        try {
            java.lang.Number number15 = defaultXYDataset0.getX(4, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        java.lang.Object obj2 = xYSeriesCollection1.clone();
        java.lang.Object obj3 = xYSeriesCollection1.clone();
        double double5 = xYSeriesCollection1.getRangeUpperBound(false);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries8.add((double) (short) 0, (double) (short) 0);
        xYSeries8.setNotify(true);
        double[][] doubleArray14 = xYSeries8.toArray();
        int int15 = xYSeriesCollection1.indexOf(xYSeries8);
        xYSeries8.setNotify(true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray12);
        categoryPlot0.setDataset(categoryDataset13);
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Stroke stroke1 = barRenderer3D0.getBaseOutlineStroke();
        barRenderer3D0.setBase((double) 0L);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isDomainZoomable();
        boolean boolean6 = categoryPlot4.isRangeZeroBaselineVisible();
        barRenderer3D0.setPlot(categoryPlot4);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image5 = null;
        combinedRangeXYPlot4.setBackgroundImage(image5);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        combinedRangeXYPlot4.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        combinedRangeXYPlot4.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = combinedRangeXYPlot4.getDomainMarkers(layer14);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker19.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer22 = null;
        combinedRangeXYPlot4.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker19, layer22, false);
        double double25 = intervalMarker19.getStartValue();
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker19, layer26);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) false, false);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(sortOrder31);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        combinedRangeXYPlot7.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke26 = xYAreaRenderer24.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image30 = null;
        combinedRangeXYPlot29.setBackgroundImage(image30);
        java.awt.Stroke stroke32 = combinedRangeXYPlot29.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset34 = combinedRangeXYPlot29.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot35 = combinedRangeXYPlot29.getParent();
        combinedRangeXYPlot29.setDomainCrosshairVisible(true);
        combinedRangeXYPlot29.configureDomainAxes();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection40 = new org.jfree.data.time.TimeSeriesCollection(timeZone39);
        boolean boolean42 = timeSeriesCollection40.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection40, valueAxis43, polarItemRenderer44);
        polarPlot45.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset48 = polarPlot45.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYAreaRenderer24.initialise(graphics2D27, rectangle2D28, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot29, xYDataset48, plotRenderingInfo50);
        java.awt.geom.Point2D point2D52 = null;
        try {
            combinedRangeXYPlot7.zoomDomainAxes((double) 6, (double) 1L, plotRenderingInfo50, point2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(xYDataset48);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean12 = xYLineAndShapeRenderer10.getSeriesVisible(2);
        int int13 = xYLineAndShapeRenderer10.getPassCount();
        boolean boolean17 = xYLineAndShapeRenderer10.getItemCreateEntity(0, 100, true);
        boolean boolean20 = xYLineAndShapeRenderer10.getItemShapeFilled(0, 15);
        boolean boolean21 = legendItemCollection7.equals((java.lang.Object) xYLineAndShapeRenderer10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        org.jfree.chart.StandardChartTheme standardChartTheme4 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint5 = standardChartTheme4.getLabelLinkPaint();
        java.awt.Paint paint6 = standardChartTheme4.getPlotOutlinePaint();
        java.awt.Paint paint7 = standardChartTheme4.getGridBandAlternatePaint();
        java.awt.Paint paint8 = standardChartTheme4.getSubtitlePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter9 = standardChartTheme4.getBarPainter();
        boolean boolean10 = multiplePiePlot1.equals((java.lang.Object) standardChartTheme4);
        java.lang.String str11 = standardChartTheme4.getName();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset12 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset12.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset12.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset12);
        piePlot3D20.clearSectionOutlineStrokes(false);
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint25 = standardChartTheme24.getLabelLinkPaint();
        java.awt.Paint paint26 = standardChartTheme24.getPlotOutlinePaint();
        java.awt.Paint paint27 = standardChartTheme24.getGridBandAlternatePaint();
        java.awt.Paint paint28 = standardChartTheme24.getBaselinePaint();
        java.awt.Paint paint29 = standardChartTheme24.getAxisLabelPaint();
        piePlot3D20.setLabelShadowPaint(paint29);
        standardChartTheme4.setBaselinePaint(paint29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(barPainter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodAnchor.END" + "'", str11.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Oct");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Oct, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate9.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
        boolean boolean14 = spreadsheetDate3.isOn(serialDate9);
        int int15 = spreadsheetDate3.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Paint paint1 = barRenderer3D0.getBaseLegendTextPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker6, layer7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Paint paint12 = combinedRangeXYPlot9.getDomainCrosshairPaint();
        combinedRangeXYPlot9.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedRangeXYPlot9.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D16, false);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = combinedRangeXYPlot9.getDomainMarkers(layer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker24.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer27 = null;
        combinedRangeXYPlot9.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        double double30 = intervalMarker24.getStartValue();
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = categoryPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24, layer31);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            barRenderer3D0.drawOutline(graphics2D4, categoryPlot5, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        java.lang.Object obj3 = barRenderer3D0.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image13 = null;
        combinedRangeXYPlot12.setBackgroundImage(image13);
        java.awt.Paint paint15 = combinedRangeXYPlot12.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint23 = categoryPlot22.getDomainCrosshairPaint();
        periodAxis18.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        java.awt.Color color25 = java.awt.Color.GREEN;
        categoryPlot22.setRangeZeroBaselinePaint((java.awt.Paint) color25);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape11, (java.awt.Paint) color25);
        java.awt.Paint paint28 = legendItem27.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image30 = null;
        combinedRangeXYPlot29.setBackgroundImage(image30);
        java.awt.Paint paint32 = combinedRangeXYPlot29.getDomainCrosshairPaint();
        java.awt.Paint paint33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot29.setDomainMinorGridlinePaint(paint33);
        legendItem27.setOutlinePaint(paint33);
        barRenderer3D0.setBaseOutlinePaint(paint33);
        double double37 = barRenderer3D0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Paint paint9 = combinedRangeXYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer13);
        org.jfree.chart.entity.TitleEntity titleEntity16 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) legendTitle14, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = legendTitle14.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle14.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle14.setLegendItemGraphicEdge(rectangleEdge19);
        boolean boolean21 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge19);
        boolean boolean22 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge19);
        try {
            double double23 = categoryAxis1.getCategoryEnd(11, 11, rectangle2D4, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers((int) (byte) 100, layer10);
        boolean boolean12 = combinedRangeXYPlot0.isDomainPannable();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) (short) 100, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        java.lang.String str22 = legendItem20.getToolTipText();
        boolean boolean23 = legendItem20.isShapeVisible();
        java.awt.Paint paint24 = null;
        legendItem20.setLabelPaint(paint24);
        boolean boolean27 = legendItem20.equals((java.lang.Object) 8);
        int int28 = legendItem20.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodAnchor.END" + "'", str22.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        boolean boolean5 = periodAxis1.isMinorTickMarksVisible();
        java.util.Locale locale6 = periodAxis1.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale6);
        java.text.NumberFormat numberFormat8 = java.text.NumberFormat.getCurrencyInstance(locale6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale6);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation3);
        java.lang.String str5 = axisLocation3.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str5.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset9 = polarPlot6.getDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate10 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset9);
        intervalXYDelegate10.setFixedIntervalWidth(0.0d);
        java.lang.Object obj13 = intervalXYDelegate10.clone();
        intervalXYDelegate10.setFixedIntervalWidth((double) 15);
        java.lang.Object obj16 = intervalXYDelegate10.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        boolean boolean9 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean11 = categoryPlot10.isDomainZoomable();
        categoryPlot10.clearDomainMarkers();
        java.util.List list13 = categoryPlot10.getCategories();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot10.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation14);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.RenderingHints renderingHints9 = jFreeChart6.getRenderingHints();
        jFreeChart6.fireChartChanged();
        int int11 = jFreeChart6.getBackgroundImageAlignment();
        jFreeChart6.clearSubtitles();
        java.util.List list13 = jFreeChart6.getSubtitles();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = jFreeChart6.getPadding();
        java.awt.Paint paint15 = null;
        jFreeChart6.setBorderPaint(paint15);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Stroke stroke1 = barRenderer3D0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = barRenderer3D0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D0.getLegendItemToolTipGenerator();
        boolean boolean4 = barRenderer3D0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot6.setRangeMinorGridlineStroke(stroke7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot6.panDomainAxes(0.05d, plotRenderingInfo10, point2D11);
        boolean boolean13 = categoryPlot6.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = combinedRangeXYPlot14.getDomainAxisEdge();
        combinedRangeXYPlot14.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = combinedRangeXYPlot14.getRangeAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            barRenderer3D0.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis18, (org.jfree.chart.plot.Marker) intervalMarker21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(valueAxis18);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Object obj3 = xYStepRenderer2.clone();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            xYStepRenderer2.addAnnotation(xYAnnotation4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(layer5);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer14);
        org.jfree.chart.entity.TitleEntity titleEntity17 = new org.jfree.chart.entity.TitleEntity(shape6, (org.jfree.chart.title.Title) legendTitle15, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = legendTitle15.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle15.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle15.setLegendItemGraphicEdge(rectangleEdge20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setBackgroundImageAlpha((float) (short) 0);
        boolean boolean25 = categoryPlot22.isOutlineVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image27 = null;
        combinedRangeXYPlot26.setBackgroundImage(image27);
        java.awt.Paint paint29 = combinedRangeXYPlot26.getDomainCrosshairPaint();
        combinedRangeXYPlot26.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder31 = combinedRangeXYPlot26.getSeriesRenderingOrder();
        java.util.List list32 = combinedRangeXYPlot26.getSubplots();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image34 = null;
        combinedRangeXYPlot33.setBackgroundImage(image34);
        java.awt.Stroke stroke36 = combinedRangeXYPlot33.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset38 = combinedRangeXYPlot33.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint44 = xYLineAndShapeRenderer42.getLegendTextPaint(0);
        combinedRangeXYPlot33.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer42);
        java.util.List list46 = combinedRangeXYPlot33.getSubplots();
        combinedRangeXYPlot33.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot51 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint52 = combinedRangeXYPlot51.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis54 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(10);
        periodAxis54.setFirst((org.jfree.data.time.RegularTimePeriod) year56);
        java.awt.Font font58 = periodAxis54.getLabelFont();
        combinedRangeXYPlot51.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis54);
        combinedRangeXYPlot33.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis54, true);
        org.jfree.chart.axis.PeriodAxis periodAxis63 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint64 = periodAxis63.getTickMarkPaint();
        periodAxis63.setInverted(true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { periodAxis54, periodAxis63 };
        combinedRangeXYPlot26.setDomainAxes(valueAxisArray67);
        categoryPlot22.setRangeAxes(valueAxisArray67);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean72 = categoryPlot71.isDomainZoomable();
        categoryPlot71.clearDomainMarkers();
        boolean boolean74 = categoryPlot71.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo76 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo76);
        java.awt.geom.Point2D point2D78 = null;
        categoryPlot71.zoomRangeAxes(0.0d, plotRenderingInfo77, point2D78, false);
        java.awt.geom.Point2D point2D81 = null;
        categoryPlot22.panDomainAxes((double) 6, plotRenderingInfo77, point2D81);
        try {
            org.jfree.chart.axis.AxisState axisState83 = numberAxis1.draw(graphics2D2, (double) 10L, rectangle2D4, rectangle2D5, rectangleEdge20, plotRenderingInfo77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(seriesRenderingOrder31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(xYDataset38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = null;
        boolean boolean9 = jFreeChart6.equals(obj8);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart6.getTitle();
        jFreeChart6.setAntiAlias(true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer16);
        jFreeChart6.addSubtitle((int) (short) 1, (org.jfree.chart.title.Title) legendTitle17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            jFreeChart6.draw(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(textTitle10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        java.lang.Object obj2 = xYBarRenderer1.clone();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke5 = xYAreaRenderer3.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image9 = null;
        combinedRangeXYPlot8.setBackgroundImage(image9);
        java.awt.Stroke stroke11 = combinedRangeXYPlot8.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset13 = combinedRangeXYPlot8.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot14 = combinedRangeXYPlot8.getParent();
        combinedRangeXYPlot8.setDomainCrosshairVisible(true);
        combinedRangeXYPlot8.configureDomainAxes();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeZone18);
        boolean boolean21 = timeSeriesCollection19.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection19, valueAxis22, polarItemRenderer23);
        polarPlot24.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset27 = polarPlot24.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState30 = xYAreaRenderer3.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8, xYDataset27, plotRenderingInfo29);
        org.jfree.data.Range range31 = xYBarRenderer1.findDomainBounds(xYDataset27);
        xYBarRenderer1.setShadowYOffset(4.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(xYDataset27);
        org.junit.Assert.assertNotNull(xYItemRendererState30);
        org.junit.Assert.assertNull(range31);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        standardChartTheme1.setBaselinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getErrorIndicatorPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Paint paint6 = combinedRangeXYPlot3.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer10);
        org.jfree.chart.entity.TitleEntity titleEntity13 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle11, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle11.getHorizontalAlignment();
        double double15 = legendTitle11.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = legendTitle11.getHorizontalAlignment();
        textTitle1.setTextAlignment(horizontalAlignment16);
        textBlock0.setLineAlignment(horizontalAlignment16);
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("", font20);
        org.jfree.chart.text.TextFragment textFragment22 = textLine21.getFirstTextFragment();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        boolean boolean26 = textLine21.equals((java.lang.Object) timeSeriesCollection24);
        org.jfree.chart.text.TextFragment textFragment27 = textLine21.getFirstTextFragment();
        textBlock0.addLine(textLine21);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(textFragment22);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(textFragment27);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean10 = xYLineAndShapeRenderer9.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYLineAndShapeRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYLineAndShapeRenderer9.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer9.setBaseCreateEntities(true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = barRenderer3D19.removeAnnotation(categoryAnnotation20);
        java.lang.Object obj22 = barRenderer3D19.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer3D19.setSeriesURLGenerator(0, categoryURLGenerator24);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(10);
        boolean boolean40 = periodAxis37.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint42 = categoryPlot41.getDomainCrosshairPaint();
        periodAxis37.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot41);
        java.awt.Color color44 = java.awt.Color.GREEN;
        categoryPlot41.setRangeZeroBaselinePaint((java.awt.Paint) color44);
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape30, (java.awt.Paint) color44);
        java.awt.Paint paint47 = legendItem46.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image49 = null;
        combinedRangeXYPlot48.setBackgroundImage(image49);
        java.awt.Paint paint51 = combinedRangeXYPlot48.getDomainCrosshairPaint();
        java.awt.Paint paint52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot48.setDomainMinorGridlinePaint(paint52);
        legendItem46.setOutlinePaint(paint52);
        barRenderer3D19.setBaseOutlinePaint(paint52);
        xYLineAndShapeRenderer9.setBaseFillPaint(paint52);
        boolean boolean57 = legendGraphic5.equals((java.lang.Object) xYLineAndShapeRenderer9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = legendGraphic5.getShapeAnchor();
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.data.Range range61 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = new org.jfree.chart.block.RectangleConstraint((double) (-11L), range61);
        try {
            org.jfree.chart.util.Size2D size2D63 = legendGraphic5.arrange(graphics2D59, rectangleConstraint62);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean9 = xYLineAndShapeRenderer8.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYLineAndShapeRenderer8.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYLineAndShapeRenderer8.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition15, false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition18 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer21);
        boolean boolean23 = xYLineAndShapeRenderer21.getBaseItemLabelsVisible();
        boolean boolean24 = dateTickMarkPosition18.equals((java.lang.Object) xYLineAndShapeRenderer21);
        java.awt.Font font28 = xYLineAndShapeRenderer21.getItemLabelFont((-9999), 6, false);
        org.jfree.chart.text.TextBlock textBlock29 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = textBlock29.calculateDimensions(graphics2D30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor35 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock29.draw(graphics2D32, 10.0f, (float) 7, textBlockAnchor35, (float) (-61835976000001L), 0.0f, (double) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean44 = xYLineAndShapeRenderer43.getAutoPopulateSeriesShape();
        java.awt.Font font45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer43.setBaseLegendTextFont(font45);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean50 = xYLineAndShapeRenderer49.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image53 = null;
        combinedRangeXYPlot52.setBackgroundImage(image53);
        java.awt.Stroke stroke55 = combinedRangeXYPlot52.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset57 = combinedRangeXYPlot52.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot58 = combinedRangeXYPlot52.getParent();
        combinedRangeXYPlot52.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer62 = null;
        java.util.Collection collection63 = combinedRangeXYPlot52.getDomainMarkers((int) (byte) 100, layer62);
        org.jfree.chart.axis.PeriodAxis periodAxis65 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(10);
        boolean boolean68 = periodAxis65.equals((java.lang.Object) 10);
        boolean boolean69 = periodAxis65.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint73 = categoryPlot72.getDomainCrosshairPaint();
        java.awt.Paint paint74 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot72.setRangeZeroBaselinePaint(paint74);
        java.awt.Stroke stroke76 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer49.drawDomainLine(graphics2D51, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot52, (org.jfree.chart.axis.ValueAxis) periodAxis65, rectangle2D70, (double) (byte) 1, paint74, stroke76);
        textBlock29.addLine("ItemLabelAnchor.OUTSIDE1", font45, paint74);
        xYLineAndShapeRenderer21.setBaseLegendTextFont(font45);
        xYLineAndShapeRenderer2.setBaseItemLabelFont(font45, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(dateTickMarkPosition18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(size2D31);
        org.junit.Assert.assertNotNull(textBlockAnchor35);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(xYDataset57);
        org.junit.Assert.assertNull(plot58);
        org.junit.Assert.assertNull(collection63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getDomainCrosshairPaint();
        categoryPlot5.setRangeZeroBaselinePaint(paint9);
        xYLineAndShapeRenderer3.setBaseFillPaint(paint9, true);
        java.text.NumberFormat numberFormat14 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat16 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat16, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator19 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat14, numberFormat16);
        xYLineAndShapeRenderer3.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator19);
        java.lang.Object obj21 = standardXYToolTipGenerator19.clone();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator23 = new org.jfree.chart.urls.StandardXYURLGenerator("Range[0.0,1.0]");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer(15, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator19, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator23);
        boolean boolean25 = xYAreaRenderer24.getPlotArea();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberFormat16);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        multiplePiePlot1.setLimit((double) 0L);
        org.jfree.chart.util.TableOrder tableOrder4 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray6, numberArray9, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CONTRACT", "", numberArray13);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str2 = axisSpace1.toString();
        axisSpace0.ensureAtLeast(axisSpace1);
        double double4 = axisSpace1.getLeft();
        double double5 = axisSpace1.getLeft();
        java.lang.String str6 = axisSpace1.toString();
        axisSpace1.setRight(5.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Range[0.0,1.0]");
        try {
            dateAxis1.setRange((double) '#', (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(12.0d, 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font3 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        double double4 = categoryAxis1.getLowerMargin();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot7.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = combinedRangeXYPlot7.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint18 = xYLineAndShapeRenderer16.getLegendTextPaint(0);
        combinedRangeXYPlot7.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer16);
        java.util.List list20 = combinedRangeXYPlot7.getSubplots();
        axisState6.setTicks(list20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        try {
            java.util.List list24 = categoryAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D22, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Stroke stroke1 = barRenderer3D0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = barRenderer3D0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D0.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            barRenderer3D0.drawBackground(graphics2D4, categoryPlot5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        combinedRangeXYPlot0.panRangeAxes((double) 6, plotRenderingInfo18, point2D19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        boolean boolean24 = timeSeriesCollection22.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, valueAxis25, polarItemRenderer26);
        java.awt.Stroke stroke28 = polarPlot27.getRadiusGridlineStroke();
        combinedRangeXYPlot0.setDomainMinorGridlineStroke(stroke28);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean33 = categoryPlot32.isDomainZoomable();
        categoryPlot32.clearDomainMarkers();
        boolean boolean35 = categoryPlot32.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot32.zoomRangeAxes(0.0d, plotRenderingInfo38, point2D39, false);
        combinedRangeXYPlot0.handleClick(7, (-2), plotRenderingInfo38);
        combinedRangeXYPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }
}

