import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        boolean boolean8 = polarPlot6.isAngleLabelsVisible();
        polarPlot6.setAngleLabelsVisible(false);
        boolean boolean11 = polarPlot6.isAngleGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline13 = dateAxis12.getTimeline();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer17);
        boolean boolean19 = xYLineAndShapeRenderer17.getBaseItemLabelsVisible();
        boolean boolean20 = dateTickMarkPosition14.equals((java.lang.Object) xYLineAndShapeRenderer17);
        dateAxis12.setTickMarkPosition(dateTickMarkPosition14);
        polarPlot6.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeline13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "", "PieLabelLinkStyle.QUAD_CURVE", false);
        int int5 = logFormat4.getMaximumFractionDigits();
        logFormat4.setMinimumIntegerDigits(9999);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("series", "", "", "series");
        basicProjectInfo4.setCopyright("{0}");
        java.lang.String str7 = basicProjectInfo4.getName();
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo4.getLibraries();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "series" + "'", str7.equals("series"));
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        boolean boolean5 = combinedRangeXYPlot0.isDomainPannable();
        double double6 = combinedRangeXYPlot0.getGap();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot0.getRangeAxisEdge((-1));
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedRangeXYPlot0.select((double) 11, (double) 11, rectangle2D11, renderingSource12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PieLabelLinkStyle.QUAD_CURVE", dateFormat2, dateFormat3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint14 = categoryPlot13.getDomainCrosshairPaint();
        categoryPlot10.setRangeZeroBaselinePaint(paint14);
        xYLineAndShapeRenderer8.setBaseFillPaint(paint14, true);
        java.text.NumberFormat numberFormat19 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat21 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat21, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator24 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat19, numberFormat21);
        xYLineAndShapeRenderer8.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator24);
        java.lang.Object obj26 = standardXYToolTipGenerator24.clone();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator28 = new org.jfree.chart.urls.StandardXYURLGenerator("Range[0.0,1.0]");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer(15, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator24, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) '#', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator28);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberFormat21);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot2.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint13 = xYLineAndShapeRenderer11.getLegendTextPaint(0);
        combinedRangeXYPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer11);
        java.util.List list15 = combinedRangeXYPlot2.getSubplots();
        combinedRangeXYPlot2.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot2.panRangeAxes((double) 6, plotRenderingInfo20, point2D21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        boolean boolean26 = timeSeriesCollection24.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis27, polarItemRenderer28);
        java.awt.Stroke stroke30 = polarPlot29.getRadiusGridlineStroke();
        combinedRangeXYPlot2.setDomainMinorGridlineStroke(stroke30);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 9, stroke30);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate36.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate36);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate36);
        serialDate40.setDescription("");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset43 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme45 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint46 = standardChartTheme45.getLabelLinkPaint();
        java.awt.Paint paint47 = standardChartTheme45.getPlotOutlinePaint();
        java.awt.Paint paint48 = standardChartTheme45.getGridBandAlternatePaint();
        java.awt.Paint paint49 = standardChartTheme45.getSubtitlePaint();
        boolean boolean50 = defaultXYDataset43.equals((java.lang.Object) paint49);
        piePlot3D0.setSectionPaint((java.lang.Comparable) "", paint49);
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(10);
        periodAxis53.setFirst((org.jfree.data.time.RegularTimePeriod) year55);
        java.awt.Font font57 = periodAxis53.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis59 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(10);
        periodAxis59.setFirst((org.jfree.data.time.RegularTimePeriod) year61);
        java.awt.Font font63 = periodAxis59.getLabelFont();
        periodAxis59.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range66 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis59.setRange(range66, false, false);
        periodAxis53.setRange(range66, true, true);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        periodAxis53.setAxisLineStroke(stroke73);
        piePlot3D0.setLabelLinkStroke(stroke73);
        boolean boolean76 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        double double14 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot16.removeDomainMarker(marker17, layer18);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image21 = null;
        combinedRangeXYPlot20.setBackgroundImage(image21);
        java.awt.Paint paint23 = combinedRangeXYPlot20.getDomainCrosshairPaint();
        combinedRangeXYPlot20.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        combinedRangeXYPlot20.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = combinedRangeXYPlot20.getDomainMarkers(layer30);
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker35.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer38 = null;
        combinedRangeXYPlot20.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker35, layer38, false);
        double double41 = intervalMarker35.getStartValue();
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = categoryPlot16.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker35, layer42);
        java.awt.Stroke stroke44 = intervalMarker35.getOutlineStroke();
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = combinedRangeXYPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker35, layer45);
        combinedRangeXYPlot0.setBackgroundImageAlignment(11);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        java.lang.Class class3 = periodAxis1.getAutoRangeTimePeriodClass();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj5 = null;
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date4, obj5);
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(10);
        boolean boolean12 = periodAxis9.equals((java.lang.Object) 10);
        boolean boolean13 = periodAxis9.isMinorTickMarksVisible();
        java.util.Locale locale14 = periodAxis9.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale14);
        java.text.NumberFormat numberFormat16 = java.text.NumberFormat.getCurrencyInstance(locale14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date4, timeZone7, locale14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean21 = xYLineAndShapeRenderer20.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYLineAndShapeRenderer20.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = xYLineAndShapeRenderer20.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer20.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image34 = null;
        combinedRangeXYPlot33.setBackgroundImage(image34);
        java.awt.Paint paint36 = combinedRangeXYPlot33.getDomainCrosshairPaint();
        combinedRangeXYPlot33.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder38 = combinedRangeXYPlot33.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image41 = null;
        combinedRangeXYPlot40.setBackgroundImage(image41);
        java.awt.Stroke stroke43 = combinedRangeXYPlot40.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset45 = combinedRangeXYPlot40.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint51 = xYLineAndShapeRenderer49.getLegendTextPaint(0);
        combinedRangeXYPlot40.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer49);
        java.util.List list53 = combinedRangeXYPlot40.getSubplots();
        combinedRangeXYPlot40.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot58 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint59 = combinedRangeXYPlot58.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis61 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(10);
        periodAxis61.setFirst((org.jfree.data.time.RegularTimePeriod) year63);
        java.awt.Font font65 = periodAxis61.getLabelFont();
        combinedRangeXYPlot58.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis61);
        combinedRangeXYPlot40.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis61, true);
        org.jfree.chart.axis.PeriodAxis periodAxis70 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(10);
        periodAxis70.setFirst((org.jfree.data.time.RegularTimePeriod) year72);
        java.lang.String str74 = periodAxis70.getLabelURL();
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection76 = new org.jfree.data.time.TimeSeriesCollection(timeZone75);
        boolean boolean78 = timeSeriesCollection76.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis79 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer80 = null;
        org.jfree.chart.plot.PolarPlot polarPlot81 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection76, valueAxis79, polarItemRenderer80);
        xYLineAndShapeRenderer20.drawItem(graphics2D30, xYItemRendererState31, rectangle2D32, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot33, (org.jfree.chart.axis.ValueAxis) periodAxis61, (org.jfree.chart.axis.ValueAxis) periodAxis70, (org.jfree.data.xy.XYDataset) timeSeriesCollection76, 0, (int) (short) 100, true, (int) '4');
        java.util.TimeZone timeZone87 = periodAxis70.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone87);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone87;
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(numberFormat16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(seriesRenderingOrder38);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(xYDataset45);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot3.setRangeZeroBaselinePaint(paint5);
        boolean boolean7 = shapeList0.equals((java.lang.Object) categoryPlot3);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot9.setRangeMinorGridlineStroke(stroke10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot9.setRangeAxis(valueAxis12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo16, point2D17);
        categoryPlot9.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D20 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = null;
        barRenderer3D20.setGradientPaintTransformer(gradientPaintTransformer21);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D20);
        java.awt.Font font25 = barRenderer3D20.getSeriesItemLabelFont(1);
        java.awt.Paint paint27 = barRenderer3D20.getSeriesFillPaint((int) '4');
        double double28 = barRenderer3D20.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = barRenderer3D20.getLegendItemToolTipGenerator();
        try {
            categoryPlot3.setRenderer((int) (byte) -1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(font25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        java.util.List list3 = xYSeries2.getItems();
        double double4 = xYSeries2.getMaxX();
        boolean boolean5 = xYSeries2.getNotify();
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Font font16 = barRenderer3D11.getSeriesItemLabelFont(1);
        java.awt.Paint paint18 = barRenderer3D11.getSeriesFillPaint((int) '4');
        barRenderer3D11.setBaseItemLabelsVisible(false, true);
        boolean boolean22 = barRenderer3D11.isDrawBarOutline();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = categoryPlot24.getDrawingSupplier();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            barRenderer3D11.drawOutline(graphics2D23, categoryPlot24, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(drawingSupplier25);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat11, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat9, numberFormat11);
        boolean boolean15 = numberFormat9.isParseIntegerOnly();
        boolean boolean16 = textBlockAnchor7.equals((java.lang.Object) boolean15);
        textBlock0.draw(graphics2D4, (float) 86400000L, (float) 0, textBlockAnchor7, (float) (byte) 10, (float) 9, 0.0d);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset1.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset1.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset1);
        piePlot3D9.clearSectionOutlineStrokes(false);
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint14 = standardChartTheme13.getLabelLinkPaint();
        java.awt.Paint paint15 = standardChartTheme13.getPlotOutlinePaint();
        java.awt.Paint paint16 = standardChartTheme13.getGridBandAlternatePaint();
        java.awt.Paint paint17 = standardChartTheme13.getBaselinePaint();
        java.awt.Paint paint18 = standardChartTheme13.getAxisLabelPaint();
        piePlot3D9.setLabelShadowPaint(paint18);
        piePlot3D9.setAutoPopulateSectionOutlinePaint(true);
        double double22 = piePlot3D9.getShadowXOffset();
        boolean boolean23 = rectangleAnchor0.equals((java.lang.Object) double22);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker15.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer18 = null;
        combinedRangeXYPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker15, layer18, false);
        combinedRangeXYPlot0.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image24 = null;
        combinedRangeXYPlot23.setBackgroundImage(image24);
        java.awt.Paint paint26 = combinedRangeXYPlot23.getDomainCrosshairPaint();
        combinedRangeXYPlot23.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder28 = combinedRangeXYPlot23.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot23);
        java.awt.Paint paint30 = jFreeChart29.getBackgroundPaint();
        java.lang.Object obj31 = null;
        boolean boolean32 = jFreeChart29.equals(obj31);
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart29.getTitle();
        java.awt.Stroke stroke34 = jFreeChart29.getBorderStroke();
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke34);
        combinedRangeXYPlot0.setWeight((int) (byte) 0);
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image41 = null;
        combinedRangeXYPlot40.setBackgroundImage(image41);
        java.awt.Stroke stroke43 = combinedRangeXYPlot40.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset45 = combinedRangeXYPlot40.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint51 = xYLineAndShapeRenderer49.getLegendTextPaint(0);
        combinedRangeXYPlot40.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer49);
        java.util.List list53 = combinedRangeXYPlot40.getSubplots();
        combinedRangeXYPlot40.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        combinedRangeXYPlot40.panRangeAxes((double) 6, plotRenderingInfo58, point2D59);
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection62 = new org.jfree.data.time.TimeSeriesCollection(timeZone61);
        boolean boolean64 = timeSeriesCollection62.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer66 = null;
        org.jfree.chart.plot.PolarPlot polarPlot67 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection62, valueAxis65, polarItemRenderer66);
        java.awt.Stroke stroke68 = polarPlot67.getRadiusGridlineStroke();
        combinedRangeXYPlot40.setDomainMinorGridlineStroke(stroke68);
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean73 = categoryPlot72.isDomainZoomable();
        categoryPlot72.clearDomainMarkers();
        boolean boolean75 = categoryPlot72.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo77);
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot72.zoomRangeAxes(0.0d, plotRenderingInfo78, point2D79, false);
        combinedRangeXYPlot40.handleClick(7, (-2), plotRenderingInfo78);
        java.awt.geom.Point2D point2D83 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(45.0d, plotRenderingInfo78, point2D83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(textTitle33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(xYDataset45);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        boolean boolean2 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot9 = combinedRangeXYPlot3.getParent();
        combinedRangeXYPlot3.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = categoryPlot12.removeDomainMarker(marker13, layer14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image17 = null;
        combinedRangeXYPlot16.setBackgroundImage(image17);
        java.awt.Paint paint19 = combinedRangeXYPlot16.getDomainCrosshairPaint();
        combinedRangeXYPlot16.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        combinedRangeXYPlot16.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23, false);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = combinedRangeXYPlot16.getDomainMarkers(layer26);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker31.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer34 = null;
        combinedRangeXYPlot16.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker31, layer34, false);
        double double37 = intervalMarker31.getStartValue();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean39 = categoryPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker31, layer38);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        combinedRangeXYPlot3.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker31, layer40);
        boolean boolean42 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font3 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        java.lang.String str4 = categoryAxis1.getLabelURL();
        org.jfree.data.xy.XYDataItem xYDataItem7 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 10);
        java.awt.Paint paint9 = null;
        try {
            categoryAxis1.setTickLabelPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker2.setEndValue((double) (-11L));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = intervalMarker2.getLabelOffsetType();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot6.setRangeMinorGridlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot6.setRangeAxis(valueAxis9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        categoryPlot6.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        int int15 = categoryPlot6.indexOf(categoryDataset14);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot3.setDomainAxisLocation(axisLocation5);
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean10 = timeSeriesCollection8.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, valueAxis11, polarItemRenderer12);
        polarPlot13.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        polarPlot13.rendererChanged(rendererChangeEvent16);
        java.awt.Color color18 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color18 };
        java.awt.Paint[] paintArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke22, stroke23, stroke24 };
        java.awt.Stroke stroke26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke26 };
        java.awt.Shape[] shapeArray28 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray25, strokeArray27, shapeArray28);
        polarPlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29, true);
        combinedRangeXYPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29);
        combinedRangeXYPlot3.clearDomainMarkers();
        boolean boolean34 = combinedRangeXYPlot3.isDomainCrosshairLockedOnData();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = combinedRangeXYPlot36.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace38 = new org.jfree.chart.axis.AxisSpace();
        double double39 = axisSpace38.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace38.add(0.0d, rectangleEdge41);
        axisSpace38.setTop(45.0d);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = dateAxis0.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot3, rectangle2D35, rectangleEdge37, axisSpace38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 100L, "", "PieLabelLinkStyle.QUAD_CURVE", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, (java.text.NumberFormat) logFormat6);
        java.text.NumberFormat numberFormat8 = logFormat6.getExponentFormat();
        int int9 = numberFormat8.getMaximumFractionDigits();
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getDomainCrosshairPaint();
        periodAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        periodAxis1.setUpperBound((double) 1900);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        periodAxis11.setFirst((org.jfree.data.time.RegularTimePeriod) year13);
        java.awt.Font font15 = periodAxis11.getLabelFont();
        periodAxis11.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis11.setRange(range18, false, false);
        boolean boolean23 = range18.contains((double) (byte) 10);
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(10);
        periodAxis25.setFirst((org.jfree.data.time.RegularTimePeriod) year27);
        java.awt.Font font29 = periodAxis25.getLabelFont();
        periodAxis25.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis25.setRange(range32, false, false);
        java.lang.String str36 = range32.toString();
        org.jfree.data.Range range37 = org.jfree.data.Range.combine(range18, range32);
        periodAxis1.setRangeWithMargins(range18, true, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Range[0.0,1.0]" + "'", str36.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(32);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 1L);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator((int) '#', xYItemLabelGenerator3);
        xYBarRenderer1.setUseYInterval(true);
        xYBarRenderer1.setBarAlignmentFactor(0.0d);
        java.awt.Stroke stroke10 = xYBarRenderer1.getSeriesStroke((int) ' ');
        org.junit.Assert.assertNull(stroke10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        double double5 = periodAxis1.getFixedDimension();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray11 = new float[] { 0.0f, (-11L), (-2208960000000L), 10.0f };
        float[] floatArray12 = color6.getComponents(floatArray11);
        periodAxis1.setTickMarkPaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer12.getSeriesCreateEntities(0);
        java.awt.Paint paint18 = xYLineAndShapeRenderer12.getSeriesOutlinePaint((int) (byte) -1);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator19 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYLineAndShapeRenderer12.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator19);
        java.awt.Shape shape22 = xYLineAndShapeRenderer12.lookupSeriesShape(2019);
        piePlot3D8.setLegendItemShape(shape22);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        java.lang.String str2 = datasetGroup0.getID();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOID" + "'", str2.equals("NOID"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        xYSeriesCollection1.setIntervalWidth((double) (byte) 10);
        double double4 = xYSeriesCollection1.getIntervalPositionFactor();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis5, polarItemRenderer6);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        polarPlot7.setRenderer(polarItemRenderer8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        textTitle0.draw(graphics2D1, rectangle2D2);
        int int4 = textTitle0.getMaximumLinesToDisplay();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedDomainXYPlot1.setRenderer(xYItemRenderer2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer3D0.getLegendItemURLGenerator();
        double double7 = barRenderer3D0.getShadowYOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot8.setRangeMinorGridlineStroke(stroke9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot8.setRangeAxis(valueAxis11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot8.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo15, point2D16);
        categoryPlot8.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        barRenderer3D19.setGradientPaintTransformer(gradientPaintTransformer20);
        categoryPlot8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D19);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray35 = new java.lang.Number[][] { numberArray28, numberArray31, numberArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray35);
        categoryPlot23.setDataset(categoryDataset36);
        java.lang.Number number38 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset36);
        org.jfree.data.Range range40 = barRenderer3D19.findRangeBounds(categoryDataset36, true);
        org.jfree.data.Range range41 = barRenderer3D0.findRangeBounds(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0.0d + "'", number38.equals(0.0d));
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint2 = textFragment1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot5.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot11 = combinedRangeXYPlot5.getParent();
        combinedRangeXYPlot5.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = combinedRangeXYPlot5.getDomainMarkers((int) (byte) 100, layer15);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        boolean boolean22 = periodAxis18.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getDomainCrosshairPaint();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot25.setRangeZeroBaselinePaint(paint27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.drawDomainLine(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.chart.axis.ValueAxis) periodAxis18, rectangle2D23, (double) (byte) 1, paint27, stroke29);
        java.awt.Paint paint31 = null;
        try {
            combinedRangeXYPlot5.setRangeCrosshairPaint(paint31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.removeAnnotations();
        java.awt.Paint paint6 = barRenderer3D0.getSeriesOutlinePaint(8);
        barRenderer3D0.setShadowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font11 = categoryAxis9.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        boolean boolean12 = jFreeChart6.equals((java.lang.Object) font11);
        jFreeChart6.setAntiAlias(false);
        jFreeChart6.setNotify(true);
        java.lang.Object obj17 = jFreeChart6.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        double double6 = barRenderer3D0.getBase();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint19 = categoryPlot18.getDomainCrosshairPaint();
        xYLineAndShapeRenderer15.setSeriesOutlinePaint((int) 'a', paint19);
        xYLineAndShapeRenderer10.setSeriesFillPaint((int) '#', paint19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYLineAndShapeRenderer10.getNegativeItemLabelPosition(3, (-9999), false);
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition25, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = xYItemRendererState23.getInfo();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNull(plotRenderingInfo24);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(categoryItemRenderer6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Paint paint6 = combinedRangeXYPlot3.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer10);
        org.jfree.chart.entity.TitleEntity titleEntity13 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle11, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle11.getHorizontalAlignment();
        double double15 = legendTitle11.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = legendTitle11.getHorizontalAlignment();
        textTitle1.setTextAlignment(horizontalAlignment16);
        textBlock0.setLineAlignment(horizontalAlignment16);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape26 = textBlock0.calculateBounds(graphics2D19, (float) (-9999), (float) (-1L), textBlockAnchor22, (float) (-9999), (float) ' ', 1.0E-8d);
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine27);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = dateAxis0.getTimeline();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getDomainCrosshairPaint();
        categoryPlot6.setRangeZeroBaselinePaint(paint10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot6.getRangeMarkers(0, layer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getRangeAxisEdge(2);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke19 = xYAreaRenderer17.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot28 = combinedRangeXYPlot22.getParent();
        combinedRangeXYPlot22.setDomainCrosshairVisible(true);
        combinedRangeXYPlot22.configureDomainAxes();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection33 = new org.jfree.data.time.TimeSeriesCollection(timeZone32);
        boolean boolean35 = timeSeriesCollection33.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection33, valueAxis36, polarItemRenderer37);
        polarPlot38.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset41 = polarPlot38.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState44 = xYAreaRenderer17.initialise(graphics2D20, rectangle2D21, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot22, xYDataset41, plotRenderingInfo43);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo43);
        try {
            org.jfree.chart.axis.AxisState axisState46 = dateAxis0.draw(graphics2D2, 0.025d, rectangle2D4, rectangle2D5, rectangleEdge16, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeline1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(xYDataset41);
        org.junit.Assert.assertNotNull(xYItemRendererState44);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset9 = polarPlot6.getDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate10 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset9);
        intervalXYDelegate10.setFixedIntervalWidth(0.0d);
        java.lang.Object obj13 = intervalXYDelegate10.clone();
        intervalXYDelegate10.setFixedIntervalWidth((double) 15);
        try {
            intervalXYDelegate10.setIntervalPositionFactor((double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset9);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint9 = periodAxis8.getTickMarkPaint();
        periodAxis8.setInverted(true);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(10);
        boolean boolean16 = periodAxis13.equals((java.lang.Object) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer19.setAutoPopulateSeriesPaint(false);
        java.awt.Color color23 = java.awt.Color.gray;
        int int24 = color23.getTransparency();
        xYLineAndShapeRenderer19.setBaseItemLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer19);
        java.util.List list27 = null;
        try {
            org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker15.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer18 = null;
        combinedRangeXYPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker15, layer18, false);
        combinedRangeXYPlot0.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image24 = null;
        combinedRangeXYPlot23.setBackgroundImage(image24);
        java.awt.Paint paint26 = combinedRangeXYPlot23.getDomainCrosshairPaint();
        combinedRangeXYPlot23.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder28 = combinedRangeXYPlot23.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot23);
        java.awt.Paint paint30 = jFreeChart29.getBackgroundPaint();
        java.lang.Object obj31 = null;
        boolean boolean32 = jFreeChart29.equals(obj31);
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart29.getTitle();
        java.awt.Stroke stroke34 = jFreeChart29.getBorderStroke();
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Point2D point2D39 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 0, plotRenderingInfo38, point2D39, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(textTitle33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Paint paint1 = barRenderer3D0.getBaseLegendTextPaint();
        boolean boolean2 = barRenderer3D0.getIncludeBaseInRange();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        combinedRangeXYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean12 = combinedRangeXYPlot0.isDomainZoomable();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        combinedRangeXYPlot0.setRangeMinorGridlineStroke(stroke13);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset15 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset15.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset15.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset15);
        piePlot3D23.clearSectionOutlineStrokes(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image27 = null;
        combinedRangeXYPlot26.setBackgroundImage(image27);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset31 = combinedRangeXYPlot26.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint37 = xYLineAndShapeRenderer35.getLegendTextPaint(0);
        combinedRangeXYPlot26.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer35);
        java.util.List list39 = combinedRangeXYPlot26.getSubplots();
        combinedRangeXYPlot26.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        combinedRangeXYPlot26.panRangeAxes((double) 6, plotRenderingInfo44, point2D45);
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection48 = new org.jfree.data.time.TimeSeriesCollection(timeZone47);
        boolean boolean50 = timeSeriesCollection48.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection48, valueAxis51, polarItemRenderer52);
        java.awt.Stroke stroke54 = polarPlot53.getRadiusGridlineStroke();
        combinedRangeXYPlot26.setDomainMinorGridlineStroke(stroke54);
        piePlot3D23.setBaseSectionOutlineStroke(stroke54);
        combinedRangeXYPlot0.setDomainZeroBaselineStroke(stroke54);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 100, 3.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot0.setRangeAxis(0, valueAxis16);
        categoryPlot0.setRangeCrosshairValue((double) (-1.0f), true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font4 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        boolean boolean5 = paintMap0.equals((java.lang.Object) (-2208960000000L));
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long9 = month8.getSerialIndex();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState10 = new org.jfree.chart.plot.XYCrosshairState();
        int int11 = month8.compareTo((java.lang.Object) xYCrosshairState10);
        int int12 = month8.getYearValue();
        java.awt.Paint paint13 = paintMap0.getPaint((java.lang.Comparable) month8);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-11L) + "'", long9 == (-11L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ClassContext");
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        combinedRangeXYPlot7.setRangeCrosshairLockedOnData(true);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_BLUE;
        combinedRangeXYPlot7.setDomainMinorGridlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.setBaseStroke(stroke7, false);
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint14 = combinedRangeXYPlot13.getDomainCrosshairPaint();
        xYLineAndShapeRenderer2.setSeriesFillPaint((int) (short) 100, paint14, false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, false);
        boolean boolean11 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image5 = null;
        combinedRangeXYPlot4.setBackgroundImage(image5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot4.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint15 = xYLineAndShapeRenderer13.getLegendTextPaint(0);
        combinedRangeXYPlot4.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer13);
        java.util.List list17 = combinedRangeXYPlot4.getSubplots();
        axisState3.setTicks(list17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image22 = null;
        combinedRangeXYPlot21.setBackgroundImage(image22);
        java.awt.Paint paint24 = combinedRangeXYPlot21.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape20, (org.jfree.chart.plot.Plot) combinedRangeXYPlot21);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer28);
        org.jfree.chart.entity.TitleEntity titleEntity31 = new org.jfree.chart.entity.TitleEntity(shape20, (org.jfree.chart.title.Title) legendTitle29, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = legendTitle29.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle29.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle29.setLegendItemGraphicEdge(rectangleEdge34);
        boolean boolean36 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge34);
        boolean boolean37 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge34);
        try {
            java.util.List list38 = categoryAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D19, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) -1, (double) 9999);
        xYDataItem2.setSelected(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setBackgroundImageAlpha((float) (short) 0);
        boolean boolean8 = categoryPlot5.isOutlineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot9.setRangeMinorGridlineStroke(stroke10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot9.setRangeAxis(valueAxis12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo16, point2D17);
        categoryPlot9.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D20 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = null;
        barRenderer3D20.setGradientPaintTransformer(gradientPaintTransformer21);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = barRenderer3D20.getItemLabelGenerator((int) (short) 10, 7, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        java.lang.Boolean boolean35 = xYLineAndShapeRenderer31.getSeriesCreateEntities(0);
        boolean boolean36 = xYLineAndShapeRenderer31.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean40 = xYLineAndShapeRenderer39.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = xYLineAndShapeRenderer39.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = xYLineAndShapeRenderer39.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer31.setBasePositiveItemLabelPosition(itemLabelPosition46);
        barRenderer3D20.setSeriesPositiveItemLabelPosition(100, itemLabelPosition46);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D49 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Stroke stroke50 = barRenderer3D49.getBaseOutlineStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator51 = barRenderer3D49.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer52 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator56 = barRenderer52.getToolTipGenerator((int) (short) 0, (int) (byte) 0, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray57 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { barRenderer3D20, barRenderer3D49, barRenderer52 };
        categoryPlot5.setRenderers(categoryItemRendererArray57);
        boolean boolean59 = xYDataItem2.equals((java.lang.Object) categoryItemRendererArray57);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator51);
        org.junit.Assert.assertNull(categoryToolTipGenerator56);
        org.junit.Assert.assertNotNull(categoryItemRendererArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        barRenderer3D0.setIncludeBaseInRange(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = barRenderer3D0.getGradientPaintTransformer();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape14, (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(10);
        boolean boolean24 = periodAxis21.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getDomainCrosshairPaint();
        periodAxis21.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot25);
        java.awt.Color color28 = java.awt.Color.GREEN;
        categoryPlot25.setRangeZeroBaselinePaint((java.awt.Paint) color28);
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape14, (java.awt.Paint) color28);
        try {
            barRenderer3D0.setSeriesShape((-2), shape14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem2.setY((java.lang.Number) 100);
        double double5 = xYDataItem2.getYValue();
        java.lang.Number number6 = xYDataItem2.getY();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100 + "'", number6.equals(100));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        java.util.List list3 = xYSeries2.getItems();
        boolean boolean4 = xYSeries2.getAllowDuplicateXValues();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries2.remove(32);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = null;
        boolean boolean9 = jFreeChart6.equals(obj8);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart6.getTitle();
        jFreeChart6.setAntiAlias(true);
        java.awt.RenderingHints renderingHints13 = jFreeChart6.getRenderingHints();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(textTitle10);
        org.junit.Assert.assertNotNull(renderingHints13);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape4, (org.jfree.chart.title.Title) legendTitle13, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = legendTitle13.getHorizontalAlignment();
        double double17 = legendTitle13.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = legendTitle13.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment19, 0.0d, 0.4d);
        textBlock0.setLineAlignment(horizontalAlignment18);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent14);
        boolean boolean16 = combinedRangeXYPlot0.isRangeCrosshairLockedOnData();
        combinedRangeXYPlot0.setWeight((int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (-11L), range4);
        java.lang.String str6 = rectangleConstraint5.toString();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint5.toRangeWidth(range7);
        boolean boolean9 = xYStepRenderer2.equals((java.lang.Object) rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=-11.0, height=0.0]" + "'", str6.equals("RectangleConstraint[LengthConstraintType.FIXED: width=-11.0, height=0.0]"));
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot2.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint13 = xYLineAndShapeRenderer11.getLegendTextPaint(0);
        combinedRangeXYPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer11);
        java.util.List list15 = combinedRangeXYPlot2.getSubplots();
        combinedRangeXYPlot2.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot2.panRangeAxes((double) 6, plotRenderingInfo20, point2D21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        boolean boolean26 = timeSeriesCollection24.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis27, polarItemRenderer28);
        java.awt.Stroke stroke30 = polarPlot29.getRadiusGridlineStroke();
        combinedRangeXYPlot2.setDomainMinorGridlineStroke(stroke30);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 9, stroke30);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate36.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate36);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate36);
        serialDate40.setDescription("");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset43 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme45 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint46 = standardChartTheme45.getLabelLinkPaint();
        java.awt.Paint paint47 = standardChartTheme45.getPlotOutlinePaint();
        java.awt.Paint paint48 = standardChartTheme45.getGridBandAlternatePaint();
        java.awt.Paint paint49 = standardChartTheme45.getSubtitlePaint();
        boolean boolean50 = defaultXYDataset43.equals((java.lang.Object) paint49);
        piePlot3D0.setSectionPaint((java.lang.Comparable) "", paint49);
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(10);
        periodAxis53.setFirst((org.jfree.data.time.RegularTimePeriod) year55);
        java.awt.Font font57 = periodAxis53.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis59 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(10);
        periodAxis59.setFirst((org.jfree.data.time.RegularTimePeriod) year61);
        java.awt.Font font63 = periodAxis59.getLabelFont();
        periodAxis59.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range66 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis59.setRange(range66, false, false);
        periodAxis53.setRange(range66, true, true);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        periodAxis53.setAxisLineStroke(stroke73);
        piePlot3D0.setLabelLinkStroke(stroke73);
        piePlot3D0.setAutoPopulateSectionPaint(true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.expand(rectangle2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        boolean boolean2 = categoryAxis1.isMinorTickMarksVisible();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(10);
        periodAxis4.setFirst((org.jfree.data.time.RegularTimePeriod) year6);
        java.awt.Font font8 = periodAxis4.getLabelFont();
        periodAxis4.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis4.setRange(range11, false, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot15.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = combinedRangeXYPlot15.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot21 = combinedRangeXYPlot15.getParent();
        combinedRangeXYPlot15.setDomainCrosshairVisible(true);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image26 = null;
        combinedRangeXYPlot25.setBackgroundImage(image26);
        java.awt.Paint paint28 = combinedRangeXYPlot25.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity29 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) combinedRangeXYPlot25);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer32);
        org.jfree.chart.entity.TitleEntity titleEntity35 = new org.jfree.chart.entity.TitleEntity(shape24, (org.jfree.chart.title.Title) legendTitle33, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = legendTitle33.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle33.getItemLabelPadding();
        combinedRangeXYPlot15.setInsets(rectangleInsets37);
        double double40 = rectangleInsets37.calculateBottomInset((double) (byte) 10);
        double double42 = rectangleInsets37.calculateTopInset((double) 'a');
        periodAxis4.setLabelInsets(rectangleInsets37);
        categoryAxis1.setTickLabelInsets(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.0d + "'", double40 == 2.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint9 = periodAxis8.getTickMarkPaint();
        periodAxis8.setInverted(true);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(10);
        boolean boolean16 = periodAxis13.equals((java.lang.Object) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer19.setAutoPopulateSeriesPaint(false);
        java.awt.Color color23 = java.awt.Color.gray;
        int int24 = color23.getTransparency();
        xYLineAndShapeRenderer19.setBaseItemLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer19);
        try {
            double double29 = timeSeriesCollection1.getStartXValue(15, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 60000L, (double) 86400000L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone6);
        boolean boolean9 = timeSeriesCollection7.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection7, valueAxis10, polarItemRenderer11);
        java.lang.Object obj13 = polarPlot12.clone();
        boolean boolean14 = polarPlot12.isAngleLabelsVisible();
        polarPlot12.setRadiusGridlinesVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        boolean boolean20 = polarPlot12.equals((java.lang.Object) combinedRangeXYPlot17);
        java.awt.Paint paint21 = polarPlot12.getRadiusGridlinePaint();
        xYLineAndShapeRenderer2.setSeriesFillPaint((int) (short) 1, paint21, true);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font4 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("Polar Plot", font4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setPadding(Double.NaN, (double) (short) 100, (double) (byte) 1, (double) 3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        java.lang.String str22 = legendItem20.getToolTipText();
        boolean boolean23 = legendItem20.isShapeVisible();
        legendItem20.setDatasetIndex((int) ' ');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer26.setBaseShape(shape27, false);
        java.awt.Color color30 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer32 = legendGraphic31.getFillPaintTransformer();
        legendItem20.setFillPaintTransformer(gradientPaintTransformer32);
        boolean boolean34 = legendItem20.isShapeFilled();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodAnchor.END" + "'", str22.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformer32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-1), 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries2.add((double) (short) 0, (double) (short) 0);
        xYSeries2.setNotify(true);
        double[][] doubleArray8 = xYSeries2.toArray();
        org.jfree.data.xy.XYSeries xYSeries9 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection(xYSeries9);
        xYSeriesCollection10.setIntervalWidth((double) (byte) 10);
        xYSeriesCollection10.setAutoWidth(false);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = xYSeriesCollection10.indexOf((java.lang.Comparable) (byte) 1);
        xYSeriesCollection10.setIntervalWidth(4.0d);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection10);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        double double10 = piePlot3D8.getDepthFactor();
        double double11 = piePlot3D8.getMaximumExplodePercent();
        java.awt.Font font12 = piePlot3D8.getLabelFont();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.12d + "'", double10 == 0.12d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer3D0.getLegendItemURLGenerator();
        int int7 = barRenderer3D0.getRowCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 6, (float) 2, (float) (-9999));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        combinedRangeXYPlot5.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedRangeXYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart11.removeProgressListener(chartProgressListener12);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity16 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart11, "", "ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke20 = categoryPlot17.getRangeZeroBaselineStroke();
        jFreeChart11.setBorderStroke(stroke20);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer2.getSeriesOutlineStroke((int) (short) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNull(xYURLGenerator23);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(10);
        periodAxis21.setFirst((org.jfree.data.time.RegularTimePeriod) year23);
        java.awt.Font font25 = periodAxis21.getLabelFont();
        combinedRangeXYPlot18.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis21);
        combinedRangeXYPlot0.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis21, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation29 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener3);
        java.lang.String str5 = xYSeries2.getDescription();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat4, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat2, numberFormat4);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat11, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat9, numberFormat11);
        java.text.NumberFormat numberFormat15 = standardXYToolTipGenerator14.getYFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator16 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!", numberFormat2, numberFormat15);
        java.math.RoundingMode roundingMode17 = null;
        try {
            numberFormat15.setRoundingMode(roundingMode17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberFormat15);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        double double14 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str16 = axisSpace15.toString();
        double double17 = axisSpace15.getRight();
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace15, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean24 = xYLineAndShapeRenderer22.getSeriesVisible(2);
        int int25 = xYLineAndShapeRenderer22.getPassCount();
        org.jfree.chart.LegendItem legendItem28 = xYLineAndShapeRenderer22.getLegendItem((-1), (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot29.setRangeMinorGridlineStroke(stroke30);
        xYLineAndShapeRenderer22.setBaseStroke(stroke30);
        combinedRangeXYPlot0.setRangeCrosshairStroke(stroke30);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke38 = xYAreaRenderer36.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image42 = null;
        combinedRangeXYPlot41.setBackgroundImage(image42);
        java.awt.Stroke stroke44 = combinedRangeXYPlot41.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset46 = combinedRangeXYPlot41.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot47 = combinedRangeXYPlot41.getParent();
        combinedRangeXYPlot41.setDomainCrosshairVisible(true);
        combinedRangeXYPlot41.configureDomainAxes();
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection52 = new org.jfree.data.time.TimeSeriesCollection(timeZone51);
        boolean boolean54 = timeSeriesCollection52.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection52, valueAxis55, polarItemRenderer56);
        polarPlot57.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset60 = polarPlot57.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo61);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState63 = xYAreaRenderer36.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot41, xYDataset60, plotRenderingInfo62);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state64 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = state64.getInfo();
        java.awt.geom.Point2D point2D66 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(0.08d, (double) 500, plotRenderingInfo65, point2D66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNull(legendItem28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(stroke38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(xYDataset46);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(xYDataset60);
        org.junit.Assert.assertNotNull(xYItemRendererState63);
        org.junit.Assert.assertNotNull(plotRenderingInfo65);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, 3.0d, 0.0d, (int) (short) -1, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) dateAxis0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer4.getSeriesVisible(2);
        xYLineAndShapeRenderer4.setBaseShapesFilled(true);
        boolean boolean9 = xYLineAndShapeRenderer4.getAutoPopulateSeriesOutlinePaint();
        boolean boolean10 = xYLineAndShapeRenderer4.getDrawOutlines();
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer4);
        combinedDomainXYPlot1.setGap((double) 1L);
        java.lang.String str14 = combinedDomainXYPlot1.getPlotType();
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined_Domain_XYPlot" + "'", str14.equals("Combined_Domain_XYPlot"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.resizeRange((double) (short) 100);
        int int8 = periodAxis1.getMinorTickCount();
        org.jfree.data.Range range9 = periodAxis1.getRange();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean9 = xYLineAndShapeRenderer8.getAutoPopulateSeriesShape();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer8.setBaseLegendTextFont(font10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("", font10);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) (short) 0, 0.5d, (double) 10, (double) 5, font10);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker16.setStartValue(4.0d);
        markerAxisBand13.addMarker(intervalMarker16);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources1 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = rangeType0.equals((java.lang.Object) jFreeChartResources1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset((int) ' ');
        double double17 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint22 = xYLineAndShapeRenderer20.getLegendTextPaint(0);
        java.lang.Boolean boolean24 = xYLineAndShapeRenderer20.getSeriesCreateEntities(0);
        boolean boolean25 = xYLineAndShapeRenderer20.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean29 = xYLineAndShapeRenderer28.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYLineAndShapeRenderer28.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = xYLineAndShapeRenderer28.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer20.setBasePositiveItemLabelPosition(itemLabelPosition35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image40 = null;
        combinedRangeXYPlot39.setBackgroundImage(image40);
        java.awt.Stroke stroke42 = combinedRangeXYPlot39.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset44 = combinedRangeXYPlot39.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot45 = combinedRangeXYPlot39.getParent();
        combinedRangeXYPlot39.setDomainCrosshairVisible(true);
        combinedRangeXYPlot39.configureDomainAxes();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection50 = new org.jfree.data.time.TimeSeriesCollection(timeZone49);
        boolean boolean52 = timeSeriesCollection50.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer54 = null;
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection50, valueAxis53, polarItemRenderer54);
        org.jfree.data.Range range57 = timeSeriesCollection50.getDomainBounds(true);
        org.jfree.data.xy.XYDataItem xYDataItem60 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem60.setY((double) 100.0f);
        int int63 = timeSeriesCollection50.indexOf((java.lang.Comparable) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState65 = xYLineAndShapeRenderer20.initialise(graphics2D37, rectangle2D38, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot39, (org.jfree.data.xy.XYDataset) timeSeriesCollection50, plotRenderingInfo64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot39.getDomainCrosshairStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke66);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(xYDataset44);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState65);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setSeriesPositiveItemLabelPosition(0, itemLabelPosition4, false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Font font11 = xYAreaRenderer7.getItemLabelFont(2, (int) (byte) 1, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = xYAreaRenderer7.getGradientTransformer();
        xYBarRenderer1.setGradientPaintTransformer(gradientPaintTransformer12);
        java.lang.Object obj14 = null;
        boolean boolean15 = xYBarRenderer1.equals(obj14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers((int) (byte) 100, layer10);
        boolean boolean12 = combinedRangeXYPlot0.isDomainPannable();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) (-11L));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        double double13 = legendTitle9.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle9.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle9.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        combinedRangeXYPlot1.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
        java.awt.geom.GeneralPath generalPath8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.RenderingSource renderingSource10 = null;
        xYPlot0.select(generalPath8, rectangle2D9, renderingSource10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        boolean boolean13 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot4.setRangeMinorGridlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot4.setRangeAxis(valueAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo11, point2D12);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = null;
        barRenderer3D15.setGradientPaintTransformer(gradientPaintTransformer16);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15);
        java.awt.Paint paint19 = barRenderer3D15.getShadowPaint();
        barRenderer3D15.setShadowYOffset((double) 10.0f);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint31 = categoryPlot30.getDomainCrosshairPaint();
        categoryPlot27.setRangeZeroBaselinePaint(paint31);
        xYLineAndShapeRenderer25.setBaseFillPaint(paint31, true);
        java.text.NumberFormat numberFormat36 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat38 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat38, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator41 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat36, numberFormat38);
        xYLineAndShapeRenderer25.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator41);
        java.lang.Object obj43 = standardXYToolTipGenerator41.clone();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType44 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis46 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(10);
        boolean boolean49 = periodAxis46.equals((java.lang.Object) 10);
        boolean boolean50 = dateTickUnitType44.equals((java.lang.Object) periodAxis46);
        java.awt.Shape shape51 = periodAxis46.getUpArrow();
        boolean boolean52 = standardXYToolTipGenerator41.equals((java.lang.Object) shape51);
        barRenderer3D15.setSeriesShape(5, shape51, false);
        java.awt.Paint paint55 = null;
        try {
            org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem("index.html", "", "Combined Range XYPlot", "Range[0.0,1.0]", shape51, paint55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(numberFormat36);
        org.junit.Assert.assertNotNull(numberFormat38);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(dateTickUnitType44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke3 = xYAreaRenderer1.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = combinedRangeXYPlot6.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot12 = combinedRangeXYPlot6.getParent();
        combinedRangeXYPlot6.setDomainCrosshairVisible(true);
        combinedRangeXYPlot6.configureDomainAxes();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis20, polarItemRenderer21);
        polarPlot22.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset25 = polarPlot22.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState28 = xYAreaRenderer1.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, xYDataset25, plotRenderingInfo27);
        int int29 = xYItemRendererState28.getFirstItemIndex();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState30 = null;
        xYItemRendererState28.setCrosshairState(xYCrosshairState30);
        boolean boolean32 = logFormat0.equals((java.lang.Object) xYCrosshairState30);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYDataset25);
        org.junit.Assert.assertNotNull(xYItemRendererState28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        java.lang.String str22 = legendItem20.getToolTipText();
        boolean boolean23 = legendItem20.isShapeVisible();
        legendItem20.setDatasetIndex((int) ' ');
        java.text.AttributedString attributedString26 = legendItem20.getAttributedLabel();
        legendItem20.setLineVisible(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodAnchor.END" + "'", str22.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(attributedString26);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint6 = periodAxis5.getTickMarkPaint();
        java.lang.Class class7 = periodAxis5.getAutoRangeTimePeriodClass();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj9 = null;
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date8, obj9);
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(10);
        boolean boolean16 = periodAxis13.equals((java.lang.Object) 10);
        boolean boolean17 = periodAxis13.isMinorTickMarksVisible();
        java.util.Locale locale18 = periodAxis13.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale18);
        java.text.NumberFormat numberFormat20 = java.text.NumberFormat.getCurrencyInstance(locale18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date8, timeZone11, locale18);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean25 = xYLineAndShapeRenderer24.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = xYLineAndShapeRenderer24.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYLineAndShapeRenderer24.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer24.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image38 = null;
        combinedRangeXYPlot37.setBackgroundImage(image38);
        java.awt.Paint paint40 = combinedRangeXYPlot37.getDomainCrosshairPaint();
        combinedRangeXYPlot37.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder42 = combinedRangeXYPlot37.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot37);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image45 = null;
        combinedRangeXYPlot44.setBackgroundImage(image45);
        java.awt.Stroke stroke47 = combinedRangeXYPlot44.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset49 = combinedRangeXYPlot44.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint55 = xYLineAndShapeRenderer53.getLegendTextPaint(0);
        combinedRangeXYPlot44.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer53);
        java.util.List list57 = combinedRangeXYPlot44.getSubplots();
        combinedRangeXYPlot44.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot62 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint63 = combinedRangeXYPlot62.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis65 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(10);
        periodAxis65.setFirst((org.jfree.data.time.RegularTimePeriod) year67);
        java.awt.Font font69 = periodAxis65.getLabelFont();
        combinedRangeXYPlot62.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis65);
        combinedRangeXYPlot44.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis65, true);
        org.jfree.chart.axis.PeriodAxis periodAxis74 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(10);
        periodAxis74.setFirst((org.jfree.data.time.RegularTimePeriod) year76);
        java.lang.String str78 = periodAxis74.getLabelURL();
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection80 = new org.jfree.data.time.TimeSeriesCollection(timeZone79);
        boolean boolean82 = timeSeriesCollection80.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis83 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer84 = null;
        org.jfree.chart.plot.PolarPlot polarPlot85 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection80, valueAxis83, polarItemRenderer84);
        xYLineAndShapeRenderer24.drawItem(graphics2D34, xYItemRendererState35, rectangle2D36, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot37, (org.jfree.chart.axis.ValueAxis) periodAxis65, (org.jfree.chart.axis.ValueAxis) periodAxis74, (org.jfree.data.xy.XYDataset) timeSeriesCollection80, 0, (int) (short) 100, true, (int) '4');
        java.util.TimeZone timeZone91 = periodAxis74.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone91);
        try {
            org.jfree.data.xy.XYSeries xYSeries93 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, 0.0d, (double) 100L, 9, (java.lang.Comparable) date8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(numberFormat20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(seriesRenderingOrder42);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(xYDataset49);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj2 = null;
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date1, obj2);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(date0, date1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (-11L));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot9.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot9);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle13.arrange(graphics2D14);
        double double16 = size2D15.width;
        size2D15.setWidth((double) (-1));
        org.jfree.chart.util.Size2D size2D19 = rectangleConstraint8.calculateConstrainedSize(size2D15);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(size2D19);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.lang.String str4 = categoryPlot0.getNoDataMessage();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean6 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation((int) (byte) 10);
        categoryPlot0.configureRangeAxes();
        int int12 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        xYLineAndShapeRenderer2.setSeriesShapesFilled(3, (java.lang.Boolean) false);
        xYLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 0, false);
        java.awt.Paint paint17 = xYLineAndShapeRenderer2.getItemOutlinePaint((-9999), (int) 'a', false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.util.Date date3 = month2.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray12);
        categoryPlot0.setDataset(categoryDataset13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset13, true);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset13, false);
        java.util.List list20 = null;
        try {
            org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset13, list20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        barRenderer3D0.setIncludeBaseInRange(true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent8.setType(chartChangeEventType9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint15 = categoryPlot14.getDomainCrosshairPaint();
        categoryPlot11.setRangeZeroBaselinePaint(paint15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot11.getDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot11.getDomainAxis((int) '#');
        boolean boolean20 = chartChangeEventType9.equals((java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean10 = xYLineAndShapeRenderer9.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYLineAndShapeRenderer9.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYLineAndShapeRenderer9.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer9.setBaseCreateEntities(true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = barRenderer3D19.removeAnnotation(categoryAnnotation20);
        java.lang.Object obj22 = barRenderer3D19.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer3D19.setSeriesURLGenerator(0, categoryURLGenerator24);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(10);
        boolean boolean40 = periodAxis37.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint42 = categoryPlot41.getDomainCrosshairPaint();
        periodAxis37.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot41);
        java.awt.Color color44 = java.awt.Color.GREEN;
        categoryPlot41.setRangeZeroBaselinePaint((java.awt.Paint) color44);
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape30, (java.awt.Paint) color44);
        java.awt.Paint paint47 = legendItem46.getFillPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image49 = null;
        combinedRangeXYPlot48.setBackgroundImage(image49);
        java.awt.Paint paint51 = combinedRangeXYPlot48.getDomainCrosshairPaint();
        java.awt.Paint paint52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        combinedRangeXYPlot48.setDomainMinorGridlinePaint(paint52);
        legendItem46.setOutlinePaint(paint52);
        barRenderer3D19.setBaseOutlinePaint(paint52);
        xYLineAndShapeRenderer9.setBaseFillPaint(paint52);
        boolean boolean57 = legendGraphic5.equals((java.lang.Object) xYLineAndShapeRenderer9);
        boolean boolean58 = legendGraphic5.isLineVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeIncludesZero(true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        combinedRangeXYPlot0.configureDomainAxes();
        java.awt.Stroke stroke10 = null;
        combinedRangeXYPlot0.setOutlineStroke(stroke10);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("Range[0.0,1.0]");
        int int12 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.lang.String str13 = dateAxis11.getLabelToolTip();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint20 = categoryPlot19.getDomainCrosshairPaint();
        categoryPlot16.setRangeZeroBaselinePaint(paint20);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getRangeMarkers(0, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getRangeAxisEdge(2);
        try {
            double double27 = dateAxis11.valueToJava2D((double) 11, rectangle2D15, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray12);
        categoryPlot0.setDataset(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset13);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0d + "'", number15.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        java.util.List list6 = categoryPlot0.getCategories();
        org.jfree.chart.StandardChartTheme standardChartTheme8 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint9 = standardChartTheme8.getLabelLinkPaint();
        java.awt.Paint paint10 = standardChartTheme8.getPlotOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        java.lang.String str22 = legendItem20.getToolTipText();
        legendItem20.setShapeVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray30, numberArray33, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray37);
        categoryPlot25.setDataset(categoryDataset38);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot40 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset38);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset38, true);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset38, false);
        boolean boolean45 = legendItem20.equals((java.lang.Object) range44);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodAnchor.END" + "'", str22.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot2.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint13 = xYLineAndShapeRenderer11.getLegendTextPaint(0);
        combinedRangeXYPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer11);
        java.util.List list15 = combinedRangeXYPlot2.getSubplots();
        combinedRangeXYPlot2.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot2.panRangeAxes((double) 6, plotRenderingInfo20, point2D21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        boolean boolean26 = timeSeriesCollection24.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis27, polarItemRenderer28);
        java.awt.Stroke stroke30 = polarPlot29.getRadiusGridlineStroke();
        combinedRangeXYPlot2.setDomainMinorGridlineStroke(stroke30);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 9, stroke30);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate36.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate36);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate36);
        serialDate40.setDescription("");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset43 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme45 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint46 = standardChartTheme45.getLabelLinkPaint();
        java.awt.Paint paint47 = standardChartTheme45.getPlotOutlinePaint();
        java.awt.Paint paint48 = standardChartTheme45.getGridBandAlternatePaint();
        java.awt.Paint paint49 = standardChartTheme45.getSubtitlePaint();
        boolean boolean50 = defaultXYDataset43.equals((java.lang.Object) paint49);
        piePlot3D0.setSectionPaint((java.lang.Comparable) "", paint49);
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(10);
        periodAxis53.setFirst((org.jfree.data.time.RegularTimePeriod) year55);
        java.awt.Font font57 = periodAxis53.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis59 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(10);
        periodAxis59.setFirst((org.jfree.data.time.RegularTimePeriod) year61);
        java.awt.Font font63 = periodAxis59.getLabelFont();
        periodAxis59.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range66 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis59.setRange(range66, false, false);
        periodAxis53.setRange(range66, true, true);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        periodAxis53.setAxisLineStroke(stroke73);
        piePlot3D0.setLabelLinkStroke(stroke73);
        java.awt.Stroke stroke76 = piePlot3D0.getBaseSectionOutlineStroke();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition77 = org.jfree.chart.axis.DateTickMarkPosition.START;
        boolean boolean78 = piePlot3D0.equals((java.lang.Object) dateTickMarkPosition77);
        java.awt.Shape shape79 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot80 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image81 = null;
        combinedRangeXYPlot80.setBackgroundImage(image81);
        java.awt.Paint paint83 = combinedRangeXYPlot80.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity84 = new org.jfree.chart.entity.PlotEntity(shape79, (org.jfree.chart.plot.Plot) combinedRangeXYPlot80);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer87 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle88 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer87);
        org.jfree.chart.entity.TitleEntity titleEntity90 = new org.jfree.chart.entity.TitleEntity(shape79, (org.jfree.chart.title.Title) legendTitle88, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment91 = legendTitle88.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets92 = legendTitle88.getPadding();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets92);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(dateTickMarkPosition77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(horizontalAlignment91);
        org.junit.Assert.assertNotNull(rectangleInsets92);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        combinedRangeXYPlot22.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        java.util.List list35 = combinedRangeXYPlot22.getSubplots();
        combinedRangeXYPlot22.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(10);
        periodAxis43.setFirst((org.jfree.data.time.RegularTimePeriod) year45);
        java.awt.Font font47 = periodAxis43.getLabelFont();
        combinedRangeXYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis43);
        combinedRangeXYPlot22.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis43, true);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        periodAxis52.setFirst((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.String str56 = periodAxis52.getLabelURL();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean60 = timeSeriesCollection58.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, valueAxis61, polarItemRenderer62);
        xYLineAndShapeRenderer2.drawItem(graphics2D12, xYItemRendererState13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.axis.ValueAxis) periodAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, 0, (int) (short) 100, true, (int) '4');
        double double70 = timeSeriesCollection58.getDomainUpperBound(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightInset(1.0E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = combinedRangeXYPlot6.getDataset((int) (short) -1);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getRangeGridlineStroke();
        xYLineAndShapeRenderer2.drawRangeLine(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.chart.axis.ValueAxis) periodAxis13, rectangle2D14, (double) 100, (java.awt.Paint) color16, stroke20);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = combinedRangeXYPlot6.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = combinedRangeXYPlot6.getRangeAxisEdge(2147483647);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        categoryPlot0.clearDomainMarkers(0);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        double[][] doubleArray6 = xYSeries2.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.lang.String str3 = size2D2.toString();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str3.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        java.awt.Paint paint7 = legendGraphic5.getFillPaint();
        java.awt.Stroke stroke8 = legendGraphic5.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendGraphic5.getShapeLocation();
        boolean boolean10 = legendGraphic5.isShapeFilled();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint15 = xYLineAndShapeRenderer13.getLegendTextPaint(0);
        java.lang.Boolean boolean17 = xYLineAndShapeRenderer13.getSeriesCreateEntities(0);
        boolean boolean18 = xYLineAndShapeRenderer13.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYLineAndShapeRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = xYLineAndShapeRenderer21.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer13.setBasePositiveItemLabelPosition(itemLabelPosition28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image33 = null;
        combinedRangeXYPlot32.setBackgroundImage(image33);
        java.awt.Stroke stroke35 = combinedRangeXYPlot32.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset37 = combinedRangeXYPlot32.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot38 = combinedRangeXYPlot32.getParent();
        combinedRangeXYPlot32.setDomainCrosshairVisible(true);
        combinedRangeXYPlot32.configureDomainAxes();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection43 = new org.jfree.data.time.TimeSeriesCollection(timeZone42);
        boolean boolean45 = timeSeriesCollection43.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer47 = null;
        org.jfree.chart.plot.PolarPlot polarPlot48 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection43, valueAxis46, polarItemRenderer47);
        org.jfree.data.Range range50 = timeSeriesCollection43.getDomainBounds(true);
        org.jfree.data.xy.XYDataItem xYDataItem53 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem53.setY((double) 100.0f);
        int int56 = timeSeriesCollection43.indexOf((java.lang.Comparable) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState58 = xYLineAndShapeRenderer13.initialise(graphics2D30, rectangle2D31, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot32, (org.jfree.data.xy.XYDataset) timeSeriesCollection43, plotRenderingInfo57);
        java.awt.Stroke stroke59 = combinedRangeXYPlot32.getDomainCrosshairStroke();
        legendGraphic5.setLineStroke(stroke59);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState58);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke4 = categoryPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getMargin();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke4, rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder11.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = dateTickUnit5.getRollUnitType();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) dateTickUnit5, 1.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot9.setRangeMinorGridlineStroke(stroke10);
        double double12 = categoryPlot9.getRangeCrosshairValue();
        categoryPlot9.setRangePannable(true);
        double double15 = categoryPlot9.getAnchorValue();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image17 = null;
        combinedRangeXYPlot16.setBackgroundImage(image17);
        java.awt.Stroke stroke19 = combinedRangeXYPlot16.getRangeGridlineStroke();
        categoryPlot9.setRangeGridlineStroke(stroke19);
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot9.getColumnRenderingOrder();
        defaultPieDataset0.sortByValues(sortOrder21);
        java.lang.Number number24 = defaultPieDataset0.getValue(0);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 2.0d + "'", number24.equals(2.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        double double10 = piePlot3D8.getDepthFactor();
        int int11 = piePlot3D8.getPieIndex();
        java.lang.String str12 = piePlot3D8.getPlotType();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.12d + "'", double10 == 0.12d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie 3D Plot" + "'", str12.equals("Pie 3D Plot"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot9.removeDomainMarker(marker10, layer11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image14 = null;
        combinedRangeXYPlot13.setBackgroundImage(image14);
        java.awt.Paint paint16 = combinedRangeXYPlot13.getDomainCrosshairPaint();
        combinedRangeXYPlot13.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        combinedRangeXYPlot13.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = combinedRangeXYPlot13.getDomainMarkers(layer23);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker28.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer31 = null;
        combinedRangeXYPlot13.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker28, layer31, false);
        double double34 = intervalMarker28.getStartValue();
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = categoryPlot9.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker28, layer35);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        combinedRangeXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker28, layer37);
        org.jfree.chart.text.TextAnchor textAnchor39 = intervalMarker28.getLabelTextAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker28);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNotNull(textAnchor39);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = dateTickUnit5.getRollUnitType();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) dateTickUnit5, 1.0d);
        java.lang.Object obj9 = null;
        boolean boolean10 = dateTickUnit5.equals(obj9);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj13 = null;
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date12, obj13);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(date11, date12);
        java.util.Date date16 = dateTickUnit5.rollDate(date11);
        int int17 = dateTickUnit5.getRollMultiple();
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint19 = xYLineAndShapeRenderer17.getLegendTextPaint(0);
        java.lang.Boolean boolean21 = xYLineAndShapeRenderer17.getSeriesCreateEntities(0);
        boolean boolean22 = xYLineAndShapeRenderer17.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = xYLineAndShapeRenderer25.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = xYLineAndShapeRenderer25.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer17.setBasePositiveItemLabelPosition(itemLabelPosition32);
        barRenderer3D11.setPositiveItemLabelPositionFallback(itemLabelPosition32);
        int int35 = barRenderer3D11.getPassCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        org.jfree.chart.StandardChartTheme standardChartTheme4 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint5 = standardChartTheme4.getLabelLinkPaint();
        java.awt.Paint paint6 = standardChartTheme4.getPlotOutlinePaint();
        java.awt.Paint paint7 = standardChartTheme4.getGridBandAlternatePaint();
        java.awt.Paint paint8 = standardChartTheme4.getSubtitlePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter9 = standardChartTheme4.getBarPainter();
        boolean boolean10 = multiplePiePlot1.equals((java.lang.Object) standardChartTheme4);
        java.lang.String str11 = standardChartTheme4.getName();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image13 = null;
        combinedRangeXYPlot12.setBackgroundImage(image13);
        java.awt.Paint paint15 = combinedRangeXYPlot12.getDomainCrosshairPaint();
        combinedRangeXYPlot12.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = combinedRangeXYPlot12.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.awt.Paint paint19 = jFreeChart18.getBackgroundPaint();
        java.lang.Object obj20 = jFreeChart18.getTextAntiAlias();
        java.awt.RenderingHints renderingHints21 = jFreeChart18.getRenderingHints();
        jFreeChart18.fireChartChanged();
        int int23 = jFreeChart18.getBackgroundImageAlignment();
        jFreeChart18.clearSubtitles();
        java.util.List list25 = jFreeChart18.getSubtitles();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = jFreeChart18.getPadding();
        standardChartTheme4.setAxisOffset(rectangleInsets26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets26.createInsetRectangle(rectangle2D28, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(barPainter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodAnchor.END" + "'", str11.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        double double3 = periodAxis1.getAutoRangeMinimumSize();
        java.lang.Object obj4 = periodAxis1.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        int int8 = legendItemCollection7.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem10 = legendItemCollection7.get((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        double double10 = piePlot3D8.getDepthFactor();
        double double11 = piePlot3D8.getMaximumExplodePercent();
        java.awt.Color color12 = java.awt.Color.GRAY;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke16 = categoryPlot13.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot17);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle21.getMargin();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color12, stroke16, rectangleInsets22);
        double double25 = rectangleInsets22.calculateTopInset((double) '4');
        piePlot3D8.setSimpleLabelOffset(rectangleInsets22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.awt.Font font33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("", font33);
        org.jfree.chart.text.TextFragment textFragment35 = textLine34.getFirstTextFragment();
        java.lang.String str36 = textFragment35.getText();
        java.awt.Paint paint37 = textFragment35.getPaint();
        piePlot3D8.setSectionPaint((java.lang.Comparable) spreadsheetDate28, paint37);
        try {
            org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate28.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.12d + "'", double10 == 0.12d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(textFragment35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        combinedRangeXYPlot1.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        java.awt.Paint paint8 = jFreeChart7.getBackgroundPaint();
        java.lang.Object obj9 = null;
        boolean boolean10 = jFreeChart7.equals(obj9);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart7.getTitle();
        jFreeChart7.setAntiAlias(true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer17);
        jFreeChart7.addSubtitle((int) (short) 1, (org.jfree.chart.title.Title) legendTitle18);
        double double20 = legendTitle18.getHeight();
        try {
            org.jfree.chart.entity.TitleEntity titleEntity22 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle18, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(textTitle11);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        java.awt.geom.Line2D line2D24 = xYItemRendererState23.workingLine;
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) line2D24);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            boolean boolean27 = org.jfree.chart.util.LineUtilities.clipLine(line2D24, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNotNull(line2D24);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("Range[0.0,1.0]");
        int int12 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.lang.String str13 = dateAxis11.getLabelToolTip();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType15 = dateTickUnit14.getRollUnitType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(dateTickUnitType15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker15.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer18 = null;
        combinedRangeXYPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker15, layer18, false);
        double double21 = intervalMarker15.getStartValue();
        double double22 = intervalMarker15.getEndValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = intervalMarker15.getLabelOffsetType();
        java.lang.String str24 = lengthAdjustmentType23.toString();
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean26 = piePlot3D25.getSimpleLabels();
        boolean boolean27 = lengthAdjustmentType23.equals((java.lang.Object) boolean26);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-11.0d) + "'", double22 == (-11.0d));
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "CONTRACT" + "'", str24.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot2.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint13 = xYLineAndShapeRenderer11.getLegendTextPaint(0);
        combinedRangeXYPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer11);
        java.util.List list15 = combinedRangeXYPlot2.getSubplots();
        combinedRangeXYPlot2.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot2.panRangeAxes((double) 6, plotRenderingInfo20, point2D21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        boolean boolean26 = timeSeriesCollection24.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis27, polarItemRenderer28);
        java.awt.Stroke stroke30 = polarPlot29.getRadiusGridlineStroke();
        combinedRangeXYPlot2.setDomainMinorGridlineStroke(stroke30);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 9, stroke30);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate36.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate36);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate36);
        serialDate40.setDescription("");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset43 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme45 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint46 = standardChartTheme45.getLabelLinkPaint();
        java.awt.Paint paint47 = standardChartTheme45.getPlotOutlinePaint();
        java.awt.Paint paint48 = standardChartTheme45.getGridBandAlternatePaint();
        java.awt.Paint paint49 = standardChartTheme45.getSubtitlePaint();
        boolean boolean50 = defaultXYDataset43.equals((java.lang.Object) paint49);
        piePlot3D0.setSectionPaint((java.lang.Comparable) "", paint49);
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(10);
        periodAxis53.setFirst((org.jfree.data.time.RegularTimePeriod) year55);
        java.awt.Font font57 = periodAxis53.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis59 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(10);
        periodAxis59.setFirst((org.jfree.data.time.RegularTimePeriod) year61);
        java.awt.Font font63 = periodAxis59.getLabelFont();
        periodAxis59.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range66 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis59.setRange(range66, false, false);
        periodAxis53.setRange(range66, true, true);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        periodAxis53.setAxisLineStroke(stroke73);
        piePlot3D0.setLabelLinkStroke(stroke73);
        java.awt.Stroke stroke76 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setCircular(false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(0, layer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getRangeAxisEdge(2);
        int int11 = categoryPlot0.getRendererCount();
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 1, (int) (byte) 100);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset9 = polarPlot6.getDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate10 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset9);
        double double11 = intervalXYDelegate10.getFixedIntervalWidth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(10);
        boolean boolean8 = periodAxis5.equals((java.lang.Object) 10);
        periodAxis5.setAxisLineVisible(false);
        java.awt.Font font11 = periodAxis5.getLabelFont();
        boolean boolean12 = textBlock0.equals((java.lang.Object) periodAxis5);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        piePlot3D8.clearSectionOutlineStrokes(false);
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint13 = standardChartTheme12.getLabelLinkPaint();
        java.awt.Paint paint14 = standardChartTheme12.getPlotOutlinePaint();
        java.awt.Paint paint15 = standardChartTheme12.getGridBandAlternatePaint();
        java.awt.Paint paint16 = standardChartTheme12.getBaselinePaint();
        java.awt.Paint paint17 = standardChartTheme12.getAxisLabelPaint();
        piePlot3D8.setLabelShadowPaint(paint17);
        piePlot3D8.setAutoPopulateSectionOutlinePaint(true);
        java.awt.Paint paint21 = piePlot3D8.getBaseSectionPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image24 = null;
        combinedRangeXYPlot23.setBackgroundImage(image24);
        java.awt.Stroke stroke26 = combinedRangeXYPlot23.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset28 = combinedRangeXYPlot23.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint34 = xYLineAndShapeRenderer32.getLegendTextPaint(0);
        combinedRangeXYPlot23.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer32);
        java.util.List list36 = combinedRangeXYPlot23.getSubplots();
        double double37 = combinedRangeXYPlot23.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace38 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str39 = axisSpace38.toString();
        double double40 = axisSpace38.getRight();
        combinedRangeXYPlot23.setFixedDomainAxisSpace(axisSpace38, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean47 = xYLineAndShapeRenderer45.getSeriesVisible(2);
        int int48 = xYLineAndShapeRenderer45.getPassCount();
        org.jfree.chart.LegendItem legendItem51 = xYLineAndShapeRenderer45.getLegendItem((-1), (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke53 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot52.setRangeMinorGridlineStroke(stroke53);
        xYLineAndShapeRenderer45.setBaseStroke(stroke53);
        combinedRangeXYPlot23.setRangeCrosshairStroke(stroke53);
        piePlot3D8.setSectionOutlineStroke((java.lang.Comparable) "CONTRACT", stroke53);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertNull(legendItem51);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke4 = categoryPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getMargin();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke4, rectangleInsets10);
        java.awt.Stroke stroke12 = lineBorder11.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = lineBorder11.getInsets();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            lineBorder11.draw(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart6.removeProgressListener(chartProgressListener7);
        boolean boolean9 = jFreeChart6.isNotify();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType10 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(10);
        boolean boolean15 = periodAxis12.equals((java.lang.Object) 10);
        boolean boolean16 = dateTickUnitType10.equals((java.lang.Object) periodAxis12);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.util.List list21 = periodAxis12.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        jFreeChart6.setSubtitles(list21);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTickUnitType10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        boolean boolean9 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.data.Range range8 = timeSeriesCollection1.getDomainBounds(true);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis1.getMarkerBand();
        numberAxis1.configure();
        org.junit.Assert.assertNull(markerAxisBand2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        piePlot3D8.clearSectionOutlineStrokes(false);
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint13 = standardChartTheme12.getLabelLinkPaint();
        java.awt.Paint paint14 = standardChartTheme12.getPlotOutlinePaint();
        java.awt.Paint paint15 = standardChartTheme12.getGridBandAlternatePaint();
        java.awt.Paint paint16 = standardChartTheme12.getBaselinePaint();
        java.awt.Paint paint17 = standardChartTheme12.getAxisLabelPaint();
        piePlot3D8.setLabelShadowPaint(paint17);
        piePlot3D8.setAutoPopulateSectionOutlinePaint(true);
        java.lang.Object obj21 = piePlot3D8.clone();
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("Range[0.0,1.0]");
        int int12 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.lang.String str13 = dateAxis11.getLabelToolTip();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj16 = null;
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date15, obj16);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(10);
        boolean boolean23 = periodAxis20.equals((java.lang.Object) 10);
        boolean boolean24 = periodAxis20.isMinorTickMarksVisible();
        java.util.Locale locale25 = periodAxis20.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource26 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale25);
        java.text.NumberFormat numberFormat27 = java.text.NumberFormat.getCurrencyInstance(locale25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date15, timeZone18, locale25);
        org.jfree.data.DomainOrder domainOrder29 = org.jfree.data.DomainOrder.NONE;
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.util.Date date33 = month32.getEnd();
        boolean boolean34 = domainOrder29.equals((java.lang.Object) month32);
        java.util.Date date35 = month32.getEnd();
        org.jfree.data.time.Year year36 = month32.getYear();
        java.util.Date date37 = month32.getEnd();
        try {
            dateAxis11.setRange(date15, date37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(tickUnitSource26);
        org.junit.Assert.assertNotNull(numberFormat27);
        org.junit.Assert.assertNotNull(domainOrder29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getSeriesItemLabelPaint(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot5.getDataset((int) (short) -1);
        boolean boolean11 = combinedRangeXYPlot5.isDomainCrosshairVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image13 = null;
        combinedRangeXYPlot12.setBackgroundImage(image13);
        java.awt.Stroke stroke15 = combinedRangeXYPlot12.getRangeGridlineStroke();
        combinedRangeXYPlot5.setDomainMinorGridlineStroke(stroke15);
        xYLineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot5);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYAreaRenderer0.getBaseNegativeItemLabelPosition();
        boolean boolean25 = xYAreaRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke3 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image5 = null;
        combinedRangeXYPlot4.setBackgroundImage(image5);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        combinedRangeXYPlot4.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = combinedRangeXYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = combinedRangeXYPlot4.getRangeAxisIndex(valueAxis11);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot4);
        java.lang.Comparable comparable14 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot0.getRenderer();
        java.lang.String str16 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(comparable14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker15.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer18 = null;
        combinedRangeXYPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker15, layer18, false);
        double double21 = intervalMarker15.getStartValue();
        double double22 = intervalMarker15.getEndValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker15);
        java.awt.Paint paint24 = intervalMarker15.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-11.0d) + "'", double22 == (-11.0d));
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1, false);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendGraphic5.getFillPaintTransformer();
        java.awt.Paint paint7 = legendGraphic5.getFillPaint();
        java.awt.Stroke stroke8 = legendGraphic5.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendGraphic5.getShapeLocation();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (-11L), range12);
        java.lang.String str14 = rectangleConstraint13.toString();
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint13.toRangeWidth(range15);
        try {
            org.jfree.chart.util.Size2D size2D17 = legendGraphic5.arrange(graphics2D10, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=-11.0, height=0.0]" + "'", str14.equals("RectangleConstraint[LengthConstraintType.FIXED: width=-11.0, height=0.0]"));
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.awt.Font font5 = periodAxis1.getLabelFont();
        periodAxis1.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis1.setRange(range8, false, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image13 = null;
        combinedRangeXYPlot12.setBackgroundImage(image13);
        java.awt.Stroke stroke15 = combinedRangeXYPlot12.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = combinedRangeXYPlot12.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot18 = combinedRangeXYPlot12.getParent();
        combinedRangeXYPlot12.setDomainCrosshairVisible(true);
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Paint paint25 = combinedRangeXYPlot22.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity26 = new org.jfree.chart.entity.PlotEntity(shape21, (org.jfree.chart.plot.Plot) combinedRangeXYPlot22);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer29);
        org.jfree.chart.entity.TitleEntity titleEntity32 = new org.jfree.chart.entity.TitleEntity(shape21, (org.jfree.chart.title.Title) legendTitle30, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = legendTitle30.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle30.getItemLabelPadding();
        combinedRangeXYPlot12.setInsets(rectangleInsets34);
        double double37 = rectangleInsets34.calculateBottomInset((double) (byte) 10);
        double double39 = rectangleInsets34.calculateTopInset((double) 'a');
        periodAxis1.setLabelInsets(rectangleInsets34);
        double double41 = periodAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-5.76E7d) + "'", double41 == (-5.76E7d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 100L, "", "PieLabelLinkStyle.QUAD_CURVE", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, (java.text.NumberFormat) logFormat6);
        java.text.NumberFormat numberFormat8 = logFormat6.getExponentFormat();
        java.lang.Object obj9 = logFormat6.clone();
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        combinedRangeXYPlot7.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke22 = combinedRangeXYPlot7.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        boolean boolean7 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYLineAndShapeRenderer10.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYLineAndShapeRenderer10.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image22 = null;
        combinedRangeXYPlot21.setBackgroundImage(image22);
        java.awt.Stroke stroke24 = combinedRangeXYPlot21.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset26 = combinedRangeXYPlot21.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot27 = combinedRangeXYPlot21.getParent();
        combinedRangeXYPlot21.setDomainCrosshairVisible(true);
        combinedRangeXYPlot21.configureDomainAxes();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeZone31);
        boolean boolean34 = timeSeriesCollection32.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection32, valueAxis35, polarItemRenderer36);
        org.jfree.data.Range range39 = timeSeriesCollection32.getDomainBounds(true);
        org.jfree.data.xy.XYDataItem xYDataItem42 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem42.setY((double) 100.0f);
        int int45 = timeSeriesCollection32.indexOf((java.lang.Comparable) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState47 = xYLineAndShapeRenderer2.initialise(graphics2D19, rectangle2D20, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot21, (org.jfree.data.xy.XYDataset) timeSeriesCollection32, plotRenderingInfo46);
        int int48 = xYItemRendererState47.getLastItemIndex();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection1.getSeries((java.lang.Comparable) 1);
        double double6 = timeSeriesCollection1.getDomainUpperBound(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(timeSeries4);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        boolean boolean8 = polarPlot6.isAngleLabelsVisible();
        polarPlot6.setRadiusGridlinesVisible(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = polarPlot6.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(polarItemRenderer11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer2.getSeriesOutlineStroke((int) (short) 100);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYLineAndShapeRenderer2.setLegendLine(shape22);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = polarPlot6.getLegendItems();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image14 = null;
        combinedRangeXYPlot13.setBackgroundImage(image14);
        java.awt.Paint paint16 = combinedRangeXYPlot13.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(10);
        boolean boolean22 = periodAxis19.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint24 = categoryPlot23.getDomainCrosshairPaint();
        periodAxis19.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.Color color26 = java.awt.Color.GREEN;
        categoryPlot23.setRangeZeroBaselinePaint((java.awt.Paint) color26);
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape12, (java.awt.Paint) color26);
        java.awt.Paint paint29 = legendItem28.getFillPaint();
        java.lang.String str30 = legendItem28.getToolTipText();
        int int31 = legendItem28.getDatasetIndex();
        org.jfree.data.general.Dataset dataset32 = legendItem28.getDataset();
        legendItemCollection7.add(legendItem28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TimePeriodAnchor.END" + "'", str30.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(dataset32);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint3 = standardChartTheme2.getLabelLinkPaint();
        java.awt.Paint paint4 = standardChartTheme2.getPlotOutlinePaint();
        java.awt.Paint paint5 = standardChartTheme2.getGridBandAlternatePaint();
        java.awt.Paint paint6 = standardChartTheme2.getSubtitlePaint();
        boolean boolean7 = defaultXYDataset0.equals((java.lang.Object) paint6);
        try {
            double double10 = defaultXYDataset0.getYValue((int) (short) 0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle9.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle9.setLegendItemGraphicEdge(rectangleEdge14);
        boolean boolean16 = legendTitle9.isVisible();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            legendTitle9.draw(graphics2D17, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long4 = month3.getSerialIndex();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState5 = new org.jfree.chart.plot.XYCrosshairState();
        int int6 = month3.compareTo((java.lang.Object) xYCrosshairState5);
        int int7 = month3.getYearValue();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(10);
        boolean boolean12 = periodAxis9.equals((java.lang.Object) 10);
        boolean boolean13 = periodAxis9.isMinorTickMarksVisible();
        java.util.Locale locale14 = periodAxis9.getLocale();
        java.text.NumberFormat numberFormat15 = java.text.NumberFormat.getPercentInstance(locale14);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale14);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale14);
        int int18 = month3.compareTo((java.lang.Object) locale14);
        try {
            java.util.ResourceBundle resourceBundle19 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale14);
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-11L) + "'", long4 == (-11L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertNotNull(numberFormat15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        piePlot3D8.setDarkerSides(true);
        org.jfree.data.general.PieDataset pieDataset12 = piePlot3D8.getDataset();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(pieDataset12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint5 = xYLineAndShapeRenderer3.getLegendTextPaint(0);
        java.lang.Boolean boolean7 = xYLineAndShapeRenderer3.getSeriesCreateEntities(0);
        boolean boolean8 = xYLineAndShapeRenderer3.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean12 = xYLineAndShapeRenderer11.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYLineAndShapeRenderer11.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYLineAndShapeRenderer11.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition18);
        boolean boolean20 = chartChangeEventType0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, 0);
        java.lang.String str4 = numberTickUnit3.toString();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[size=0]" + "'", str4.equals("[size=0]"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean28 = xYLineAndShapeRenderer26.getSeriesVisible(2);
        int int29 = xYLineAndShapeRenderer26.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint32 = periodAxis31.getTickMarkPaint();
        xYLineAndShapeRenderer26.setBaseFillPaint(paint32, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean39 = xYLineAndShapeRenderer38.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = xYLineAndShapeRenderer38.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYLineAndShapeRenderer26.setSeriesNegativeItemLabelPosition(0, itemLabelPosition41);
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition41, false);
        boolean boolean45 = xYAreaRenderer0.getPlotShapes();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("-3,-3,3,3", "PlotEntity: tooltip = null", "PlotEntity: tooltip = null", "TimePeriodAnchor.END");
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        legendTitle9.setVisible(true);
        legendTitle9.setHeight(0.0d);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer7);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getDomainCrosshairPaint();
        xYLineAndShapeRenderer7.setSeriesOutlinePaint((int) 'a', paint11);
        xYLineAndShapeRenderer2.setSeriesFillPaint((int) '#', paint11);
        xYLineAndShapeRenderer2.setUseFillPaint(true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot20);
        boolean boolean22 = combinedRangeXYPlot17.isDomainPannable();
        double double23 = combinedRangeXYPlot17.getGap();
        org.jfree.data.xy.XYDataset xYDataset24 = combinedRangeXYPlot17.getDataset();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection(timeZone25);
        boolean boolean28 = timeSeriesCollection26.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection26, valueAxis29, polarItemRenderer30);
        org.jfree.chart.axis.PeriodAxis periodAxis33 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint34 = periodAxis33.getTickMarkPaint();
        periodAxis33.setInverted(true);
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(10);
        boolean boolean41 = periodAxis38.equals((java.lang.Object) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer44 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean45 = xYLineAndShapeRenderer44.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer44.setAutoPopulateSeriesPaint(false);
        java.awt.Color color48 = java.awt.Color.gray;
        int int49 = color48.getTransparency();
        xYLineAndShapeRenderer44.setBaseItemLabelPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection26, (org.jfree.chart.axis.ValueAxis) periodAxis33, (org.jfree.chart.axis.ValueAxis) periodAxis38, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer44);
        periodAxis38.setLabel("Combined Range XYPlot");
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace57 = color56.getColorSpace();
        java.awt.Color color58 = color56.darker();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer61 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint63 = xYLineAndShapeRenderer61.getLegendTextPaint(0);
        java.lang.Boolean boolean65 = xYLineAndShapeRenderer61.getSeriesCreateEntities(0);
        java.awt.Stroke stroke66 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer61.setBaseStroke(stroke66, false);
        try {
            xYLineAndShapeRenderer2.drawDomainLine(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis38, rectangle2D54, (double) (byte) 10, (java.awt.Paint) color56, stroke66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 5.0d + "'", double23 == 5.0d);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(colorSpace57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertNull(boolean65);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        java.lang.Object obj2 = xYSeriesCollection1.clone();
        java.lang.Object obj3 = xYSeriesCollection1.clone();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("MINOR", font5, paint6);
        java.awt.Font font9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer12.getSeriesVisible(2);
        int int15 = xYLineAndShapeRenderer12.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint18 = periodAxis17.getTickMarkPaint();
        xYLineAndShapeRenderer12.setBaseFillPaint(paint18, false);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("Combined Range XYPlot", font9, paint18);
        org.jfree.chart.text.TextMeasurer textMeasurer23 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("ERROR : Relative To String", font5, paint18, (float) (-2), textMeasurer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        categoryPlot0.clearDomainMarkers();
        java.util.List list3 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        int int5 = categoryPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        double double3 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.setRangePannable(true);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(categoryAxis8);
        categoryAxis8.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        double double10 = piePlot3D8.getDepthFactor();
        double double11 = piePlot3D8.getMaximumExplodePercent();
        java.awt.Color color12 = java.awt.Color.GRAY;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke16 = categoryPlot13.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot17);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle21.getMargin();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color12, stroke16, rectangleInsets22);
        double double25 = rectangleInsets22.calculateTopInset((double) '4');
        piePlot3D8.setSimpleLabelOffset(rectangleInsets22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.awt.Font font33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("", font33);
        org.jfree.chart.text.TextFragment textFragment35 = textLine34.getFirstTextFragment();
        java.lang.String str36 = textFragment35.getText();
        java.awt.Paint paint37 = textFragment35.getPaint();
        piePlot3D8.setSectionPaint((java.lang.Comparable) spreadsheetDate28, paint37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int44 = spreadsheetDate42.getYYYY();
        int int45 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.12d + "'", double10 == 0.12d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(textFragment35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat2, 0);
        try {
            org.jfree.chart.axis.TickUnit tickUnit5 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset9 = polarPlot6.getDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate10 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset9);
        intervalXYDelegate10.setFixedIntervalWidth(0.0d);
        java.lang.Object obj13 = intervalXYDelegate10.clone();
        java.lang.Object obj14 = intervalXYDelegate10.clone();
        intervalXYDelegate10.setIntervalPositionFactor(0.12d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot5.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot11 = combinedRangeXYPlot5.getParent();
        combinedRangeXYPlot5.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = combinedRangeXYPlot5.getDomainMarkers((int) (byte) 100, layer15);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        boolean boolean22 = periodAxis18.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getDomainCrosshairPaint();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot25.setRangeZeroBaselinePaint(paint27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.drawDomainLine(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.chart.axis.ValueAxis) periodAxis18, rectangle2D23, (double) (byte) 1, paint27, stroke29);
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(10);
        periodAxis32.setFirst((org.jfree.data.time.RegularTimePeriod) year34);
        java.awt.Font font36 = periodAxis32.getLabelFont();
        org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(10);
        periodAxis38.setFirst((org.jfree.data.time.RegularTimePeriod) year40);
        java.awt.Font font42 = periodAxis38.getLabelFont();
        periodAxis38.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range45 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis38.setRange(range45, false, false);
        periodAxis32.setRange(range45, true, true);
        periodAxis18.setRangeWithMargins(range45, true, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        piePlot3D8.clearSectionOutlineStrokes(false);
        org.jfree.chart.StandardChartTheme standardChartTheme12 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint13 = standardChartTheme12.getLabelLinkPaint();
        java.awt.Paint paint14 = standardChartTheme12.getPlotOutlinePaint();
        java.awt.Paint paint15 = standardChartTheme12.getGridBandAlternatePaint();
        java.awt.Paint paint16 = standardChartTheme12.getBaselinePaint();
        java.awt.Paint paint17 = standardChartTheme12.getAxisLabelPaint();
        piePlot3D8.setLabelShadowPaint(paint17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 3.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Paint paint25 = combinedRangeXYPlot22.getDomainCrosshairPaint();
        combinedRangeXYPlot22.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        combinedRangeXYPlot22.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = combinedRangeXYPlot22.getDomainMarkers(layer32);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker37.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer40 = null;
        combinedRangeXYPlot22.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker37, layer40, false);
        combinedRangeXYPlot22.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image46 = null;
        combinedRangeXYPlot45.setBackgroundImage(image46);
        java.awt.Paint paint48 = combinedRangeXYPlot45.getDomainCrosshairPaint();
        combinedRangeXYPlot45.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder50 = combinedRangeXYPlot45.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot45);
        java.awt.Paint paint52 = jFreeChart51.getBackgroundPaint();
        java.lang.Object obj53 = null;
        boolean boolean54 = jFreeChart51.equals(obj53);
        org.jfree.chart.title.TextTitle textTitle55 = jFreeChart51.getTitle();
        java.awt.Stroke stroke56 = jFreeChart51.getBorderStroke();
        combinedRangeXYPlot22.setDomainCrosshairStroke(stroke56);
        int int58 = timeSeriesDataItem21.compareTo((java.lang.Object) combinedRangeXYPlot22);
        java.lang.Object obj59 = null;
        boolean boolean60 = timeSeriesDataItem21.equals(obj59);
        double double61 = piePlot3D8.getExplodePercent((java.lang.Comparable) timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(textTitle55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        boolean boolean5 = periodAxis1.isMinorTickMarksVisible();
        java.util.Locale locale6 = periodAxis1.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale6);
        java.text.NumberFormat numberFormat8 = java.text.NumberFormat.getCurrencyInstance(locale6);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale6);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getPercentInstance(locale6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Paint paint15 = barRenderer3D11.getShadowPaint();
        barRenderer3D11.setShadowYOffset((double) 10.0f);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint27 = categoryPlot26.getDomainCrosshairPaint();
        categoryPlot23.setRangeZeroBaselinePaint(paint27);
        xYLineAndShapeRenderer21.setBaseFillPaint(paint27, true);
        java.text.NumberFormat numberFormat32 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat34 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat34, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator37 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat32, numberFormat34);
        xYLineAndShapeRenderer21.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator37);
        java.lang.Object obj39 = standardXYToolTipGenerator37.clone();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType40 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis42 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(10);
        boolean boolean45 = periodAxis42.equals((java.lang.Object) 10);
        boolean boolean46 = dateTickUnitType40.equals((java.lang.Object) periodAxis42);
        java.awt.Shape shape47 = periodAxis42.getUpArrow();
        boolean boolean48 = standardXYToolTipGenerator37.equals((java.lang.Object) shape47);
        barRenderer3D11.setSeriesShape(5, shape47, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint55 = xYLineAndShapeRenderer53.getLegendTextPaint(0);
        java.lang.Boolean boolean57 = xYLineAndShapeRenderer53.getSeriesCreateEntities(0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer60 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean62 = xYLineAndShapeRenderer60.getSeriesVisible(2);
        int int63 = xYLineAndShapeRenderer60.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis65 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint66 = periodAxis65.getTickMarkPaint();
        xYLineAndShapeRenderer60.setBaseFillPaint(paint66, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer72 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean73 = xYLineAndShapeRenderer72.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition75 = xYLineAndShapeRenderer72.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYLineAndShapeRenderer60.setSeriesNegativeItemLabelPosition(0, itemLabelPosition75);
        java.awt.Shape shape80 = xYLineAndShapeRenderer60.getItemShape(2, (-1), true);
        xYLineAndShapeRenderer53.setLegendLine(shape80);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot82 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image83 = null;
        combinedRangeXYPlot82.setBackgroundImage(image83);
        java.awt.Paint paint85 = combinedRangeXYPlot82.getDomainCrosshairPaint();
        combinedRangeXYPlot82.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder87 = combinedRangeXYPlot82.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart88 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot82);
        java.awt.Paint paint89 = jFreeChart88.getBackgroundPaint();
        java.lang.Object obj90 = jFreeChart88.getTextAntiAlias();
        java.awt.RenderingHints renderingHints91 = jFreeChart88.getRenderingHints();
        jFreeChart88.fireChartChanged();
        int int93 = jFreeChart88.getBackgroundImageAlignment();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity95 = new org.jfree.chart.entity.JFreeChartEntity(shape80, jFreeChart88, "hi!");
        org.jfree.chart.JFreeChart jFreeChart96 = jFreeChartEntity95.getChart();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity99 = new org.jfree.chart.entity.JFreeChartEntity(shape47, jFreeChart96, "RectangleInsets[t=1.0,l=32.0,b=35.0,r=0.0]", "JFreeChartEntity: tooltip = hi!");
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(numberFormat32);
        org.junit.Assert.assertNotNull(numberFormat34);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(dateTickUnitType40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertNull(boolean57);
        org.junit.Assert.assertNull(boolean62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition75);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(seriesRenderingOrder87);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNull(obj90);
        org.junit.Assert.assertNotNull(renderingHints91);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 15 + "'", int93 == 15);
        org.junit.Assert.assertNotNull(jFreeChart96);
    }
}

