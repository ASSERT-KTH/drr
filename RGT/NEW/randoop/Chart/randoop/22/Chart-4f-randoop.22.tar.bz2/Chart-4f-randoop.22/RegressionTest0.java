import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity2 = new org.jfree.chart.entity.PlotEntity(shape0, plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', (int) 'a', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        java.util.List list2 = null;
        try {
            org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = null;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) '#', dateTickUnitType2, (int) (short) -1, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.gray;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Color color7 = java.awt.Color.gray;
        int int8 = color7.getTransparency();
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "series", "hi!", "hi!", shape4, (java.awt.Paint) color5, stroke6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity4 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, 1.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "series", "series");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            polarPlot6.drawOutline(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer4 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, (java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.Axis axis0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity4 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape1, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean4 = pieLabelLinkStyle0.equals((java.lang.Object) range3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker2 = null;
        org.jfree.chart.util.Layer layer3 = null;
        try {
            categoryPlot0.addRangeMarker(10, marker2, layer3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            categoryPlot0.setAxisOffset(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            categoryPlot0.setAxisOffset(rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.data.Range range8 = timeSeriesCollection1.getDomainBounds(true);
        try {
            java.lang.Number number11 = timeSeriesCollection1.getEndY(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            double double4 = timeSeriesCollection1.getYValue(0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = null;
        try {
            xYLineAndShapeRenderer2.setLegendItemLabelGenerator(xYSeriesLabelGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (byte) -1, plotRenderingInfo4, point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        try {
            combinedRangeXYPlot0.rendererChanged(rendererChangeEvent5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint2 = null;
        try {
            combinedRangeXYPlot0.setQuadrantPaint((int) (byte) -1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        try {
            java.lang.Number number4 = xYSeriesCollection1.getEndX(1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str1 = axisSpace0.toString();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.expand(rectangle2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean18 = xYLineAndShapeRenderer16.getSeriesVisible(2);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image21 = null;
        combinedRangeXYPlot20.setBackgroundImage(image21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot20.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = combinedRangeXYPlot20.getDataset((int) (short) -1);
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Stroke stroke34 = combinedRangeXYPlot31.getRangeGridlineStroke();
        xYLineAndShapeRenderer16.drawRangeLine(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis27, rectangle2D28, (double) 100, (java.awt.Paint) color30, stroke34);
        try {
            xYLineAndShapeRenderer9.setSeriesOutlineStroke((int) (byte) -1, stroke34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge5);
        try {
            double double7 = categoryAxis1.getCategoryMiddle(1, 1, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.data.Range range8 = timeSeriesCollection1.getDomainBounds(true);
        try {
            java.lang.Number number11 = timeSeriesCollection1.getEndX(0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        try {
            boolean boolean2 = categoryPlot0.removeRangeMarker(marker1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        try {
            xYLineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 100, (double) 10L, (double) ' ', (double) '#', (java.awt.Paint) color4);
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color4, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) (short) 1);
        org.jfree.chart.title.Title title3 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity6 = new org.jfree.chart.entity.TitleEntity(shape2, title3, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot6 = combinedRangeXYPlot0.findSubplot(plotRenderingInfo4, point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 10, 10.0f, textAnchor4, (double) (-1.0f), textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isDomainZoomable();
        boolean boolean3 = lengthConstraintType0.equals((java.lang.Object) boolean2);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean5 = xYLineAndShapeRenderer4.getAutoPopulateSeriesShape();
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer4.setBaseLegendTextFont(font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font6);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean13 = xYLineAndShapeRenderer11.getSeriesVisible(2);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot15.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = combinedRangeXYPlot15.getDataset((int) (short) -1);
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image27 = null;
        combinedRangeXYPlot26.setBackgroundImage(image27);
        java.awt.Stroke stroke29 = combinedRangeXYPlot26.getRangeGridlineStroke();
        xYLineAndShapeRenderer11.drawRangeLine(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.QUAD_CURVE", font6, (java.awt.Paint) color25, rectangleEdge31, horizontalAlignment32, verticalAlignment33, rectangleInsets34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(verticalAlignment33);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("{0}", font1, (java.awt.Paint) color2, rectangleEdge3, horizontalAlignment5, verticalAlignment6, rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        org.jfree.chart.plot.Marker marker7 = null;
        try {
            boolean boolean8 = categoryPlot0.removeRangeMarker(marker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            java.awt.Color color1 = java.awt.Color.decode("{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"{0}\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) (short) 1);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, (double) '4', (float) (-1L), (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.plot.Marker marker7 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(marker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeRangeMarker(2, marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        try {
            polarPlot6.zoomRangeAxes((double) (short) -1, plotRenderingInfo8, point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            combinedRangeXYPlot3.addRangeMarker((int) ' ', marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        java.util.List list7 = categoryPlot0.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("PieLabelLinkStyle.QUAD_CURVE", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        try {
            java.lang.Object obj2 = numberFormat0.parseObject("PieLabelLinkStyle.QUAD_CURVE");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart6.removeChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        java.awt.Paint paint2 = null;
        try {
            categoryPlot0.setDomainGridlinePaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double14 = categoryAxis7.getCategoryEnd(0, (-1), rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        java.awt.Paint paint5 = null;
        try {
            combinedRangeXYPlot0.setDomainGridlinePaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.data.Range range8 = timeSeriesCollection1.getDomainBounds(true);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeriesCollection1.getSeries(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        try {
            double double15 = categoryAxis7.getCategoryEnd(10, 0, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        int int8 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Paint paint12 = combinedRangeXYPlot9.getDomainCrosshairPaint();
        combinedRangeXYPlot9.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = combinedRangeXYPlot9.getSeriesRenderingOrder();
        java.util.List list15 = combinedRangeXYPlot9.getSubplots();
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = timeSeriesCollection1.getRangeBounds(list15, range16, false);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.util.SortOrder sortOrder5 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        categoryPlot0.configureDomainAxes();
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = null;
        try {
            combinedRangeXYPlot0.setOrientation(plotOrientation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        polarPlot6.setRenderer(polarItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        try {
            java.lang.Number number4 = xYSeriesCollection1.getX(1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, 0.4d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, 0.0d, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        int int4 = year3.getYear();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("", regularTimePeriod1, (org.jfree.data.time.RegularTimePeriod) year3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE1" + "'", str1.equals("ItemLabelAnchor.OUTSIDE1"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) ' ');
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) '#', (double) (short) 1, 0, (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj1 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date0, obj1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.resizeRange((double) (short) 100);
        org.jfree.data.Range range8 = null;
        try {
            periodAxis1.setRange(range8, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("{0}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.OUTSIDE1");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ItemLabelAnchor.OUTSIDE1, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 'a', plotRenderingInfo18, point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            java.lang.Object obj16 = legendTitle9.draw(graphics2D13, rectangle2D14, (java.lang.Object) stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent4);
        try {
            double double8 = timeSeriesCollection1.getXValue(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        java.lang.Object obj3 = barRenderer3D0.clone();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            barRenderer3D0.drawOutline(graphics2D4, categoryPlot5, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        java.awt.Paint paint6 = xYLineAndShapeRenderer2.getSeriesOutlinePaint((int) (byte) 10);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean5 = xYLineAndShapeRenderer4.getAutoPopulateSeriesShape();
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer4.setBaseLegendTextFont(font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font6);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("series", font6, paint9, (float) (-9999), 2, textMeasurer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Color color0 = java.awt.Color.GREEN;
        float[] floatArray3 = new float[] { (byte) 1, 0L };
        try {
            float[] floatArray4 = color0.getColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        try {
            barRenderer3D0.setLegendItemLabelGenerator(categorySeriesLabelGenerator3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        java.lang.Class class3 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.setFixedAutoRange((double) '4');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(10);
        int int3 = year2.getYear();
        boolean boolean4 = dateTickMarkPosition0.equals((java.lang.Object) int3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        try {
            java.util.ResourceBundle resourceBundle8 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale7);
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.data.Range range8 = timeSeriesCollection1.getDomainBounds(true);
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem11.setY((double) 100.0f);
        int int14 = timeSeriesCollection1.indexOf((java.lang.Comparable) 100.0f);
        timeSeriesCollection1.clearSelection();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            java.lang.Comparable comparable2 = defaultPieDataset0.getKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot4.setRangeMinorGridlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot4.setRangeAxis(valueAxis7);
        boolean boolean9 = categoryPlot4.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis11.getCategoryLabelPositions();
        categoryPlot4.setDomainAxis(categoryAxis11);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(10);
        periodAxis15.setFirst((org.jfree.data.time.RegularTimePeriod) year17);
        java.awt.Font font19 = periodAxis15.getLabelFont();
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            barRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis15, marker20, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            java.lang.Number number2 = defaultPieDataset0.getValue((java.lang.Comparable) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: -1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, false);
        boolean boolean11 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        xYLineAndShapeRenderer2.setDrawOutlines(false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent4);
        try {
            java.lang.Number number8 = timeSeriesCollection1.getEndY((-1), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        java.lang.String str6 = plotEntity5.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Object obj3 = null;
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date2, obj3);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(date1, date2);
        java.util.TimeZone timeZone6 = null;
        try {
            java.util.Date date7 = dateTickUnit0.rollDate(date1, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge13);
        try {
            java.util.List list16 = categoryAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent4);
        timeSeriesCollection1.removeAllSeries();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(10);
        periodAxis8.setFirst((org.jfree.data.time.RegularTimePeriod) year10);
        java.awt.Font font12 = periodAxis8.getLabelFont();
        periodAxis8.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis8.setRange(range15, false, false);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(10);
        periodAxis20.setFirst((org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.chart.util.Layer layer24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            xYLineAndShapeRenderer2.drawAnnotations(graphics2D5, rectangle2D6, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis20, layer24, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = dateTickUnitType0.equals((java.lang.Object) periodAxis2);
        java.text.DateFormat dateFormat8 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 0, dateFormat8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            labelBlock7.draw(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.data.Range range8 = timeSeriesCollection1.getDomainBounds(true);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeriesCollection1.getSeries((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            jFreeChart6.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        combinedRangeXYPlot0.panRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8);
        java.lang.String str10 = combinedRangeXYPlot0.getPlotType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Combined Range XYPlot" + "'", str10.equals("Combined Range XYPlot"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) '#', plotRenderingInfo8, point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            labelBlock7.setBounds(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, 0);
        java.math.RoundingMode roundingMode4 = null;
        try {
            numberFormat1.setRoundingMode(roundingMode4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        int int8 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Paint paint12 = combinedRangeXYPlot9.getDomainCrosshairPaint();
        combinedRangeXYPlot9.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = combinedRangeXYPlot9.getSeriesRenderingOrder();
        java.util.List list15 = combinedRangeXYPlot9.getSubplots();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(10);
        periodAxis17.setFirst((org.jfree.data.time.RegularTimePeriod) year19);
        java.awt.Font font21 = periodAxis17.getLabelFont();
        periodAxis17.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        periodAxis17.setRange(range24, false, false);
        org.jfree.data.Range range29 = timeSeriesCollection1.getRangeBounds(list15, range24, false);
        double double30 = range24.getLength();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = null;
        categoryPlot0.setDomainCrosshairColumnKey(comparable3);
        boolean boolean5 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        java.awt.Color color6 = java.awt.Color.gray;
        int int7 = color6.getTransparency();
        xYLineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color6);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer2.getSeriesStroke(6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(stroke10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker(0, categoryMarker11, layer12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        xYLineAndShapeRenderer2.setDrawSeriesLineAsPath(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        try {
            xYLineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) -1, xYToolTipGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer3.setBaseLegendTextFont(font5);
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font5);
        java.lang.Object obj8 = labelBlock7.clone();
        boolean boolean10 = labelBlock7.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.lang.Comparable comparable15 = categoryPlot0.getDomainCrosshairRowKey();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable15);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.lang.String str4 = categoryPlot0.getNoDataMessage();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean6 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot0.getFixedLegendItems();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            boolean boolean8 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Font font4 = xYAreaRenderer0.getItemLabelFont(2, (int) (byte) 1, false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image9 = null;
        combinedRangeXYPlot8.setBackgroundImage(image9);
        java.awt.Stroke stroke11 = combinedRangeXYPlot8.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset13 = combinedRangeXYPlot8.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot14 = combinedRangeXYPlot8.getParent();
        combinedRangeXYPlot8.setDomainCrosshairVisible(true);
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image19 = null;
        combinedRangeXYPlot18.setBackgroundImage(image19);
        java.awt.Paint paint21 = combinedRangeXYPlot18.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape17, (org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer25);
        org.jfree.chart.entity.TitleEntity titleEntity28 = new org.jfree.chart.entity.TitleEntity(shape17, (org.jfree.chart.title.Title) legendTitle26, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = legendTitle26.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle26.getItemLabelPadding();
        combinedRangeXYPlot8.setInsets(rectangleInsets30);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint36 = xYLineAndShapeRenderer34.getLegendTextPaint(0);
        java.lang.Boolean boolean38 = xYLineAndShapeRenderer34.getSeriesCreateEntities(0);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer34.setBaseStroke(stroke39, false);
        xYLineAndShapeRenderer34.setAutoPopulateSeriesPaint(false);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(10);
        periodAxis47.setFirst((org.jfree.data.time.RegularTimePeriod) year49);
        java.awt.Font font51 = periodAxis47.getLabelFont();
        periodAxis47.setMinorTickMarkInsideLength((float) ' ');
        org.jfree.chart.plot.Marker marker54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        xYLineAndShapeRenderer34.drawRangeMarker(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, marker54, rectangle2D55);
        org.jfree.chart.axis.PeriodAxis periodAxis58 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(10);
        boolean boolean61 = periodAxis58.equals((java.lang.Object) 10);
        double double62 = periodAxis58.getFixedDimension();
        java.util.TimeZone timeZone63 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection64 = new org.jfree.data.time.TimeSeriesCollection(timeZone63);
        boolean boolean66 = timeSeriesCollection64.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer68 = null;
        org.jfree.chart.plot.PolarPlot polarPlot69 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection64, valueAxis67, polarItemRenderer68);
        try {
            xYAreaRenderer0.drawItem(graphics2D5, xYItemRendererState6, rectangle2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis47, (org.jfree.chart.axis.ValueAxis) periodAxis58, (org.jfree.data.xy.XYDataset) timeSeriesCollection64, (int) '#', (-1), false, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNull(boolean38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        categoryPlot0.clearDomainMarkers(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            multiplePiePlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect(Double.NaN, (double) 6, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        java.awt.Shape shape6 = plotEntity5.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("series");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key series");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot0.getRangeMarkers(layer3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Paint paint9 = combinedRangeXYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer13);
        org.jfree.chart.entity.TitleEntity titleEntity16 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) legendTitle14, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = legendTitle14.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle14.getItemLabelPadding();
        categoryPlot0.setInsets(rectangleInsets18);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        polarPlot6.rendererChanged(rendererChangeEvent9);
        java.awt.Color color11 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color11 };
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke15, stroke16, stroke17 };
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray13, paintArray14, strokeArray18, strokeArray20, shapeArray21);
        polarPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22, true);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            polarPlot6.drawBackground(graphics2D25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        java.lang.Object obj3 = barRenderer3D0.clone();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot8.setRangeMinorGridlineStroke(stroke9);
        java.lang.Comparable comparable11 = categoryPlot8.getDomainCrosshairRowKey();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot12.setRangeMinorGridlineStroke(stroke13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot12.setRangeAxis(valueAxis15);
        boolean boolean17 = categoryPlot12.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis19.getCategoryLabelPositions();
        categoryPlot12.setDomainAxis(categoryAxis19);
        categoryAxis19.setTickMarksVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            barRenderer3D0.drawDomainMarker(graphics2D7, categoryPlot8, categoryAxis19, categoryMarker24, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(comparable11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle9.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle9.setLegendItemGraphicEdge(rectangleEdge14);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle9.getSources();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        boolean boolean8 = polarPlot6.isAngleLabelsVisible();
        java.awt.Paint paint9 = polarPlot6.getRadiusGridlinePaint();
        java.awt.Paint paint10 = null;
        try {
            polarPlot6.setAngleLabelPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        combinedRangeXYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean12 = combinedRangeXYPlot0.isDomainZoomable();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        try {
            combinedRangeXYPlot0.rendererChanged(rendererChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Combined Range XYPlot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Combined Range XYPlot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, false);
        java.awt.Stroke stroke12 = xYLineAndShapeRenderer2.lookupSeriesStroke((int) (byte) 0);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        categoryAxis7.setTickMarksVisible(false);
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeZone13);
        boolean boolean16 = timeSeriesCollection14.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection14, valueAxis17, polarItemRenderer18);
        int int21 = timeSeriesCollection14.indexOf((java.lang.Comparable) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Paint paint25 = combinedRangeXYPlot22.getDomainCrosshairPaint();
        combinedRangeXYPlot22.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = combinedRangeXYPlot22.getSeriesRenderingOrder();
        java.util.List list28 = combinedRangeXYPlot22.getSubplots();
        org.jfree.data.Range range29 = null;
        org.jfree.data.Range range31 = timeSeriesCollection14.getRangeBounds(list28, range29, false);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image35 = null;
        combinedRangeXYPlot34.setBackgroundImage(image35);
        java.awt.Paint paint37 = combinedRangeXYPlot34.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape33, (org.jfree.chart.plot.Plot) combinedRangeXYPlot34);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer41);
        org.jfree.chart.entity.TitleEntity titleEntity44 = new org.jfree.chart.entity.TitleEntity(shape33, (org.jfree.chart.title.Title) legendTitle42, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = legendTitle42.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle42.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle42.setLegendItemGraphicEdge(rectangleEdge47);
        try {
            double double49 = categoryAxis7.getCategoryMiddle((java.lang.Comparable) "{0}", list28, rectangle2D32, rectangleEdge47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.resizeRange((double) (short) 100);
        boolean boolean8 = periodAxis1.isMinorTickMarksVisible();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.plot.Plot plot6 = plotEntity5.getPlot();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (float) (byte) 1, (-1.0f), textAnchor4, (-1.0d), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image3 = null;
        combinedRangeXYPlot2.setBackgroundImage(image3);
        java.awt.Paint paint5 = combinedRangeXYPlot2.getDomainCrosshairPaint();
        combinedRangeXYPlot2.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = combinedRangeXYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.awt.Paint paint9 = jFreeChart8.getBackgroundPaint();
        java.lang.Object obj10 = jFreeChart8.getTextAntiAlias();
        java.awt.RenderingHints renderingHints11 = jFreeChart8.getRenderingHints();
        jFreeChart8.fireChartChanged();
        try {
            multiplePiePlot1.setPieChart(jFreeChart8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(renderingHints11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(Double.NaN, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        int int7 = polarPlot6.getSeriesCount();
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.axis.TickUnit tickUnit10 = polarPlot6.getAngleTickUnit();
        double double11 = tickUnit10.getSize();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(tickUnit10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 45.0d + "'", double11 == 45.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        periodAxis1.setTickMarkInsideLength((float) 3);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str1 = axisSpace0.toString();
        double double2 = axisSpace0.getRight();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            axisSpace0.add(0.0d, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.setLowerMargin((double) 100.0f);
        periodAxis1.setTickMarkInsideLength((float) 1);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        java.lang.ClassLoader classLoader8 = null;
        try {
            java.util.ResourceBundle resourceBundle9 = java.util.ResourceBundle.getBundle("Range[0.0,1.0]", locale7, classLoader8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("hi!");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oct" + "'", str2.equals("Oct"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            jFreeChart6.handleClick(0, 9999, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        java.awt.Paint paint6 = combinedRangeXYPlot0.getRangeMinorGridlinePaint();
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint6, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("MINOR", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeriesCollection1.getSeries((java.lang.Comparable) (-1));
        double double7 = timeSeriesCollection1.getDomainUpperBound(true);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor8 = timeSeriesCollection1.getXPosition();
        try {
            java.lang.Comparable comparable10 = timeSeriesCollection1.getSeriesKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (3).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(timeSeries5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator((int) (short) 0, (int) (byte) 0, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        try {
            legendItemCollection7.addAll(legendItemCollection8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getParent();
        try {
            java.awt.Font font7 = plot6.getNoDataMessageFont();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYLineAndShapeRenderer3.getPositiveItemLabelPosition((-1), 3, true);
        boolean boolean11 = strokeList0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        java.awt.Font font12 = xYLineAndShapeRenderer3.getBaseLegendTextFont();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart6.removeProgressListener(chartProgressListener7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            jFreeChart6.draw(graphics2D9, rectangle2D10, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 45.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("{0}");
        try {
            categoryPlot0.setDomainAxis((int) (byte) -1, categoryAxis5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str2 = axisSpace1.toString();
        axisSpace0.ensureAtLeast(axisSpace1);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = axisSpace0.expand(rectangle2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        try {
            int int3 = xYSeriesCollection1.getItemCount((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            barRenderer3D0.drawBackground(graphics2D6, categoryPlot7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.panRangeAxes((double) 'a', plotRenderingInfo6, point2D7);
        org.junit.Assert.assertNull(collection4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getDomainCrosshairPaint();
        periodAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        java.awt.Color color8 = java.awt.Color.GREEN;
        categoryPlot5.setRangeZeroBaselinePaint((java.awt.Paint) color8);
        java.awt.color.ColorSpace colorSpace10 = null;
        float[] floatArray12 = new float[] { 10 };
        try {
            float[] floatArray13 = color8.getColorComponents(colorSpace10, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5);
        axisSpace5.setLeft((double) 'a');
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D17, (double) 6);
        periodAxis15.setLabelToolTip("Oct");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker15.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer18 = null;
        combinedRangeXYPlot0.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker15, layer18, false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        intervalMarker15.setLabelAnchor(rectangleAnchor21);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator12 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator13 = null;
        try {
            java.lang.String str14 = titleEntity11.getImageMapAreaTag(toolTipTagFragmentGenerator12, uRLTagFragmentGenerator13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(5.0d, Double.NaN, 0.05d, (double) (-11L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        combinedRangeXYPlot0.panRangeAxes((double) (byte) 100, plotRenderingInfo7, point2D8);
        combinedRangeXYPlot0.setBackgroundAlpha((float) (short) 1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("series");
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        polarPlot6.rendererChanged(rendererChangeEvent9);
        java.awt.Color color11 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color11 };
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke15, stroke16, stroke17 };
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray13, paintArray14, strokeArray18, strokeArray20, shapeArray21);
        polarPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22, true);
        boolean boolean25 = polarPlot6.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale7);
        boolean boolean9 = textAnchor0.equals((java.lang.Object) tickUnitSource8);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        double double7 = rectangleInsets5.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("TimePeriodAnchor.END", "Range[0.0,1.0]");
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("Range[0.0,1.0]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer7.setAutoPopulateSeriesPaint(false);
        java.awt.Color color11 = java.awt.Color.gray;
        int int12 = color11.getTransparency();
        xYLineAndShapeRenderer7.setBaseItemLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("MINOR", font3, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("Combined Range XYPlot", font3);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(comparable3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        double double3 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getDomainCrosshairPaint();
        combinedRangeXYPlot7.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        combinedRangeXYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo13, point2D14, false);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image20 = null;
        combinedRangeXYPlot19.setBackgroundImage(image20);
        java.awt.Paint paint22 = combinedRangeXYPlot19.getDomainCrosshairPaint();
        combinedRangeXYPlot19.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = combinedRangeXYPlot19.getSeriesRenderingOrder();
        java.util.List list25 = combinedRangeXYPlot19.getSubplots();
        combinedRangeXYPlot7.drawRangeTickBands(graphics2D17, rectangle2D18, list25);
        try {
            categoryPlot0.mapDatasetToRangeAxes((-1), list25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer7);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getDomainCrosshairPaint();
        xYLineAndShapeRenderer7.setSeriesOutlinePaint((int) 'a', paint11);
        xYLineAndShapeRenderer2.setSeriesFillPaint((int) '#', paint11);
        boolean boolean14 = xYLineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer6.setAutoPopulateSeriesPaint(false);
        java.awt.Color color10 = java.awt.Color.gray;
        int int11 = color10.getTransparency();
        xYLineAndShapeRenderer6.setBaseItemLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("MINOR", font2, (java.awt.Paint) color10);
        java.awt.color.ColorSpace colorSpace14 = color10.getColorSpace();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(colorSpace14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainZoomable();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        polarPlot6.setAngleGridlinesVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        polarPlot6.rendererChanged(rendererChangeEvent10);
        java.awt.Paint paint12 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        polarPlot6.setAngleGridlinePaint(paint12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(0, (-9999), 0, (int) (short) 0, (double) 0L, rectangle2D7, rectangleEdge8);
        categoryAxis1.setCategoryMargin((double) 0L);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean18 = xYLineAndShapeRenderer16.getSeriesVisible(2);
        int int19 = xYLineAndShapeRenderer16.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint22 = periodAxis21.getTickMarkPaint();
        xYLineAndShapeRenderer16.setBaseFillPaint(paint22, false);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("Combined Range XYPlot", font13, paint22);
        categoryAxis1.setLabelFont(font13);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint8 = periodAxis7.getTickMarkPaint();
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYLineAndShapeRenderer2.setBaseToolTipGenerator(xYToolTipGenerator11, false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) ' ', (double) '#', 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        combinedRangeXYPlot5.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedRangeXYPlot5.getSeriesRenderingOrder();
        java.awt.Paint paint11 = combinedRangeXYPlot5.getRangeMinorGridlinePaint();
        boolean boolean12 = rectangleInsets4.equals((java.lang.Object) combinedRangeXYPlot5);
        java.lang.String str13 = rectangleInsets4.toString();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=1.0,l=32.0,b=35.0,r=0.0]" + "'", str13.equals("RectangleInsets[t=1.0,l=32.0,b=35.0,r=0.0]"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        java.lang.Class class3 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis1.getStandardTickUnits();
        float float5 = periodAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) ' ', (double) '#', 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        combinedRangeXYPlot5.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedRangeXYPlot5.getSeriesRenderingOrder();
        java.awt.Paint paint11 = combinedRangeXYPlot5.getRangeMinorGridlinePaint();
        boolean boolean12 = rectangleInsets4.equals((java.lang.Object) combinedRangeXYPlot5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = null;
        try {
            combinedRangeXYPlot5.setDatasetRenderingOrder(datasetRenderingOrder13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        boolean boolean7 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYLineAndShapeRenderer2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        periodAxis1.setAxisLineVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = periodAxis1.getLabelInsets();
        double double9 = rectangleInsets7.calculateLeftInset((double) (-9999));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke2 = xYAreaRenderer0.getSeriesStroke(0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        try {
            xYAreaRenderer0.setGradientTransformer(gradientPaintTransformer3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        java.lang.Object obj2 = xYSeriesCollection1.clone();
        java.lang.Object obj3 = xYSeriesCollection1.clone();
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = xYSeriesCollection1.getSeries((java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: ");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean28 = xYLineAndShapeRenderer26.getSeriesVisible(2);
        int int29 = xYLineAndShapeRenderer26.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint32 = periodAxis31.getTickMarkPaint();
        xYLineAndShapeRenderer26.setBaseFillPaint(paint32, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean39 = xYLineAndShapeRenderer38.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = xYLineAndShapeRenderer38.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYLineAndShapeRenderer26.setSeriesNegativeItemLabelPosition(0, itemLabelPosition41);
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition41, false);
        xYAreaRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition41);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYLineAndShapeRenderer9.setBaseShape(shape13, false);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.entity.XYItemEntity xYItemEntity26 = new org.jfree.chart.entity.XYItemEntity(shape13, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, (int) ' ', (int) (byte) 1, "series", "");
        try {
            int int30 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection17, 3, (double) '4', 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        java.lang.Object obj2 = xYBarRenderer1.clone();
        boolean boolean3 = xYBarRenderer1.isDrawBarOutline();
        boolean boolean4 = xYBarRenderer1.getShadowsVisible();
        xYBarRenderer1.setShadowVisible(true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        double double5 = periodAxis1.getFixedDimension();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = periodAxis1.lengthToJava2D((double) (short) -1, rectangle2D7, rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.updateCrosshairY((double) 100);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint3 = periodAxis2.getTickMarkPaint();
        periodAxis2.setInverted(true);
        org.jfree.chart.entity.AxisEntity axisEntity6 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) periodAxis2);
        java.awt.Font font7 = periodAxis2.getTickLabelFont();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.LegendItem legendItem8 = xYLineAndShapeRenderer2.getLegendItem((-1), (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot9.setRangeMinorGridlineStroke(stroke10);
        xYLineAndShapeRenderer2.setBaseStroke(stroke10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        try {
            xYLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Paint paint12 = combinedRangeXYPlot9.getDomainCrosshairPaint();
        combinedRangeXYPlot9.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedRangeXYPlot9.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D16, false);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image22 = null;
        combinedRangeXYPlot21.setBackgroundImage(image22);
        java.awt.Paint paint24 = combinedRangeXYPlot21.getDomainCrosshairPaint();
        combinedRangeXYPlot21.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = combinedRangeXYPlot21.getSeriesRenderingOrder();
        java.util.List list27 = combinedRangeXYPlot21.getSubplots();
        combinedRangeXYPlot9.drawRangeTickBands(graphics2D19, rectangle2D20, list27);
        try {
            categoryPlot0.mapDatasetToDomainAxes(2, list27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray7 = new java.awt.Stroke[] { stroke4, stroke5, stroke6 };
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke8 };
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray7, strokeArray9, shapeArray10);
        try {
            java.awt.Shape shape12 = defaultDrawingSupplier11.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(strokeArray7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shapeArray10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = legendTitle9.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle9.getItemLabelPadding();
        java.awt.Paint paint14 = legendTitle9.getItemPaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        java.awt.Paint paint8 = xYLineAndShapeRenderer2.getSeriesOutlinePaint((int) (byte) -1);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYLineAndShapeRenderer2.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9);
        java.awt.Paint paint12 = xYLineAndShapeRenderer2.getLegendTextPaint((int) (short) 100);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) ' ', (double) '#', 0.0d);
        double double6 = rectangleInsets4.calculateBottomOutset((double) 6);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.setLowerMargin((double) 100.0f);
        boolean boolean8 = periodAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.RenderingHints renderingHints9 = jFreeChart6.getRenderingHints();
        java.awt.RenderingHints renderingHints10 = jFreeChart6.getRenderingHints();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart6.createBufferedImage(3, 0, 0, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertNotNull(renderingHints10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = legendTitle4.arrange(graphics2D5);
        double double7 = size2D6.width;
        size2D6.setHeight((double) (-2208960000000L));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat3, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat1, numberFormat3);
        numberFormat3.setGroupingUsed(true);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((int) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot3.setRangeMinorGridlineStroke(stroke4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        categoryPlot3.setRangeAxis(valueAxis6);
        boolean boolean8 = categoryPlot3.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = categoryAxis10.getCategoryLabelPositions();
        categoryPlot3.setDomainAxis(categoryAxis10);
        categoryPlot3.setRangePannable(true);
        boolean boolean15 = strokeList0.equals((java.lang.Object) true);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        barRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.geom.RectangularShape rectangularShape8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D2, (-9999), (int) (short) -1, false, rectangularShape8, rectangleEdge9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        double double3 = xYSeriesCollection1.getRangeLowerBound(true);
        try {
            java.lang.Number number6 = xYSeriesCollection1.getStartY((int) (short) 1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        java.awt.geom.Line2D line2D24 = xYItemRendererState23.workingLine;
        org.jfree.chart.entity.EntityCollection entityCollection25 = xYItemRendererState23.getEntityCollection();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNotNull(line2D24);
        org.junit.Assert.assertNull(entityCollection25);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        java.awt.Color color6 = java.awt.Color.gray;
        int int7 = color6.getTransparency();
        xYLineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color6);
        boolean boolean9 = xYLineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        xYLineAndShapeRenderer2.setDefaultEntityRadius(5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        java.lang.Object obj6 = plotEntity5.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        java.lang.Object obj2 = xYSeriesCollection1.clone();
        java.lang.Object obj3 = xYSeriesCollection1.clone();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        try {
            int int6 = xYSeriesCollection1.getItemCount((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            legendTitle4.setBounds(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets5.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        boolean boolean6 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image8 = null;
        combinedRangeXYPlot7.setBackgroundImage(image8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot7.getRangeGridlineStroke();
        combinedRangeXYPlot0.setDomainMinorGridlineStroke(stroke10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot0.getRangeGridlineStroke();
        java.awt.Paint paint13 = combinedRangeXYPlot0.getDomainMinorGridlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PieLabelLinkStyle.QUAD_CURVE", dateFormat1, dateFormat2);
        org.jfree.data.xy.XYSeries xYSeries4 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries4);
        java.lang.Object obj6 = xYSeriesCollection5.clone();
        try {
            java.lang.String str9 = standardXYToolTipGenerator3.generateToolTip((org.jfree.data.xy.XYDataset) xYSeriesCollection5, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createInsetRectangle(rectangle2D6, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color2 };
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke6, stroke7, stroke8 };
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke10 };
        java.awt.Shape[] shapeArray12 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray4, paintArray5, strokeArray9, strokeArray11, shapeArray12);
        boolean boolean14 = strokeList0.equals((java.lang.Object) paintArray4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean11 = xYLineAndShapeRenderer9.getSeriesVisible(2);
        int int12 = xYLineAndShapeRenderer9.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint15 = periodAxis14.getTickMarkPaint();
        xYLineAndShapeRenderer9.setBaseFillPaint(paint15, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYLineAndShapeRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYLineAndShapeRenderer9.setSeriesNegativeItemLabelPosition(0, itemLabelPosition24);
        java.awt.Shape shape29 = xYLineAndShapeRenderer9.getItemShape(2, (-1), true);
        xYLineAndShapeRenderer2.setLegendLine(shape29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        combinedRangeXYPlot31.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = combinedRangeXYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        java.awt.Paint paint38 = jFreeChart37.getBackgroundPaint();
        java.lang.Object obj39 = jFreeChart37.getTextAntiAlias();
        java.awt.RenderingHints renderingHints40 = jFreeChart37.getRenderingHints();
        jFreeChart37.fireChartChanged();
        int int42 = jFreeChart37.getBackgroundImageAlignment();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity44 = new org.jfree.chart.entity.JFreeChartEntity(shape29, jFreeChart37, "hi!");
        java.lang.String str45 = jFreeChartEntity44.toString();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNotNull(renderingHints40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "JFreeChartEntity: tooltip = hi!" + "'", str45.equals("JFreeChartEntity: tooltip = hi!"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("{0}");
        java.awt.Font font4 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (-2208960000000L));
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("{0}", font4);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        categoryPlot0.setRangePannable(true);
        try {
            categoryPlot0.zoom((double) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        java.lang.Object obj2 = xYSeriesCollection1.clone();
        java.lang.Object obj3 = xYSeriesCollection1.clone();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        org.jfree.data.DomainOrder domainOrder5 = xYSeriesCollection1.getDomainOrder();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(domainOrder5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        java.lang.Object obj3 = barRenderer3D0.clone();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot10.setRangeMinorGridlineStroke(stroke11);
        double double13 = categoryPlot10.getRangeCrosshairValue();
        categoryPlot10.setRangePannable(true);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            barRenderer3D0.drawOutline(graphics2D9, categoryPlot10, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        int int7 = polarPlot6.getSeriesCount();
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke16 = xYAreaRenderer14.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image20 = null;
        combinedRangeXYPlot19.setBackgroundImage(image20);
        java.awt.Stroke stroke22 = combinedRangeXYPlot19.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset24 = combinedRangeXYPlot19.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot25 = combinedRangeXYPlot19.getParent();
        combinedRangeXYPlot19.setDomainCrosshairVisible(true);
        combinedRangeXYPlot19.configureDomainAxes();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        boolean boolean32 = timeSeriesCollection30.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection30, valueAxis33, polarItemRenderer34);
        polarPlot35.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset38 = polarPlot35.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo39);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState41 = xYAreaRenderer14.initialise(graphics2D17, rectangle2D18, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot19, xYDataset38, plotRenderingInfo40);
        try {
            polarPlot6.draw(graphics2D10, rectangle2D11, point2D12, plotState13, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(xYDataset38);
        org.junit.Assert.assertNotNull(xYItemRendererState41);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            timeSeriesCollection2.addSeries(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        boolean boolean4 = periodAxis1.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getDomainCrosshairPaint();
        periodAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        java.awt.Color color8 = java.awt.Color.GREEN;
        categoryPlot5.setRangeZeroBaselinePaint((java.awt.Paint) color8);
        categoryPlot5.clearRangeMarkers(0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean15 = xYLineAndShapeRenderer14.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image18 = null;
        combinedRangeXYPlot17.setBackgroundImage(image18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset22 = combinedRangeXYPlot17.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot23 = combinedRangeXYPlot17.getParent();
        combinedRangeXYPlot17.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = combinedRangeXYPlot17.getDomainMarkers((int) (byte) 100, layer27);
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(10);
        boolean boolean33 = periodAxis30.equals((java.lang.Object) 10);
        boolean boolean34 = periodAxis30.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint38 = categoryPlot37.getDomainCrosshairPaint();
        java.awt.Paint paint39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot37.setRangeZeroBaselinePaint(paint39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer14.drawDomainLine(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis30, rectangle2D35, (double) (byte) 1, paint39, stroke41);
        int int43 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis30);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str1 = axisSpace0.toString();
        double double2 = axisSpace0.getRight();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean7 = xYLineAndShapeRenderer5.getSeriesVisible(2);
        int int8 = xYLineAndShapeRenderer5.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint11 = periodAxis10.getTickMarkPaint();
        xYLineAndShapeRenderer5.setBaseFillPaint(paint11, false);
        boolean boolean14 = xYLineAndShapeRenderer5.getUseOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYLineAndShapeRenderer5.getPositiveItemLabelPosition((int) (short) 0, (int) (byte) 0, false);
        boolean boolean19 = axisSpace0.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        double double2 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        combinedRangeXYPlot22.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        java.util.List list35 = combinedRangeXYPlot22.getSubplots();
        combinedRangeXYPlot22.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(10);
        periodAxis43.setFirst((org.jfree.data.time.RegularTimePeriod) year45);
        java.awt.Font font47 = periodAxis43.getLabelFont();
        combinedRangeXYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis43);
        combinedRangeXYPlot22.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis43, true);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        periodAxis52.setFirst((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.String str56 = periodAxis52.getLabelURL();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean60 = timeSeriesCollection58.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, valueAxis61, polarItemRenderer62);
        xYLineAndShapeRenderer2.drawItem(graphics2D12, xYItemRendererState13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.axis.ValueAxis) periodAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, 0, (int) (short) 100, true, (int) '4');
        boolean boolean69 = xYLineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator70 = xYLineAndShapeRenderer2.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNull(xYURLGenerator70);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis11.getCategoryLabelPositions();
        int int13 = categoryAxis11.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint16 = periodAxis15.getTickMarkPaint();
        java.lang.Class class17 = periodAxis15.getAutoRangeTimePeriodClass();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = periodAxis15.getStandardTickUnits();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 5.0d, 100L };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray24, numberArray27, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "series", numberArray31);
        categoryPlot19.setDataset(categoryDataset32);
        try {
            barRenderer3D0.drawItem(graphics2D6, categoryItemRendererState7, rectangle2D8, categoryPlot9, categoryAxis11, (org.jfree.chart.axis.ValueAxis) periodAxis15, categoryDataset32, (int) (short) 0, 6, false, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) ' ', (double) '#', 0.0d);
        double double6 = rectangleInsets4.calculateRightInset((double) (-1.0f));
        double double8 = rectangleInsets4.extendWidth(2.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 34.0d + "'", double8 == 34.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        java.lang.Object obj3 = barRenderer3D0.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke11 = categoryPlot8.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint14 = periodAxis13.getTickMarkPaint();
        periodAxis13.setInverted(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image21 = null;
        combinedRangeXYPlot20.setBackgroundImage(image21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot20.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = combinedRangeXYPlot20.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint31 = xYLineAndShapeRenderer29.getLegendTextPaint(0);
        combinedRangeXYPlot20.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer29);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection(timeZone33);
        boolean boolean36 = timeSeriesCollection34.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent37 = null;
        timeSeriesCollection34.seriesChanged(seriesChangeEvent37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState40 = xYAreaRenderer17.initialise(graphics2D18, rectangle2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.data.xy.XYDataset) timeSeriesCollection34, plotRenderingInfo39);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image42 = null;
        combinedRangeXYPlot41.setBackgroundImage(image42);
        java.awt.Paint paint44 = combinedRangeXYPlot41.getDomainCrosshairPaint();
        combinedRangeXYPlot41.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        combinedRangeXYPlot41.zoomRangeAxes(0.0d, plotRenderingInfo47, point2D48, false);
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = combinedRangeXYPlot41.getDomainMarkers(layer51);
        org.jfree.chart.plot.IntervalMarker intervalMarker56 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker56.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer59 = null;
        combinedRangeXYPlot41.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker56, layer59, false);
        double double62 = intervalMarker56.getStartValue();
        org.jfree.chart.util.Layer layer63 = null;
        boolean boolean64 = combinedRangeXYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker56, layer63);
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        try {
            barRenderer3D0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.plot.Marker) intervalMarker56, rectangle2D65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker2.setEndValue((double) (-11L));
        double double5 = intervalMarker2.getEndValue();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(10);
        boolean boolean10 = periodAxis7.equals((java.lang.Object) 10);
        periodAxis7.setAxisLineVisible(false);
        java.awt.Font font13 = periodAxis7.getLabelFont();
        java.awt.Stroke stroke14 = periodAxis7.getMinorTickMarkStroke();
        intervalMarker2.setStroke(stroke14);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-11.0d) + "'", double5 == (-11.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer3.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYLineAndShapeRenderer3.getPositiveItemLabelPosition((-1), 3, true);
        boolean boolean11 = strokeList0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        java.lang.Object obj12 = null;
        boolean boolean13 = strokeList0.equals(obj12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint11 = xYLineAndShapeRenderer9.getLegendTextPaint(0);
        combinedRangeXYPlot0.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.util.List list13 = combinedRangeXYPlot0.getSubplots();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        combinedRangeXYPlot0.panRangeAxes((double) 6, plotRenderingInfo18, point2D19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        boolean boolean24 = timeSeriesCollection22.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, valueAxis25, polarItemRenderer26);
        java.awt.Stroke stroke28 = polarPlot27.getRadiusGridlineStroke();
        combinedRangeXYPlot0.setDomainMinorGridlineStroke(stroke28);
        boolean boolean30 = combinedRangeXYPlot0.isRangePannable();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        barRenderer3D0.setIncludeBaseInRange(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNull(itemLabelPosition8);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        boolean boolean6 = periodAxis3.equals((java.lang.Object) 10);
        boolean boolean7 = periodAxis3.isMinorTickMarksVisible();
        java.util.Locale locale8 = periodAxis3.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale8);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getCurrencyInstance(locale8);
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date0, timeZone1, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(locale8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (-9999), (double) (-11L), (double) 0, (double) (short) 100, paint4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean9 = xYLineAndShapeRenderer8.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image12 = null;
        combinedRangeXYPlot11.setBackgroundImage(image12);
        java.awt.Stroke stroke14 = combinedRangeXYPlot11.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset16 = combinedRangeXYPlot11.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getParent();
        combinedRangeXYPlot11.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot11.getDomainMarkers((int) (byte) 100, layer21);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(10);
        boolean boolean27 = periodAxis24.equals((java.lang.Object) 10);
        boolean boolean28 = periodAxis24.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint32 = categoryPlot31.getDomainCrosshairPaint();
        java.awt.Paint paint33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot31.setRangeZeroBaselinePaint(paint33);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer8.drawDomainLine(graphics2D10, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) periodAxis24, rectangle2D29, (double) (byte) 1, paint33, stroke35);
        boolean boolean37 = blockBorder5.equals((java.lang.Object) graphics2D10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.removeAnnotations();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint9 = xYLineAndShapeRenderer7.getLegendTextPaint(0);
        java.lang.Boolean boolean11 = xYLineAndShapeRenderer7.getSeriesCreateEntities(0);
        boolean boolean12 = xYLineAndShapeRenderer7.getBaseSeriesVisible();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYLineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYLineAndShapeRenderer15.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer7.setBasePositiveItemLabelPosition(itemLabelPosition22);
        barRenderer3D0.setBaseNegativeItemLabelPosition(itemLabelPosition22, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer7);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint11 = categoryPlot10.getDomainCrosshairPaint();
        xYLineAndShapeRenderer7.setSeriesOutlinePaint((int) 'a', paint11);
        xYLineAndShapeRenderer2.setSeriesFillPaint((int) '#', paint11);
        xYLineAndShapeRenderer2.setUseFillPaint(true);
        java.awt.Font font17 = xYLineAndShapeRenderer2.lookupLegendTextFont(2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(font17);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot2.setRangeMinorGridlineStroke(stroke3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot2.setRangeAxis(valueAxis5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        categoryPlot2.drawBackgroundImage(graphics2D7, rectangle2D8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        boolean boolean15 = periodAxis11.isMinorTickMarksVisible();
        java.util.Locale locale16 = periodAxis11.getLocale();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image21 = null;
        combinedRangeXYPlot20.setBackgroundImage(image21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot20.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = combinedRangeXYPlot20.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint31 = xYLineAndShapeRenderer29.getLegendTextPaint(0);
        combinedRangeXYPlot20.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer29);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection(timeZone33);
        boolean boolean36 = timeSeriesCollection34.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent37 = null;
        timeSeriesCollection34.seriesChanged(seriesChangeEvent37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState40 = xYAreaRenderer17.initialise(graphics2D18, rectangle2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.data.xy.XYDataset) timeSeriesCollection34, plotRenderingInfo39);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image42 = null;
        combinedRangeXYPlot41.setBackgroundImage(image42);
        java.awt.Paint paint44 = combinedRangeXYPlot41.getDomainCrosshairPaint();
        combinedRangeXYPlot41.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        combinedRangeXYPlot41.zoomRangeAxes(0.0d, plotRenderingInfo47, point2D48, false);
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = combinedRangeXYPlot41.getDomainMarkers(layer51);
        org.jfree.chart.plot.IntervalMarker intervalMarker56 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker56.setEndValue((double) (-11L));
        org.jfree.chart.util.Layer layer59 = null;
        combinedRangeXYPlot41.addRangeMarker(2, (org.jfree.chart.plot.Marker) intervalMarker56, layer59, false);
        double double62 = intervalMarker56.getStartValue();
        org.jfree.chart.util.Layer layer63 = null;
        boolean boolean64 = combinedRangeXYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker56, layer63);
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        try {
            barRenderer3D0.drawRangeMarker(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis11, (org.jfree.chart.plot.Marker) intervalMarker56, rectangle2D65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke3 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image5 = null;
        combinedRangeXYPlot4.setBackgroundImage(image5);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        combinedRangeXYPlot4.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = combinedRangeXYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = combinedRangeXYPlot4.getRangeAxisIndex(valueAxis11);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot4);
        org.jfree.data.xy.XYSeries xYSeries17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries17.add((double) (short) 0, (double) (short) 0);
        java.util.List list21 = xYSeries17.getItems();
        try {
            categoryPlot0.mapDatasetToRangeAxes(3, list21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Indices must be Integer instances.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, 0.4d);
        intervalMarker2.setEndValue((double) (-11L));
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke8 = categoryPlot5.getRangeZeroBaselineStroke();
        intervalMarker2.setStroke(stroke8);
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) intervalMarker2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        java.lang.Object obj8 = null;
        boolean boolean9 = jFreeChart6.equals(obj8);
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart6.createBufferedImage(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer2.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getDomainCrosshairPaint();
        combinedRangeXYPlot15.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image23 = null;
        combinedRangeXYPlot22.setBackgroundImage(image23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot22.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint33 = xYLineAndShapeRenderer31.getLegendTextPaint(0);
        combinedRangeXYPlot22.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        java.util.List list35 = combinedRangeXYPlot22.getSubplots();
        combinedRangeXYPlot22.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(10);
        periodAxis43.setFirst((org.jfree.data.time.RegularTimePeriod) year45);
        java.awt.Font font47 = periodAxis43.getLabelFont();
        combinedRangeXYPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis43);
        combinedRangeXYPlot22.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis43, true);
        org.jfree.chart.axis.PeriodAxis periodAxis52 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(10);
        periodAxis52.setFirst((org.jfree.data.time.RegularTimePeriod) year54);
        java.lang.String str56 = periodAxis52.getLabelURL();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean60 = timeSeriesCollection58.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, valueAxis61, polarItemRenderer62);
        xYLineAndShapeRenderer2.drawItem(graphics2D12, xYItemRendererState13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.axis.ValueAxis) periodAxis52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, 0, (int) (short) 100, true, (int) '4');
        org.jfree.chart.axis.TickUnits tickUnits69 = new org.jfree.chart.axis.TickUnits();
        periodAxis43.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits69);
        periodAxis43.setMinorTickCount((int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot0.getDomainMarkers(layer10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        combinedRangeXYPlot0.setDomainMinorGridlineStroke(stroke12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 6, (float) 2, (float) (-9999));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image10 = null;
        combinedRangeXYPlot9.setBackgroundImage(image10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot9.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot9.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint20 = xYLineAndShapeRenderer18.getLegendTextPaint(0);
        combinedRangeXYPlot9.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer18);
        java.util.List list22 = combinedRangeXYPlot9.getSubplots();
        combinedRangeXYPlot9.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        combinedRangeXYPlot9.panRangeAxes((double) 6, plotRenderingInfo27, point2D28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeZone30);
        boolean boolean33 = timeSeriesCollection31.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection31, valueAxis34, polarItemRenderer35);
        java.awt.Stroke stroke37 = polarPlot36.getRadiusGridlineStroke();
        combinedRangeXYPlot9.setDomainMinorGridlineStroke(stroke37);
        java.awt.Font font40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean45 = xYLineAndShapeRenderer43.getSeriesVisible(2);
        int int46 = xYLineAndShapeRenderer43.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis48 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint49 = periodAxis48.getTickMarkPaint();
        xYLineAndShapeRenderer43.setBaseFillPaint(paint49, false);
        org.jfree.chart.text.TextLine textLine52 = new org.jfree.chart.text.TextLine("Combined Range XYPlot", font40, paint49);
        try {
            org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem(attributedString0, "", "TimePeriodAnchor.END", "RectangleInsets[t=1.0,l=32.0,b=35.0,r=0.0]", shape8, stroke37, paint49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.lang.String str4 = categoryPlot0.getNoDataMessage();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean6 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 10, (double) '4');
        try {
            categoryPlot0.setRenderer((-9999), (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        long long2 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.updateCrosshairY((double) 0L, 100);
        xYCrosshairState0.setCrosshairX((double) 100);
        java.awt.geom.Point2D point2D7 = xYCrosshairState0.getAnchor();
        int int8 = xYCrosshairState0.getRangeAxisIndex();
        org.junit.Assert.assertNull(point2D1);
        org.junit.Assert.assertNull(point2D7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.setLowerMargin((double) 100.0f);
        periodAxis1.setLowerBound(0.0d);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        combinedRangeXYPlot1.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot8.getDrawingSupplier();
        xYPlot0.setDrawingSupplier(drawingSupplier9);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertNotNull(drawingSupplier9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint2 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot1.setDomainAxisLocation(axisLocation3);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean8 = timeSeriesCollection6.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        polarPlot11.rendererChanged(rendererChangeEvent14);
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color16 };
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke20, stroke21, stroke22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke24 };
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray17, paintArray18, paintArray19, strokeArray23, strokeArray25, shapeArray26);
        polarPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27, true);
        combinedRangeXYPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        java.lang.Object obj31 = defaultDrawingSupplier27.clone();
        boolean boolean32 = centerArrangement0.equals((java.lang.Object) defaultDrawingSupplier27);
        org.jfree.data.xy.XYSeries xYSeries33 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection34 = new org.jfree.data.xy.XYSeriesCollection(xYSeries33);
        xYSeriesCollection34.setIntervalWidth((double) (byte) 10);
        xYSeriesCollection34.setAutoWidth(false);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = xYSeriesCollection34.indexOf((java.lang.Comparable) (byte) 1);
        boolean boolean43 = defaultDrawingSupplier27.equals((java.lang.Object) xYSeriesCollection34);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        periodAxis1.setInverted(true);
        periodAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        java.lang.Object obj2 = xYBarRenderer1.clone();
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) (byte) 0, (-1.0d), 3.0d, paint7);
        xYBarRenderer1.setBaseItemLabelPaint(paint7, false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image16 = null;
        combinedRangeXYPlot15.setBackgroundImage(image16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot15.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = combinedRangeXYPlot15.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint26 = xYLineAndShapeRenderer24.getLegendTextPaint(0);
        combinedRangeXYPlot15.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer24);
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeZone28);
        boolean boolean31 = timeSeriesCollection29.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = null;
        timeSeriesCollection29.seriesChanged(seriesChangeEvent32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = xYAreaRenderer12.initialise(graphics2D13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.data.xy.XYDataset) timeSeriesCollection29, plotRenderingInfo34);
        java.awt.geom.Line2D line2D36 = xYItemRendererState35.workingLine;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image39 = null;
        combinedRangeXYPlot38.setBackgroundImage(image39);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot38.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot41);
        combinedRangeXYPlot38.setDomainZeroBaselineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(10);
        boolean boolean50 = periodAxis47.equals((java.lang.Object) 10);
        periodAxis47.setAxisLineVisible(false);
        periodAxis47.setAxisLineVisible(true);
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection56 = new org.jfree.data.time.TimeSeriesCollection(timeZone55);
        boolean boolean58 = timeSeriesCollection56.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection56, valueAxis59, polarItemRenderer60);
        org.jfree.data.Range range63 = timeSeriesCollection56.getDomainBounds(true);
        try {
            xYBarRenderer1.drawItem(graphics2D11, xYItemRendererState35, rectangle2D37, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot38, valueAxis45, (org.jfree.chart.axis.ValueAxis) periodAxis47, (org.jfree.data.xy.XYDataset) timeSeriesCollection56, 0, 100, true, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState35);
        org.junit.Assert.assertNotNull(line2D36);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(range63);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = axisSpace5.expand(rectangle2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.data.Range range8 = timeSeriesCollection1.getDomainBounds(true);
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) 2);
        xYDataItem11.setY((double) 100.0f);
        int int14 = timeSeriesCollection1.indexOf((java.lang.Comparable) 100.0f);
        org.jfree.data.Range range16 = timeSeriesCollection1.getDomainBounds(false);
        try {
            java.lang.Number number19 = timeSeriesCollection1.getEndX((-9999), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        java.lang.Object obj7 = polarPlot6.clone();
        boolean boolean8 = polarPlot6.isAngleLabelsVisible();
        polarPlot6.setAngleLabelsVisible(false);
        java.lang.String str11 = polarPlot6.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setBaseCreateEntities(true);
        boolean boolean3 = xYStepAreaRenderer0.getShapesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        barRenderer3D0.setBase((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        categoryAxis7.setTickMarksVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis7.getCategoryLabelPositions();
        double double13 = categoryAxis7.getCategoryMargin();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYAreaRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = xYAreaRenderer0.getSeriesURLGenerator(0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNull(xYURLGenerator26);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        periodAxis2.setFirst((org.jfree.data.time.RegularTimePeriod) year4);
        java.awt.Font font6 = periodAxis2.getLabelFont();
        boolean boolean7 = tickType0.equals((java.lang.Object) font6);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        java.lang.Class class3 = periodAxis1.getAutoRangeTimePeriodClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        boolean boolean5 = org.jfree.chart.util.SerialUtilities.isSerializable(class4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.lang.String str4 = categoryPlot0.getNoDataMessage();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean6 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setDrawSharedDomainAxis(true);
        categoryPlot0.setAnchorValue((double) (short) 0);
        int int11 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getDomainCrosshairPaint();
        categoryPlot4.setRangeZeroBaselinePaint(paint8);
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, true);
        java.text.NumberFormat numberFormat13 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat15 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat15, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator18 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat13, numberFormat15);
        xYLineAndShapeRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        try {
            java.lang.String str23 = standardXYToolTipGenerator18.generateLabelString(xYDataset20, 4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertNotNull(numberFormat15);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        java.util.Iterator iterator8 = legendItemCollection7.iterator();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(iterator8);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        combinedRangeXYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean12 = combinedRangeXYPlot0.isDomainZoomable();
        boolean boolean13 = combinedRangeXYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke17 = xYAreaRenderer15.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image21 = null;
        combinedRangeXYPlot20.setBackgroundImage(image21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot20.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = combinedRangeXYPlot20.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot26 = combinedRangeXYPlot20.getParent();
        combinedRangeXYPlot20.setDomainCrosshairVisible(true);
        combinedRangeXYPlot20.configureDomainAxes();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeZone30);
        boolean boolean33 = timeSeriesCollection31.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection31, valueAxis34, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset39 = polarPlot36.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = xYAreaRenderer15.initialise(graphics2D18, rectangle2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, xYDataset39, plotRenderingInfo41);
        java.awt.geom.Point2D point2D43 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (-2), plotRenderingInfo41, point2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(xYDataset39);
        org.junit.Assert.assertNotNull(xYItemRendererState42);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        legendItem20.setToolTipText("ClassContext");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge8);
        try {
            double double10 = categoryAxis3D1.getCategorySeriesMiddle((int) (byte) 0, 5, 100, (-1), (double) 1L, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean11 = xYLineAndShapeRenderer9.getSeriesVisible(2);
        int int12 = xYLineAndShapeRenderer9.getPassCount();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint15 = periodAxis14.getTickMarkPaint();
        xYLineAndShapeRenderer9.setBaseFillPaint(paint15, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYLineAndShapeRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        xYLineAndShapeRenderer9.setSeriesNegativeItemLabelPosition(0, itemLabelPosition24);
        java.awt.Shape shape29 = xYLineAndShapeRenderer9.getItemShape(2, (-1), true);
        xYLineAndShapeRenderer2.setLegendLine(shape29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        combinedRangeXYPlot31.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = combinedRangeXYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        java.awt.Paint paint38 = jFreeChart37.getBackgroundPaint();
        java.lang.Object obj39 = jFreeChart37.getTextAntiAlias();
        java.awt.RenderingHints renderingHints40 = jFreeChart37.getRenderingHints();
        jFreeChart37.fireChartChanged();
        int int42 = jFreeChart37.getBackgroundImageAlignment();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity44 = new org.jfree.chart.entity.JFreeChartEntity(shape29, jFreeChart37, "hi!");
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent45 = null;
        try {
            jFreeChart37.plotChanged(plotChangeEvent45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNotNull(renderingHints40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint9 = periodAxis8.getTickMarkPaint();
        periodAxis8.setInverted(true);
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(10);
        boolean boolean16 = periodAxis13.equals((java.lang.Object) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer19.setAutoPopulateSeriesPaint(false);
        java.awt.Color color23 = java.awt.Color.gray;
        int int24 = color23.getTransparency();
        xYLineAndShapeRenderer19.setBaseItemLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer19);
        try {
            java.lang.Number number29 = timeSeriesCollection1.getStartX(1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = legendTitle4.arrange(graphics2D5);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray7 = legendTitle4.getSources();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(legendItemSourceArray7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo7, point2D8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer3D11.setGradientPaintTransformer(gradientPaintTransformer12);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D11);
        java.awt.Font font16 = barRenderer3D11.getSeriesItemLabelFont(1);
        java.lang.Object obj17 = barRenderer3D11.clone();
        java.awt.Shape shape19 = barRenderer3D11.getLegendShape(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(shape19);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getDomainCrosshairPaint();
        categoryPlot4.setRangeZeroBaselinePaint(paint8);
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, true);
        java.text.NumberFormat numberFormat13 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat15 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat15, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator18 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat13, numberFormat15);
        xYLineAndShapeRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator18);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        try {
            xYLineAndShapeRenderer2.addAnnotation(xYAnnotation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertNotNull(numberFormat15);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}", dateFormat1, dateFormat2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean14 = periodAxis11.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getDomainCrosshairPaint();
        periodAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "", "TimePeriodAnchor.END", "", shape4, (java.awt.Paint) color18);
        java.awt.Paint paint21 = legendItem20.getFillPaint();
        java.lang.String str22 = legendItem20.getToolTipText();
        legendItem20.setShapeVisible(true);
        java.lang.String str25 = legendItem20.getToolTipText();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodAnchor.END" + "'", str22.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodAnchor.END" + "'", str25.equals("TimePeriodAnchor.END"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        int int2 = categoryAxis3D1.getMaximumCategoryLabelLines();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke10 = xYAreaRenderer8.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image14 = null;
        combinedRangeXYPlot13.setBackgroundImage(image14);
        java.awt.Stroke stroke16 = combinedRangeXYPlot13.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset18 = combinedRangeXYPlot13.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot19 = combinedRangeXYPlot13.getParent();
        combinedRangeXYPlot13.setDomainCrosshairVisible(true);
        combinedRangeXYPlot13.configureDomainAxes();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        boolean boolean26 = timeSeriesCollection24.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis27, polarItemRenderer28);
        polarPlot29.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset32 = polarPlot29.getDataset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = xYAreaRenderer8.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, xYDataset32, plotRenderingInfo34);
        try {
            org.jfree.chart.axis.AxisState axisState36 = categoryAxis3D1.draw(graphics2D3, (double) (byte) 100, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(xYDataset32);
        org.junit.Assert.assertNotNull(xYItemRendererState35);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        java.lang.Class class3 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis1.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        periodAxis1.setStandardTickUnits(tickUnitSource5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis7.getCategoryLabelPositions();
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 100, 3.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot0.setRangeAxis(0, valueAxis16);
        java.util.List list18 = categoryPlot0.getCategories();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNull(list18);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        boolean boolean8 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent9);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate2.setDescription("MINOR");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        xYBarRenderer1.setAutoPopulateSeriesShape(false);
        java.text.NumberFormat numberFormat6 = java.text.NumberFormat.getInstance();
        java.text.NumberFormat numberFormat8 = java.text.NumberFormat.getInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat8, 0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("series", numberFormat6, numberFormat8);
        java.text.NumberFormat numberFormat12 = standardXYToolTipGenerator11.getYFormat();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNotNull(numberFormat12);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Paint paint7 = jFreeChart6.getBackgroundPaint();
        int int8 = jFreeChart6.getSubtitleCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = timeSeriesCollection1.getGroup();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            timeSeriesCollection1.addSeries(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(datasetGroup7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        boolean boolean3 = xYSeries2.getAutoSort();
        xYSeries2.clear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getDomainCrosshairPaint();
        categoryPlot4.setRangeZeroBaselinePaint(paint8);
        xYLineAndShapeRenderer2.setBaseFillPaint(paint8, true);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(paint8);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot5.getDataset((int) (short) -1);
        org.jfree.chart.plot.Plot plot11 = combinedRangeXYPlot5.getParent();
        combinedRangeXYPlot5.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = combinedRangeXYPlot5.getDomainMarkers((int) (byte) 100, layer15);
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(10);
        boolean boolean21 = periodAxis18.equals((java.lang.Object) 10);
        boolean boolean22 = periodAxis18.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint26 = categoryPlot25.getDomainCrosshairPaint();
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot25.setRangeZeroBaselinePaint(paint27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.drawDomainLine(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.chart.axis.ValueAxis) periodAxis18, rectangle2D23, (double) (byte) 1, paint27, stroke29);
        boolean boolean33 = xYLineAndShapeRenderer2.getItemLineVisible(9, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean5 = xYLineAndShapeRenderer4.getAutoPopulateSeriesShape();
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer4.setBaseLegendTextFont(font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("PieLabelLinkStyle.QUAD_CURVE", font6);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font6, (java.awt.Paint) color9, 0.0f, textMeasurer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image2 = null;
        combinedRangeXYPlot1.setBackgroundImage(image2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity5 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer8);
        org.jfree.chart.entity.TitleEntity titleEntity11 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle9, "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot12.setRangeMinorGridlineStroke(stroke13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot12.setRangeAxis(valueAxis15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot12.zoomDomainAxes((double) 0, 0.0d, plotRenderingInfo19, point2D20);
        categoryPlot12.clearRangeAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D23 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        barRenderer3D23.setGradientPaintTransformer(gradientPaintTransformer24);
        categoryPlot12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState31 = null;
        boolean boolean32 = categoryPlot12.render(graphics2D27, rectangle2D28, 3, plotRenderingInfo30, categoryCrosshairState31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setCategoryLabelPositionOffset((int) (short) 10);
        categoryPlot12.setDomainAxis((int) '4', categoryAxis34, false);
        boolean boolean39 = legendTitle9.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.resizeRange((double) (short) 100);
        int int8 = periodAxis1.getMinorTickCount();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint12 = periodAxis11.getTickMarkPaint();
        periodAxis11.setInverted(true);
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape9, (org.jfree.chart.axis.Axis) periodAxis11);
        periodAxis1.setDownArrow(shape9);
        org.jfree.data.Range range17 = periodAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getDomainCrosshairPaint();
        categoryPlot5.setRangeZeroBaselinePaint(paint9);
        xYLineAndShapeRenderer3.setBaseFillPaint(paint9, true);
        boolean boolean13 = gradientPaintTransformType0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge10);
        axisSpace8.ensureAtLeast(0.0d, rectangleEdge10);
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = axisSpace5.reserved(rectangle2D7, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        double double5 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.util.SortOrder sortOrder6 = null;
        try {
            defaultPieDataset0.sortByKeys(sortOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke3 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image5 = null;
        combinedRangeXYPlot4.setBackgroundImage(image5);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        combinedRangeXYPlot4.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = combinedRangeXYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = combinedRangeXYPlot4.getRangeAxisIndex(valueAxis11);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot4);
        java.awt.Paint paint14 = categoryPlot0.getRangeZeroBaselinePaint();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = dateTickUnitType0.equals((java.lang.Object) periodAxis2);
        periodAxis2.setRangeWithMargins(35.0d, 35.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint13 = periodAxis12.getTickMarkPaint();
        java.lang.Class class14 = periodAxis12.getAutoRangeTimePeriodClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        periodAxis2.setAutoRangeTimePeriodClass(class14);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(10);
        periodAxis1.setFirst((org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Class class5 = periodAxis1.getAutoRangeTimePeriodClass();
        periodAxis1.setLowerMargin((double) 100.0f);
        java.lang.Object obj8 = periodAxis1.clone();
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(9999);
        boolean boolean2 = xYAreaRenderer1.isOutline();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(valueAxis3);
        boolean boolean5 = categoryPlot0.isRangePannable();
        java.util.List list6 = categoryPlot0.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(100.0d, plotRenderingInfo4, point2D5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            timeSeriesCollection1.removeSeries(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        standardChartTheme1.setBaselinePaint(paint3);
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint7 = periodAxis6.getTickMarkPaint();
        standardChartTheme1.setAxisLabelPaint(paint7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) (short) 100, (double) (-2), Double.NaN);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        java.lang.Object obj7 = xYBarRenderer6.clone();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) (byte) 0, (-1.0d), 3.0d, paint12);
        xYBarRenderer6.setBaseItemLabelPaint(paint12, false);
        java.awt.geom.RectangularShape rectangularShape19 = null;
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image22 = null;
        combinedRangeXYPlot21.setBackgroundImage(image22);
        java.awt.Paint paint24 = combinedRangeXYPlot21.getDomainCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape20, (org.jfree.chart.plot.Plot) combinedRangeXYPlot21);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer28);
        org.jfree.chart.entity.TitleEntity titleEntity31 = new org.jfree.chart.entity.TitleEntity(shape20, (org.jfree.chart.title.Title) legendTitle29, "hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = legendTitle29.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle29.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle29.setLegendItemGraphicEdge(rectangleEdge34);
        try {
            gradientXYBarPainter3.paintBar(graphics2D4, xYBarRenderer6, 0, (-1), false, rectangularShape19, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        xYLineAndShapeRenderer2.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = null;
        xYLineAndShapeRenderer2.setBaseItemLabelGenerator(xYItemLabelGenerator9, false);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint2 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot1.setDomainAxisLocation(axisLocation3);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean8 = timeSeriesCollection6.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        polarPlot11.rendererChanged(rendererChangeEvent14);
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color16 };
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke20, stroke21, stroke22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke24 };
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray17, paintArray18, paintArray19, strokeArray23, strokeArray25, shapeArray26);
        polarPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27, true);
        combinedRangeXYPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        java.lang.Object obj31 = defaultDrawingSupplier27.clone();
        boolean boolean32 = centerArrangement0.equals((java.lang.Object) defaultDrawingSupplier27);
        org.jfree.chart.block.BlockContainer blockContainer33 = null;
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.data.Range range36 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) (-11L), range36);
        try {
            org.jfree.chart.util.Size2D size2D38 = centerArrangement0.arrange(blockContainer33, graphics2D34, rectangleConstraint37);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot7.getDomainAxisEdge();
        try {
            double double9 = categoryAxis1.getCategoryEnd((int) (short) -1, 4, rectangle2D6, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        int int2 = year1.getYear();
        long long3 = year1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61835976000001L) + "'", long3 == (-61835976000001L));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint1 = null;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint1);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        xYLineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        java.awt.Font font9 = xYLineAndShapeRenderer2.getLegendTextFont((int) (byte) 1);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNull(font9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke5 = categoryPlot2.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image7 = null;
        combinedRangeXYPlot6.setBackgroundImage(image7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot6.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle10.getMargin();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke5, rectangleInsets11);
        categoryAxis0.setTickMarkStroke(stroke5);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(10);
        boolean boolean7 = periodAxis4.equals((java.lang.Object) 10);
        periodAxis4.setAxisLineVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = periodAxis4.getLabelInsets();
        categoryPlot0.setInsets(rectangleInsets10, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale7);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getCurrencyInstance(locale7);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ItemLabelAnchor.OUTSIDE1", numberFormat9, numberFormat10);
        java.util.Currency currency12 = null;
        try {
            numberFormat10.setCurrency(currency12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        java.awt.Stroke stroke3 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image5 = null;
        combinedRangeXYPlot4.setBackgroundImage(image5);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        combinedRangeXYPlot4.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = combinedRangeXYPlot4.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = combinedRangeXYPlot4.getRangeAxisIndex(valueAxis11);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot15.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        categoryPlot15.setRangeAxis(valueAxis18);
        boolean boolean20 = categoryPlot15.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis22.getCategoryLabelPositions();
        categoryPlot15.setDomainAxis(categoryAxis22);
        categoryAxis22.setTickMarksVisible(false);
        try {
            categoryPlot0.setDomainAxis((-2), categoryAxis22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TimePeriodAnchor.END");
        java.awt.Paint paint2 = standardChartTheme1.getLabelLinkPaint();
        java.awt.Font font3 = standardChartTheme1.getLargeFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) ' ', (double) '#', 0.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = barRenderer3D0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer3D0.getPlot();
        barRenderer3D0.setShadowXOffset((double) 100);
        barRenderer3D0.setIncludeBaseInRange(true);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainZoomable();
        categoryPlot12.clearDomainMarkers();
        boolean boolean15 = categoryPlot12.isSubplot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot12.zoomRangeAxes(0.0d, plotRenderingInfo18, point2D19, false);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = barRenderer3D0.initialise(graphics2D8, rectangle2D9, categoryPlot10, 8, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle4.getMargin();
        double double7 = rectangleInsets5.calculateBottomInset((double) 0);
        double double9 = rectangleInsets5.calculateTopOutset(0.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesVisible(2);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer6.setBaseShape(shape7, false);
        java.awt.Color color10 = java.awt.Color.gray;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color10);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint(8, (java.awt.Paint) color10, true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        try {
            int int3 = xYSeriesCollection1.getItemCount(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Polar Plot");
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        xYItemRendererState23.setProcessVisibleItemsOnly(true);
        int int26 = xYItemRendererState23.getFirstItemIndex();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = combinedRangeXYPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(10);
        boolean boolean6 = periodAxis3.equals((java.lang.Object) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getDomainCrosshairPaint();
        periodAxis3.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = periodAxis3.getFirst();
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis3);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale7);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getCurrencyInstance(locale7);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ItemLabelAnchor.OUTSIDE1", numberFormat9, numberFormat10);
        try {
            java.lang.Object obj13 = numberFormat10.parseObject("ClassContext");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("series");
        java.awt.Paint paint2 = periodAxis1.getTickMarkPaint();
        java.lang.Class class3 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis1.getStandardTickUnits();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) ' ', (double) '#', 0.0d);
        periodAxis1.setTickLabelInsets(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(tickUnitSource4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint2);
        java.lang.String str4 = categoryPlot0.getNoDataMessage();
        java.awt.Stroke stroke5 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean6 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.getLegendTextPaint(0);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities(0);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image9 = null;
        combinedRangeXYPlot8.setBackgroundImage(image9);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getDomainCrosshairPaint();
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12, timeZone13);
        int int15 = combinedRangeXYPlot8.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean19 = xYLineAndShapeRenderer18.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYLineAndShapeRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYLineAndShapeRenderer18.getPositiveItemLabelPosition((-1), 3, true);
        xYLineAndShapeRenderer18.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image32 = null;
        combinedRangeXYPlot31.setBackgroundImage(image32);
        java.awt.Paint paint34 = combinedRangeXYPlot31.getDomainCrosshairPaint();
        combinedRangeXYPlot31.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = combinedRangeXYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot31);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image39 = null;
        combinedRangeXYPlot38.setBackgroundImage(image39);
        java.awt.Stroke stroke41 = combinedRangeXYPlot38.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset43 = combinedRangeXYPlot38.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint49 = xYLineAndShapeRenderer47.getLegendTextPaint(0);
        combinedRangeXYPlot38.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer47);
        java.util.List list51 = combinedRangeXYPlot38.getSubplots();
        combinedRangeXYPlot38.setDomainCrosshairValue((double) '4', true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint57 = combinedRangeXYPlot56.getDomainCrosshairPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis59 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(10);
        periodAxis59.setFirst((org.jfree.data.time.RegularTimePeriod) year61);
        java.awt.Font font63 = periodAxis59.getLabelFont();
        combinedRangeXYPlot56.setRangeAxis((org.jfree.chart.axis.ValueAxis) periodAxis59);
        combinedRangeXYPlot38.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) periodAxis59, true);
        org.jfree.chart.axis.PeriodAxis periodAxis68 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(10);
        periodAxis68.setFirst((org.jfree.data.time.RegularTimePeriod) year70);
        java.lang.String str72 = periodAxis68.getLabelURL();
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection74 = new org.jfree.data.time.TimeSeriesCollection(timeZone73);
        boolean boolean76 = timeSeriesCollection74.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer78 = null;
        org.jfree.chart.plot.PolarPlot polarPlot79 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection74, valueAxis77, polarItemRenderer78);
        xYLineAndShapeRenderer18.drawItem(graphics2D28, xYItemRendererState29, rectangle2D30, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot31, (org.jfree.chart.axis.ValueAxis) periodAxis59, (org.jfree.chart.axis.ValueAxis) periodAxis68, (org.jfree.data.xy.XYDataset) timeSeriesCollection74, 0, (int) (short) 100, true, (int) '4');
        periodAxis68.setNegativeArrowVisible(true);
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        try {
            xYLineAndShapeRenderer2.fillDomainGridBand(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis68, rectangle2D87, 0.0d, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(xYDataset43);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer1.setBaseShape(shape2, false);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, (double) '#', 0.0f, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = periodAxis2.isMinorTickMarksVisible();
        java.util.Locale locale7 = periodAxis2.getLocale();
        java.text.NumberFormat numberFormat8 = java.text.NumberFormat.getPercentInstance(locale7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale7);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator10 = new org.jfree.chart.labels.StandardPieToolTipGenerator("TimePeriodAnchor.END", locale7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainCrosshairPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot0.getDataset();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot0.getDomainMarkers((-2), layer8);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.plot.Plot plot3 = waferMapPlot2.getParent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer6.setAutoPopulateSeriesPaint(false);
        java.awt.Color color10 = java.awt.Color.gray;
        int int11 = color10.getTransparency();
        xYLineAndShapeRenderer6.setBaseItemLabelPaint((java.awt.Paint) color10);
        try {
            plot3.setOutlinePaint((java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.0f);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYBarRenderer1.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        java.awt.Font font6 = xYBarRenderer1.getLegendTextFont(6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(font6);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image4 = null;
        combinedRangeXYPlot3.setBackgroundImage(image4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot3.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = combinedRangeXYPlot3.getDataset((int) (short) -1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        java.awt.Paint paint14 = xYLineAndShapeRenderer12.getLegendTextPaint(0);
        combinedRangeXYPlot3.setRenderer((int) (short) 10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean19 = timeSeriesCollection17.equals((java.lang.Object) 100.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        timeSeriesCollection17.seriesChanged(seriesChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, (org.jfree.data.xy.XYDataset) timeSeriesCollection17, plotRenderingInfo22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYAreaRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Font font29 = xYAreaRenderer25.getItemLabelFont(2, (int) (byte) 1, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = xYAreaRenderer25.getGradientTransformer();
        xYAreaRenderer0.setGradientTransformer(gradientPaintTransformer30);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(gradientPaintTransformer30);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        int int2 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 45.0d, true);
        xYSeries2.add((double) (short) 0, (double) (short) 0);
        java.util.List list6 = xYSeries2.getItems();
        try {
            xYSeries2.updateByIndex(1, (java.lang.Number) 8.64E7d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image1 = null;
        combinedRangeXYPlot0.setBackgroundImage(image1);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot5.setRangeAxis(valueAxis8);
        boolean boolean10 = categoryPlot5.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("{0}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = categoryAxis12.getCategoryLabelPositions();
        categoryPlot5.setDomainAxis(categoryAxis12);
        categoryPlot5.setRangeCrosshairValue((double) 10.0f, false);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot5.getDomainAxisLocation();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation18);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        combinedRangeXYPlot0.setDomainMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        try {
            java.lang.Number number6 = timeSeriesCollection1.getEndX(100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.DomainOrder domainOrder3 = defaultXYDataset2.getDomainOrder();
        boolean boolean4 = xYSeriesCollection1.equals((java.lang.Object) defaultXYDataset2);
        org.jfree.data.DomainOrder domainOrder5 = xYSeriesCollection1.getDomainOrder();
        org.junit.Assert.assertNotNull(domainOrder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(domainOrder5);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) (byte) 100, (java.lang.Number) 2.0d);
        defaultPieDataset0.setValue((java.lang.Comparable) (-1), (java.lang.Number) 9999);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        double double10 = piePlot3D8.getDepthFactor();
        double double11 = piePlot3D8.getMaximumExplodePercent();
        piePlot3D8.setBackgroundImageAlpha((float) (byte) 1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.12d + "'", double10 == 0.12d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) ' ', (double) '#', 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Image image6 = null;
        combinedRangeXYPlot5.setBackgroundImage(image6);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getDomainCrosshairPaint();
        combinedRangeXYPlot5.configureDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedRangeXYPlot5.getSeriesRenderingOrder();
        java.awt.Paint paint11 = combinedRangeXYPlot5.getRangeMinorGridlinePaint();
        boolean boolean12 = rectangleInsets4.equals((java.lang.Object) combinedRangeXYPlot5);
        double double14 = rectangleInsets4.calculateBottomOutset((double) (byte) 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        xYSeriesCollection1.setIntervalWidth((double) (byte) 10);
        xYSeriesCollection1.setAutoWidth(false);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, false);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("PieLabelLinkStyle.QUAD_CURVE");
        org.jfree.data.xy.XYDataset xYDataset9 = polarPlot6.getDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate10 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset9);
        try {
            intervalXYDelegate10.setFixedIntervalWidth((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'w' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(xYDataset9);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("series");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(10);
        boolean boolean5 = periodAxis2.equals((java.lang.Object) 10);
        boolean boolean6 = dateTickUnitType0.equals((java.lang.Object) periodAxis2);
        java.util.Locale locale7 = periodAxis2.getLocale();
        java.text.NumberFormat numberFormat8 = java.text.NumberFormat.getIntegerInstance(locale7);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(numberFormat8);
    }
}

