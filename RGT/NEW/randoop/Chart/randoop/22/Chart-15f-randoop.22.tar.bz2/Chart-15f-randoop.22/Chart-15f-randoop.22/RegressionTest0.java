import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color1 = java.awt.Color.darkGray;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getRGBColorComponents(floatArray2);
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = java.awt.Color.GREEN;
        float[] floatArray2 = new float[] { (-1) };
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) (-1), 0.0d, 0.0d, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toRangeWidth(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) multiplePiePlot2, true);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot7 = jFreeChart6.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Color color0 = java.awt.Color.darkGray;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray9 = new float[] { 0L, (byte) 10, (byte) 10, 0, (byte) 1 };
        try {
            float[] floatArray10 = color0.getComponents(colorSpace3, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) multiplePiePlot2, true);
        try {
            org.jfree.chart.title.Title title8 = jFreeChart6.getSubtitle((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.darkGray;
        float[] floatArray3 = null;
        float[] floatArray4 = color2.getRGBColorComponents(floatArray3);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray4);
        try {
            float[] floatArray6 = color0.getColorComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets2.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        try {
            polarPlot3.zoom((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getAngleLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        try {
            java.awt.Point point13 = polarPlot3.translateValueThetaRadiusToJava2D((double) 10L, (double) (short) 1, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("Other", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            float float5 = textFragment2.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.Color color15 = java.awt.Color.orange;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color15, stroke16, rectangleInsets17);
        double double20 = rectangleInsets17.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) '#', 0.0d, rectangleAnchor24);
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets17.createOutsetRectangle(rectangle2D25);
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color12.createContext(colorModel13, rectangle14, rectangle2D26, affineTransform27, renderingHints28);
        try {
            piePlot1.drawBackground(graphics2D11, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(paintContext29);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot3.zoomDomainAxes((double) 10L, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot3.zoomRangeAxes((double) 1, (double) (byte) 0, plotRenderingInfo10, point2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.Object obj10 = null;
        boolean boolean11 = projectInfo7.equals(obj10);
        java.lang.String str12 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.Object obj2 = piePlot1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        double double13 = rectangleInsets10.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) '#', 0.0d, rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets10.createOutsetRectangle(rectangle2D18);
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color5.createContext(colorModel6, rectangle7, rectangle2D19, affineTransform20, renderingHints21);
        try {
            lineBorder3.draw(graphics2D4, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(paintContext22);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 1L, (float) (short) 1, (float) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (short) 100, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) multiplePiePlot2, true);
        multiplePiePlot2.setNoDataMessage("hi!");
        java.lang.Object obj9 = multiplePiePlot2.clone();
        org.jfree.chart.util.TableOrder tableOrder10 = multiplePiePlot2.getDataExtractOrder();
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(tableOrder10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) multiplePiePlot2, true);
        org.jfree.chart.title.Title title8 = null;
        try {
            jFreeChart6.addSubtitle((int) (short) 1, title8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Other", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int3 = java.awt.Color.HSBtoRGB((float) 100L, (float) 0L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int9 = categoryPlot4.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot4.handleClick(100, (int) '#', plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.text.AttributedString attributedString3 = null;
        try {
            standardPieSectionLabelGenerator1.setAttributedLabel((-16777216), attributedString3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot3.setOutlineStroke(stroke5);
        java.awt.Image image7 = null;
        polarPlot3.setBackgroundImage(image7);
        org.jfree.chart.block.Arrangement arrangement9 = null;
        org.jfree.chart.block.Arrangement arrangement10 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot3, arrangement9, arrangement10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) (-16777216));
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot4.getRangeAxis(0);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        try {
            boolean boolean28 = categoryPlot4.removeRangeMarker(marker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot4.getDomainAxis();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(categoryAxis24);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) "RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color1 = java.awt.Color.getColor("ClassContext");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot4.getRangeAxis(0);
        org.jfree.chart.plot.Marker marker27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        try {
            boolean boolean29 = categoryPlot4.removeRangeMarker((int) (byte) 1, marker27, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelLinkStroke(stroke8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot1.setDataset(pieDataset10);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot18.getFixedDomainAxisSpace();
        int int20 = categoryPlot18.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot18.setDomainAxisLocation((int) (byte) 100, axisLocation22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot18.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder24);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(sortOrder24);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getPlotType();
        java.awt.Color color13 = java.awt.Color.orange;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color13, stroke14, rectangleInsets15);
        double double18 = rectangleInsets15.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) '#', 0.0d, rectangleAnchor22);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets15.createOutsetRectangle(rectangle2D23);
        try {
            java.awt.Point point25 = polarPlot3.translateValueThetaRadiusToJava2D((double) 0, 0.2d, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Polar Plot" + "'", str10.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) multiplePiePlot2, true);
        multiplePiePlot2.setNoDataMessage("hi!");
        java.lang.String str9 = multiplePiePlot2.getPlotType();
        java.lang.Comparable comparable10 = multiplePiePlot2.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (-16777216), (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("Other", font1);
        java.lang.String str3 = textFragment2.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Other" + "'", str3.equals("Other"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot4.addRangeMarker((int) (short) 10, marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = categoryPlot4.removeRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.text.AttributedString attributedString3 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel((int) (byte) 100, attributedString3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        try {
            java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset5, (java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double3 = rectangleConstraint2.getHeight();
        java.lang.String str4 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toFixedHeight((double) 100.0f);
        java.lang.Class<?> wildcardClass7 = rectangleConstraint2.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (java.lang.Class) wildcardClass7);
        java.lang.Class class9 = null;
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Polar Plot", (java.lang.Class) wildcardClass7, class9);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.clearAnnotations();
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        try {
            boolean boolean28 = categoryPlot4.removeRangeMarker((int) '#', marker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = polarPlot3.getRenderer();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(polarItemRenderer10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            java.awt.Color color1 = java.awt.Color.decode("ChartChangeEventType.GENERAL");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ChartChangeEventType.GENERAL\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight((double) 100.0f);
        java.lang.Class<?> wildcardClass5 = rectangleConstraint0.getClass();
        org.jfree.data.Range range6 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint0.toRangeHeight(range6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = categoryPlot4.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        categoryPlot4.setRangeAxisLocation((int) '#', axisLocation24);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Paint paint1 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        java.awt.Paint paint6 = polarPlot5.getAngleGridlinePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot5.setOutlineStroke(stroke7);
        java.awt.Color color9 = java.awt.Color.blue;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, paint1, stroke7, (java.awt.Paint) color9, stroke10, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        boolean boolean6 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot4.setDataset(0, categoryDataset9);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Color color10 = java.awt.Color.orange;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets12);
        double double15 = rectangleInsets12.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, (double) '#', 0.0d, rectangleAnchor19);
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets12.createOutsetRectangle(rectangle2D20);
        try {
            categoryPlot4.drawBackground(graphics2D9, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        try {
            numberAxis0.setRangeWithMargins((double) 10, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getPlotType();
        java.lang.Object obj11 = polarPlot3.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Polar Plot" + "'", str10.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets2);
        double double5 = rectangleInsets2.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) '#', 0.0d, rectangleAnchor9);
        java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets2.createOutsetRectangle(rectangle2D10);
        double double13 = rectangleInsets2.calculateRightOutset((double) (short) 0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.Object obj10 = null;
        boolean boolean11 = projectInfo7.equals(obj10);
        projectInfo7.setInfo("");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "Multiple Pie Plot", "hi!", "java.awt.Color[r=255,g=200,b=0]");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double3 = rectangleInsets0.getTop();
        double double4 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            numberAxis0.setTickLabelInsets(rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        double double10 = rectangleInsets7.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) '#', 0.0d, rectangleAnchor14);
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets7.createOutsetRectangle(rectangle2D15);
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color2.createContext(colorModel3, rectangle4, rectangle2D16, affineTransform17, renderingHints18);
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color2);
        int int21 = color2.getGreen();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color0 = java.awt.Color.orange;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.lang.String str2 = color0.toString();
        int int3 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str2.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "java.awt.Color[r=255,g=200,b=0]", "hi!", "hi!");
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = categoryPlot4.getDatasetRenderingOrder();
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            categoryPlot4.addRangeMarker(255, marker24, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Paint paint3 = blockBorder1.getPaint();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        int int8 = color7.getRed();
        java.awt.Color color9 = java.awt.Color.darkGray;
        float[] floatArray10 = null;
        float[] floatArray11 = color9.getRGBColorComponents(floatArray10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray11);
        float[] floatArray13 = color7.getRGBColorComponents(floatArray11);
        piePlot5.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color7);
        java.awt.Stroke stroke15 = piePlot5.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateRightOutset((double) 10.0f);
        double double19 = rectangleInsets16.getTop();
        java.lang.String str20 = rectangleInsets16.toString();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint3, stroke15, rectangleInsets16);
        java.awt.Paint paint22 = lineBorder21.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str20.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = null;
        boolean boolean2 = paintMap0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = null;
        try {
            categoryPlot4.setDomainGridlinePosition(categoryAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener3 = null;
        jFreeChart2.addProgressListener(chartProgressListener3);
        jFreeChart2.setTextAntiAlias(false);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        try {
            jFreeChart2.draw(graphics2D7, rectangle2D8, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 45.0d, (double) (short) 10);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        boolean boolean6 = columnArrangement4.equals((java.lang.Object) paint5);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart3, 192, (int) ' ');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        try {
            jFreeChart3.handleClick((-1), (int) (short) 1, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", graphics2D1, (float) 255, (float) 1, (double) 0.0f, (float) 1L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Color color18 = java.awt.Color.orange;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke19, rectangleInsets20);
        double double23 = rectangleInsets20.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', 0.0d, rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets20.createOutsetRectangle(rectangle2D28);
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        categoryPlot16.draw(graphics2D17, rectangle2D28, point2D30, plotState31, plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        categoryPlot4.draw(graphics2D11, rectangle2D28, point2D34, plotState35, plotRenderingInfo36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font41 = numberAxis40.getTickLabelFont();
        numberAxis40.centerRange((double) ' ');
        try {
            categoryPlot4.setRangeAxis((-8355712), (org.jfree.chart.axis.ValueAxis) numberAxis40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(font41);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ClassContext", graphics2D1, (float) 192, (float) 2, textAnchor4, (-1.0d), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        boolean boolean14 = categoryPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Color color14 = java.awt.Color.orange;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets16);
        double double19 = rectangleInsets16.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D24 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (double) '#', 0.0d, rectangleAnchor23);
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets16.createOutsetRectangle(rectangle2D24);
        java.awt.geom.Point2D point2D26 = null;
        org.jfree.chart.plot.PlotState plotState27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        categoryPlot12.draw(graphics2D13, rectangle2D24, point2D26, plotState27, plotRenderingInfo28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            java.util.List list31 = numberAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D24, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Stroke stroke3 = null;
        multiplePiePlot0.setOutlineStroke(stroke3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        java.awt.Paint paint8 = blockBorder6.getPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        int int13 = color12.getRed();
        java.awt.Color color14 = java.awt.Color.darkGray;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getRGBColorComponents(floatArray15);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray16);
        float[] floatArray18 = color12.getRGBColorComponents(floatArray16);
        piePlot10.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color12);
        java.awt.Stroke stroke20 = piePlot10.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double23 = rectangleInsets21.calculateRightOutset((double) 10.0f);
        double double24 = rectangleInsets21.getTop();
        java.lang.String str25 = rectangleInsets21.toString();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder(paint8, stroke20, rectangleInsets21);
        multiplePiePlot0.setInsets(rectangleInsets21, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 192 + "'", int13 == 192);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str25.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot3.getAxis();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Polar Plot" + "'", str10.equals("Polar Plot"));
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = categoryPlot4.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range3, lengthConstraintType4, (double) (short) 0, range6, lengthConstraintType7);
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range15 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range12, lengthConstraintType13, (double) (short) 0, range15, lengthConstraintType16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) 1, range1, lengthConstraintType7, (double) 100L, range10, lengthConstraintType13);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight((double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint0.toFixedHeight((double) (-16777216));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint0.toFixedWidth((double) (byte) 10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = rectangleConstraint0.getWidthConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
        java.lang.String str8 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomRangeAxes((double) 8, plotRenderingInfo9, point2D10, false);
        categoryPlot4.mapDatasetToDomainAxis((int) '#', (int) (short) -1);
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot4.getDatasetGroup();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNull(datasetGroup16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes((double) (-1.0f), plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str1.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int9 = categoryPlot4.getDatasetCount();
        boolean boolean10 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            categoryPlot4.addDomainMarker(0, categoryMarker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("ClassContext", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.Color color13 = java.awt.Color.orange;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color13, stroke14, rectangleInsets15);
        double double18 = rectangleInsets15.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) '#', 0.0d, rectangleAnchor22);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets15.createOutsetRectangle(rectangle2D23);
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color10.createContext(colorModel11, rectangle12, rectangle2D24, affineTransform25, renderingHints26);
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.plot.PlotState plotState29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            categoryPlot4.draw(graphics2D9, (java.awt.geom.Rectangle2D) rectangle12, point2D28, plotState29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(paintContext27);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot4.getRangeAxis(0);
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        try {
            boolean boolean33 = categoryPlot4.removeDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker31, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) rectangleEdge1);
        java.lang.String str3 = chartChangeEventType0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace10);
        boolean boolean12 = chartChangeEventType0.equals((java.lang.Object) axisSpace10);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str3.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Rotation.ANTICLOCKWISE", graphics2D1, 0.0f, (float) 1, textAnchor4, (double) '#', textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Color color18 = java.awt.Color.orange;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke19, rectangleInsets20);
        double double23 = rectangleInsets20.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', 0.0d, rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets20.createOutsetRectangle(rectangle2D28);
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        categoryPlot16.draw(graphics2D17, rectangle2D28, point2D30, plotState31, plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        categoryPlot4.draw(graphics2D11, rectangle2D28, point2D34, plotState35, plotRenderingInfo36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot42.getFixedDomainAxisSpace();
        int int44 = categoryPlot42.getWeight();
        java.awt.Color color45 = java.awt.Color.darkGray;
        categoryPlot42.setRangeCrosshairPaint((java.awt.Paint) color45);
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color45);
        double double48 = categoryPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color2 = java.awt.Color.getColor("Polar Plot", 255);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getNoDataMessage();
        polarPlot3.setNoDataMessage("");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot3.setRadiusGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot3);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.Color color19 = java.awt.Color.orange;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color19, stroke20, rectangleInsets21);
        double double24 = rectangleInsets21.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D25 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) '#', 0.0d, rectangleAnchor28);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets21.createOutsetRectangle(rectangle2D29);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot(xYDataset32, valueAxis33, polarItemRenderer34);
        java.awt.Paint paint36 = polarPlot35.getAngleGridlinePaint();
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot35.setOutlineStroke(stroke37);
        ringPlot31.setSeparatorStroke(stroke37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.PiePlotState piePlotState42 = ringPlot17.initialise(graphics2D18, rectangle2D30, (org.jfree.chart.plot.PiePlot) ringPlot31, (java.lang.Integer) 255, plotRenderingInfo41);
        try {
            legendTitle15.draw(graphics2D16, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(piePlotState42);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("Multiple Pie Plot", font2);
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textLine5.calculateDimensions(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot5.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double3 = rectangleInsets0.getTop();
        java.lang.String str4 = rectangleInsets0.toString();
        double double6 = rectangleInsets0.calculateLeftOutset((double) (short) 100);
        double double8 = rectangleInsets0.calculateTopOutset((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str4.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Color color18 = java.awt.Color.orange;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke19, rectangleInsets20);
        double double23 = rectangleInsets20.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', 0.0d, rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets20.createOutsetRectangle(rectangle2D28);
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        categoryPlot16.draw(graphics2D17, rectangle2D28, point2D30, plotState31, plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        categoryPlot4.draw(graphics2D11, rectangle2D28, point2D34, plotState35, plotRenderingInfo36);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        valueMarker39.notifyListeners(markerChangeEvent40);
        org.jfree.chart.util.Layer layer42 = null;
        try {
            boolean boolean43 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker39, layer42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot4.setRenderer(categoryItemRenderer9);
        java.awt.Paint paint11 = categoryPlot4.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        boolean boolean5 = polarPlot3.isRadiusGridlinesVisible();
        polarPlot3.removeCornerTextItem("Other");
        org.jfree.chart.axis.ValueAxis valueAxis8 = polarPlot3.getAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            polarPlot3.zoomRangeAxes(90.0d, plotRenderingInfo10, point2D11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", graphics2D1, 0.5f, 1.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis0.getTickLabelInsets();
        double double8 = rectangleInsets6.extendWidth((double) '#');
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 43.0d + "'", double8 == 43.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getRadiusGridlinePaint();
        org.jfree.chart.axis.TickUnit tickUnit5 = polarPlot3.getAngleTickUnit();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = polarPlot3.getRenderer();
        boolean boolean7 = polarPlot3.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(tickUnit5);
        org.junit.Assert.assertNull(polarItemRenderer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        java.awt.Paint paint4 = piePlot1.getLabelOutlinePaint();
        java.awt.Paint paint5 = piePlot1.getBackgroundPaint();
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("", font7, (java.awt.Paint) color8);
        piePlot1.setLabelShadowPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ClassContext", "ChartChangeEventType.GENERAL");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getEmail();
        java.lang.String str5 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str3.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str4.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ClassContext" + "'", str5.equals("ClassContext"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        int int11 = categoryPlot9.getWeight();
        java.awt.Color color12 = java.awt.Color.darkGray;
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color12);
        int int14 = categoryPlot9.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("Multiple Pie Plot", font2, (org.jfree.chart.plot.Plot) categoryPlot9, false);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart16.getLegend((int) (byte) 100);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(legendTitle18);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Font font11 = piePlot1.getLabelFont();
        java.awt.Stroke stroke12 = piePlot1.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        boolean boolean24 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        boolean boolean5 = polarPlot3.isRadiusGridlinesVisible();
        polarPlot3.removeCornerTextItem("Other");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot14.getFixedDomainAxisSpace();
        int int16 = categoryPlot14.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot14.setDomainAxisLocation((int) (byte) 100, axisLocation18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot14.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.Color color28 = java.awt.Color.orange;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color28, stroke29, rectangleInsets30);
        double double33 = rectangleInsets30.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) '#', 0.0d, rectangleAnchor37);
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets30.createOutsetRectangle(rectangle2D38);
        java.awt.geom.Point2D point2D40 = null;
        org.jfree.chart.plot.PlotState plotState41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        categoryPlot26.draw(graphics2D27, rectangle2D38, point2D40, plotState41, plotRenderingInfo42);
        java.awt.geom.Point2D point2D44 = null;
        org.jfree.chart.plot.PlotState plotState45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        categoryPlot14.draw(graphics2D21, rectangle2D38, point2D44, plotState45, plotRenderingInfo46);
        try {
            java.awt.Point point48 = polarPlot3.translateValueThetaRadiusToJava2D((double) (byte) 0, (double) '4', rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Rotation.ANTICLOCKWISE", graphics2D1, (float) (short) 10, (float) (byte) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getAngleLabelFont();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        int int6 = color5.getRed();
        polarPlot3.setAngleGridlinePaint((java.awt.Paint) color5);
        int int8 = polarPlot3.getSeriesCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint10 = multiplePiePlot9.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot9.getPieChart();
        java.awt.Stroke stroke12 = jFreeChart11.getBorderStroke();
        polarPlot3.setRadiusGridlineStroke(stroke12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        try {
            polarPlot3.zoomRangeAxes(8.0d, plotRenderingInfo15, point2D16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 192 + "'", int6 == 192);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean1 = multiplePiePlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Shape shape6 = piePlot5.getLegendItemShape();
        java.awt.Paint paint7 = piePlot5.getLabelShadowPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot5.getToolTipGenerator();
        boolean boolean9 = piePlot5.isCircular();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) piePlot5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot4.getRangeAxis(0);
        categoryPlot4.setDrawSharedDomainAxis(true);
        boolean boolean28 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        categoryPlot4.setDataset(0, categoryDataset30);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) dateTickUnit3);
        java.lang.Object obj5 = standardPieSectionLabelGenerator1.clone();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        try {
            java.text.AttributedString attributedString8 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset6, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        double double6 = numberAxis0.getLowerBound();
        org.jfree.data.Range range7 = null;
        try {
            numberAxis0.setRange(range7, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat3 = numberAxis2.getNumberFormatOverride();
        numberAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint10 = multiplePiePlot9.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot9.getPieChart();
        java.awt.Stroke stroke12 = null;
        multiplePiePlot9.setOutlineStroke(stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightOutset((double) 10.0f);
        double double18 = rectangleInsets14.extendWidth((double) 10.0f);
        double double19 = rectangleInsets14.getRight();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.Color color23 = java.awt.Color.orange;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color23, stroke24, rectangleInsets25);
        double double28 = rectangleInsets25.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, (double) '#', 0.0d, rectangleAnchor32);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets25.createOutsetRectangle(rectangle2D33);
        java.awt.geom.AffineTransform affineTransform35 = null;
        java.awt.RenderingHints renderingHints36 = null;
        java.awt.PaintContext paintContext37 = color20.createContext(colorModel21, rectangle22, rectangle2D34, affineTransform35, renderingHints36);
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets14.createOutsetRectangle(rectangle2D34, true, true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean43 = chartChangeEventType41.equals((java.lang.Object) rectangleEdge42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = numberAxis2.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) multiplePiePlot9, rectangle2D34, rectangleEdge42, axisSpace44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 16.0d + "'", double18 == 16.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(paintContext37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(chartChangeEventType41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        boolean boolean4 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        piePlot1.setLabelPaint(paint5);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getRadiusGridlinePaint();
        boolean boolean5 = polarPlot3.isAngleLabelsVisible();
        boolean boolean6 = polarPlot3.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        paintMap0.clear();
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
        java.lang.String str8 = projectInfo7.getVersion();
        java.lang.String str9 = projectInfo7.toString();
        org.jfree.chart.text.TextBlock textBlock10 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint13 = multiplePiePlot12.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart14 = multiplePiePlot12.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart14, 192, (int) ' ');
        int int18 = chartProgressEvent17.getType();
        boolean boolean19 = textBlock10.equals((java.lang.Object) chartProgressEvent17);
        java.util.List list20 = textBlock10.getLines();
        projectInfo7.setContributors(list20);
        org.jfree.chart.ui.Library[] libraryArray22 = projectInfo7.getLibraries();
        org.jfree.chart.ui.Library library23 = null;
        try {
            projectInfo7.addLibrary(library23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n" + "'", str9.equals(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(jFreeChart14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 192 + "'", int18 == 192);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(libraryArray22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, (double) 8, 0.0d, (double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createInsetRectangle(rectangle2D6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        boolean boolean13 = standardPieSectionLabelGenerator1.equals((java.lang.Object) polarPlot6);
        boolean boolean14 = polarPlot6.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.TOP" + "'", str2.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.plot.Plot plot8 = piePlot1.getRootPlot();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = numberAxis1.getTickLabelFont();
        boolean boolean3 = numberAxis1.isAutoRange();
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer6);
        try {
            numberAxis1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        java.awt.Paint paint6 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setLabelOutlinePaint(paint6);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment36, verticalAlignment37, (double) 100L, (double) (byte) 10);
        columnArrangement40.clear();
        org.jfree.chart.block.BlockContainer blockContainer42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement40);
        org.jfree.chart.block.Arrangement arrangement43 = blockContainer42.getArrangement();
        legendTitle18.setWrapper(blockContainer42);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color46 = java.awt.Color.darkGray;
        float[] floatArray47 = null;
        float[] floatArray48 = color46.getRGBColorComponents(floatArray47);
        java.awt.image.ColorModel colorModel49 = null;
        java.awt.Rectangle rectangle50 = null;
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis53, categoryItemRenderer54);
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.Color color57 = java.awt.Color.orange;
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder60 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color57, stroke58, rectangleInsets59);
        double double62 = rectangleInsets59.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D63 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D67 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D63, (double) '#', 0.0d, rectangleAnchor66);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets59.createOutsetRectangle(rectangle2D67);
        java.awt.geom.Point2D point2D69 = null;
        org.jfree.chart.plot.PlotState plotState70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        categoryPlot55.draw(graphics2D56, rectangle2D67, point2D69, plotState70, plotRenderingInfo71);
        java.awt.geom.AffineTransform affineTransform73 = null;
        java.awt.RenderingHints renderingHints74 = null;
        java.awt.PaintContext paintContext75 = color46.createContext(colorModel49, rectangle50, rectangle2D67, affineTransform73, renderingHints74);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment76 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment77 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement80 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment76, verticalAlignment77, (double) 100L, (double) (byte) 10);
        columnArrangement80.clear();
        org.jfree.chart.block.BlockContainer blockContainer82 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement80);
        org.jfree.chart.block.Block block83 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor84 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        columnArrangement80.add(block83, (java.lang.Object) textBlockAnchor84);
        try {
            java.lang.Object obj86 = blockContainer42.draw(graphics2D45, (java.awt.geom.Rectangle2D) rectangle50, (java.lang.Object) block83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(arrangement43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 3.0d + "'", double62 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(paintContext75);
        org.junit.Assert.assertNotNull(textBlockAnchor84);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        numberAxis0.setRangeWithMargins((double) 0L, (double) (byte) 1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range1, lengthConstraintType2, (double) (short) 0, range4, lengthConstraintType5);
        org.jfree.data.Range range7 = rectangleConstraint6.getHeightRange();
        org.jfree.data.Range range8 = rectangleConstraint6.getWidthRange();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", font1, (java.awt.Paint) color2, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color3 = java.awt.Color.orange;
        java.lang.Class<?> wildcardClass4 = color3.getClass();
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ChartChangeEventType.GENERAL", (java.lang.Class) wildcardClass4);
        try {
            java.util.EventListener[] eventListenerArray6 = valueMarker1.getListeners((java.lang.Class) wildcardClass4);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(inputStream5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            java.awt.Color color1 = java.awt.Color.decode(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("Other", font1);
        float float3 = textFragment2.getBaselineOffset();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = null;
        try {
            textFragment2.draw(graphics2D4, (float) (-1), 0.0f, textAnchor7, 2.0f, (float) '4', (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getRadiusGridlinePaint();
        org.jfree.chart.axis.TickUnit tickUnit5 = polarPlot3.getAngleTickUnit();
        boolean boolean6 = polarPlot3.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(tickUnit5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart3, 192, (int) ' ');
        jFreeChart3.setTitle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint9 = jFreeChart3.getBorderPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart3.getPadding();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Color color12 = java.awt.Color.orange;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color12, stroke13, rectangleInsets14);
        double double17 = rectangleInsets14.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D18 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, (double) '#', 0.0d, rectangleAnchor21);
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets14.createOutsetRectangle(rectangle2D22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean26 = chartChangeEventType24.equals((java.lang.Object) rectangleEdge25);
        java.lang.String str27 = rectangleEdge25.toString();
        double double28 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D23, rectangleEdge25);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        try {
            jFreeChart3.draw(graphics2D11, rectangle2D23, chartRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleEdge.TOP" + "'", str27.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-3.0d) + "'", double28 == (-3.0d));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator6);
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        double double10 = piePlot1.getExplodePercent((java.lang.Comparable) 3.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        java.awt.Color color6 = java.awt.Color.darkGray;
        float[] floatArray7 = null;
        float[] floatArray8 = color6.getRGBColorComponents(floatArray7);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Color color0 = java.awt.Color.darkGray;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray2);
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartChangeEvent3, (java.lang.Object) 1L);
        java.lang.String str6 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) rectangleEdge8);
        java.lang.String str10 = chartChangeEventType7.toString();
        chartChangeEvent3.setType(chartChangeEventType7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str10.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        double double26 = piePlotState25.getPieCenterY();
        piePlotState25.setLatestAngle((double) (-1));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        categoryPlot4.configureRangeAxes();
        categoryPlot4.setRangeCrosshairValue((double) (short) 0, true);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("", font3, (java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot10.getFixedDomainAxisSpace();
        int int12 = categoryPlot10.getWeight();
        java.awt.Color color13 = java.awt.Color.darkGray;
        categoryPlot10.setRangeCrosshairPaint((java.awt.Paint) color13);
        int int15 = categoryPlot10.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("Multiple Pie Plot", font3, (org.jfree.chart.plot.Plot) categoryPlot10, false);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Paint paint20 = valueMarker19.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("", font3, paint20);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener3 = null;
        jFreeChart2.addProgressListener(chartProgressListener3);
        jFreeChart2.setTextAntiAlias(false);
        java.lang.Object obj7 = jFreeChart2.getTextAntiAlias();
        jFreeChart2.setBackgroundImageAlpha((float) 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, (double) 8, 0.0d, (double) (short) 10);
        double double7 = rectangleInsets5.calculateBottomOutset(1.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) (byte) 10);
        columnArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Paint paint11 = polarPlot10.getAngleGridlinePaint();
        boolean boolean12 = polarPlot10.isRadiusGridlinesVisible();
        boolean boolean13 = columnArrangement4.equals((java.lang.Object) boolean12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) columnArrangement4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomRangeAxes((double) 8, plotRenderingInfo9, point2D10, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot4.setOrientation(plotOrientation13);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(plotOrientation13);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 0, (float) (-8355712), (float) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot3.zoomDomainAxes((double) 10, plotRenderingInfo5, point2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = polarPlot3.getDataset();
        try {
            double double9 = polarPlot3.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        double double5 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.14d + "'", double5 == 0.14d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Shape shape11 = piePlot10.getLegendItemShape();
        java.awt.Paint paint12 = piePlot10.getLabelShadowPaint();
        boolean boolean13 = piePlot10.getIgnoreNullValues();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) piePlot10);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Paint paint17 = valueMarker16.getOutlinePaint();
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        int int19 = color18.getRed();
        valueMarker16.setOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.util.Layer layer21 = null;
        try {
            boolean boolean22 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker16, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 192 + "'", int19 == 192);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Stroke stroke3 = jFreeChart2.getBorderStroke();
        try {
            org.jfree.chart.plot.XYPlot xYPlot4 = jFreeChart2.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) dateTickUnit3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        try {
            java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset5, (java.lang.Comparable) 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        java.lang.Object obj3 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.TOP" + "'", str2.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        int int11 = categoryPlot9.getWeight();
        java.awt.Color color12 = java.awt.Color.darkGray;
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color12);
        int int14 = categoryPlot9.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("Multiple Pie Plot", font2, (org.jfree.chart.plot.Plot) categoryPlot9, false);
        java.lang.Object obj17 = jFreeChart16.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.equals((java.lang.Object) 16.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        java.awt.Color color4 = java.awt.Color.darkGray;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getRGBColorComponents(floatArray5);
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.Color color15 = java.awt.Color.orange;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color15, stroke16, rectangleInsets17);
        double double20 = rectangleInsets17.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) '#', 0.0d, rectangleAnchor24);
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets17.createOutsetRectangle(rectangle2D25);
        java.awt.geom.Point2D point2D27 = null;
        org.jfree.chart.plot.PlotState plotState28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        categoryPlot13.draw(graphics2D14, rectangle2D25, point2D27, plotState28, plotRenderingInfo29);
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color4.createContext(colorModel7, rectangle8, rectangle2D25, affineTransform31, renderingHints32);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean36 = chartChangeEventType34.equals((java.lang.Object) rectangleEdge35);
        java.lang.String str37 = rectangleEdge35.toString();
        boolean boolean38 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge35);
        try {
            double double39 = categoryAxis0.getCategoryMiddle((int) (byte) 1, (int) (byte) 1, (java.awt.geom.Rectangle2D) rectangle8, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleEdge.TOP" + "'", str37.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Multiple Pie Plot", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Stroke stroke11 = piePlot1.getLabelOutlineStroke();
        double double12 = piePlot1.getMaximumLabelWidth();
        piePlot1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.14d + "'", double12 == 0.14d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        double double8 = piePlot1.getLabelGap();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(1.0d);
        categoryAxis0.setCategoryMargin((double) (byte) 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint3 = valueMarker1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double7 = rectangleInsets4.getTop();
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double12 = rectangleInsets4.calculateTopOutset((double) 255);
        textTitle1.setMargin(rectangleInsets4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle1.getTextAlignment();
        java.lang.String str15 = textTitle1.getToolTipText();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        try {
            double double5 = polarPlot3.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        jFreeChart2.setBackgroundImageAlignment(100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSectionDepth((double) '4');
        java.awt.Stroke stroke4 = ringPlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        double double26 = piePlotState25.getPieCenterY();
        double double27 = piePlotState25.getPieHRadius();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", image3, "Other", "", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getVersion();
        java.lang.String str10 = projectInfo7.getLicenceName();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Font font11 = piePlot1.getLabelFont();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot1.setURLGenerator(pieURLGenerator12);
        org.jfree.data.general.PieDataset pieDataset14 = piePlot1.getDataset();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(pieDataset14);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.Object obj10 = null;
        boolean boolean11 = projectInfo7.equals(obj10);
        java.util.List list12 = null;
        projectInfo7.setContributors(list12);
        projectInfo7.setName("Polar Plot");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double3 = rectangleInsets0.getTop();
        java.lang.String str4 = rectangleInsets0.toString();
        double double6 = rectangleInsets0.calculateLeftOutset((double) (short) 100);
        double double8 = rectangleInsets0.calculateLeftOutset((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str4.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) rectangleEdge1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getRadiusGridlinePaint();
        boolean boolean8 = chartChangeEventType0.equals((java.lang.Object) polarPlot6);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Stroke stroke11 = piePlot1.getLabelOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot1.setDataset(pieDataset12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot18.getFixedDomainAxisSpace();
        int int20 = categoryPlot18.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot18.setDomainAxisLocation((int) (byte) 100, axisLocation22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot18.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.Color color32 = java.awt.Color.orange;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder35 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color32, stroke33, rectangleInsets34);
        double double37 = rectangleInsets34.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D38 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, (double) '#', 0.0d, rectangleAnchor41);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets34.createOutsetRectangle(rectangle2D42);
        java.awt.geom.Point2D point2D44 = null;
        org.jfree.chart.plot.PlotState plotState45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        categoryPlot30.draw(graphics2D31, rectangle2D42, point2D44, plotState45, plotRenderingInfo46);
        java.awt.geom.Point2D point2D48 = null;
        org.jfree.chart.plot.PlotState plotState49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        categoryPlot18.draw(graphics2D25, rectangle2D42, point2D48, plotState49, plotRenderingInfo50);
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, valueAxis54, categoryItemRenderer55);
        org.jfree.chart.axis.AxisSpace axisSpace57 = categoryPlot56.getFixedDomainAxisSpace();
        int int58 = categoryPlot56.getWeight();
        java.awt.Color color59 = java.awt.Color.darkGray;
        categoryPlot56.setRangeCrosshairPaint((java.awt.Paint) color59);
        categoryPlot18.setRangeGridlinePaint((java.awt.Paint) color59);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        categoryPlot18.setInsets(rectangleInsets62, false);
        piePlot1.setSimpleLabelOffset(rectangleInsets62);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.0d + "'", double37 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNull(axisSpace57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes((double) (-1.0f), plotRenderingInfo9, point2D10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot16.getFixedDomainAxisSpace();
        int int18 = categoryPlot16.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot16.setDomainAxisLocation((int) (byte) 100, axisLocation20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot16.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder22);
        java.awt.Paint paint24 = categoryPlot4.getOutlinePaint();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color25);
        categoryPlot4.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        double double31 = numberAxis30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font34 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("", font34, (java.awt.Paint) color35);
        numberAxis32.setTickLabelFont(font34);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis32.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot39 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot40 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot39.setParent((org.jfree.chart.plot.Plot) multiplePiePlot40);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        java.awt.Shape shape44 = piePlot43.getLegendItemShape();
        boolean boolean45 = piePlot43.getSimpleLabels();
        piePlot43.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double50 = rectangleInsets48.calculateRightOutset((double) 10.0f);
        piePlot43.setSimpleLabelOffset(rectangleInsets48);
        boolean boolean52 = multiplePiePlot39.equals((java.lang.Object) piePlot43);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double55 = rectangleInsets53.calculateRightOutset((double) 10.0f);
        double double57 = rectangleInsets53.extendWidth((double) (byte) 10);
        double double59 = rectangleInsets53.calculateBottomOutset((double) 2);
        multiplePiePlot39.setInsets(rectangleInsets53);
        numberAxis32.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot39);
        float float62 = numberAxis32.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer63);
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot64.getDomainAxisLocation(0);
        try {
            categoryPlot4.setDomainAxisLocation((int) (short) -1, axisLocation66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 3.0d + "'", double50 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.0d + "'", double55 == 3.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 16.0d + "'", double57 == 16.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 3.0d + "'", double59 == 3.0d);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 0.0f + "'", float62 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation66);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.block.BlockContainer blockContainer38 = legendTitle18.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement39 = blockContainer38.getArrangement();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockContainer38);
        org.junit.Assert.assertNotNull(arrangement39);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes((double) (-1.0f), plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot4.zoomDomainAxes((-3.0d), 0.0d, plotRenderingInfo14, point2D15);
        categoryPlot4.clearDomainAxes();
        org.junit.Assert.assertNull(axisSpace5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getRangeAxis();
        boolean boolean42 = xYPlot35.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.gray;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color2);
        int int4 = color2.getGreen();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean6 = chartChangeEventType4.equals((java.lang.Object) rectangleEdge5);
        java.awt.Paint paint7 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean8 = rectangleEdge5.equals((java.lang.Object) paint7);
        try {
            double double9 = categoryAxis0.getCategoryStart((int) '4', (-1), rectangle2D3, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        java.awt.Color color2 = java.awt.Color.cyan;
        boolean boolean3 = rotation0.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation41 = null;
        try {
            boolean boolean42 = xYPlot35.removeAnnotation(xYAnnotation41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot3.setOutlineStroke(stroke5);
        java.awt.Image image7 = null;
        polarPlot3.setBackgroundImage(image7);
        java.awt.Color color9 = java.awt.Color.orange;
        java.lang.Class<?> wildcardClass10 = color9.getClass();
        java.lang.String str11 = color9.toString();
        polarPlot3.setAngleGridlinePaint((java.awt.Paint) color9);
        java.awt.Stroke stroke13 = polarPlot3.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str11.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        double double4 = piePlot1.getStartAngle();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str6 = categoryAxis5.getLabelURL();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint9 = multiplePiePlot8.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart10 = multiplePiePlot8.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart10, 192, (int) ' ');
        jFreeChart10.setTitle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint16 = jFreeChart10.getBorderPaint();
        boolean boolean17 = categoryAxis5.equals((java.lang.Object) paint16);
        piePlot1.setBaseSectionPaint(paint16);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(jFreeChart10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Shape shape12 = piePlot11.getLegendItemShape();
        java.awt.Paint paint13 = piePlot11.getLabelShadowPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = piePlot11.getToolTipGenerator();
        org.jfree.chart.plot.Plot plot15 = piePlot11.getRootPlot();
        boolean boolean16 = categoryPlot4.equals((java.lang.Object) piePlot11);
        java.awt.Image image17 = categoryPlot4.getBackgroundImage();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(pieToolTipGenerator14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(image17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        boolean boolean5 = polarPlot3.isRadiusGridlinesVisible();
        polarPlot3.removeCornerTextItem("Other");
        boolean boolean8 = polarPlot3.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot13.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        categoryPlot13.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot13.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot13.setDataset(categoryDataset18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot13.getAxisOffset();
        polarPlot3.setInsets(rectangleInsets20, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(1.0d);
        double double3 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot4.getRangeAxis(0);
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot4.zoomDomainAxes(0.14d, plotRenderingInfo30, point2D31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot4.getAxisOffset();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        categoryPlot4.setDrawSharedDomainAxis(true);
        categoryPlot4.clearAnnotations();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Pie Plot", "ChartChangeEventType.GENERAL", "", "", "Other");
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.Color color7 = java.awt.Color.orange;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets9);
        double double12 = rectangleInsets9.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) '#', 0.0d, rectangleAnchor16);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets9.createOutsetRectangle(rectangle2D17);
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color4.createContext(colorModel5, rectangle6, rectangle2D18, affineTransform19, renderingHints20);
        textTitle1.draw(graphics2D3, (java.awt.geom.Rectangle2D) rectangle6);
        java.awt.Paint paint23 = textTitle1.getBackgroundPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        java.awt.Shape shape27 = piePlot26.getLegendItemShape();
        java.awt.Paint paint28 = piePlot26.getLabelShadowPaint();
        piePlot26.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis24.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot26);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator33 = null;
        piePlot26.setToolTipGenerator(pieToolTipGenerator33);
        boolean boolean35 = textTitle1.equals((java.lang.Object) pieToolTipGenerator33);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight((double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint0.toFixedHeight((double) (-16777216));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint0.toFixedHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart3, 192, (int) ' ');
        jFreeChart3.setTitle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint9 = jFreeChart3.getBorderPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart3.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart3.getPadding();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (-3.0d), 0.0d, (-16777216), (java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getNoDataMessage();
        polarPlot3.setNoDataMessage("");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot3.setRadiusGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot3);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle15.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double19 = rectangleConstraint18.getHeight();
        java.lang.String str20 = rectangleConstraint18.toString();
        org.jfree.chart.util.Size2D size2D21 = legendTitle15.arrange(graphics2D17, rectangleConstraint18);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str20.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(size2D21);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getAngleLabelFont();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        boolean boolean9 = polarPlot3.equals((java.lang.Object) floatArray7);
        org.jfree.chart.axis.TickUnit tickUnit10 = polarPlot3.getAngleTickUnit();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(tickUnit10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) (byte) 10);
        columnArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        blockContainer6.setPadding((double) 1L, 16.0d, 90.0d, (double) (short) -1);
        blockContainer6.setMargin(0.2d, (double) (byte) 0, 0.14d, (double) (short) 10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setInteriorGap(0.0d);
        java.awt.Paint paint8 = piePlot1.getShadowPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        boolean boolean14 = categoryPlot4.getDrawSharedDomainAxis();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        categoryPlot4.setDrawSharedDomainAxis(true);
        boolean boolean24 = categoryPlot4.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator2.setAttributedLabel((int) (byte) 100, attributedString4);
        ringPlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        java.awt.color.ColorSpace colorSpace9 = null;
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        int int11 = color10.getRed();
        java.awt.Color color12 = java.awt.Color.darkGray;
        float[] floatArray13 = null;
        float[] floatArray14 = color12.getRGBColorComponents(floatArray13);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray14);
        float[] floatArray16 = color10.getRGBColorComponents(floatArray14);
        try {
            float[] floatArray17 = color7.getComponents(colorSpace9, floatArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot35.getRangeAxisEdge(0);
        xYPlot35.setDomainZeroBaselineVisible(false);
        try {
            java.awt.Paint paint46 = xYPlot35.getQuadrantPaint(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (255) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart3, 192, (int) ' ');
        chartProgressEvent6.setPercent(8);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            boolean boolean26 = categoryPlot4.removeRangeMarker(marker24, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Shape shape8 = piePlot7.getLegendItemShape();
        boolean boolean9 = piePlot7.getSimpleLabels();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        piePlot7.markerChanged(markerChangeEvent10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        piePlot7.setBaseSectionPaint((java.awt.Paint) color12);
        piePlot1.setOutlinePaint((java.awt.Paint) color12);
        piePlot1.setIgnoreZeroValues(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        numberAxis0.setAxisLineVisible(true);
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        boolean boolean4 = piePlot1.getIgnoreNullValues();
        piePlot1.setBackgroundImageAlignment(100);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Paint paint8 = polarPlot7.getAngleGridlinePaint();
        java.awt.Color color9 = java.awt.Color.orange;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets11);
        polarPlot7.setAngleGridlineStroke(stroke10);
        java.lang.String str14 = polarPlot7.getNoDataMessage();
        polarPlot7.setNoDataMessage("");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot7.setRadiusGridlinePaint((java.awt.Paint) color17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot7);
        jFreeChart3.addLegend(legendTitle19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent23 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle22);
        java.lang.String str24 = textTitle22.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double27 = rectangleInsets25.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets25.getTop();
        java.lang.String str29 = rectangleInsets25.toString();
        double double31 = rectangleInsets25.calculateLeftOutset((double) (short) 100);
        double double33 = rectangleInsets25.calculateTopOutset((double) 255);
        textTitle22.setMargin(rectangleInsets25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle22.getTextAlignment();
        legendTitle19.setHorizontalAlignment(horizontalAlignment35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle19.setLegendItemGraphicAnchor(rectangleAnchor37);
        org.jfree.chart.block.BlockContainer blockContainer39 = legendTitle19.getItemContainer();
        java.awt.Font font40 = legendTitle19.getItemFont();
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT", font40);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str29.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(blockContainer39);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getAngleGridlinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot4.setOutlineStroke(stroke6);
        ringPlot0.setSeparatorStroke(stroke6);
        boolean boolean9 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight((double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint0.toFixedHeight((double) (-16777216));
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) rectangleEdge1);
        java.lang.String str3 = rectangleEdge1.toString();
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge1);
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Color color18 = java.awt.Color.orange;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke19, rectangleInsets20);
        double double23 = rectangleInsets20.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', 0.0d, rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets20.createOutsetRectangle(rectangle2D28);
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        categoryPlot16.draw(graphics2D17, rectangle2D28, point2D30, plotState31, plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        categoryPlot4.draw(graphics2D11, rectangle2D28, point2D34, plotState35, plotRenderingInfo36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot42.getFixedDomainAxisSpace();
        int int44 = categoryPlot42.getWeight();
        java.awt.Color color45 = java.awt.Color.darkGray;
        categoryPlot42.setRangeCrosshairPaint((java.awt.Paint) color45);
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color45);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        categoryPlot4.setInsets(rectangleInsets48, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation51 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double3 = rectangleConstraint2.getHeight();
        java.lang.String str4 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toFixedHeight((double) 100.0f);
        java.lang.Class<?> wildcardClass7 = rectangleConstraint2.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (java.lang.Class) wildcardClass7);
        java.awt.Color color9 = java.awt.Color.BLUE;
        java.lang.Class<?> wildcardClass10 = color9.getClass();
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Other", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        java.awt.Paint paint7 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Stroke stroke8 = piePlot1.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot4.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            categoryPlot4.setAxisOffset(rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getDomainAxis();
        int int42 = xYPlot35.getRangeAxisCount();
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.Color color44 = java.awt.Color.orange;
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder47 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color44, stroke45, rectangleInsets46);
        double double49 = rectangleInsets46.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D54 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, (double) '#', 0.0d, rectangleAnchor53);
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets46.createOutsetRectangle(rectangle2D54);
        try {
            xYPlot35.drawBackground(graphics2D43, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 3.0d + "'", double49 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getDomainAxis();
        boolean boolean42 = xYPlot35.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        boolean boolean5 = piePlot1.isCircular();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        java.awt.Paint paint9 = blockBorder7.getPaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        int int14 = color13.getRed();
        java.awt.Color color15 = java.awt.Color.darkGray;
        float[] floatArray16 = null;
        float[] floatArray17 = color15.getRGBColorComponents(floatArray16);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray17);
        float[] floatArray19 = color13.getRGBColorComponents(floatArray17);
        piePlot11.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color13);
        java.awt.Stroke stroke21 = piePlot11.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double24 = rectangleInsets22.calculateRightOutset((double) 10.0f);
        double double25 = rectangleInsets22.getTop();
        java.lang.String str26 = rectangleInsets22.toString();
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder(paint9, stroke21, rectangleInsets22);
        java.awt.Stroke stroke28 = lineBorder27.getStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke28);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 192 + "'", int14 == 192);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str26.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Font font11 = piePlot1.getLabelFont();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset13, valueAxis14, polarItemRenderer15);
        java.awt.Paint paint17 = polarPlot16.getAngleGridlinePaint();
        boolean boolean18 = polarPlot16.isRadiusGridlinesVisible();
        polarPlot16.removeCornerTextItem("Other");
        java.awt.Paint paint21 = polarPlot16.getAngleLabelPaint();
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 0.08d, paint21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint24 = multiplePiePlot23.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot23.getPieChart();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart25);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(jFreeChart25);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        int int11 = categoryPlot9.getWeight();
        java.awt.Color color12 = java.awt.Color.darkGray;
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color12);
        int int14 = categoryPlot9.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("Multiple Pie Plot", font2, (org.jfree.chart.plot.Plot) categoryPlot9, false);
        jFreeChart16.setNotify(true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(1.0d);
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (byte) 10);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("", font7, (java.awt.Paint) color8);
        numberAxis5.setTickLabelFont(font7);
        categoryAxis0.setLabelFont(font7);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font13, (java.awt.Paint) color14);
        numberAxis11.setTickLabelFont(font13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis11.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot18.setParent((org.jfree.chart.plot.Plot) multiplePiePlot19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        java.awt.Shape shape23 = piePlot22.getLegendItemShape();
        boolean boolean24 = piePlot22.getSimpleLabels();
        piePlot22.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double29 = rectangleInsets27.calculateRightOutset((double) 10.0f);
        piePlot22.setSimpleLabelOffset(rectangleInsets27);
        boolean boolean31 = multiplePiePlot18.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double34 = rectangleInsets32.calculateRightOutset((double) 10.0f);
        double double36 = rectangleInsets32.extendWidth((double) (byte) 10);
        double double38 = rectangleInsets32.calculateBottomOutset((double) 2);
        multiplePiePlot18.setInsets(rectangleInsets32);
        numberAxis11.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot18);
        float float41 = numberAxis11.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot43.getDomainAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis48, categoryItemRenderer49);
        org.jfree.chart.axis.AxisSpace axisSpace51 = categoryPlot50.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent52 = null;
        categoryPlot50.datasetChanged(datasetChangeEvent52);
        org.jfree.chart.plot.PlotOrientation plotOrientation54 = categoryPlot50.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation45, plotOrientation54);
        categoryPlot4.setRangeAxisLocation((int) (byte) 100, axisLocation45);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.0d + "'", double34 == 3.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 16.0d + "'", double36 == 16.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.0d + "'", double38 == 3.0d);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNull(axisSpace51);
        org.junit.Assert.assertNotNull(plotOrientation54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.jfree.data.Range range3 = rectangleConstraint0.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot4.getRangeAxis(0);
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker28, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        int int7 = categoryPlot5.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes((double) 8, plotRenderingInfo10, point2D11, false);
        categoryPlot5.setWeight(100);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Paint paint21 = polarPlot20.getAngleGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot20.setOutlineStroke(stroke22);
        ringPlot16.setSeparatorStroke(stroke22);
        categoryPlot5.setRangeGridlineStroke(stroke22);
        ringPlot0.setSeparatorStroke(stroke22);
        ringPlot0.setSeparatorsVisible(false);
        double double29 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.2d + "'", double29 == 0.2d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setPositiveArrowVisible(true);
        numberAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getAngleLabelFont();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        int int6 = color5.getRed();
        polarPlot3.setAngleGridlinePaint((java.awt.Paint) color5);
        int int8 = polarPlot3.getSeriesCount();
        polarPlot3.removeCornerTextItem(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 192 + "'", int6 == 192);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = categoryPlot4.getDatasetRenderingOrder();
        categoryPlot4.clearRangeMarkers(2);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot4.getRangeAxis((int) (short) 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', 0.0d, rectangleAnchor3);
        double double5 = size2D0.width;
        size2D0.setWidth((double) 'a');
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        boolean boolean5 = polarPlot3.isRadiusGridlinesVisible();
        polarPlot3.removeCornerTextItem("Other");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot3.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit8);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM_RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        boolean boolean3 = textBlock0.equals((java.lang.Object) numberFormat2);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment36, verticalAlignment37, (double) 100L, (double) (byte) 10);
        columnArrangement40.clear();
        org.jfree.chart.block.BlockContainer blockContainer42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement40);
        org.jfree.chart.block.Arrangement arrangement43 = blockContainer42.getArrangement();
        legendTitle18.setWrapper(blockContainer42);
        java.awt.Paint paint45 = legendTitle18.getItemPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(arrangement43);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart3, 192, (int) ' ');
        int int7 = chartProgressEvent6.getType();
        int int8 = chartProgressEvent6.getPercent();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 192 + "'", int7 == 192);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        java.lang.Object obj2 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        boolean boolean8 = numberAxis0.isInverted();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis0.setNumberFormatOverride(numberFormat9);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = numberAxis1.getTickLabelFont();
        boolean boolean3 = numberAxis1.isAutoRange();
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer6);
        numberAxis1.setFixedDimension((double) '4');
        numberAxis1.setUpperMargin((double) 1.0f);
        java.awt.Font font12 = numberAxis1.getLabelFont();
        numberAxis1.resizeRange(10.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        piePlot1.setInteriorGap(0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Paint paint3 = blockBorder1.getPaint();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        int int8 = color7.getRed();
        java.awt.Color color9 = java.awt.Color.darkGray;
        float[] floatArray10 = null;
        float[] floatArray11 = color9.getRGBColorComponents(floatArray10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray11);
        float[] floatArray13 = color7.getRGBColorComponents(floatArray11);
        piePlot5.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color7);
        java.awt.Stroke stroke15 = piePlot5.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateRightOutset((double) 10.0f);
        double double19 = rectangleInsets16.getTop();
        java.lang.String str20 = rectangleInsets16.toString();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint3, stroke15, rectangleInsets16);
        java.awt.Stroke stroke22 = lineBorder21.getStroke();
        java.awt.Stroke stroke23 = lineBorder21.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str20.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, (java.awt.Paint) color7);
        numberAxis4.setTickLabelFont(font6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis4.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot11.setParent((org.jfree.chart.plot.Plot) multiplePiePlot12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Shape shape16 = piePlot15.getLegendItemShape();
        boolean boolean17 = piePlot15.getSimpleLabels();
        piePlot15.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double22 = rectangleInsets20.calculateRightOutset((double) 10.0f);
        piePlot15.setSimpleLabelOffset(rectangleInsets20);
        boolean boolean24 = multiplePiePlot11.equals((java.lang.Object) piePlot15);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double27 = rectangleInsets25.calculateRightOutset((double) 10.0f);
        double double29 = rectangleInsets25.extendWidth((double) (byte) 10);
        double double31 = rectangleInsets25.calculateBottomOutset((double) 2);
        multiplePiePlot11.setInsets(rectangleInsets25);
        numberAxis4.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot11);
        float float34 = numberAxis4.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot36.getRangeAxis();
        org.jfree.data.Range range38 = valueAxis37.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, range38);
        double double40 = range38.getLowerBound();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 16.0d + "'", double29 == 16.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(valueAxis37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLegendLabelToolTipGenerator();
        float float4 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat3 = numberAxis2.getNumberFormatOverride();
        numberAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer6);
        numberAxis2.setVisible(false);
        org.junit.Assert.assertNull(numberFormat3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        categoryPlot4.setAnchorValue((-1.0d), true);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double7 = rectangleInsets4.getTop();
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double12 = rectangleInsets4.calculateTopOutset((double) 255);
        textTitle1.setMargin(rectangleInsets4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle1.getTextAlignment();
        textTitle1.setID("Multiple Pie Plot");
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        size2D17.height = 0.0d;
        boolean boolean20 = textTitle1.equals((java.lang.Object) size2D17);
        double double21 = size2D17.width;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint3 = multiplePiePlot2.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot2.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart4, 192, (int) ' ');
        int int8 = chartProgressEvent7.getType();
        boolean boolean9 = textBlock0.equals((java.lang.Object) chartProgressEvent7);
        int int10 = chartProgressEvent7.getPercent();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        polarPlot3.setDataset(xYDataset11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getNoDataMessage();
        polarPlot3.setNoDataMessage("");
        polarPlot3.setRadiusGridlinesVisible(true);
        java.awt.Font font15 = polarPlot3.getAngleLabelFont();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        numberAxis0.setVisible(true);
        double double10 = numberAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot4.getRangeAxisLocation();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("", font39, (java.awt.Paint) color40);
        numberAxis37.setTickLabelFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color46 = java.awt.Color.orange;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color46, stroke47, rectangleInsets48);
        double double51 = rectangleInsets48.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) '#', 0.0d, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets48.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot(xYDataset59, valueAxis60, polarItemRenderer61);
        java.awt.Paint paint63 = polarPlot62.getAngleGridlinePaint();
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot62.setOutlineStroke(stroke64);
        ringPlot58.setSeparatorStroke(stroke64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.PiePlotState piePlotState69 = ringPlot44.initialise(graphics2D45, rectangle2D57, (org.jfree.chart.plot.PiePlot) ringPlot58, (java.lang.Integer) 255, plotRenderingInfo68);
        numberAxis37.setDownArrow((java.awt.Shape) rectangle2D57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot35.drawAnnotations(graphics2D36, rectangle2D57, plotRenderingInfo71);
        xYPlot35.setDomainCrosshairValue((double) (-16777216));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(piePlotState69);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot35.getRangeAxis();
        org.jfree.data.Range range37 = valueAxis36.getDefaultAutoRange();
        org.jfree.data.Range range40 = org.jfree.data.Range.shift(range37, (double) (byte) 100, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(valueAxis36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range40);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            categoryPlot4.handleClick((int) (byte) 0, 0, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLegendLabelToolTipGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double8 = rectangleInsets4.extendWidth((double) (byte) 10);
        double double10 = rectangleInsets4.calculateBottomOutset((double) 2);
        piePlot1.setInsets(rectangleInsets4, false);
        double double14 = rectangleInsets4.calculateRightInset((double) (byte) 100);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 16.0d + "'", double8 == 16.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Paint paint3 = blockBorder1.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        numberAxis0.setVisible(true);
        numberAxis0.setAutoRange(true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Shape shape5 = piePlot4.getLegendItemShape();
        boolean boolean6 = piePlot4.getSimpleLabels();
        piePlot4.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double11 = rectangleInsets9.calculateRightOutset((double) 10.0f);
        piePlot4.setSimpleLabelOffset(rectangleInsets9);
        boolean boolean13 = multiplePiePlot0.equals((java.lang.Object) piePlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightOutset((double) 10.0f);
        double double18 = rectangleInsets14.extendWidth((double) (byte) 10);
        double double20 = rectangleInsets14.calculateBottomOutset((double) 2);
        multiplePiePlot0.setInsets(rectangleInsets14);
        org.jfree.chart.util.TableOrder tableOrder22 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 16.0d + "'", double18 == 16.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertNotNull(tableOrder22);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Font font11 = piePlot1.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot1.setDataset(pieDataset12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(8);
        java.lang.Object obj3 = objectList1.get((-16777216));
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int9 = categoryPlot4.getDatasetCount();
        try {
            categoryPlot4.setBackgroundImageAlpha((float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getFirstTextFragment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            textLine3.draw(graphics2D5, (float) 2, 0.0f, textAnchor8, (float) (short) 100, 1.0f, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.gray;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color2);
        int int4 = color2.getRGB();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        double double13 = rectangleInsets10.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) '#', 0.0d, rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets10.createOutsetRectangle(rectangle2D18);
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color5.createContext(colorModel6, rectangle7, rectangle2D19, affineTransform20, renderingHints21);
        java.awt.Color color23 = java.awt.Color.darkGray;
        float[] floatArray24 = null;
        float[] floatArray25 = color23.getRGBColorComponents(floatArray24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray25);
        float[] floatArray27 = color5.getColorComponents(floatArray25);
        try {
            float[] floatArray28 = color2.getComponents(floatArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-8355712) + "'", int4 == (-8355712));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot35.getRangeAxisEdge(0);
        java.awt.Paint paint43 = xYPlot35.getRangeTickBandPaint();
        org.jfree.chart.plot.Marker marker44 = null;
        try {
            xYPlot35.addRangeMarker(marker44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNull(paint43);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = legendTitle18.getLegendItemGraphicAnchor();
        java.awt.Font font39 = legendTitle18.getItemFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        java.awt.Color color8 = java.awt.Color.orange;
        java.lang.Class<?> wildcardClass9 = color8.getClass();
        java.lang.String str10 = color8.toString();
        numberAxis0.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat13 = numberAxis12.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType14 = numberAxis12.getRangeType();
        numberAxis0.setRangeType(rangeType14);
        numberAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str10.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertNotNull(rangeType14);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getFirstTextFragment();
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textLine3.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textFragment4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat3 = numberAxis2.getNumberFormatOverride();
        numberAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer6);
        categoryAxis1.configure();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        java.awt.Paint paint14 = polarPlot13.getRadiusGridlinePaint();
        boolean boolean15 = polarPlot13.isAngleLabelsVisible();
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, (double) '#', 0.0d, rectangleAnchor19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        double double23 = numberAxis22.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font26 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("", font26, (java.awt.Paint) color27);
        numberAxis24.setTickLabelFont(font26);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis24.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot31.setParent((org.jfree.chart.plot.Plot) multiplePiePlot32);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        java.awt.Shape shape36 = piePlot35.getLegendItemShape();
        boolean boolean37 = piePlot35.getSimpleLabels();
        piePlot35.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double42 = rectangleInsets40.calculateRightOutset((double) 10.0f);
        piePlot35.setSimpleLabelOffset(rectangleInsets40);
        boolean boolean44 = multiplePiePlot31.equals((java.lang.Object) piePlot35);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double47 = rectangleInsets45.calculateRightOutset((double) 10.0f);
        double double49 = rectangleInsets45.extendWidth((double) (byte) 10);
        double double51 = rectangleInsets45.calculateBottomOutset((double) 2);
        multiplePiePlot31.setInsets(rectangleInsets45);
        numberAxis24.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot31);
        float float54 = numberAxis24.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis24, xYItemRenderer55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = xYPlot56.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        xYPlot56.setDataset((int) (short) 1, xYDataset60);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = xYPlot56.getRangeAxisEdge(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot56.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace66 = categoryAxis1.reserveSpace(graphics2D9, (org.jfree.chart.plot.Plot) polarPlot13, rectangle2D20, rectangleEdge64, axisSpace65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 3.0d + "'", double47 == 3.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 16.0d + "'", double49 == 16.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 0.0f + "'", float54 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        java.awt.Stroke stroke11 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getDomainAxisEdge();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) rectangleEdge9);
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = rectangleEdge9.equals((java.lang.Object) paint11);
        piePlot1.setLabelPaint(paint11);
        java.awt.Paint paint14 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot35.getDomainAxisLocation((int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertNotNull(axisLocation43);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelLinkStroke(stroke8);
        java.awt.Color color10 = java.awt.Color.orange;
        java.lang.Class<?> wildcardClass11 = color10.getClass();
        piePlot1.setBackgroundPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setInteriorGap(0.0d);
        java.lang.Object obj4 = piePlot1.clone();
        boolean boolean5 = piePlot1.isSubplot();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart3, 192, (int) ' ');
        jFreeChart3.setTitle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint9 = jFreeChart3.getBorderPaint();
        jFreeChart3.removeLegend();
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart3.addChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator6);
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Shape shape12 = piePlot11.getLegendItemShape();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot11.getLegendLabelToolTipGenerator();
        java.awt.Color color14 = java.awt.Color.orange;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets16);
        piePlot11.setBaseSectionOutlineStroke(stroke15);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 100.0f, stroke15);
        piePlot1.setCircular(false, false);
        java.awt.Color color23 = java.awt.Color.CYAN;
        piePlot1.setBackgroundPaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double11 = rectangleInsets9.calculateRightOutset((double) 10.0f);
        double double12 = rectangleInsets9.getTop();
        boolean boolean14 = rectangleInsets9.equals((java.lang.Object) (-1.0f));
        categoryPlot4.setInsets(rectangleInsets9);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        double double18 = numberAxis17.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font21 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font21, (java.awt.Paint) color22);
        numberAxis19.setTickLabelFont(font21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis19.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot26.setParent((org.jfree.chart.plot.Plot) multiplePiePlot27);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        java.awt.Shape shape31 = piePlot30.getLegendItemShape();
        boolean boolean32 = piePlot30.getSimpleLabels();
        piePlot30.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateRightOutset((double) 10.0f);
        piePlot30.setSimpleLabelOffset(rectangleInsets35);
        boolean boolean39 = multiplePiePlot26.equals((java.lang.Object) piePlot30);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double42 = rectangleInsets40.calculateRightOutset((double) 10.0f);
        double double44 = rectangleInsets40.extendWidth((double) (byte) 10);
        double double46 = rectangleInsets40.calculateBottomOutset((double) 2);
        multiplePiePlot26.setInsets(rectangleInsets40);
        numberAxis19.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot26);
        float float49 = numberAxis19.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font55 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine57 = new org.jfree.chart.text.TextLine("", font55, (java.awt.Paint) color56);
        numberAxis53.setTickLabelFont(font55);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = numberAxis53.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot60 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.Color color62 = java.awt.Color.orange;
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder65 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color62, stroke63, rectangleInsets64);
        double double67 = rectangleInsets64.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D68 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D68, (double) '#', 0.0d, rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets64.createOutsetRectangle(rectangle2D72);
        org.jfree.chart.plot.RingPlot ringPlot74 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer77 = null;
        org.jfree.chart.plot.PolarPlot polarPlot78 = new org.jfree.chart.plot.PolarPlot(xYDataset75, valueAxis76, polarItemRenderer77);
        java.awt.Paint paint79 = polarPlot78.getAngleGridlinePaint();
        java.awt.Stroke stroke80 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot78.setOutlineStroke(stroke80);
        ringPlot74.setSeparatorStroke(stroke80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo84 = null;
        org.jfree.chart.plot.PiePlotState piePlotState85 = ringPlot60.initialise(graphics2D61, rectangle2D73, (org.jfree.chart.plot.PiePlot) ringPlot74, (java.lang.Integer) 255, plotRenderingInfo84);
        numberAxis53.setDownArrow((java.awt.Shape) rectangle2D73);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        xYPlot51.drawAnnotations(graphics2D52, rectangle2D73, plotRenderingInfo87);
        org.jfree.chart.LegendItemCollection legendItemCollection89 = xYPlot51.getLegendItems();
        categoryPlot4.setFixedLegendItems(legendItemCollection89);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.0d + "'", double37 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 16.0d + "'", double44 == 16.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 3.0d + "'", double46 == 3.0d);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 3.0d + "'", double67 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(piePlotState85);
        org.junit.Assert.assertNotNull(legendItemCollection89);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
        java.lang.String str8 = projectInfo7.getVersion();
        java.lang.String str9 = projectInfo7.toString();
        org.jfree.chart.text.TextBlock textBlock10 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint13 = multiplePiePlot12.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart14 = multiplePiePlot12.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart14, 192, (int) ' ');
        int int18 = chartProgressEvent17.getType();
        boolean boolean19 = textBlock10.equals((java.lang.Object) chartProgressEvent17);
        java.util.List list20 = textBlock10.getLines();
        projectInfo7.setContributors(list20);
        java.awt.Image image22 = projectInfo7.getLogo();
        java.lang.String str23 = projectInfo7.getInfo();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n" + "'", str9.equals(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(jFreeChart14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 192 + "'", int18 == 192);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(image22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener3 = null;
        jFreeChart2.addProgressListener(chartProgressListener3);
        jFreeChart2.fireChartChanged();
        float float6 = jFreeChart2.getBackgroundImageAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font9, (java.awt.Paint) color10);
        numberAxis7.setTickLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis7.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Color color16 = java.awt.Color.orange;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color16, stroke17, rectangleInsets18);
        double double21 = rectangleInsets18.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D22 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, (double) '#', 0.0d, rectangleAnchor25);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets18.createOutsetRectangle(rectangle2D26);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset29, valueAxis30, polarItemRenderer31);
        java.awt.Paint paint33 = polarPlot32.getAngleGridlinePaint();
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot32.setOutlineStroke(stroke34);
        ringPlot28.setSeparatorStroke(stroke34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.PiePlotState piePlotState39 = ringPlot14.initialise(graphics2D15, rectangle2D27, (org.jfree.chart.plot.PiePlot) ringPlot28, (java.lang.Integer) 255, plotRenderingInfo38);
        numberAxis7.setDownArrow((java.awt.Shape) rectangle2D27);
        try {
            jFreeChart2.setTextAntiAlias((java.lang.Object) numberAxis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.axis.NumberAxis@0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(piePlotState39);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Paint paint44 = valueMarker43.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = valueMarker43.getLabelOffsetType();
        double double46 = valueMarker43.getValue();
        java.lang.Object obj47 = valueMarker43.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = valueMarker43.getLabelAnchor();
        try {
            boolean boolean49 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(lengthAdjustmentType45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-1.0d) + "'", double46 == (-1.0d));
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Shape shape11 = piePlot10.getLegendItemShape();
        java.awt.Paint paint12 = piePlot10.getLabelShadowPaint();
        boolean boolean13 = piePlot10.getIgnoreNullValues();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) piePlot10);
        double double15 = piePlot10.getLabelLinkMargin();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.025d + "'", double15 == 0.025d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot1.getLabelDistributor();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("hi!", (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        double double4 = rectangleInsets2.calculateLeftInset((double) (-1));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean2 = unitType0.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot1.setLabelFont(font2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Stroke stroke5 = piePlot1.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.net.URL uRL3 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(uRL3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) (byte) 10);
        columnArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer6.getArrangement();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range10);
        org.jfree.data.Range range12 = rectangleConstraint11.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D13 = blockContainer6.arrange(graphics2D8, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(arrangement7);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        java.awt.Paint paint42 = xYPlot35.getRangeGridlinePaint();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = null;
        valueMarker44.notifyListeners(markerChangeEvent45);
        org.jfree.chart.util.Layer layer47 = null;
        try {
            xYPlot35.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker44, layer47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(8);
        java.lang.Object obj3 = objectList1.get((int) (short) -1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.lang.String str6 = standardPieSectionLabelGenerator5.getLabelFormat();
        boolean boolean7 = objectList1.equals((java.lang.Object) standardPieSectionLabelGenerator5);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.TOP" + "'", str6.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 10L, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', 0.0d, rectangleAnchor3);
        double double5 = size2D0.width;
        size2D0.height = (byte) 0;
        size2D0.setWidth((double) 8);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(255);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot3.zoomDomainAxes((double) 10, plotRenderingInfo5, point2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = polarPlot3.getDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot3.datasetChanged(datasetChangeEvent9);
        polarPlot3.removeCornerTextItem(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getRadiusGridlinePaint();
        java.lang.String str5 = polarPlot3.getPlotType();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Polar Plot" + "'", str5.equals("Polar Plot"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot35.getRangeAxisEdge(0);
        xYPlot35.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot35.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        double double26 = piePlotState25.getPieCenterY();
        double double27 = piePlotState25.getPieCenterY();
        piePlotState25.setPieWRadius(45.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedWidth(90.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        valueMarker2.notifyListeners(markerChangeEvent3);
        boolean boolean5 = chartChangeEventType0.equals((java.lang.Object) markerChangeEvent3);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, (double) 8, 0.0d, (double) (short) 10);
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Color color18 = java.awt.Color.orange;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke19, rectangleInsets20);
        double double23 = rectangleInsets20.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', 0.0d, rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets20.createOutsetRectangle(rectangle2D28);
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        categoryPlot16.draw(graphics2D17, rectangle2D28, point2D30, plotState31, plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        categoryPlot4.draw(graphics2D11, rectangle2D28, point2D34, plotState35, plotRenderingInfo36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot42.getFixedDomainAxisSpace();
        int int44 = categoryPlot42.getWeight();
        java.awt.Color color45 = java.awt.Color.darkGray;
        categoryPlot42.setRangeCrosshairPaint((java.awt.Paint) color45);
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color45);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot4.getOrientation();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent49 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent49);
        org.jfree.chart.util.SortOrder sortOrder51 = categoryPlot4.getColumnRenderingOrder();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(sortOrder51);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setRangeAboutValue((double) 1L, 16.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) rectangleEdge9);
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = rectangleEdge9.equals((java.lang.Object) paint11);
        piePlot1.setLabelPaint(paint11);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot1.getLegendLabelGenerator();
        java.awt.Paint paint15 = null;
        try {
            piePlot1.setBaseSectionOutlinePaint(paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setLabelLinksVisible(true);
        boolean boolean4 = ringPlot1.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double7 = rectangleInsets4.getTop();
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double12 = rectangleInsets4.calculateTopOutset((double) 255);
        textTitle1.setMargin(rectangleInsets4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle1.getTextAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        double double18 = numberAxis17.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font21 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font21, (java.awt.Paint) color22);
        numberAxis19.setTickLabelFont(font21);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis19.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot26.setParent((org.jfree.chart.plot.Plot) multiplePiePlot27);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        java.awt.Shape shape31 = piePlot30.getLegendItemShape();
        boolean boolean32 = piePlot30.getSimpleLabels();
        piePlot30.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateRightOutset((double) 10.0f);
        piePlot30.setSimpleLabelOffset(rectangleInsets35);
        boolean boolean39 = multiplePiePlot26.equals((java.lang.Object) piePlot30);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double42 = rectangleInsets40.calculateRightOutset((double) 10.0f);
        double double44 = rectangleInsets40.extendWidth((double) (byte) 10);
        double double46 = rectangleInsets40.calculateBottomOutset((double) 2);
        multiplePiePlot26.setInsets(rectangleInsets40);
        numberAxis19.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot26);
        float float49 = numberAxis19.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font55 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine57 = new org.jfree.chart.text.TextLine("", font55, (java.awt.Paint) color56);
        numberAxis53.setTickLabelFont(font55);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = numberAxis53.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot60 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.Color color62 = java.awt.Color.orange;
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder65 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color62, stroke63, rectangleInsets64);
        double double67 = rectangleInsets64.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D68 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D68, (double) '#', 0.0d, rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets64.createOutsetRectangle(rectangle2D72);
        org.jfree.chart.plot.RingPlot ringPlot74 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer77 = null;
        org.jfree.chart.plot.PolarPlot polarPlot78 = new org.jfree.chart.plot.PolarPlot(xYDataset75, valueAxis76, polarItemRenderer77);
        java.awt.Paint paint79 = polarPlot78.getAngleGridlinePaint();
        java.awt.Stroke stroke80 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot78.setOutlineStroke(stroke80);
        ringPlot74.setSeparatorStroke(stroke80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo84 = null;
        org.jfree.chart.plot.PiePlotState piePlotState85 = ringPlot60.initialise(graphics2D61, rectangle2D73, (org.jfree.chart.plot.PiePlot) ringPlot74, (java.lang.Integer) 255, plotRenderingInfo84);
        numberAxis53.setDownArrow((java.awt.Shape) rectangle2D73);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        xYPlot51.drawAnnotations(graphics2D52, rectangle2D73, plotRenderingInfo87);
        org.jfree.chart.block.BlockParams blockParams89 = new org.jfree.chart.block.BlockParams();
        double double90 = blockParams89.getTranslateX();
        java.lang.Object obj91 = textTitle1.draw(graphics2D15, rectangle2D73, (java.lang.Object) double90);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.0d + "'", double37 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 16.0d + "'", double44 == 16.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 3.0d + "'", double46 == 3.0d);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 3.0d + "'", double67 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(piePlotState85);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNull(obj91);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("", font39, (java.awt.Paint) color40);
        numberAxis37.setTickLabelFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color46 = java.awt.Color.orange;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color46, stroke47, rectangleInsets48);
        double double51 = rectangleInsets48.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) '#', 0.0d, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets48.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot(xYDataset59, valueAxis60, polarItemRenderer61);
        java.awt.Paint paint63 = polarPlot62.getAngleGridlinePaint();
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot62.setOutlineStroke(stroke64);
        ringPlot58.setSeparatorStroke(stroke64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.PiePlotState piePlotState69 = ringPlot44.initialise(graphics2D45, rectangle2D57, (org.jfree.chart.plot.PiePlot) ringPlot58, (java.lang.Integer) 255, plotRenderingInfo68);
        numberAxis37.setDownArrow((java.awt.Shape) rectangle2D57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot35.drawAnnotations(graphics2D36, rectangle2D57, plotRenderingInfo71);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = xYPlot35.getRenderer((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        try {
            xYPlot35.handleClick((-16777216), 3, plotRenderingInfo77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(piePlotState69);
        org.junit.Assert.assertNull(xYItemRenderer74);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("", font39, (java.awt.Paint) color40);
        numberAxis37.setTickLabelFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color46 = java.awt.Color.orange;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color46, stroke47, rectangleInsets48);
        double double51 = rectangleInsets48.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) '#', 0.0d, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets48.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot(xYDataset59, valueAxis60, polarItemRenderer61);
        java.awt.Paint paint63 = polarPlot62.getAngleGridlinePaint();
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot62.setOutlineStroke(stroke64);
        ringPlot58.setSeparatorStroke(stroke64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.PiePlotState piePlotState69 = ringPlot44.initialise(graphics2D45, rectangle2D57, (org.jfree.chart.plot.PiePlot) ringPlot58, (java.lang.Integer) 255, plotRenderingInfo68);
        numberAxis37.setDownArrow((java.awt.Shape) rectangle2D57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot35.drawAnnotations(graphics2D36, rectangle2D57, plotRenderingInfo71);
        org.jfree.chart.LegendItemCollection legendItemCollection73 = xYPlot35.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer75 = null;
        xYPlot35.setRenderer(100, xYItemRenderer75);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(piePlotState69);
        org.junit.Assert.assertNotNull(legendItemCollection73);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        double double26 = piePlotState25.getPieCenterY();
        double double27 = piePlotState25.getPieCenterY();
        java.awt.geom.Rectangle2D rectangle2D28 = piePlotState25.getLinkArea();
        piePlotState25.setLatestAngle((double) 100.0f);
        int int31 = piePlotState25.getPassesRequired();
        double double32 = piePlotState25.getPieCenterX();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int9 = categoryPlot4.getDatasetCount();
        boolean boolean10 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12, false);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getFirstTextFragment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.String str9 = textAnchor8.toString();
        try {
            textLine3.draw(graphics2D5, (float) (byte) -1, (float) 'a', textAnchor8, (float) (byte) 100, 0.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str9.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setPositiveArrowVisible(true);
        java.awt.Font font5 = numberAxis0.getTickLabelFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        boolean boolean13 = standardPieSectionLabelGenerator1.equals((java.lang.Object) polarPlot6);
        java.lang.Object obj14 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.TOP" + "'", str2.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        java.lang.Object obj4 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        java.awt.Stroke stroke38 = xYPlot35.getDomainZeroBaselineStroke();
        double double39 = xYPlot35.getDomainCrosshairValue();
        java.awt.Color color42 = java.awt.Color.getColor("Rotation.ANTICLOCKWISE", 10);
        xYPlot35.setDomainCrosshairPaint((java.awt.Paint) color42);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        int int45 = xYPlot35.getIndexOf(xYItemRenderer44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem1 = null;
        legendItemCollection0.add(legendItem1);
        java.util.Iterator iterator3 = legendItemCollection0.iterator();
        try {
            org.jfree.chart.LegendItem legendItem5 = legendItemCollection0.get((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iterator3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Shape shape3 = piePlot2.getLegendItemShape();
        java.awt.Paint paint4 = piePlot2.getLabelShadowPaint();
        piePlot2.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        double double9 = categoryAxis0.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            java.util.List list14 = categoryAxis0.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Shape shape17 = piePlot16.getLegendItemShape();
        java.awt.Paint paint18 = piePlot16.getLabelShadowPaint();
        piePlot16.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis14.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot16);
        int int23 = categoryPlot4.getDomainAxisIndex(categoryAxis14);
        java.awt.Paint paint24 = categoryPlot4.getDomainGridlinePaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint26 = multiplePiePlot25.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart27 = multiplePiePlot25.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener28 = null;
        jFreeChart27.addProgressListener(chartProgressListener28);
        jFreeChart27.setTextAntiAlias(false);
        jFreeChart27.setNotify(true);
        java.awt.Image image37 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo41 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image37, "", "", "");
        java.lang.String str42 = projectInfo41.getVersion();
        java.lang.String str43 = projectInfo41.toString();
        org.jfree.chart.text.TextBlock textBlock44 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot46 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint47 = multiplePiePlot46.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart48 = multiplePiePlot46.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent51 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart48, 192, (int) ' ');
        int int52 = chartProgressEvent51.getType();
        boolean boolean53 = textBlock44.equals((java.lang.Object) chartProgressEvent51);
        java.util.List list54 = textBlock44.getLines();
        projectInfo41.setContributors(list54);
        jFreeChart27.setSubtitles(list54);
        java.awt.Stroke stroke57 = jFreeChart27.getBorderStroke();
        categoryPlot4.setDomainGridlineStroke(stroke57);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(jFreeChart27);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n" + "'", str43.equals(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(jFreeChart48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 192 + "'", int52 == 192);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font40 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine42 = new org.jfree.chart.text.TextLine("", font40, (java.awt.Paint) color41);
        numberAxis38.setTickLabelFont(font40);
        java.awt.Shape shape44 = numberAxis38.getLeftArrow();
        java.awt.Shape shape45 = numberAxis38.getDownArrow();
        numberAxis38.setVisible(true);
        int int48 = xYPlot35.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double4 = rectangleInsets0.extendWidth((double) 10.0f);
        double double5 = rectangleInsets0.getRight();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("", font8, (java.awt.Paint) color9);
        numberAxis6.setTickLabelFont(font8);
        java.awt.Shape shape12 = numberAxis6.getLeftArrow();
        boolean boolean13 = numberAxis6.isInverted();
        java.awt.Font font14 = numberAxis6.getLabelFont();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis6.setStandardTickUnits(tickUnitSource15);
        boolean boolean17 = rectangleInsets0.equals((java.lang.Object) numberAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.0d + "'", double4 == 16.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getDomainAxis();
        boolean boolean42 = xYPlot35.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryPlot47.getFixedDomainAxisSpace();
        int int49 = categoryPlot47.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = categoryPlot47.getOrientation();
        categoryPlot47.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = categoryPlot47.getOrientation();
        xYPlot35.setOrientation(plotOrientation53);
        xYPlot35.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(axisSpace48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertNotNull(plotOrientation53);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        double double26 = piePlotState25.getPieCenterY();
        double double27 = piePlotState25.getPieCenterY();
        java.awt.geom.Rectangle2D rectangle2D28 = piePlotState25.getLinkArea();
        piePlotState25.setLatestAngle((double) 100.0f);
        java.awt.geom.Rectangle2D rectangle2D31 = piePlotState25.getLinkArea();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D28);
        org.junit.Assert.assertNull(rectangle2D31);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        boolean boolean7 = numberAxis0.isInverted();
        java.awt.Font font8 = numberAxis0.getLabelFont();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis0.setStandardTickUnits(tickUnitSource9);
        java.awt.Paint paint11 = numberAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        try {
            boolean boolean25 = categoryPlot4.removeAnnotation(categoryAnnotation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) (byte) 10, (double) ' ', plotRenderingInfo10, point2D11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot4.getRendererForDataset(categoryDataset13);
        categoryPlot4.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Stroke stroke2 = ringPlot1.getSeparatorStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            legendTitle18.draw(graphics2D36, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot1.getLabelDistributor();
        piePlot1.setLabelGap((double) 3);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { paint1, color2, color3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Shape[] shapeArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray4, strokeArray5, strokeArray6, shapeArray7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int5 = color4.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(3.0d, 21.5d, 0.0d, (double) 10, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) multiplePiePlot2, true);
        multiplePiePlot2.setNoDataMessage("hi!");
        java.lang.Object obj9 = multiplePiePlot2.clone();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = multiplePiePlot2.getDrawingSupplier();
        double double11 = multiplePiePlot2.getLimit();
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.block.BlockContainer blockContainer38 = legendTitle18.getItemContainer();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = legendTitle18.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockContainer38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        double double7 = numberAxis0.getLabelAngle();
        numberAxis0.configure();
        numberAxis0.setUpperBound(0.0d);
        java.awt.Font font11 = numberAxis0.getLabelFont();
        try {
            numberAxis0.setRange(90.0d, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (90.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis0.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot7.setParent((org.jfree.chart.plot.Plot) multiplePiePlot8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Shape shape12 = piePlot11.getLegendItemShape();
        boolean boolean13 = piePlot11.getSimpleLabels();
        piePlot11.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateRightOutset((double) 10.0f);
        piePlot11.setSimpleLabelOffset(rectangleInsets16);
        boolean boolean20 = multiplePiePlot7.equals((java.lang.Object) piePlot11);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double23 = rectangleInsets21.calculateRightOutset((double) 10.0f);
        double double25 = rectangleInsets21.extendWidth((double) (byte) 10);
        double double27 = rectangleInsets21.calculateBottomOutset((double) 2);
        multiplePiePlot7.setInsets(rectangleInsets21);
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot7);
        float float30 = numberAxis0.getTickMarkInsideLength();
        numberAxis0.resizeRange((double) (short) 10);
        boolean boolean33 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 16.0d + "'", double25 == 16.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = valueMarker1.getLabelOffsetType();
        double double4 = valueMarker1.getValue();
        java.lang.Object obj5 = valueMarker1.clone();
        java.awt.Stroke stroke6 = valueMarker1.getStroke();
        java.awt.Paint paint7 = null;
        try {
            valueMarker1.setLabelPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Color color18 = java.awt.Color.orange;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke19, rectangleInsets20);
        double double23 = rectangleInsets20.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', 0.0d, rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets20.createOutsetRectangle(rectangle2D28);
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        categoryPlot16.draw(graphics2D17, rectangle2D28, point2D30, plotState31, plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        categoryPlot4.draw(graphics2D11, rectangle2D28, point2D34, plotState35, plotRenderingInfo36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot42.getFixedDomainAxisSpace();
        int int44 = categoryPlot42.getWeight();
        java.awt.Color color45 = java.awt.Color.darkGray;
        categoryPlot42.setRangeCrosshairPaint((java.awt.Paint) color45);
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color45);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot4.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, categoryItemRenderer52);
        org.jfree.chart.axis.AxisSpace axisSpace54 = categoryPlot53.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace55 = null;
        categoryPlot53.setFixedDomainAxisSpace(axisSpace55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double59 = rectangleInsets57.calculateRightOutset((double) 10.0f);
        double double61 = rectangleInsets57.extendWidth((double) 10.0f);
        double double62 = rectangleInsets57.getTop();
        categoryPlot53.setInsets(rectangleInsets57);
        categoryPlot53.clearRangeAxes();
        boolean boolean65 = plotOrientation48.equals((java.lang.Object) categoryPlot53);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent66 = null;
        categoryPlot53.rendererChanged(rendererChangeEvent66);
        org.jfree.chart.util.Layer layer69 = null;
        java.util.Collection collection70 = categoryPlot53.getDomainMarkers((int) '4', layer69);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNull(axisSpace54);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 3.0d + "'", double59 == 3.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 16.0d + "'", double61 == 16.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 3.0d + "'", double62 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(collection70);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot4.getDomainMarkers(layer9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset((int) (byte) 0, categoryDataset12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot4.setInsets(rectangleInsets14, false);
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
        java.util.List list8 = null;
        projectInfo7.setContributors(list8);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot1.getLegendLabelURLGenerator();
        java.lang.String str9 = piePlot1.getPlotType();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.lang.String str12 = standardPieSectionLabelGenerator11.getLabelFormat();
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie Plot" + "'", str9.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.TOP" + "'", str12.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        int int2 = color1.getRed();
        java.awt.Color color3 = java.awt.Color.darkGray;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getRGBColorComponents(floatArray4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray5);
        float[] floatArray7 = color1.getRGBColorComponents(floatArray5);
        float[] floatArray8 = color0.getRGBColorComponents(floatArray5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelGenerator();
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        piePlot1.setExplodePercent((java.lang.Comparable) date5, (double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Shape shape10 = piePlot9.getLegendItemShape();
        boolean boolean11 = piePlot9.getSimpleLabels();
        piePlot9.setIgnoreNullValues(false);
        piePlot9.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor16 = piePlot9.getLabelDistributor();
        int int17 = abstractPieLabelDistributor16.getItemCount();
        piePlot1.setLabelDistributor(abstractPieLabelDistributor16);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord20 = abstractPieLabelDistributor16.getPieLabelRecord((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int9 = categoryPlot4.getDatasetCount();
        boolean boolean10 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        categoryPlot4.clearDomainMarkers((int) '4');
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) ' ');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            multiplePiePlot1.drawOutline(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot8.getFixedDomainAxisSpace();
        int int10 = categoryPlot8.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot8.getOrientation();
        categoryPlot8.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double15 = rectangleInsets13.calculateRightOutset((double) 10.0f);
        double double16 = rectangleInsets13.getTop();
        boolean boolean18 = rectangleInsets13.equals((java.lang.Object) (-1.0f));
        categoryPlot8.setInsets(rectangleInsets13);
        piePlot1.setLabelPadding(rectangleInsets13);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Color color0 = java.awt.Color.orange;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.awt.color.ColorSpace colorSpace2 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(colorSpace2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Shape shape3 = piePlot2.getLegendItemShape();
        java.awt.Paint paint4 = piePlot2.getLabelShadowPaint();
        piePlot2.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        categoryAxis0.setFixedDimension(90.0d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = legendItemCollection0.equals(obj1);
        java.lang.Object obj3 = null;
        boolean boolean4 = legendItemCollection0.equals(obj3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Shape shape17 = piePlot16.getLegendItemShape();
        java.awt.Paint paint18 = piePlot16.getLabelShadowPaint();
        piePlot16.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis14.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot16);
        int int23 = categoryPlot4.getDomainAxisIndex(categoryAxis14);
        java.awt.Paint paint24 = categoryPlot4.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot4.setDataset(0, categoryDataset26);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat3 = numberAxis2.getNumberFormatOverride();
        java.awt.Color color4 = java.awt.Color.CYAN;
        numberAxis2.setTickMarkPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, xYItemRenderer6);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot7.setDomainAxes(valueAxisArray8);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot35.getRangeAxisEdge(0);
        java.awt.Paint paint43 = xYPlot35.getRangeTickBandPaint();
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int46 = color45.getGreen();
        try {
            xYPlot35.setQuadrantPaint(8, (java.awt.Paint) color45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (8) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 255 + "'", int46 == 255);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("", font39, (java.awt.Paint) color40);
        numberAxis37.setTickLabelFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color46 = java.awt.Color.orange;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color46, stroke47, rectangleInsets48);
        double double51 = rectangleInsets48.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) '#', 0.0d, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets48.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot(xYDataset59, valueAxis60, polarItemRenderer61);
        java.awt.Paint paint63 = polarPlot62.getAngleGridlinePaint();
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot62.setOutlineStroke(stroke64);
        ringPlot58.setSeparatorStroke(stroke64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.PiePlotState piePlotState69 = ringPlot44.initialise(graphics2D45, rectangle2D57, (org.jfree.chart.plot.PiePlot) ringPlot58, (java.lang.Integer) 255, plotRenderingInfo68);
        numberAxis37.setDownArrow((java.awt.Shape) rectangle2D57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot35.drawAnnotations(graphics2D36, rectangle2D57, plotRenderingInfo71);
        org.jfree.chart.LegendItemCollection legendItemCollection73 = xYPlot35.getLegendItems();
        java.awt.Stroke stroke74 = xYPlot35.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(piePlotState69);
        org.junit.Assert.assertNotNull(legendItemCollection73);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = numberAxis1.getTickLabelFont();
        boolean boolean3 = numberAxis1.isAutoRange();
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer6);
        numberAxis1.setFixedDimension((double) '4');
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint11 = multiplePiePlot10.getAggregatedItemsPaint();
        org.jfree.chart.plot.Plot plot12 = multiplePiePlot10.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) multiplePiePlot10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double7 = rectangleInsets4.getTop();
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double12 = rectangleInsets4.calculateTopOutset((double) 255);
        textTitle1.setMargin(rectangleInsets4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle1.getTextAlignment();
        textTitle1.setID("Multiple Pie Plot");
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        size2D17.height = 0.0d;
        boolean boolean20 = textTitle1.equals((java.lang.Object) size2D17);
        textTitle1.setHeight(0.08d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        double double7 = numberAxis0.getLabelAngle();
        numberAxis0.setAutoRange(true);
        boolean boolean11 = numberAxis0.equals((java.lang.Object) 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }
}

