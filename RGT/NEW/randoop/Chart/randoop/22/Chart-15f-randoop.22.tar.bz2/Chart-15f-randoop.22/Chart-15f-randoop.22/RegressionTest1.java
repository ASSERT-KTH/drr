import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(1.0d);
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (byte) 10);
        double double5 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getAngleLabelFont();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        int int6 = color5.getRed();
        polarPlot3.setAngleGridlinePaint((java.awt.Paint) color5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        polarPlot3.setRadiusGridlineStroke(stroke8);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 192 + "'", int6 == 192);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, (java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextFragment textFragment8 = textLine7.getFirstTextFragment();
        textLine3.addFragment(textFragment8);
        java.awt.Graphics2D graphics2D10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textLine3.calculateDimensions(graphics2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textFragment8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke5, rectangleInsets6);
        double double9 = rectangleInsets6.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) '#', 0.0d, rectangleAnchor13);
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets6.createOutsetRectangle(rectangle2D14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        boolean boolean18 = chartChangeEventType16.equals((java.lang.Object) defaultDrawingSupplier17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean21 = chartChangeEventType19.equals((java.lang.Object) rectangleEdge20);
        java.lang.String str22 = rectangleEdge20.toString();
        boolean boolean23 = defaultDrawingSupplier17.equals((java.lang.Object) rectangleEdge20);
        try {
            double double24 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor1, 0, 100, rectangle2D15, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleEdge.TOP" + "'", str22.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("Other", font1);
        float float3 = textFragment2.getBaselineOffset();
        java.lang.String str4 = textFragment2.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Other" + "'", str4.equals("Other"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot35.getRangeAxisEdge(0);
        xYPlot35.setRangeCrosshairValue((double) (short) 10, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("", font39, (java.awt.Paint) color40);
        numberAxis37.setTickLabelFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color46 = java.awt.Color.orange;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color46, stroke47, rectangleInsets48);
        double double51 = rectangleInsets48.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) '#', 0.0d, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets48.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot(xYDataset59, valueAxis60, polarItemRenderer61);
        java.awt.Paint paint63 = polarPlot62.getAngleGridlinePaint();
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot62.setOutlineStroke(stroke64);
        ringPlot58.setSeparatorStroke(stroke64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.PiePlotState piePlotState69 = ringPlot44.initialise(graphics2D45, rectangle2D57, (org.jfree.chart.plot.PiePlot) ringPlot58, (java.lang.Integer) 255, plotRenderingInfo68);
        numberAxis37.setDownArrow((java.awt.Shape) rectangle2D57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot35.drawAnnotations(graphics2D36, rectangle2D57, plotRenderingInfo71);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = xYPlot35.getRenderer((int) (short) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer75 = null;
        int int76 = xYPlot35.getIndexOf(xYItemRenderer75);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer78 = xYPlot35.getRenderer((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(piePlotState69);
        org.junit.Assert.assertNull(xYItemRenderer74);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNull(xYItemRenderer78);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean1 = multiplePiePlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        int int8 = color7.getRed();
        java.awt.Color color9 = java.awt.Color.darkGray;
        float[] floatArray10 = null;
        float[] floatArray11 = color9.getRGBColorComponents(floatArray10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray11);
        float[] floatArray13 = color7.getRGBColorComponents(floatArray11);
        piePlot5.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color7);
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) 100.0f);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        java.awt.Paint paint2 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Stroke stroke11 = piePlot1.getLabelOutlineStroke();
        double double12 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor13 = piePlot1.getLabelDistributor();
        int int14 = abstractPieLabelDistributor13.getItemCount();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.14d + "'", double12 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot35.getRangeAxisEdge(0);
        xYPlot35.setDomainZeroBaselineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, categoryItemRenderer48);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.Color color51 = java.awt.Color.orange;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder54 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color51, stroke52, rectangleInsets53);
        double double56 = rectangleInsets53.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D57 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D57, (double) '#', 0.0d, rectangleAnchor60);
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets53.createOutsetRectangle(rectangle2D61);
        java.awt.geom.Point2D point2D63 = null;
        org.jfree.chart.plot.PlotState plotState64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        categoryPlot49.draw(graphics2D50, rectangle2D61, point2D63, plotState64, plotRenderingInfo65);
        float float67 = categoryPlot49.getBackgroundAlpha();
        int int68 = categoryPlot49.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis70 = categoryPlot49.getRangeAxis(0);
        categoryPlot49.setDrawSharedDomainAxis(true);
        boolean boolean73 = categoryPlot49.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot49.getRangeAxisLocation(10);
        xYPlot35.setRangeAxisLocation(axisLocation75);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 3.0d + "'", double56 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 1.0f + "'", float67 == 1.0f);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNull(valueAxis70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        int int7 = categoryPlot5.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes((double) 8, plotRenderingInfo10, point2D11, false);
        categoryPlot5.setWeight(100);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Paint paint21 = polarPlot20.getAngleGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot20.setOutlineStroke(stroke22);
        ringPlot16.setSeparatorStroke(stroke22);
        categoryPlot5.setRangeGridlineStroke(stroke22);
        ringPlot0.setSeparatorStroke(stroke22);
        boolean boolean27 = ringPlot0.getSeparatorsVisible();
        java.awt.Paint paint28 = ringPlot0.getBaseSectionPaint();
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        double double7 = numberAxis0.getLabelAngle();
        numberAxis0.setAutoRange(true);
        boolean boolean10 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = legendTitle18.getLegendItemGraphicAnchor();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = legendTitle18.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = null;
        try {
            categoryPlot4.setDomainGridlinePosition(categoryAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean1 = multiplePiePlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        int int8 = color7.getRed();
        java.awt.Color color9 = java.awt.Color.darkGray;
        float[] floatArray10 = null;
        float[] floatArray11 = color9.getRGBColorComponents(floatArray10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray11);
        float[] floatArray13 = color7.getRGBColorComponents(floatArray11);
        piePlot5.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color7);
        boolean boolean15 = multiplePiePlot0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        multiplePiePlot0.handleClick(100, 0, plotRenderingInfo18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Stroke stroke3 = jFreeChart2.getBorderStroke();
        java.awt.RenderingHints renderingHints4 = null;
        try {
            jFreeChart2.setRenderingHints(renderingHints4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat3 = numberAxis2.getNumberFormatOverride();
        java.awt.Color color4 = java.awt.Color.CYAN;
        numberAxis2.setTickMarkPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, xYItemRenderer6);
        xYPlot7.clearAnnotations();
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str1.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) defaultDrawingSupplier1);
        java.awt.Stroke stroke3 = defaultDrawingSupplier1.getNextStroke();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setParent((org.jfree.chart.plot.Plot) multiplePiePlot1);
        multiplePiePlot1.zoom((double) (byte) 10);
        multiplePiePlot1.setBackgroundImageAlignment((int) (short) -1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment36, verticalAlignment37, (double) 100L, (double) (byte) 10);
        columnArrangement40.clear();
        org.jfree.chart.block.BlockContainer blockContainer42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement40);
        org.jfree.chart.block.Arrangement arrangement43 = blockContainer42.getArrangement();
        legendTitle18.setWrapper(blockContainer42);
        java.util.List list45 = blockContainer42.getBlocks();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(arrangement43);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double3 = rectangleConstraint2.getHeight();
        java.lang.String str4 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toFixedHeight((double) 100.0f);
        java.lang.Class<?> wildcardClass7 = rectangleConstraint2.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Multiple Pie Plot", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNull(inputStream9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        double double10 = rectangleInsets7.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) '#', 0.0d, rectangleAnchor14);
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets7.createOutsetRectangle(rectangle2D15);
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color2.createContext(colorModel3, rectangle4, rectangle2D16, affineTransform17, renderingHints18);
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = ringPlot1.getLabelPadding();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = null;
        ringPlot0.setLabelOutlineStroke(stroke1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLegendLabelToolTipGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double8 = rectangleInsets4.extendWidth((double) (byte) 10);
        double double10 = rectangleInsets4.calculateBottomOutset((double) 2);
        piePlot1.setInsets(rectangleInsets4, false);
        double double13 = piePlot1.getLabelGap();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 16.0d + "'", double8 == 16.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.025d + "'", double13 == 0.025d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double7 = rectangleInsets4.getTop();
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double12 = rectangleInsets4.calculateTopOutset((double) 255);
        textTitle1.setMargin(rectangleInsets4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle1.getHorizontalAlignment();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        int int7 = color0.getRed();
        int int8 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setStartAngle((double) 8);
        ringPlot1.setInnerSeparatorExtension(0.14d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes((double) (-1.0f), plotRenderingInfo9, point2D10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot16.getFixedDomainAxisSpace();
        int int18 = categoryPlot16.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot16.setDomainAxisLocation((int) (byte) 100, axisLocation20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot16.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder22);
        java.awt.Paint paint24 = categoryPlot4.getOutlinePaint();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color25);
        java.awt.Color color27 = color25.darker();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot4.getDomainMarkers(layer9);
        java.awt.Paint paint11 = categoryPlot4.getNoDataMessagePaint();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot4.getRangeAxis((int) (byte) 10);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Paint paint9 = valueMarker8.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = valueMarker8.getLabelOffsetType();
        double double11 = valueMarker8.getValue();
        float float12 = valueMarker8.getAlpha();
        try {
            boolean boolean13 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.8f + "'", float12 == 0.8f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getNoDataMessage();
        polarPlot3.setNoDataMessage("");
        polarPlot3.setRadiusGridlinesVisible(true);
        java.lang.Object obj15 = polarPlot3.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.2d, (double) 128, 10.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font7 = numberAxis6.getTickLabelFont();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis6.setDownArrow(shape8);
        piePlot1.setLegendItemShape(shape8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("RectangleAnchor.TOP_LEFT");
        boolean boolean13 = piePlot1.equals((java.lang.Object) "RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', 0.0d, rectangleAnchor3);
        size2D0.width = 45.0d;
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        java.awt.Stroke stroke38 = xYPlot35.getDomainZeroBaselineStroke();
        double double39 = xYPlot35.getDomainCrosshairValue();
        java.awt.Color color42 = java.awt.Color.getColor("Rotation.ANTICLOCKWISE", 10);
        xYPlot35.setDomainCrosshairPaint((java.awt.Paint) color42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot35.setRangeZeroBaselineStroke(stroke44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.Color color7 = java.awt.Color.orange;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets9);
        double double12 = rectangleInsets9.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) '#', 0.0d, rectangleAnchor16);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets9.createOutsetRectangle(rectangle2D17);
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color4.createContext(colorModel5, rectangle6, rectangle2D18, affineTransform19, renderingHints20);
        textTitle1.draw(graphics2D3, (java.awt.geom.Rectangle2D) rectangle6);
        textTitle1.setWidth((double) 10.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paintContext21);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.block.BlockContainer blockContainer38 = legendTitle18.getItemContainer();
        java.awt.Font font39 = legendTitle18.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = legendTitle18.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockContainer38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (-8355712));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            categoryAxis0.setTickLabelInsets(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", image3, "Other", "", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getName();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 192);
        double double3 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 192.0d + "'", double3 == 192.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Color color0 = java.awt.Color.darkGray;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray2);
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartChangeEvent3, (java.lang.Object) 1L);
        java.lang.String str6 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent3.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart3, 192, (int) ' ');
        java.lang.String str7 = chartProgressEvent6.toString();
        chartProgressEvent6.setType(4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1]" + "'", str7.equals("org.jfree.chart.event.ChartProgressEvent[source=-1]"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ClassContext", "ChartChangeEventType.GENERAL");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str3.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ClassContext" + "'", str4.equals("ClassContext"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double7 = rectangleInsets4.getTop();
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double12 = rectangleInsets4.calculateTopOutset((double) 255);
        textTitle1.setMargin(rectangleInsets4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle1.getTextAlignment();
        textTitle1.setID("Multiple Pie Plot");
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        size2D17.height = 0.0d;
        boolean boolean20 = textTitle1.equals((java.lang.Object) size2D17);
        textTitle1.setWidth((double) 128);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setExplodePercent((java.lang.Comparable) "java.awt.Color[r=255,g=200,b=0]", (double) 100.0f);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        double double26 = piePlotState25.getPieCenterY();
        double double27 = piePlotState25.getPieCenterY();
        piePlotState25.setPieCenterX(90.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = piePlotState25.getInfo();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo30);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.title.Title title3 = titleChangeEvent2.getTitle();
        org.junit.Assert.assertNotNull(title3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        int int7 = categoryPlot5.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes((double) 8, plotRenderingInfo10, point2D11, false);
        categoryPlot5.setWeight(100);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Paint paint21 = polarPlot20.getAngleGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot20.setOutlineStroke(stroke22);
        ringPlot16.setSeparatorStroke(stroke22);
        categoryPlot5.setRangeGridlineStroke(stroke22);
        ringPlot0.setSeparatorStroke(stroke22);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator27 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator27);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.TOP");
        java.text.AttributedString attributedString6 = null;
        standardPieSectionLabelGenerator4.setAttributedLabel((int) (byte) 100, attributedString6);
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) attributedString6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle2.getMargin();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        java.awt.Paint paint14 = polarPlot13.getAngleGridlinePaint();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot13.setOutlineStroke(stroke15);
        java.awt.Image image17 = null;
        polarPlot13.setBackgroundImage(image17);
        java.awt.Color color19 = java.awt.Color.orange;
        java.lang.Class<?> wildcardClass20 = color19.getClass();
        java.lang.String str21 = color19.toString();
        polarPlot13.setAngleGridlinePaint((java.awt.Paint) color19);
        boolean boolean23 = textTitle2.equals((java.lang.Object) color19);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str21.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D3, (double) '#', 0.0d, rectangleAnchor6);
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint4 = multiplePiePlot3.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot3.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart5, 192, (int) ' ');
        jFreeChart5.setTitle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint11 = jFreeChart5.getBorderPaint();
        boolean boolean12 = categoryAxis0.equals((java.lang.Object) paint11);
        categoryAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        xYPlot35.setFixedRangeAxisSpace(axisSpace38);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelLinkStroke(stroke8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot1.getURLGenerator();
        double double11 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getDomainAxis();
        xYPlot35.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot4.getDomainMarkers(layer9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightOutset((double) 10.0f);
        piePlot1.setSimpleLabelOffset(rectangleInsets6);
        double double11 = rectangleInsets6.calculateRightInset((double) (byte) 100);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        valueMarker1.setLabelPaint((java.awt.Paint) color2);
        valueMarker1.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1]");
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelGenerator();
        piePlot1.setShadowYOffset(90.0d);
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot35.getRangeAxis();
        org.jfree.data.Range range37 = valueAxis36.getDefaultAutoRange();
        valueAxis36.setRangeAboutValue(0.0d, 43.0d);
        double double41 = valueAxis36.getUpperBound();
        valueAxis36.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(valueAxis36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 21.5d + "'", double41 == 21.5d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("", font39, (java.awt.Paint) color40);
        numberAxis37.setTickLabelFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color46 = java.awt.Color.orange;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color46, stroke47, rectangleInsets48);
        double double51 = rectangleInsets48.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) '#', 0.0d, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets48.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot(xYDataset59, valueAxis60, polarItemRenderer61);
        java.awt.Paint paint63 = polarPlot62.getAngleGridlinePaint();
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot62.setOutlineStroke(stroke64);
        ringPlot58.setSeparatorStroke(stroke64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.PiePlotState piePlotState69 = ringPlot44.initialise(graphics2D45, rectangle2D57, (org.jfree.chart.plot.PiePlot) ringPlot58, (java.lang.Integer) 255, plotRenderingInfo68);
        numberAxis37.setDownArrow((java.awt.Shape) rectangle2D57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot35.drawAnnotations(graphics2D36, rectangle2D57, plotRenderingInfo71);
        org.jfree.data.general.PieDataset pieDataset73 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity79 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D57, pieDataset73, 0, (int) ' ', (java.lang.Comparable) 0.08d, "Multiple Pie Plot", "TextAnchor.HALF_ASCENT_RIGHT");
        pieSectionEntity79.setPieIndex(1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(piePlotState69);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 16.0d);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Shape shape6 = piePlot5.getLegendItemShape();
        java.awt.Paint paint7 = piePlot5.getLabelShadowPaint();
        piePlot5.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        java.awt.Paint paint11 = piePlot5.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Color color14 = java.awt.Color.orange;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets16);
        double double19 = rectangleInsets16.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D24 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (double) '#', 0.0d, rectangleAnchor23);
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets16.createOutsetRectangle(rectangle2D24);
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset27, valueAxis28, polarItemRenderer29);
        java.awt.Paint paint31 = polarPlot30.getAngleGridlinePaint();
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot30.setOutlineStroke(stroke32);
        ringPlot26.setSeparatorStroke(stroke32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.PiePlotState piePlotState37 = ringPlot12.initialise(graphics2D13, rectangle2D25, (org.jfree.chart.plot.PiePlot) ringPlot26, (java.lang.Integer) 255, plotRenderingInfo36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        double double40 = numberAxis39.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font43 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine45 = new org.jfree.chart.text.TextLine("", font43, (java.awt.Paint) color44);
        numberAxis41.setTickLabelFont(font43);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = numberAxis41.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot48 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot49 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot48.setParent((org.jfree.chart.plot.Plot) multiplePiePlot49);
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot(pieDataset51);
        java.awt.Shape shape53 = piePlot52.getLegendItemShape();
        boolean boolean54 = piePlot52.getSimpleLabels();
        piePlot52.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double59 = rectangleInsets57.calculateRightOutset((double) 10.0f);
        piePlot52.setSimpleLabelOffset(rectangleInsets57);
        boolean boolean61 = multiplePiePlot48.equals((java.lang.Object) piePlot52);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double64 = rectangleInsets62.calculateRightOutset((double) 10.0f);
        double double66 = rectangleInsets62.extendWidth((double) (byte) 10);
        double double68 = rectangleInsets62.calculateBottomOutset((double) 2);
        multiplePiePlot48.setInsets(rectangleInsets62);
        numberAxis41.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot48);
        float float71 = numberAxis41.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = null;
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis41, xYItemRenderer72);
        org.jfree.chart.axis.AxisLocation axisLocation75 = xYPlot73.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset77 = null;
        xYPlot73.setDataset((int) (short) 1, xYDataset77);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = xYPlot73.getRangeAxisEdge(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = xYPlot73.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace82 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace83 = categoryAxis0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) piePlot5, rectangle2D25, rectangleEdge81, axisSpace82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(piePlotState37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 3.0d + "'", double59 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.0d + "'", double64 == 3.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 16.0d + "'", double66 == 16.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 3.0d + "'", double68 == 3.0d);
        org.junit.Assert.assertTrue("'" + float71 + "' != '" + 0.0f + "'", float71 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(rectangleEdge81);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        int int7 = categoryPlot5.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes((double) 8, plotRenderingInfo10, point2D11, false);
        categoryPlot5.setWeight(100);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        java.awt.Paint paint21 = polarPlot20.getAngleGridlinePaint();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot20.setOutlineStroke(stroke22);
        ringPlot16.setSeparatorStroke(stroke22);
        categoryPlot5.setRangeGridlineStroke(stroke22);
        ringPlot0.setSeparatorStroke(stroke22);
        double double27 = ringPlot0.getInnerSeparatorExtension();
        java.awt.Paint paint28 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        java.awt.Stroke stroke38 = xYPlot35.getDomainZeroBaselineStroke();
        boolean boolean39 = xYPlot35.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint3 = multiplePiePlot2.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot2.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart4, 192, (int) ' ');
        int int8 = chartProgressEvent7.getType();
        boolean boolean9 = textBlock0.equals((java.lang.Object) chartProgressEvent7);
        int int10 = chartProgressEvent7.getType();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 192 + "'", int10 == 192);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("Multiple Pie Plot", font2);
        org.jfree.chart.text.TextFragment textFragment6 = textLine5.getLastTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textFragment6);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        numberAxis0.setLabelURL("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot35.setDomainCrosshairStroke(stroke38);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = categoryPlot44.getFixedDomainAxisSpace();
        int int46 = categoryPlot44.getWeight();
        java.awt.Color color47 = java.awt.Color.darkGray;
        categoryPlot44.setRangeCrosshairPaint((java.awt.Paint) color47);
        categoryPlot44.setWeight((int) ' ');
        java.awt.Stroke stroke51 = categoryPlot44.getRangeCrosshairStroke();
        xYPlot35.setDomainGridlineStroke(stroke51);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot1.getLabelDistributor();
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        piePlot1.setShadowXOffset((double) (byte) 100);
        java.awt.Color color12 = java.awt.Color.darkGray;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        numberAxis0.setLowerMargin((double) 10L);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis0.setNumberFormatOverride(numberFormat4);
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Shape shape3 = piePlot2.getLegendItemShape();
        java.awt.Paint paint4 = piePlot2.getLabelShadowPaint();
        piePlot2.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot2);
        categoryAxis0.setCategoryMargin(0.08d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Color color18 = java.awt.Color.orange;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke19, rectangleInsets20);
        double double23 = rectangleInsets20.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, (double) '#', 0.0d, rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets20.createOutsetRectangle(rectangle2D28);
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        categoryPlot16.draw(graphics2D17, rectangle2D28, point2D30, plotState31, plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        categoryPlot4.draw(graphics2D11, rectangle2D28, point2D34, plotState35, plotRenderingInfo36);
        categoryPlot4.setRangeCrosshairValue((double) 1.0f);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = categoryPlot45.getFixedDomainAxisSpace();
        int int47 = categoryPlot45.getWeight();
        java.awt.Color color48 = java.awt.Color.darkGray;
        categoryPlot45.setRangeCrosshairPaint((java.awt.Paint) color48);
        categoryPlot45.setWeight((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        categoryPlot45.setRenderer(categoryItemRenderer52, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset56 = null;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot(pieDataset56);
        java.awt.Shape shape58 = piePlot57.getLegendItemShape();
        java.awt.Paint paint59 = piePlot57.getLabelShadowPaint();
        piePlot57.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis55.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot57);
        int int64 = categoryPlot45.getDomainAxisIndex(categoryAxis55);
        categoryPlot4.setDomainAxis(128, categoryAxis55, true);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(axisSpace46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", image3, "Other", "", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo7.getLibraries();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot1.getLabelDistributor();
        piePlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int9 = categoryPlot4.getDatasetCount();
        boolean boolean10 = categoryPlot4.isRangeGridlinesVisible();
        categoryPlot4.setAnchorValue((double) 0.8f);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis0.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Color color9 = java.awt.Color.orange;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets11);
        double double14 = rectangleInsets11.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) '#', 0.0d, rectangleAnchor18);
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets11.createOutsetRectangle(rectangle2D19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset22, valueAxis23, polarItemRenderer24);
        java.awt.Paint paint26 = polarPlot25.getAngleGridlinePaint();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot25.setOutlineStroke(stroke27);
        ringPlot21.setSeparatorStroke(stroke27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.PiePlotState piePlotState32 = ringPlot7.initialise(graphics2D8, rectangle2D20, (org.jfree.chart.plot.PiePlot) ringPlot21, (java.lang.Integer) 255, plotRenderingInfo31);
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D20);
        java.awt.Font font34 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        numberAxis0.setTickLabelFont(font34);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(piePlotState32);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        boolean boolean5 = polarPlot3.isRadiusGridlinesVisible();
        polarPlot3.removeCornerTextItem("Other");
        java.lang.String str8 = polarPlot3.getPlotType();
        boolean boolean9 = polarPlot3.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Polar Plot" + "'", str8.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        xYPlot35.setWeight((int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset43 = xYPlot35.getDataset();
        boolean boolean44 = xYPlot35.isDomainZoomable();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent45 = null;
        xYPlot35.datasetChanged(datasetChangeEvent45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(xYDataset43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot1.getLegendLabelURLGenerator();
        java.lang.String str9 = piePlot1.getPlotType();
        double double10 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie Plot" + "'", str9.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot4.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset9, valueAxis10, polarItemRenderer11);
        java.awt.Paint paint13 = polarPlot12.getRadiusGridlinePaint();
        org.jfree.chart.axis.TickUnit tickUnit14 = polarPlot12.getAngleTickUnit();
        boolean boolean15 = legendItemCollection8.equals((java.lang.Object) polarPlot12);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(tickUnit14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double4 = rectangleInsets0.extendWidth((double) 10.0f);
        double double5 = rectangleInsets0.getRight();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.Color color9 = java.awt.Color.orange;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets11);
        double double14 = rectangleInsets11.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) '#', 0.0d, rectangleAnchor18);
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets11.createOutsetRectangle(rectangle2D19);
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color6.createContext(colorModel7, rectangle8, rectangle2D20, affineTransform21, renderingHints22);
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets0.createOutsetRectangle(rectangle2D20, true, true);
        double double28 = rectangleInsets0.calculateTopOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.0d + "'", double4 == 16.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot35.getDomainAxis();
        xYPlot35.clearAnnotations();
        xYPlot35.setRangeCrosshairValue((double) (-8355712), false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(valueAxis42);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("Other", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            textFragment2.draw(graphics2D3, (float) (byte) 100, (float) (short) 10, textAnchor6, 100.0f, (float) (byte) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', 0.0d, rectangleAnchor3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj6 = legendItemCollection5.clone();
        boolean boolean7 = rectangleAnchor3.equals((java.lang.Object) legendItemCollection5);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        valueMarker1.notifyListeners(markerChangeEvent2);
        double double4 = valueMarker1.getValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = valueMarker1.getLabelOffsetType();
        double double4 = valueMarker1.getValue();
        java.lang.Object obj5 = valueMarker1.clone();
        java.awt.Stroke stroke6 = valueMarker1.getStroke();
        float float7 = valueMarker1.getAlpha();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, (float) (short) 1, 0.5f);
        valueMarker1.setLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8f + "'", float7 == 0.8f);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        double double7 = numberAxis0.getLabelAngle();
        numberAxis0.configure();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat10 = numberAxis9.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType11 = numberAxis9.getRangeType();
        numberAxis0.setRangeType(rangeType11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = numberAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertNotNull(numberTickUnit13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double2 = rectangleConstraint1.getHeight();
        java.lang.String str3 = rectangleConstraint1.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint1.toFixedHeight((double) 100.0f);
        java.lang.Class<?> wildcardClass6 = rectangleConstraint1.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleAnchor.TOP_LEFT", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) multiplePiePlot2, true);
        multiplePiePlot2.setNoDataMessage("hi!");
        java.lang.Object obj9 = multiplePiePlot2.clone();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = multiplePiePlot2.getDrawingSupplier();
        java.awt.Color color11 = java.awt.Color.orange;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        int int18 = color11.getRed();
        multiplePiePlot2.setOutlinePaint((java.awt.Paint) color11);
        java.lang.String str20 = color11.toString();
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str20.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType2 = numberAxis0.getRangeType();
        numberAxis0.resizeRange((double) (byte) 10);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getDomainAxisLocation();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener3 = null;
        jFreeChart2.addProgressListener(chartProgressListener3);
        jFreeChart2.setTextAntiAlias(false);
        jFreeChart2.setNotify(true);
        java.awt.Image image12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image12, "", "", "");
        java.lang.String str17 = projectInfo16.getVersion();
        java.lang.String str18 = projectInfo16.toString();
        org.jfree.chart.text.TextBlock textBlock19 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint22 = multiplePiePlot21.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart23 = multiplePiePlot21.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart23, 192, (int) ' ');
        int int27 = chartProgressEvent26.getType();
        boolean boolean28 = textBlock19.equals((java.lang.Object) chartProgressEvent26);
        java.util.List list29 = textBlock19.getLines();
        projectInfo16.setContributors(list29);
        jFreeChart2.setSubtitles(list29);
        java.awt.Stroke stroke32 = jFreeChart2.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        try {
            java.awt.image.BufferedImage bufferedImage37 = jFreeChart2.createBufferedImage(100, (int) '#', (int) (short) 0, chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n" + "'", str18.equals(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(jFreeChart23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 192 + "'", int27 == 192);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        categoryPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = categoryPlot4.getOrientation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot4.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = categoryPlot17.getFixedDomainAxisSpace();
        int int19 = categoryPlot17.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = categoryPlot17.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot17.zoomRangeAxes((double) 8, plotRenderingInfo22, point2D23, false);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("", font31, (java.awt.Paint) color32);
        numberAxis29.setTickLabelFont(font31);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis29.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot36 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot37 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot36.setParent((org.jfree.chart.plot.Plot) multiplePiePlot37);
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        java.awt.Shape shape41 = piePlot40.getLegendItemShape();
        boolean boolean42 = piePlot40.getSimpleLabels();
        piePlot40.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double47 = rectangleInsets45.calculateRightOutset((double) 10.0f);
        piePlot40.setSimpleLabelOffset(rectangleInsets45);
        boolean boolean49 = multiplePiePlot36.equals((java.lang.Object) piePlot40);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double52 = rectangleInsets50.calculateRightOutset((double) 10.0f);
        double double54 = rectangleInsets50.extendWidth((double) (byte) 10);
        double double56 = rectangleInsets50.calculateBottomOutset((double) 2);
        multiplePiePlot36.setInsets(rectangleInsets50);
        numberAxis29.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot36);
        float float59 = numberAxis29.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis29, xYItemRenderer60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = xYPlot61.getDomainAxisLocation(0);
        categoryPlot17.setDomainAxisLocation(axisLocation63);
        categoryPlot4.setDomainAxisLocation((int) ' ', axisLocation63);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 3.0d + "'", double47 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.0d + "'", double52 == 3.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 16.0d + "'", double54 == 16.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 3.0d + "'", double56 == 3.0d);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        try {
            java.awt.image.BufferedImage bufferedImage6 = jFreeChart2.createBufferedImage(0, (int) (byte) 1, chartRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot35.getDomainAxis();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat44 = numberAxis43.getNumberFormatOverride();
        java.awt.Color color45 = java.awt.Color.CYAN;
        numberAxis43.setTickMarkPaint((java.awt.Paint) color45);
        xYPlot35.setDomainCrosshairPaint((java.awt.Paint) color45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(valueAxis42);
        org.junit.Assert.assertNull(numberFormat44);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Paint paint7 = polarPlot6.getAngleGridlinePaint();
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        polarPlot6.setAngleGridlineStroke(stroke9);
        java.lang.String str13 = polarPlot6.getNoDataMessage();
        polarPlot6.setNoDataMessage("");
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot6.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot6);
        jFreeChart2.addLegend(legendTitle18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.lang.String str23 = textTitle21.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double27 = rectangleInsets24.getTop();
        java.lang.String str28 = rectangleInsets24.toString();
        double double30 = rectangleInsets24.calculateLeftOutset((double) (short) 100);
        double double32 = rectangleInsets24.calculateTopOutset((double) 255);
        textTitle21.setMargin(rectangleInsets24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle21.getTextAlignment();
        legendTitle18.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.block.BlockContainer blockContainer38 = legendTitle18.getItemContainer();
        java.awt.Font font39 = legendTitle18.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = legendTitle18.getLegendItemGraphicPadding();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = categoryPlot45.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot45.setFixedDomainAxisSpace(axisSpace47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        categoryPlot45.zoomDomainAxes((double) (-1.0f), plotRenderingInfo50, point2D51);
        java.awt.Image image53 = categoryPlot45.getBackgroundImage();
        boolean boolean54 = legendTitle18.equals((java.lang.Object) categoryPlot45);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str28.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockContainer38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNull(axisSpace46);
        org.junit.Assert.assertNull(image53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, (java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextFragment textFragment8 = textLine7.getFirstTextFragment();
        textLine3.addFragment(textFragment8);
        java.awt.Paint paint10 = textFragment8.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textFragment8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        piePlot1.setLabelGap((double) (-1L));
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Shape shape8 = piePlot7.getLegendItemShape();
        boolean boolean9 = piePlot7.getSimpleLabels();
        piePlot7.setIgnoreNullValues(false);
        piePlot7.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = piePlot7.getLabelDistributor();
        piePlot1.setLabelDistributor(abstractPieLabelDistributor14);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot4.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot4.setDataset(categoryDataset9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        try {
            categoryPlot4.zoom((double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Stroke stroke3 = null;
        multiplePiePlot0.setOutlineStroke(stroke3);
        boolean boolean5 = multiplePiePlot0.isOutlineVisible();
        java.lang.String str6 = multiplePiePlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        boolean boolean5 = piePlot1.isCircular();
        java.awt.Stroke stroke6 = piePlot1.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        java.awt.Color color8 = java.awt.Color.orange;
        java.lang.Class<?> wildcardClass9 = color8.getClass();
        java.lang.String str10 = color8.toString();
        numberAxis0.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        double double16 = numberAxis15.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font19 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("", font19, (java.awt.Paint) color20);
        numberAxis17.setTickLabelFont(font19);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis17.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot24.setParent((org.jfree.chart.plot.Plot) multiplePiePlot25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.awt.Shape shape29 = piePlot28.getLegendItemShape();
        boolean boolean30 = piePlot28.getSimpleLabels();
        piePlot28.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double35 = rectangleInsets33.calculateRightOutset((double) 10.0f);
        piePlot28.setSimpleLabelOffset(rectangleInsets33);
        boolean boolean37 = multiplePiePlot24.equals((java.lang.Object) piePlot28);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double40 = rectangleInsets38.calculateRightOutset((double) 10.0f);
        double double42 = rectangleInsets38.extendWidth((double) (byte) 10);
        double double44 = rectangleInsets38.calculateBottomOutset((double) 2);
        multiplePiePlot24.setInsets(rectangleInsets38);
        numberAxis17.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot24);
        float float47 = numberAxis17.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer48);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font53 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine55 = new org.jfree.chart.text.TextLine("", font53, (java.awt.Paint) color54);
        numberAxis51.setTickLabelFont(font53);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = numberAxis51.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.Color color60 = java.awt.Color.orange;
        java.awt.Stroke stroke61 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder63 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color60, stroke61, rectangleInsets62);
        double double65 = rectangleInsets62.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D66 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D70 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D66, (double) '#', 0.0d, rectangleAnchor69);
        java.awt.geom.Rectangle2D rectangle2D71 = rectangleInsets62.createOutsetRectangle(rectangle2D70);
        org.jfree.chart.plot.RingPlot ringPlot72 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer75 = null;
        org.jfree.chart.plot.PolarPlot polarPlot76 = new org.jfree.chart.plot.PolarPlot(xYDataset73, valueAxis74, polarItemRenderer75);
        java.awt.Paint paint77 = polarPlot76.getAngleGridlinePaint();
        java.awt.Stroke stroke78 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot76.setOutlineStroke(stroke78);
        ringPlot72.setSeparatorStroke(stroke78);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        org.jfree.chart.plot.PiePlotState piePlotState83 = ringPlot58.initialise(graphics2D59, rectangle2D71, (org.jfree.chart.plot.PiePlot) ringPlot72, (java.lang.Integer) 255, plotRenderingInfo82);
        numberAxis51.setDownArrow((java.awt.Shape) rectangle2D71);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        xYPlot49.drawAnnotations(graphics2D50, rectangle2D71, plotRenderingInfo85);
        java.awt.geom.AffineTransform affineTransform87 = null;
        java.awt.RenderingHints renderingHints88 = null;
        java.awt.PaintContext paintContext89 = color8.createContext(colorModel12, rectangle13, rectangle2D71, affineTransform87, renderingHints88);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str10.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 16.0d + "'", double42 == 16.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 3.0d + "'", double44 == 3.0d);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 3.0d + "'", double65 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(piePlotState83);
        org.junit.Assert.assertNotNull(paintContext89);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getAngleLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        polarPlot3.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = polarPlot3.isAngleLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        polarPlot3.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight((double) 100.0f);
        org.jfree.chart.util.Size2D size2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = rectangleConstraint4.calculateConstrainedSize(size2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        boolean boolean3 = jFreeChartResources0.containsKey("");
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getNoDataMessage();
        polarPlot3.setNoDataMessage("");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot3.setRadiusGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot3);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font18, (java.awt.Paint) color19);
        numberAxis16.setTickLabelFont(font18);
        java.awt.Shape shape22 = numberAxis16.getLeftArrow();
        java.awt.Shape shape23 = numberAxis16.getDownArrow();
        boolean boolean24 = numberAxis16.isInverted();
        double double25 = numberAxis16.getLabelAngle();
        org.jfree.data.Range range26 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis16);
        numberAxis16.resizeRange(0.0d, (double) 1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        int int24 = categoryPlot4.getDomainAxisCount();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot35.getRangeAxis();
        org.jfree.data.Range range37 = valueAxis36.getDefaultAutoRange();
        try {
            valueAxis36.zoomRange(4.0d, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (4.2) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(valueAxis36);
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        double double1 = rotation0.getFactor();
        double double2 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis0.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Color color9 = java.awt.Color.orange;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets11);
        double double14 = rectangleInsets11.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) '#', 0.0d, rectangleAnchor18);
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets11.createOutsetRectangle(rectangle2D19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset22, valueAxis23, polarItemRenderer24);
        java.awt.Paint paint26 = polarPlot25.getAngleGridlinePaint();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot25.setOutlineStroke(stroke27);
        ringPlot21.setSeparatorStroke(stroke27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.PiePlotState piePlotState32 = ringPlot7.initialise(graphics2D8, rectangle2D20, (org.jfree.chart.plot.PiePlot) ringPlot21, (java.lang.Integer) 255, plotRenderingInfo31);
        numberAxis0.setDownArrow((java.awt.Shape) rectangle2D20);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "Pie Plot");
        java.lang.Object obj36 = chartEntity35.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(piePlotState32);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        boolean boolean3 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(false);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot1.setLabelLinkStroke(stroke8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot1.getURLGenerator();
        piePlot1.setMinimumArcAngleToDraw(100.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(pieURLGenerator10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = piePlotState25.getInfo();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertNull(plotRenderingInfo26);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot4.setOrientation(plotOrientation8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset((int) ' ');
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(categoryDataset11);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        int int9 = categoryPlot4.getDatasetCount();
        boolean boolean10 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot4.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot4.getRangeAxisLocation((int) (short) 100);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        paintMap0.clear();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getAngleLabelFont();
        java.awt.Image image5 = polarPlot3.getBackgroundImage();
        java.awt.Paint paint6 = polarPlot3.getAngleGridlinePaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint3 = multiplePiePlot2.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot2.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart4, 192, (int) ' ');
        int int8 = chartProgressEvent7.getType();
        boolean boolean9 = textBlock0.equals((java.lang.Object) chartProgressEvent7);
        chartProgressEvent7.setPercent(10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        numberAxis0.setVisible(true);
        java.awt.Color color11 = java.awt.Color.orange;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color11, stroke12, rectangleInsets13);
        double double16 = rectangleInsets13.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, (double) '#', 0.0d, rectangleAnchor20);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets13.createOutsetRectangle(rectangle2D21);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean25 = chartChangeEventType23.equals((java.lang.Object) rectangleEdge24);
        java.lang.String str26 = rectangleEdge24.toString();
        double double27 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D22, rectangleEdge24);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean30 = chartChangeEventType28.equals((java.lang.Object) rectangleEdge29);
        java.lang.String str31 = rectangleEdge29.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge29);
        double double33 = numberAxis0.valueToJava2D((double) 1L, rectangle2D22, rectangleEdge32);
        numberAxis0.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleEdge.TOP" + "'", str26.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-3.0d) + "'", double27 == (-3.0d));
        org.junit.Assert.assertNotNull(chartChangeEventType28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleEdge.TOP" + "'", str31.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 38.0d + "'", double33 == 38.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getDomainAxis();
        int int42 = xYPlot35.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        xYPlot35.setDataset(0, xYDataset44);
        java.awt.Stroke stroke46 = xYPlot35.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = xYPlot35.getDomainMarkers(layer47);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(collection48);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Shape shape4 = piePlot3.getLegendItemShape();
        java.awt.Paint paint5 = piePlot3.getLabelShadowPaint();
        piePlot3.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3);
        double double10 = categoryAxis1.getCategoryMargin();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        double double13 = numberAxis12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("", font16, (java.awt.Paint) color17);
        numberAxis14.setTickLabelFont(font16);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis14.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot21.setParent((org.jfree.chart.plot.Plot) multiplePiePlot22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Shape shape26 = piePlot25.getLegendItemShape();
        boolean boolean27 = piePlot25.getSimpleLabels();
        piePlot25.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double32 = rectangleInsets30.calculateRightOutset((double) 10.0f);
        piePlot25.setSimpleLabelOffset(rectangleInsets30);
        boolean boolean34 = multiplePiePlot21.equals((java.lang.Object) piePlot25);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateRightOutset((double) 10.0f);
        double double39 = rectangleInsets35.extendWidth((double) (byte) 10);
        double double41 = rectangleInsets35.calculateBottomOutset((double) 2);
        multiplePiePlot21.setInsets(rectangleInsets35);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot21);
        float float44 = numberAxis14.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer47);
        categoryPlot48.mapDatasetToRangeAxis(2, (int) (short) 1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.0d + "'", double37 == 3.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 16.0d + "'", double39 == 16.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.0d + "'", double41 == 3.0d);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', 0.0d, rectangleAnchor3);
        double double5 = size2D0.getHeight();
        size2D0.setHeight((double) 0L);
        java.lang.String str8 = size2D0.toString();
        double double9 = size2D0.height;
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str8.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomRangeAxes((double) 8, plotRenderingInfo9, point2D10, false);
        categoryPlot4.setWeight(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot4.getDomainAxisEdge(8);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.Color color7 = java.awt.Color.orange;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets9);
        double double12 = rectangleInsets9.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) '#', 0.0d, rectangleAnchor16);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets9.createOutsetRectangle(rectangle2D17);
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color4.createContext(colorModel5, rectangle6, rectangle2D18, affineTransform19, renderingHints20);
        textTitle1.draw(graphics2D3, (java.awt.geom.Rectangle2D) rectangle6);
        java.awt.Paint paint23 = textTitle1.getBackgroundPaint();
        boolean boolean24 = textTitle1.getNotify();
        boolean boolean25 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        textTitle1.setText("");
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        double double10 = rectangleInsets7.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) '#', 0.0d, rectangleAnchor14);
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets7.createOutsetRectangle(rectangle2D15);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) rectangleEdge18);
        java.lang.String str20 = rectangleEdge18.toString();
        double double21 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D16, rectangleEdge18);
        java.awt.Color color22 = java.awt.Color.red;
        java.lang.Object obj23 = textTitle1.draw(graphics2D4, rectangle2D16, (java.lang.Object) color22);
        java.awt.Paint paint24 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleEdge.TOP" + "'", str20.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-3.0d) + "'", double21 == (-3.0d));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot35.getRangeAxis();
        org.jfree.data.xy.XYDataset xYDataset37 = xYPlot35.getDataset();
        java.awt.Paint paint38 = null;
        xYPlot35.setRangeTickBandPaint(paint38);
        java.awt.Color color40 = java.awt.Color.DARK_GRAY;
        xYPlot35.setRangeGridlinePaint((java.awt.Paint) color40);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(valueAxis36);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        ringPlot4.setStartAngle((double) 8);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font9, (java.awt.Paint) color10);
        numberAxis7.setTickLabelFont(font9);
        java.awt.Shape shape13 = numberAxis7.getLeftArrow();
        java.awt.Shape shape14 = numberAxis7.getDownArrow();
        boolean boolean15 = ringPlot4.equals((java.lang.Object) numberAxis7);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateRightOutset((double) 10.0f);
        double double20 = rectangleInsets16.extendWidth((double) 10.0f);
        double double21 = rectangleInsets16.getRight();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        java.awt.Color color25 = java.awt.Color.orange;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color25, stroke26, rectangleInsets27);
        double double30 = rectangleInsets27.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, (double) '#', 0.0d, rectangleAnchor34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets27.createOutsetRectangle(rectangle2D35);
        java.awt.geom.AffineTransform affineTransform37 = null;
        java.awt.RenderingHints renderingHints38 = null;
        java.awt.PaintContext paintContext39 = color22.createContext(colorModel23, rectangle24, rectangle2D36, affineTransform37, renderingHints38);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets16.createOutsetRectangle(rectangle2D36, true, true);
        numberAxis7.setRightArrow((java.awt.Shape) rectangle2D42);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean46 = chartChangeEventType44.equals((java.lang.Object) rectangleEdge45);
        java.lang.String str47 = rectangleEdge45.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge45);
        double double49 = categoryAxis3D0.getCategoryMiddle(8, (int) (byte) 1, rectangle2D42, rectangleEdge45);
        categoryAxis3D0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 16.0d + "'", double20 == 16.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(paintContext39);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "RectangleEdge.TOP" + "'", str47.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 121.4d + "'", double49 == 121.4d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setParent((org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) multiplePiePlot2, true);
        multiplePiePlot2.setNoDataMessage("hi!");
        java.lang.Object obj9 = multiplePiePlot2.clone();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = multiplePiePlot2.getDrawingSupplier();
        boolean boolean11 = multiplePiePlot2.isSubplot();
        java.lang.String str12 = multiplePiePlot2.getPlotType();
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Multiple Pie Plot" + "'", str12.equals("Multiple Pie Plot"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        int int42 = xYPlot35.getDatasetCount();
        int int43 = xYPlot35.getSeriesCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) '#', (double) 128);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot35.getRangeAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray37 = null;
        try {
            xYPlot35.setDomainAxes(valueAxisArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(valueAxis36);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot4.setOrientation(plotOrientation8);
        java.awt.Color color10 = java.awt.Color.darkGray;
        float[] floatArray11 = null;
        float[] floatArray12 = color10.getRGBColorComponents(floatArray11);
        boolean boolean13 = plotOrientation8.equals((java.lang.Object) floatArray12);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getDomainAxis();
        int int42 = xYPlot35.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = xYPlot35.getRenderer((-1));
        xYPlot35.setDomainGridlinesVisible(false);
        java.awt.Stroke stroke47 = xYPlot35.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(xYItemRenderer44);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        int int11 = categoryPlot9.getWeight();
        java.awt.Color color12 = java.awt.Color.darkGray;
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace14);
        boolean boolean16 = textAnchor4.equals((java.lang.Object) axisSpace14);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            java.awt.Shape shape19 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.TOP_LEFT", graphics2D1, 10.0f, 10.0f, textAnchor4, (double) (byte) 100, textAnchor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint3 = multiplePiePlot2.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot2.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart4, 192, (int) ' ');
        int int8 = chartProgressEvent7.getType();
        boolean boolean9 = textBlock0.equals((java.lang.Object) chartProgressEvent7);
        java.util.List list10 = textBlock0.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textBlock0.getLineAlignment();
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("RectangleEdge.TOP");
        textBlock0.addLine(textLine13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement22 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment19, (double) 100L, (double) (byte) 10);
        columnArrangement22.clear();
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement22);
        org.jfree.chart.block.Block block25 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        columnArrangement22.add(block25, (java.lang.Object) textBlockAnchor26);
        try {
            textBlock0.draw(graphics2D15, (float) '4', (float) 1, textBlockAnchor26, (float) (byte) 1, (float) (short) 10, 45.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(1, (int) (short) 0, 192);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Shape shape4 = piePlot3.getLegendItemShape();
        boolean boolean5 = piePlot3.getSimpleLabels();
        piePlot3.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double10 = rectangleInsets8.calculateRightOutset((double) 10.0f);
        piePlot3.setSimpleLabelOffset(rectangleInsets8);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Shape shape14 = piePlot13.getLegendItemShape();
        boolean boolean15 = piePlot13.getSimpleLabels();
        piePlot13.setIgnoreNullValues(false);
        piePlot13.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot13.getLabelDistributor();
        java.awt.Paint paint21 = piePlot13.getBaseSectionOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets8, paint21);
        ringPlot0.setInsets(rectangleInsets8);
        org.jfree.chart.util.Rotation rotation24 = ringPlot0.getDirection();
        org.junit.Assert.assertNull(pieURLGenerator1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rotation24);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "", "", "");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.Object obj10 = null;
        boolean boolean11 = projectInfo7.equals(obj10);
        java.lang.String str12 = projectInfo7.getVersion();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint14 = multiplePiePlot13.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot13.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart15.addProgressListener(chartProgressListener16);
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart15.createBufferedImage((int) ' ', 10);
        projectInfo7.setLogo((java.awt.Image) bufferedImage20);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNotNull(bufferedImage20);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font39 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("", font39, (java.awt.Paint) color40);
        numberAxis37.setTickLabelFont(font39);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis37.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color46 = java.awt.Color.orange;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color46, stroke47, rectangleInsets48);
        double double51 = rectangleInsets48.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) '#', 0.0d, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets48.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot(xYDataset59, valueAxis60, polarItemRenderer61);
        java.awt.Paint paint63 = polarPlot62.getAngleGridlinePaint();
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot62.setOutlineStroke(stroke64);
        ringPlot58.setSeparatorStroke(stroke64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.PiePlotState piePlotState69 = ringPlot44.initialise(graphics2D45, rectangle2D57, (org.jfree.chart.plot.PiePlot) ringPlot58, (java.lang.Integer) 255, plotRenderingInfo68);
        numberAxis37.setDownArrow((java.awt.Shape) rectangle2D57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot35.drawAnnotations(graphics2D36, rectangle2D57, plotRenderingInfo71);
        org.jfree.data.general.PieDataset pieDataset73 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity79 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D57, pieDataset73, 0, (int) ' ', (java.lang.Comparable) 0.08d, "Multiple Pie Plot", "TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.data.general.PieDataset pieDataset80 = pieSectionEntity79.getDataset();
        int int81 = pieSectionEntity79.getPieIndex();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(piePlotState69);
        org.junit.Assert.assertNull(pieDataset80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        java.awt.Color color42 = java.awt.Color.MAGENTA;
        xYPlot35.setRangeTickBandPaint((java.awt.Paint) color42);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray44 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot35.setRenderers(xYItemRendererArray44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(xYItemRendererArray44);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        double double26 = piePlotState25.getPieCenterY();
        double double27 = piePlotState25.getPieCenterY();
        java.awt.geom.Rectangle2D rectangle2D28 = piePlotState25.getLinkArea();
        piePlotState25.setLatestAngle((double) 100.0f);
        int int31 = piePlotState25.getPassesRequired();
        piePlotState25.setLatestAngle((double) 0L);
        piePlotState25.setPieCenterY((double) ' ');
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Class class2 = null;
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.lang.Class<?> wildcardClass4 = color3.getClass();
        java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Multiple Pie Plot", class2, (java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("Multiple Pie Plot", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(uRL6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("Other", font3);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ClassContext", font3);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("RectangleAnchor.BOTTOM_RIGHT", font3);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 0, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        java.lang.Object obj7 = null;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle6, obj7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.Color color13 = java.awt.Color.orange;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color13, stroke14, rectangleInsets15);
        double double18 = rectangleInsets15.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) '#', 0.0d, rectangleAnchor22);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets15.createOutsetRectangle(rectangle2D23);
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color10.createContext(colorModel11, rectangle12, rectangle2D24, affineTransform25, renderingHints26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint29 = multiplePiePlot28.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart30 = multiplePiePlot28.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener31 = null;
        jFreeChart30.addProgressListener(chartProgressListener31);
        jFreeChart30.fireChartChanged();
        float float34 = jFreeChart30.getBackgroundImageAlpha();
        java.awt.image.BufferedImage bufferedImage37 = jFreeChart30.createBufferedImage((int) ' ', (int) (short) 10);
        java.lang.Object obj38 = textTitle6.draw(graphics2D9, (java.awt.geom.Rectangle2D) rectangle12, (java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(paintContext27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(jFreeChart30);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.5f + "'", float34 == 0.5f);
        org.junit.Assert.assertNotNull(bufferedImage37);
        org.junit.Assert.assertNull(obj38);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str1.equals("TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot4.getOrientation();
        categoryPlot4.configureRangeAxes();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color9);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color2 = java.awt.Color.orange;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
        double double7 = rectangleInsets4.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 0.0d, rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        java.awt.Paint paint19 = polarPlot18.getAngleGridlinePaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot18.setOutlineStroke(stroke20);
        ringPlot14.setSeparatorStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot0.initialise(graphics2D1, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 255, plotRenderingInfo24);
        try {
            ringPlot14.setInteriorGap(4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (4.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState25);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double7 = rectangleInsets4.getTop();
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double12 = rectangleInsets4.calculateTopOutset((double) 255);
        textTitle1.setMargin(rectangleInsets4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle1.getTextAlignment();
        boolean boolean15 = textTitle1.getNotify();
        textTitle1.setText("");
        textTitle1.setNotify(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double4 = rectangleInsets0.extendWidth((double) 10.0f);
        boolean boolean6 = rectangleInsets0.equals((java.lang.Object) (-16777216));
        double double8 = rectangleInsets0.trimHeight((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.0d + "'", double4 == 16.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-6.0d) + "'", double8 == (-6.0d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Paint paint3 = blockBorder1.getPaint();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        int int8 = color7.getRed();
        java.awt.Color color9 = java.awt.Color.darkGray;
        float[] floatArray10 = null;
        float[] floatArray11 = color9.getRGBColorComponents(floatArray10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray11);
        float[] floatArray13 = color7.getRGBColorComponents(floatArray11);
        piePlot5.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color7);
        java.awt.Stroke stroke15 = piePlot5.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateRightOutset((double) 10.0f);
        double double19 = rectangleInsets16.getTop();
        java.lang.String str20 = rectangleInsets16.toString();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint3, stroke15, rectangleInsets16);
        double double23 = rectangleInsets16.calculateTopInset(43.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 192 + "'", int8 == 192);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str20.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double3 = rectangleInsets0.getTop();
        double double5 = rectangleInsets0.calculateRightInset((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range1, (double) (-8355712));
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Color color1 = java.awt.Color.getColor("TextBlockAnchor.TOP_CENTER");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot3.setOutlineStroke(stroke5);
        polarPlot3.removeCornerTextItem("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        polarPlot3.setAxis(valueAxis9);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart3, 192, (int) ' ');
        jFreeChart3.setTitle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint9 = jFreeChart3.getBorderPaint();
        jFreeChart3.removeLegend();
        jFreeChart3.clearSubtitles();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        java.awt.Color color7 = java.awt.Color.darkGray;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color7);
        categoryPlot4.setWeight((int) ' ');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Shape shape17 = piePlot16.getLegendItemShape();
        java.awt.Paint paint18 = piePlot16.getLabelShadowPaint();
        piePlot16.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis14.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot16);
        int int23 = categoryPlot4.getDomainAxisIndex(categoryAxis14);
        java.awt.Paint paint24 = categoryPlot4.getDomainGridlinePaint();
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot4.getColumnRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat29 = numberAxis28.getNumberFormatOverride();
        numberAxis28.setAutoTickUnitSelection(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer32);
        int int34 = categoryAxis27.getMaximumCategoryLabelLines();
        categoryPlot4.setDomainAxis(categoryAxis27);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNull(numberFormat29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getNoDataMessage();
        polarPlot3.setNoDataMessage("");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot3.setRadiusGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot3);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle15.getLegendItemGraphicEdge();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = valueMarker18.getLabelOffset();
        boolean boolean20 = legendTitle15.equals((java.lang.Object) rectangleInsets19);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        boolean boolean2 = numberAxis0.isAutoRange();
        numberAxis0.setPositiveArrowVisible(true);
        boolean boolean5 = numberAxis0.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        java.awt.Stroke stroke38 = xYPlot35.getDomainZeroBaselineStroke();
        double double39 = xYPlot35.getDomainCrosshairValue();
        java.awt.Color color42 = java.awt.Color.getColor("Rotation.ANTICLOCKWISE", 10);
        xYPlot35.setDomainCrosshairPaint((java.awt.Paint) color42);
        java.awt.Paint paint44 = xYPlot35.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(paint44);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener3 = null;
        jFreeChart2.addProgressListener(chartProgressListener3);
        jFreeChart2.fireChartChanged();
        float float6 = jFreeChart2.getBackgroundImageAlpha();
        java.awt.image.BufferedImage bufferedImage9 = jFreeChart2.createBufferedImage((int) ' ', (int) (short) 10);
        jFreeChart2.fireChartChanged();
        java.lang.Object obj11 = jFreeChart2.clone();
        java.awt.Image image12 = jFreeChart2.getBackgroundImage();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNotNull(bufferedImage9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(image12);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str3 = textTitle1.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateRightOutset((double) 10.0f);
        double double7 = rectangleInsets4.getTop();
        java.lang.String str8 = rectangleInsets4.toString();
        double double10 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double12 = rectangleInsets4.calculateTopOutset((double) 255);
        textTitle1.setMargin(rectangleInsets4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle1.getTextAlignment();
        textTitle1.setID("Multiple Pie Plot");
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Shape shape19 = piePlot18.getLegendItemShape();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = piePlot18.getLegendLabelToolTipGenerator();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot(xYDataset21, valueAxis22, polarItemRenderer23);
        java.awt.Font font25 = polarPlot24.getAngleLabelFont();
        java.awt.Color color26 = java.awt.Color.LIGHT_GRAY;
        int int27 = color26.getRed();
        polarPlot24.setAngleGridlinePaint((java.awt.Paint) color26);
        piePlot18.setLabelPaint((java.awt.Paint) color26);
        textTitle1.setPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str8.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 192 + "'", int27 == 192);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        int int42 = xYPlot35.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font46 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine48 = new org.jfree.chart.text.TextLine("", font46, (java.awt.Paint) color47);
        numberAxis44.setTickLabelFont(font46);
        java.awt.Shape shape50 = numberAxis44.getLeftArrow();
        java.awt.Paint paint51 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis44.setTickLabelPaint(paint51);
        xYPlot35.setQuadrantPaint((int) (short) 1, paint51);
        xYPlot35.clearDomainMarkers(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot35.setDomainCrosshairStroke(stroke38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot35.getRangeMarkers((int) (byte) 100, layer41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double46 = rectangleInsets44.calculateRightOutset((double) 10.0f);
        double double48 = rectangleInsets44.extendWidth((double) 10.0f);
        double double49 = rectangleInsets44.getRight();
        java.awt.Color color50 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel51 = null;
        java.awt.Rectangle rectangle52 = null;
        java.awt.Color color53 = java.awt.Color.orange;
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color53, stroke54, rectangleInsets55);
        double double58 = rectangleInsets55.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D59 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, (double) '#', 0.0d, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets55.createOutsetRectangle(rectangle2D63);
        java.awt.geom.AffineTransform affineTransform65 = null;
        java.awt.RenderingHints renderingHints66 = null;
        java.awt.PaintContext paintContext67 = color50.createContext(colorModel51, rectangle52, rectangle2D64, affineTransform65, renderingHints66);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets44.createOutsetRectangle(rectangle2D64, true, true);
        try {
            xYPlot35.drawBackground(graphics2D43, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 3.0d + "'", double46 == 3.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 16.0d + "'", double48 == 16.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 3.0d + "'", double49 == 3.0d);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 3.0d + "'", double58 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(paintContext67);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Paint paint3 = valueMarker2.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = valueMarker2.getLabelOffsetType();
        java.lang.String str5 = valueMarker2.getLabel();
        java.awt.Font font6 = valueMarker2.getLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font9, (java.awt.Paint) color10);
        numberAxis7.setTickLabelFont(font9);
        java.awt.Shape shape13 = numberAxis7.getLeftArrow();
        java.awt.Shape shape14 = numberAxis7.getDownArrow();
        numberAxis7.setVisible(true);
        java.awt.Paint paint17 = numberAxis7.getLabelPaint();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer21 = new org.jfree.chart.text.G2TextMeasurer(graphics2D20);
        try {
            org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.BOTTOM_RIGHT", font6, paint17, (float) 2, 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat3 = numberAxis2.getNumberFormatOverride();
        numberAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, categoryItemRenderer6);
        int int8 = categoryAxis1.getMaximumCategoryLabelLines();
        float float9 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        double double7 = numberAxis0.getLabelAngle();
        numberAxis0.configure();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat10 = numberAxis9.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType11 = numberAxis9.getRangeType();
        numberAxis0.setRangeType(rangeType11);
        float float13 = numberAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartProgressListener chartProgressListener4 = null;
        jFreeChart3.addProgressListener(chartProgressListener4);
        jFreeChart3.setTextAntiAlias(false);
        jFreeChart3.setNotify(true);
        jFreeChart3.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 2, jFreeChart3, chartChangeEventType12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomDomainAxes((double) ' ', plotRenderingInfo10, point2D11, true);
        categoryPlot4.setWeight(128);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent23);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = categoryPlot21.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot21.setDataset(categoryDataset26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot21.getAxisOffset();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("", font31, (java.awt.Paint) color32);
        numberAxis29.setTickLabelFont(font31);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis29.getTickLabelInsets();
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.Color color38 = java.awt.Color.orange;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder41 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color38, stroke39, rectangleInsets40);
        double double43 = rectangleInsets40.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D44 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, (double) '#', 0.0d, rectangleAnchor47);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets40.createOutsetRectangle(rectangle2D48);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot();
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer53 = null;
        org.jfree.chart.plot.PolarPlot polarPlot54 = new org.jfree.chart.plot.PolarPlot(xYDataset51, valueAxis52, polarItemRenderer53);
        java.awt.Paint paint55 = polarPlot54.getAngleGridlinePaint();
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot54.setOutlineStroke(stroke56);
        ringPlot50.setSeparatorStroke(stroke56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        org.jfree.chart.plot.PiePlotState piePlotState61 = ringPlot36.initialise(graphics2D37, rectangle2D49, (org.jfree.chart.plot.PiePlot) ringPlot50, (java.lang.Integer) 255, plotRenderingInfo60);
        numberAxis29.setDownArrow((java.awt.Shape) rectangle2D49);
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets28.createOutsetRectangle(rectangle2D49, false, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        boolean boolean68 = categoryPlot4.render(graphics2D16, rectangle2D49, 0, plotRenderingInfo67);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 3.0d + "'", double43 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(piePlotState61);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot35.getRangeAxisEdge(0);
        java.awt.Paint paint43 = xYPlot35.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace44 = xYPlot35.getFixedDomainAxisSpace();
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot35.getDomainMarkers(layer45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNull(axisSpace44);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 10.0f);
        double double4 = rectangleInsets0.extendWidth((double) 10.0f);
        double double5 = rectangleInsets0.getRight();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.Color color9 = java.awt.Color.orange;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets11);
        double double14 = rectangleInsets11.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) '#', 0.0d, rectangleAnchor18);
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets11.createOutsetRectangle(rectangle2D19);
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color6.createContext(colorModel7, rectangle8, rectangle2D20, affineTransform21, renderingHints22);
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets0.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot31.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent33 = null;
        categoryPlot31.datasetChanged(datasetChangeEvent33);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = categoryPlot31.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot31.zoomDomainAxes((double) ' ', plotRenderingInfo37, point2D38, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot31.getDomainAxisEdge((int) '#');
        double double43 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D20, rectangleEdge42);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.0d + "'", double4 == 16.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-3.0d) + "'", double43 == (-3.0d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot1.setLabelFont(font2);
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Color color5 = java.awt.Color.orange;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot4.getInsets();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        valueMarker10.notifyListeners(markerChangeEvent11);
        double double13 = valueMarker10.getValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightOutset((double) 10.0f);
        double double17 = rectangleInsets14.getTop();
        java.lang.String str18 = rectangleInsets14.toString();
        double double20 = rectangleInsets14.extendHeight((double) (-1.0f));
        valueMarker10.setLabelOffset(rectangleInsets14);
        org.jfree.chart.util.Layer layer22 = null;
        try {
            boolean boolean23 = categoryPlot4.removeRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker10, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str18.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 5.0d + "'", double20 == 5.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Shape shape11 = piePlot10.getLegendItemShape();
        java.awt.Paint paint12 = piePlot10.getLabelShadowPaint();
        boolean boolean13 = piePlot10.getIgnoreNullValues();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) piePlot10);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        java.awt.Paint paint18 = blockBorder16.getPaint();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        int int23 = color22.getRed();
        java.awt.Color color24 = java.awt.Color.darkGray;
        float[] floatArray25 = null;
        float[] floatArray26 = color24.getRGBColorComponents(floatArray25);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray26);
        float[] floatArray28 = color22.getRGBColorComponents(floatArray26);
        piePlot20.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color22);
        java.awt.Stroke stroke30 = piePlot20.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double33 = rectangleInsets31.calculateRightOutset((double) 10.0f);
        double double34 = rectangleInsets31.getTop();
        java.lang.String str35 = rectangleInsets31.toString();
        org.jfree.chart.block.LineBorder lineBorder36 = new org.jfree.chart.block.LineBorder(paint18, stroke30, rectangleInsets31);
        piePlot10.setNoDataMessagePaint(paint18);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 192 + "'", int23 == 192);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.0d + "'", double34 == 3.0d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str35.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke4 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange2);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange2, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        double double11 = numberAxis10.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font14, (java.awt.Paint) color15);
        numberAxis12.setTickLabelFont(font14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis12.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot19.setParent((org.jfree.chart.plot.Plot) multiplePiePlot20);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        java.awt.Shape shape24 = piePlot23.getLegendItemShape();
        boolean boolean25 = piePlot23.getSimpleLabels();
        piePlot23.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets28.calculateRightOutset((double) 10.0f);
        piePlot23.setSimpleLabelOffset(rectangleInsets28);
        boolean boolean32 = multiplePiePlot19.equals((java.lang.Object) piePlot23);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double35 = rectangleInsets33.calculateRightOutset((double) 10.0f);
        double double37 = rectangleInsets33.extendWidth((double) (byte) 10);
        double double39 = rectangleInsets33.calculateBottomOutset((double) 2);
        multiplePiePlot19.setInsets(rectangleInsets33);
        numberAxis12.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot19);
        float float42 = numberAxis12.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot44.getRangeAxis();
        org.jfree.data.Range range46 = valueAxis45.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, range46);
        org.jfree.data.Range range49 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange8, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double51 = rectangleConstraint50.getHeight();
        java.lang.String str52 = rectangleConstraint50.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = rectangleConstraint50.toFixedHeight((double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = rectangleConstraint50.toFixedHeight((double) (-16777216));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType57 = rectangleConstraint50.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, (org.jfree.data.Range) dateRange2, lengthConstraintType6, (double) 4, (org.jfree.data.Range) dateRange8, lengthConstraintType57);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 16.0d + "'", double37 == 16.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.0d + "'", double39 == 3.0d);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(valueAxis45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str52.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint54);
        org.junit.Assert.assertNotNull(rectangleConstraint56);
        org.junit.Assert.assertNotNull(lengthConstraintType57);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot35.getFixedRangeAxisSpace();
        int int42 = xYPlot35.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font46 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine48 = new org.jfree.chart.text.TextLine("", font46, (java.awt.Paint) color47);
        numberAxis44.setTickLabelFont(font46);
        java.awt.Shape shape50 = numberAxis44.getLeftArrow();
        java.awt.Paint paint51 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis44.setTickLabelPaint(paint51);
        xYPlot35.setQuadrantPaint((int) (short) 1, paint51);
        double double54 = xYPlot35.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot35.getRangeAxis((-1));
        int int38 = xYPlot35.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) defaultDrawingSupplier1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint4 = defaultDrawingSupplier3.getNextPaint();
        java.awt.Stroke stroke5 = defaultDrawingSupplier3.getNextOutlineStroke();
        java.awt.Paint paint6 = defaultDrawingSupplier3.getNextOutlinePaint();
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) defaultDrawingSupplier3);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font13, (java.awt.Paint) color14);
        numberAxis11.setTickLabelFont(font13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis11.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot18.setParent((org.jfree.chart.plot.Plot) multiplePiePlot19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        java.awt.Shape shape23 = piePlot22.getLegendItemShape();
        boolean boolean24 = piePlot22.getSimpleLabels();
        piePlot22.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double29 = rectangleInsets27.calculateRightOutset((double) 10.0f);
        piePlot22.setSimpleLabelOffset(rectangleInsets27);
        boolean boolean31 = multiplePiePlot18.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double34 = rectangleInsets32.calculateRightOutset((double) 10.0f);
        double double36 = rectangleInsets32.extendWidth((double) (byte) 10);
        double double38 = rectangleInsets32.calculateBottomOutset((double) 2);
        multiplePiePlot18.setInsets(rectangleInsets32);
        numberAxis11.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot18);
        float float41 = numberAxis11.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot43.getDomainAxisLocation(0);
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot43.setDomainCrosshairStroke(stroke46);
        boolean boolean48 = chartChangeEventType0.equals((java.lang.Object) stroke46);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.0d + "'", double34 == 3.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 16.0d + "'", double36 == 16.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.0d + "'", double38 == 3.0d);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font2, (java.awt.Paint) color3);
        numberAxis0.setTickLabelFont(font2);
        java.awt.Shape shape6 = numberAxis0.getLeftArrow();
        java.awt.Shape shape7 = numberAxis0.getDownArrow();
        boolean boolean8 = numberAxis0.isInverted();
        double double9 = numberAxis0.getLabelAngle();
        java.text.NumberFormat numberFormat10 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(numberFormat10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot4.zoomRangeAxes((double) (byte) 10, (double) ' ', plotRenderingInfo10, point2D11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot4.getRendererForDataset(categoryDataset13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot4.getRangeAxisEdge();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font5, (java.awt.Paint) color6);
        numberAxis3.setTickLabelFont(font5);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot10.setParent((org.jfree.chart.plot.Plot) multiplePiePlot11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Shape shape15 = piePlot14.getLegendItemShape();
        boolean boolean16 = piePlot14.getSimpleLabels();
        piePlot14.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double21 = rectangleInsets19.calculateRightOutset((double) 10.0f);
        piePlot14.setSimpleLabelOffset(rectangleInsets19);
        boolean boolean23 = multiplePiePlot10.equals((java.lang.Object) piePlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateRightOutset((double) 10.0f);
        double double28 = rectangleInsets24.extendWidth((double) (byte) 10);
        double double30 = rectangleInsets24.calculateBottomOutset((double) 2);
        multiplePiePlot10.setInsets(rectangleInsets24);
        numberAxis3.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot10);
        float float33 = numberAxis3.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot35.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (short) 1, xYDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getDomainAxis();
        int int42 = xYPlot35.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = xYPlot35.getRenderer((-1));
        java.awt.Paint paint45 = xYPlot35.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(xYItemRenderer44);
        org.junit.Assert.assertNull(paint45);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) '#', 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        categoryPlot4.draw(graphics2D5, rectangle2D16, point2D18, plotState19, plotRenderingInfo20);
        float float22 = categoryPlot4.getBackgroundAlpha();
        int int23 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot4.getRangeAxis(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot4.setRenderer(categoryItemRenderer26, false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setParent((org.jfree.chart.plot.Plot) multiplePiePlot5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Shape shape9 = piePlot8.getLegendItemShape();
        boolean boolean10 = piePlot8.getSimpleLabels();
        piePlot8.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double15 = rectangleInsets13.calculateRightOutset((double) 10.0f);
        piePlot8.setSimpleLabelOffset(rectangleInsets13);
        boolean boolean17 = multiplePiePlot4.equals((java.lang.Object) piePlot8);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightOutset((double) 10.0f);
        double double22 = rectangleInsets18.extendWidth((double) (byte) 10);
        double double24 = rectangleInsets18.calculateBottomOutset((double) 2);
        multiplePiePlot4.setInsets(rectangleInsets18);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot(xYDataset26, valueAxis27, polarItemRenderer28);
        java.awt.Paint paint30 = polarPlot29.getAngleGridlinePaint();
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        polarPlot29.setOutlineStroke(stroke31);
        multiplePiePlot4.setOutlineStroke(stroke31);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((-6.0d), paint1, stroke2, paint3, stroke31, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 16.0d + "'", double22 == 16.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getAngleGridlinePaint();
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets7);
        polarPlot3.setAngleGridlineStroke(stroke6);
        java.lang.String str10 = polarPlot3.getNoDataMessage();
        polarPlot3.setNoDataMessage("");
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot3.setRadiusGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot3);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font18, (java.awt.Paint) color19);
        numberAxis16.setTickLabelFont(font18);
        java.awt.Shape shape22 = numberAxis16.getLeftArrow();
        java.awt.Shape shape23 = numberAxis16.getDownArrow();
        boolean boolean24 = numberAxis16.isInverted();
        double double25 = numberAxis16.getLabelAngle();
        org.jfree.data.Range range26 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis16);
        boolean boolean27 = numberAxis16.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(0.0d);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
        textTitle4.setText("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Color color8 = java.awt.Color.orange;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets10);
        double double13 = rectangleInsets10.calculateLeftInset((double) (-1.0f));
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, (double) '#', 0.0d, rectangleAnchor17);
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets10.createOutsetRectangle(rectangle2D18);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean22 = chartChangeEventType20.equals((java.lang.Object) rectangleEdge21);
        java.lang.String str23 = rectangleEdge21.toString();
        double double24 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge21);
        java.awt.Color color25 = java.awt.Color.red;
        java.lang.Object obj26 = textTitle4.draw(graphics2D7, rectangle2D19, (java.lang.Object) color25);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets0.createInsetRectangle(rectangle2D19);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D19, "TextBlockAnchor.TOP_RIGHT");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleEdge.TOP" + "'", str23.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-3.0d) + "'", double24 == (-3.0d));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        int int6 = categoryPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot4.setDomainAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Shape shape12 = piePlot11.getLegendItemShape();
        java.awt.Paint paint13 = piePlot11.getLabelShadowPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = piePlot11.getToolTipGenerator();
        org.jfree.chart.plot.Plot plot15 = piePlot11.getRootPlot();
        boolean boolean16 = categoryPlot4.equals((java.lang.Object) piePlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot4.getRangeAxisEdge();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(pieToolTipGenerator14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        java.awt.Stroke stroke4 = jFreeChart3.getBorderStroke();
        categoryAxis3D0.setAxisLineStroke(stroke4);
        categoryAxis3D0.setMaximumCategoryLabelLines((int) ' ');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes((double) (-1.0f), plotRenderingInfo9, point2D10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot16.getFixedDomainAxisSpace();
        int int18 = categoryPlot16.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot16.setDomainAxisLocation((int) (byte) 100, axisLocation20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot16.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder22);
        java.awt.Paint paint24 = categoryPlot4.getOutlinePaint();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color25);
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot4.getRangeMarkers(layer28);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(collection29);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getRed();
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBColorComponents(floatArray6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        piePlot1.setSectionPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color3);
        java.awt.Stroke stroke11 = piePlot1.getLabelOutlineStroke();
        double double12 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor13 = piePlot1.getLabelDistributor();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = null;
        piePlot1.setURLGenerator(pieURLGenerator14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator16);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.14d + "'", double12 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Shape shape6 = piePlot5.getLegendItemShape();
        java.awt.Paint paint7 = piePlot5.getLabelShadowPaint();
        piePlot5.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        categoryAxis3.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot5);
        double double12 = categoryAxis3.getCategoryMargin();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font18, (java.awt.Paint) color19);
        numberAxis16.setTickLabelFont(font18);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis16.getTickLabelInsets();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot23.setParent((org.jfree.chart.plot.Plot) multiplePiePlot24);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        java.awt.Shape shape28 = piePlot27.getLegendItemShape();
        boolean boolean29 = piePlot27.getSimpleLabels();
        piePlot27.setIgnoreNullValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double34 = rectangleInsets32.calculateRightOutset((double) 10.0f);
        piePlot27.setSimpleLabelOffset(rectangleInsets32);
        boolean boolean36 = multiplePiePlot23.equals((java.lang.Object) piePlot27);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double39 = rectangleInsets37.calculateRightOutset((double) 10.0f);
        double double41 = rectangleInsets37.extendWidth((double) (byte) 10);
        double double43 = rectangleInsets37.calculateBottomOutset((double) 2);
        multiplePiePlot23.setInsets(rectangleInsets37);
        numberAxis16.setPlot((org.jfree.chart.plot.Plot) multiplePiePlot23);
        float float46 = numberAxis16.getTickMarkInsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer49);
        boolean boolean51 = piePlot3D1.equals((java.lang.Object) categoryPlot50);
        double double52 = piePlot3D1.getDepthFactor();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.0d + "'", double34 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.0d + "'", double39 == 3.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 16.0d + "'", double41 == 16.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 3.0d + "'", double43 == 3.0d);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.0f + "'", float46 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.12d + "'", double52 == 0.12d);
    }
}

