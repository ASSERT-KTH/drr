import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        long long9 = day8.getSerialIndex();
        timePeriodValues1.setKey((java.lang.Comparable) long9);
        int int11 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43830L + "'", long9 == 43830L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setKey((java.lang.Comparable) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        int int5 = timePeriodValues4.getMaxMiddleIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) 10);
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day13, 0.0d);
        timePeriodValues4.delete((int) '4', 11);
        int int19 = timePeriodValues4.getMaxEndIndex();
        int int20 = timePeriodValues4.getMaxMiddleIndex();
        java.lang.String str21 = timePeriodValues4.getRangeDescription();
        timePeriodValues4.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getSerialIndex();
        java.util.Calendar calendar16 = null;
        try {
            day11.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43830L + "'", long15 == 43830L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getSerialIndex();
        int int17 = year10.compareTo((java.lang.Object) long16);
        long long18 = year10.getFirstMillisecond();
        long long19 = year10.getSerialIndex();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year10.getMiddleMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        int int8 = timePeriodValues1.getItemCount();
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean10 = timePeriodValues9.isEmpty();
        java.lang.Class<?> wildcardClass11 = timePeriodValues9.getClass();
        int int12 = timePeriodValues9.getMinMiddleIndex();
        int int13 = timePeriodValues9.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues9.createCopy((int) (byte) 10, 4);
        boolean boolean17 = year5.equals((java.lang.Object) timePeriodValues16);
        java.lang.String str18 = timePeriodValues16.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues16.createCopy((int) (byte) 1, 0);
        int int24 = year0.compareTo((java.lang.Object) timePeriodValues16);
        int int25 = timePeriodValues16.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        boolean boolean10 = year0.equals((java.lang.Object) date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.next();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass13 = year12.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year12);
        java.lang.Class<?> wildcardClass15 = year12.getClass();
        int int16 = year0.compareTo((java.lang.Object) wildcardClass15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.Object obj18 = seriesChangeEvent17.getSource();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (byte) 10, 4);
        boolean boolean9 = timePeriodValues1.isEmpty();
        int int10 = timePeriodValues1.getMinEndIndex();
        boolean boolean11 = timePeriodValues1.isEmpty();
        timePeriodValues1.setDescription("TimePeriodValue[2019,null]");
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues1.createCopy((int) (byte) -1, 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getMiddleMillisecond();
//        long long6 = day0.getSerialIndex();
//        int int7 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (-1L));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        boolean boolean14 = timePeriodValues1.equals((java.lang.Object) day13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean10 = timePeriodValues9.isEmpty();
        java.lang.Class<?> wildcardClass11 = timePeriodValues9.getClass();
        int int12 = timePeriodValues9.getMinMiddleIndex();
        int int13 = timePeriodValues9.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues9.createCopy((int) (byte) 10, 4);
        boolean boolean17 = year5.equals((java.lang.Object) timePeriodValues16);
        java.lang.String str18 = timePeriodValues16.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues16.createCopy((int) (byte) 1, 0);
        int int24 = year0.compareTo((java.lang.Object) timePeriodValues16);
        try {
            timePeriodValues16.update(9, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener15);
        java.lang.Object obj17 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.delete((int) ' ', (-1));
        timePeriodValues1.setDomainDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass10 = year9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date7, timeZone12);
        boolean boolean15 = timePeriodValues1.equals((java.lang.Object) timeZone12);
        int int16 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean24 = timePeriodValues23.isEmpty();
        java.lang.Class<?> wildcardClass25 = timePeriodValues23.getClass();
        int int26 = timePeriodValues23.getMinMiddleIndex();
        int int27 = timePeriodValues23.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues23.createCopy((int) (byte) 10, 4);
        boolean boolean31 = year19.equals((java.lang.Object) timePeriodValues30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) 10);
        java.util.Date date35 = year32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass38 = year37.getClass();
        java.util.Date date39 = null;
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date39, timeZone40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date35, timeZone40);
        int int43 = year19.compareTo((java.lang.Object) date35);
        long long44 = year19.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year19, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 1577822399999L);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean23 = timePeriodValues22.isEmpty();
        java.lang.Class<?> wildcardClass24 = timePeriodValues22.getClass();
        int int25 = timePeriodValues22.getMinMiddleIndex();
        int int26 = timePeriodValues22.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = timePeriodValues22.createCopy((int) (byte) 10, 4);
        boolean boolean30 = year18.equals((java.lang.Object) timePeriodValues29);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean30);
        boolean boolean32 = timePeriodValues1.equals((java.lang.Object) boolean30);
        java.lang.Comparable comparable33 = timePeriodValues1.getKey();
        int int34 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: 31-December-2019");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 1577822399999L + "'", comparable33.equals(1577822399999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.Year year8 = org.jfree.data.time.Year.parseYear("2019");
        long long9 = year8.getFirstMillisecond();
        int int10 = day5.compareTo((java.lang.Object) long9);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        java.lang.Object obj6 = timePeriodValues1.clone();
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (byte) 10, 4);
        java.lang.Object obj9 = timePeriodValues8.clone();
        int int10 = timePeriodValues8.getMinEndIndex();
        int int11 = timePeriodValues8.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, (int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (byte) 10, 4);
        java.lang.Object obj9 = timePeriodValues8.clone();
        java.lang.String str10 = timePeriodValues8.getDescription();
        int int11 = timePeriodValues8.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("13-June-2019");
        java.lang.Object obj18 = timePeriodValues1.clone();
        java.lang.String str19 = timePeriodValues1.getRangeDescription();
        java.lang.String str20 = timePeriodValues1.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue22 = timePeriodValues1.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues1.getMinMiddleIndex();
        try {
            timePeriodValues1.delete(7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.Class<?> wildcardClass6 = timePeriodValues4.getClass();
        int int7 = timePeriodValues4.getMinMiddleIndex();
        int int8 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy((int) (byte) 10, 4);
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass19 = year18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date16, timeZone21);
        int int24 = year0.compareTo((java.lang.Object) date16);
        long long25 = year0.getSerialIndex();
        int int26 = year0.getYear();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year0.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean22 = timePeriodValues21.isEmpty();
        java.lang.Class<?> wildcardClass23 = timePeriodValues21.getClass();
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) 10);
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) 10);
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date37, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date17, timeZone39);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, (int) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues2.setRangeDescription("hi!");
        java.lang.String str5 = timePeriodValues2.getDomainDescription();
        boolean boolean7 = timePeriodValues2.equals((java.lang.Object) '4');
        java.lang.Object obj8 = timePeriodValues2.clone();
        java.lang.String str9 = timePeriodValues2.getDescription();
        int int10 = timePeriodValues2.getMaxEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (byte) 10, 4);
        java.lang.Object obj9 = timePeriodValues8.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues8.addChangeListener(seriesChangeListener10);
        timePeriodValues8.setDomainDescription("TimePeriodValue[2019,0.0]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(100L, 100L);
        long long17 = simpleTimePeriod16.getStartMillis();
        java.util.Date date18 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) 10);
        java.util.Date date22 = year19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.String str24 = day23.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
        int int26 = simpleTimePeriod16.compareTo((java.lang.Object) regularTimePeriod25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) 10);
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass33 = year32.getClass();
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date30, timeZone35);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date30);
        int int39 = simpleTimePeriod16.compareTo((java.lang.Object) day38);
        boolean boolean40 = timePeriodValues8.equals((java.lang.Object) simpleTimePeriod16);
        timePeriodValues8.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.Class<?> wildcardClass6 = timePeriodValues4.getClass();
        int int7 = timePeriodValues4.getMinMiddleIndex();
        int int8 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy((int) (byte) 10, 4);
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass19 = year18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date16, timeZone21);
        int int24 = year0.compareTo((java.lang.Object) date16);
        long long25 = year0.getSerialIndex();
        int int26 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 2019L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getSerialIndex();
        int int17 = year10.compareTo((java.lang.Object) long16);
        java.lang.Class<?> wildcardClass18 = year10.getClass();
        long long19 = year10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year10.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        int int4 = year0.getYear();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.Class<?> wildcardClass6 = timePeriodValues4.getClass();
        int int7 = timePeriodValues4.getMinMiddleIndex();
        int int8 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy((int) (byte) 10, 4);
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass19 = year18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date16, timeZone21);
        int int24 = year0.compareTo((java.lang.Object) date16);
        long long25 = year0.getSerialIndex();
        int int26 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year0.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Class<?> wildcardClass5 = simpleTimePeriod2.getClass();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        java.lang.Object obj2 = null;
        boolean boolean3 = timePeriodValues1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.lang.String str7 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 43830L);
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        int int4 = year0.getYear();
        java.lang.Number number5 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number5);
        java.util.Date date7 = year0.getStart();
        java.lang.Number number8 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number8);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
        long long10 = day9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean9 = timePeriodValues8.isEmpty();
        java.lang.Class<?> wildcardClass10 = timePeriodValues8.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10);
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date24, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date3, date24);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean31 = timePeriodValues30.isEmpty();
        java.lang.Class<?> wildcardClass32 = timePeriodValues30.getClass();
        int int33 = timePeriodValues30.getMinMiddleIndex();
        int int34 = timePeriodValues30.getMaxEndIndex();
        int int35 = timePeriodValues30.getMinStartIndex();
        try {
            int int36 = simpleTimePeriod28.compareTo((java.lang.Object) int35);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) 10);
        java.util.Date date4 = year1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        java.lang.Class<?> wildcardClass8 = day5.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) 10);
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass15 = year14.getClass();
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date12, timeZone17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date23 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean26 = timePeriodValues25.isEmpty();
        java.lang.Class<?> wildcardClass27 = timePeriodValues25.getClass();
        int int28 = timePeriodValues25.getMinMiddleIndex();
        int int29 = timePeriodValues25.getMaxEndIndex();
        int int30 = timePeriodValues25.getItemCount();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        java.util.Date date34 = year31.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        long long36 = day35.getLastMillisecond();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day35, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day35.previous();
        int int40 = simpleTimePeriod22.compareTo((java.lang.Object) regularTimePeriod39);
        long long41 = simpleTimePeriod22.getStartMillis();
        long long42 = simpleTimePeriod22.getStartMillis();
        java.util.Date date43 = simpleTimePeriod22.getEnd();
        java.util.Date date44 = simpleTimePeriod22.getEnd();
        java.util.Date date45 = simpleTimePeriod22.getStart();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone46);
        try {
            org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date0, timeZone46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        long long5 = year0.getSerialIndex();
        int int6 = year0.getYear();
        long long7 = year0.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        java.lang.String str6 = day4.toString();
        int int7 = day4.getYear();
        long long8 = day4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=100]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.String str4 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str6 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.lang.Number number4 = timePeriodValue3.getValue();
        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        timePeriodValues1.setRangeDescription("hi!");
        java.lang.String str17 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year18, 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year18.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass7 = year6.getClass();
        int int8 = day4.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        int int10 = year6.getYear();
        java.lang.Object obj11 = null;
        boolean boolean12 = year6.equals(obj11);
        java.util.Date date13 = year6.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.previous();
        long long17 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate18 = day11.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean7 = timePeriodValues1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        timePeriodValues1.delete(9, 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10);
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass11 = year10.getClass();
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date8, timeZone13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date4, timeZone13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean19 = timePeriodValues18.isEmpty();
        java.lang.Class<?> wildcardClass20 = timePeriodValues18.getClass();
        int int21 = timePeriodValues18.getMinMiddleIndex();
        int int22 = timePeriodValues18.getMaxEndIndex();
        int int23 = timePeriodValues18.getItemCount();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) 10);
        java.util.Date date27 = year24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        long long29 = day28.getLastMillisecond();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day28, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day28.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date4, date34);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean39 = timePeriodValues38.isEmpty();
        java.lang.Class<?> wildcardClass40 = timePeriodValues38.getClass();
        int int41 = timePeriodValues38.getMinMiddleIndex();
        int int42 = timePeriodValues38.getMaxEndIndex();
        int int43 = timePeriodValues38.getItemCount();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        boolean boolean46 = year44.equals((java.lang.Object) 10);
        java.util.Date date47 = year44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        long long49 = day48.getLastMillisecond();
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) day48, (double) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        timePeriodValues38.addChangeListener(seriesChangeListener52);
        try {
            int int54 = simpleTimePeriod36.compareTo((java.lang.Object) seriesChangeListener52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        int int8 = timePeriodValues5.getMinMiddleIndex();
        int int9 = timePeriodValues5.getMaxEndIndex();
        int int10 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.previous();
        int int20 = simpleTimePeriod2.compareTo((java.lang.Object) regularTimePeriod19);
        long long21 = simpleTimePeriod2.getStartMillis();
        long long22 = simpleTimePeriod2.getStartMillis();
        java.util.Date date23 = simpleTimePeriod2.getEnd();
        java.util.Date date24 = simpleTimePeriod2.getEnd();
        java.util.Date date25 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = year27.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean22 = timePeriodValues21.isEmpty();
        java.lang.Class<?> wildcardClass23 = timePeriodValues21.getClass();
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) 10);
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) 10);
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date37, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date17, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year41.compareTo((java.lang.Object) year42);
        java.util.Calendar calendar44 = null;
        try {
            year41.peg(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (byte) 10, 4);
        boolean boolean9 = timePeriodValues1.isEmpty();
        int int10 = timePeriodValues1.getMinEndIndex();
        boolean boolean11 = timePeriodValues1.isEmpty();
        timePeriodValues1.setDescription("TimePeriodValue[2019,null]");
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10);
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean23 = timePeriodValues22.isEmpty();
        java.lang.Class<?> wildcardClass24 = timePeriodValues22.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) 10);
        java.util.Date date31 = year28.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date31, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) 10);
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date38, timeZone40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date17, date38);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date17);
        int int45 = day44.getYear();
        java.util.Calendar calendar46 = null;
        try {
            long long47 = day44.getMiddleMillisecond(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        java.lang.Class<?> wildcardClass7 = day4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean16 = timePeriodValues15.isEmpty();
        java.lang.Class<?> wildcardClass17 = timePeriodValues15.getClass();
        int int18 = timePeriodValues15.getMinMiddleIndex();
        int int19 = timePeriodValues15.getMaxEndIndex();
        int int20 = timePeriodValues15.getItemCount();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        long long26 = day25.getLastMillisecond();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day25, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day25.previous();
        int int30 = simpleTimePeriod12.compareTo((java.lang.Object) regularTimePeriod29);
        long long31 = simpleTimePeriod12.getStartMillis();
        long long32 = simpleTimePeriod12.getStartMillis();
        java.util.Date date33 = simpleTimePeriod12.getEnd();
        java.util.Date date34 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) 10);
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) 10);
        java.util.Date date44 = year41.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass47 = year46.getClass();
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date48, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date44, timeZone49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date38, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date34, timeZone49);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getSerialIndex();
        int int17 = year10.compareTo((java.lang.Object) long16);
        java.lang.Class<?> wildcardClass18 = year10.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass18);
        java.lang.Object obj20 = seriesChangeEvent19.getSource();
        java.lang.Object obj21 = seriesChangeEvent19.getSource();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, 0.0d);
        timePeriodValues1.add(timePeriodValue12);
        java.lang.String str14 = timePeriodValue12.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str14.equals("TimePeriodValue[2019,0.0]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        int int7 = day4.compareTo((java.lang.Object) 2019L);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day4.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 1577822399999L);
        boolean boolean18 = timePeriodValues1.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1577822399999L + "'", comparable19.equals(1577822399999L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        java.util.Date date4 = year0.getStart();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1577779200000L);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        boolean boolean2 = timePeriodValues1.isEmpty();
//        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
//        java.lang.String str4 = timePeriodValues1.getDescription();
//        int int5 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
//        java.lang.String str8 = day6.toString();
//        long long9 = day6.getFirstMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) long9);
//        int int11 = timePeriodValues1.getMaxMiddleIndex();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=100]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getSerialIndex();
        int int17 = year10.compareTo((java.lang.Object) long16);
        long long18 = year10.getFirstMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date22 = simpleTimePeriod21.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        int int25 = day24.getDayOfMonth();
        int int26 = day24.getYear();
        boolean boolean27 = year10.equals((java.lang.Object) int26);
        java.lang.String str28 = year10.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.Class<?> wildcardClass6 = timePeriodValues4.getClass();
        int int7 = timePeriodValues4.getMinMiddleIndex();
        int int8 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy((int) (byte) 10, 4);
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues11);
        java.lang.String str13 = timePeriodValues11.getRangeDescription();
        timePeriodValues11.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues11.createCopy((int) (byte) 10, (int) '#');
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean20 = timePeriodValues19.isEmpty();
        java.lang.Class<?> wildcardClass21 = timePeriodValues19.getClass();
        int int22 = timePeriodValues19.getMinMiddleIndex();
        int int23 = timePeriodValues19.getMaxEndIndex();
        int int24 = timePeriodValues19.getItemCount();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) 10);
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getLastMillisecond();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day29, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day29.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.next();
        java.util.Date date35 = regularTimePeriod34.getStart();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        timePeriodValues17.setKey((java.lang.Comparable) date35);
        java.lang.Comparable comparable39 = timePeriodValues17.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(comparable39);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(0, (int) (byte) 100);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        long long8 = year5.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, (double) (-1.0f));
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, 43830L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException9.getSuppressed();
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) throwableArray12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        boolean boolean2 = timePeriodValues1.isEmpty();
//        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        int int5 = timePeriodValues1.getMaxEndIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        boolean boolean10 = timePeriodValues9.isEmpty();
//        java.lang.Class<?> wildcardClass11 = timePeriodValues9.getClass();
//        int int12 = timePeriodValues9.getMinMiddleIndex();
//        int int13 = timePeriodValues9.getMaxEndIndex();
//        boolean boolean14 = timePeriodValues9.getNotify();
//        timePeriodValues9.setNotify(true);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.lang.String str18 = year17.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 0.0d);
//        timePeriodValues9.add(timePeriodValue20);
//        timePeriodValues1.add(timePeriodValue20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day23);
//        java.lang.String str25 = day23.toString();
//        long long26 = day23.getFirstMillisecond();
//        long long27 = day23.getLastMillisecond();
//        boolean boolean28 = timePeriodValue20.equals((java.lang.Object) long27);
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        boolean boolean31 = timePeriodValues30.isEmpty();
//        java.lang.Class<?> wildcardClass32 = timePeriodValues30.getClass();
//        int int33 = timePeriodValues30.getMinMiddleIndex();
//        int int34 = timePeriodValues30.getMaxStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues30.removePropertyChangeListener(propertyChangeListener35);
//        boolean boolean37 = timePeriodValue20.equals((java.lang.Object) propertyChangeListener35);
//        java.lang.Number number38 = timePeriodValue20.getValue();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560409200000L + "'", long26 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560495599999L + "'", long27 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0.0d + "'", number38.equals(0.0d));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.Class<?> wildcardClass6 = timePeriodValues4.getClass();
        int int7 = timePeriodValues4.getMinMiddleIndex();
        int int8 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy((int) (byte) 10, 4);
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues11);
        java.lang.String str13 = timePeriodValues11.getRangeDescription();
        timePeriodValues11.fireSeriesChanged();
        timePeriodValues11.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("2019");
        timePeriodValues1.setDomainDescription("TimePeriodValue[2019,0.0]");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) 10);
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass23 = year22.getClass();
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date20, timeZone25);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date14, timeZone25);
        boolean boolean29 = timePeriodValues1.equals((java.lang.Object) timeZone25);
        java.lang.String str30 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.util.Date date10 = year5.getEnd();
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) year5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod2.equals(obj12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', 100L);
        boolean boolean4 = simpleTimePeriod2.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        java.lang.Class<?> wildcardClass7 = day4.getClass();
        long long8 = day4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43830L + "'", long8 == 43830L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        java.util.Date date5 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod(date4, date5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        int int5 = timePeriodValues4.getMaxMiddleIndex();
        int int6 = timePeriodValues4.getMinStartIndex();
        int int7 = timePeriodValues4.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (byte) 10, 4);
        java.lang.String str9 = timePeriodValues1.getDomainDescription();
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        java.lang.String str11 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (byte) 10 + "'", comparable10.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.Object obj5 = seriesChangeEvent4.getSource();
        java.lang.Object obj6 = seriesChangeEvent4.getSource();
        java.lang.String str7 = seriesChangeEvent4.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str7);
        java.lang.String str9 = seriesChangeEvent8.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesChangeEvent[source=2019]]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesChangeEvent[source=2019]]"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Class<?> wildcardClass5 = simpleTimePeriod2.getClass();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass9 = year8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year8);
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10);
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        boolean boolean18 = year8.equals((java.lang.Object) date15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date15);
        try {
            int int21 = simpleTimePeriod2.compareTo((java.lang.Object) date15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        java.lang.Object obj8 = null;
        int int9 = day5.compareTo(obj8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day5.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 1577822399999L);
        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        java.lang.String str6 = day4.toString();
        int int7 = day4.getYear();
        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day11);
        java.lang.Class<?> wildcardClass18 = timePeriodValues17.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = year10.equals(obj13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues2.setRangeDescription("hi!");
        java.lang.String str5 = timePeriodValues2.getDomainDescription();
        timePeriodValues2.setRangeDescription("13-June-2019");
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        int int7 = day4.compareTo((java.lang.Object) 2019L);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day4.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,0]");
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,1577865599999]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.Class<?> wildcardClass6 = timePeriodValues4.getClass();
        int int7 = timePeriodValues4.getMinMiddleIndex();
        int int8 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy((int) (byte) 10, 4);
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues11);
        java.lang.String str13 = timePeriodValues11.getRangeDescription();
        timePeriodValues11.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues11.createCopy((int) (byte) 10, (int) '#');
        try {
            java.lang.Number number19 = timePeriodValues11.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues17);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.delete(8, (int) (byte) -1);
        java.lang.String str8 = timePeriodValues1.getDescription();
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        int int8 = timePeriodValues5.getMinMiddleIndex();
        int int9 = timePeriodValues5.getMaxEndIndex();
        int int10 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.previous();
        int int20 = simpleTimePeriod2.compareTo((java.lang.Object) regularTimePeriod19);
        long long21 = simpleTimePeriod2.getStartMillis();
        long long22 = simpleTimePeriod2.getStartMillis();
        java.util.Date date23 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) 10);
        java.util.Date date27 = year24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass30 = year29.getClass();
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date27, timeZone32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date23, timeZone32);
        org.jfree.data.time.SerialDate serialDate36 = day35.getSerialDate();
        java.util.Calendar calendar37 = null;
        try {
            long long38 = day35.getFirstMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.Class<?> wildcardClass6 = timePeriodValues4.getClass();
        int int7 = timePeriodValues4.getMinMiddleIndex();
        int int8 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy((int) (byte) 10, 4);
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues11);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 10.0f);
        long long19 = year14.getFirstMillisecond();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate7);
        java.lang.String str9 = seriesChangeEvent8.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=31-December-2019]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=31-December-2019]"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10);
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean23 = timePeriodValues22.isEmpty();
        java.lang.Class<?> wildcardClass24 = timePeriodValues22.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) 10);
        java.util.Date date31 = year28.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date31, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) 10);
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date38, timeZone40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date17, date38);
        long long43 = simpleTimePeriod42.getStartMillis();
        java.util.Date date44 = simpleTimePeriod42.getStart();
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(7, 0);
        timePeriodValues9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        int int7 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (byte) 1, 12);
        int int13 = timePeriodValues12.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        java.util.Date date6 = day4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        int int11 = day4.compareTo((java.lang.Object) simpleTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getLastMillisecond();
        int int16 = day11.getMonth();
        java.util.Calendar calendar17 = null;
        try {
            day11.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        int int4 = year0.getYear();
        java.lang.Number number5 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.delete((int) ' ', (-1));
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 10.0f);
        boolean boolean18 = timePeriodValue16.equals((java.lang.Object) "2019");
        boolean boolean19 = timePeriodValues1.equals((java.lang.Object) timePeriodValue16);
        java.lang.String str20 = timePeriodValue16.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[2019,10.0]" + "'", str20.equals("TimePeriodValue[2019,10.0]"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener17);
        try {
            timePeriodValues1.delete(7, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue4.getPeriod();
        java.lang.Number number6 = null;
        timePeriodValue4.setValue(number6);
        java.lang.Object obj8 = timePeriodValue4.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(timePeriod5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 10L);
        java.lang.String str9 = timePeriodValue8.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[31-December-2019,10]" + "'", str9.equals("TimePeriodValue[31-December-2019,10]"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.delete((int) ' ', (-1));
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 10.0f);
        boolean boolean18 = timePeriodValue16.equals((java.lang.Object) "2019");
        boolean boolean19 = timePeriodValues1.equals((java.lang.Object) timePeriodValue16);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, 0.0d);
        java.lang.Number number26 = timePeriodValue25.getValue();
        timePeriodValues1.add(timePeriodValue25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean9 = timePeriodValues8.isEmpty();
        java.lang.Class<?> wildcardClass10 = timePeriodValues8.getClass();
        int int11 = timePeriodValues8.getMinMiddleIndex();
        int int12 = timePeriodValues8.getMaxEndIndex();
        int int13 = timePeriodValues8.getMinStartIndex();
        int int14 = timePeriodValues8.getMinStartIndex();
        int int15 = year0.compareTo((java.lang.Object) timePeriodValues8);
        int int16 = timePeriodValues8.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        boolean boolean10 = year0.equals((java.lang.Object) date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.next();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass13 = year12.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year12);
        java.lang.Class<?> wildcardClass15 = year12.getClass();
        int int16 = year0.compareTo((java.lang.Object) wildcardClass15);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year0.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 10L);
        int int5 = timePeriodValues1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues1.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) 10);
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        boolean boolean13 = year0.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 6);
        int int17 = day14.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        timePeriodValues1.setRangeDescription("2019");
        int int6 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        int int5 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getFirstMillisecond();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10);
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        long long10 = day9.getSerialIndex();
        java.lang.String str11 = day9.toString();
        int int12 = day9.getDayOfMonth();
        int int13 = year0.compareTo((java.lang.Object) int12);
        java.lang.String str14 = year0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43830L + "'", long10 == 43830L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10);
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean23 = timePeriodValues22.isEmpty();
        java.lang.Class<?> wildcardClass24 = timePeriodValues22.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) 10);
        java.util.Date date31 = year28.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date31, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) 10);
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date38, timeZone40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date17, date38);
        java.util.Date date43 = simpleTimePeriod42.getStart();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date43);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) 10);
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        int int23 = day20.getYear();
        int int24 = day20.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean27 = timePeriodValues26.isEmpty();
        java.lang.Class<?> wildcardClass28 = timePeriodValues26.getClass();
        int int29 = timePeriodValues26.getMinMiddleIndex();
        int int30 = timePeriodValues26.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues26.createCopy((int) (byte) 10, 4);
        java.lang.String str34 = timePeriodValues26.getDomainDescription();
        java.lang.Comparable comparable35 = timePeriodValues26.getKey();
        boolean boolean36 = day20.equals((java.lang.Object) comparable35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) 10);
        java.util.Date date40 = year37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean45 = timePeriodValues44.isEmpty();
        java.lang.Class<?> wildcardClass46 = timePeriodValues44.getClass();
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date47, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        boolean boolean52 = year50.equals((java.lang.Object) 10);
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date53, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        boolean boolean59 = year57.equals((java.lang.Object) 10);
        java.util.Date date60 = year57.getEnd();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date60, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date40, timeZone62);
        int int65 = day20.compareTo((java.lang.Object) date40);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date40);
        timePeriodValues1.setKey((java.lang.Comparable) date40);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date40);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (byte) 10 + "'", comparable35.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass7 = year6.getClass();
        int int8 = day4.compareTo((java.lang.Object) year6);
        long long9 = year6.getSerialIndex();
        java.util.Calendar calendar10 = null;
        try {
            year6.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        java.lang.String str6 = day4.toString();
        int int7 = day4.getYear();
        long long8 = day4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
        long long10 = day4.getMiddleMillisecond();
        java.util.Date date11 = day4.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577822399999L + "'", long10 == 1577822399999L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: 31-December-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "31-December-2019", "31-December-2019");
        int int8 = timePeriodValues7.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean3 = timePeriodValues2.isEmpty();
        java.lang.Class<?> wildcardClass4 = timePeriodValues2.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date11, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) 10);
        java.util.Date date18 = year15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date18, timeZone20);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean24 = timePeriodValues23.isEmpty();
        java.lang.Class<?> wildcardClass25 = timePeriodValues23.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) 10);
        java.util.Date date32 = year29.getEnd();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date32, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) 10);
        java.util.Date date39 = year36.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date39, timeZone41);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date18, date39);
        java.util.Date date44 = simpleTimePeriod43.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date48 = simpleTimePeriod47.getEnd();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date48);
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean54 = timePeriodValues53.isEmpty();
        java.lang.Class<?> wildcardClass55 = timePeriodValues53.getClass();
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        boolean boolean61 = year59.equals((java.lang.Object) 10);
        java.util.Date date62 = year59.getEnd();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date62, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        boolean boolean68 = year66.equals((java.lang.Object) 10);
        java.util.Date date69 = year66.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date69, timeZone71);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(date48, date69);
        java.util.Date date74 = simpleTimePeriod73.getEnd();
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        boolean boolean77 = year75.equals((java.lang.Object) 10);
        java.util.Date date78 = year75.getEnd();
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date78);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass81 = year80.getClass();
        java.util.Date date82 = null;
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date82, timeZone83);
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date78, timeZone83);
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date74, timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date44, timeZone83);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNull(regularTimePeriod87);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date17, timeZone22);
        int int25 = year24.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year24, "TimePeriodValue[31-December-2019,6]", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2020 + "'", int25 == 2020);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        int int8 = timePeriodValues5.getMinMiddleIndex();
        int int9 = timePeriodValues5.getMaxEndIndex();
        int int10 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.previous();
        int int20 = simpleTimePeriod2.compareTo((java.lang.Object) regularTimePeriod19);
        long long21 = simpleTimePeriod2.getStartMillis();
        long long22 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) 10);
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        long long28 = day27.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
        int int30 = day27.getYear();
        int int31 = day27.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean34 = timePeriodValues33.isEmpty();
        java.lang.Class<?> wildcardClass35 = timePeriodValues33.getClass();
        int int36 = timePeriodValues33.getMinMiddleIndex();
        int int37 = timePeriodValues33.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues33.createCopy((int) (byte) 10, 4);
        java.lang.String str41 = timePeriodValues33.getDomainDescription();
        java.lang.Comparable comparable42 = timePeriodValues33.getKey();
        boolean boolean43 = day27.equals((java.lang.Object) comparable42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        boolean boolean46 = year44.equals((java.lang.Object) 10);
        java.util.Date date47 = year44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean52 = timePeriodValues51.isEmpty();
        java.lang.Class<?> wildcardClass53 = timePeriodValues51.getClass();
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        boolean boolean59 = year57.equals((java.lang.Object) 10);
        java.util.Date date60 = year57.getEnd();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date60, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        boolean boolean66 = year64.equals((java.lang.Object) 10);
        java.util.Date date67 = year64.getEnd();
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date67);
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date67, timeZone69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date47, timeZone69);
        int int72 = day27.compareTo((java.lang.Object) date47);
        int int73 = simpleTimePeriod2.compareTo((java.lang.Object) day27);
        org.jfree.data.time.TimePeriodValue timePeriodValue75 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 43629L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + (byte) 10 + "'", comparable42.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.lang.String str4 = timePeriodValue3.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        boolean boolean10 = timePeriodValue3.equals((java.lang.Object) wildcardClass6);
        java.lang.String str11 = timePeriodValue3.toString();
        java.lang.Number number12 = timePeriodValue3.getValue();
        java.lang.Number number13 = timePeriodValue3.getValue();
        timePeriodValue3.setValue((java.lang.Number) 2019L);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str4.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str11.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        timePeriodValues1.setRangeDescription("2019");
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day11, "Value", "");
        timePeriodValues19.setDomainDescription("2019");
        int int22 = timePeriodValues19.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate7);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        timePeriodValues1.setRangeDescription("hi!");
        java.lang.String str17 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year18, 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year18.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Object obj3 = timePeriodValues2.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        int int8 = timePeriodValues5.getMinMiddleIndex();
        int int9 = timePeriodValues5.getMaxEndIndex();
        int int10 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.next();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 13);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod20, 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 10L);
        int int5 = timePeriodValues1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
        timePeriodValues1.setRangeDescription("31-December-2019");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass13 = year12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) 10);
        java.util.Date date18 = year15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        long long20 = day19.getLastMillisecond();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass22 = year21.getClass();
        int int23 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        int int25 = year21.getYear();
        java.lang.Object obj26 = null;
        boolean boolean27 = year21.equals(obj26);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean30 = timePeriodValues29.isEmpty();
        java.lang.Class<?> wildcardClass31 = timePeriodValues29.getClass();
        int int32 = timePeriodValues29.getMinMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass34 = year33.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year33);
        java.lang.Class<?> wildcardClass36 = year33.getClass();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year33, (double) '4');
        boolean boolean39 = year21.equals((java.lang.Object) year33);
        java.lang.Object obj40 = null;
        int int41 = year33.compareTo(obj40);
        java.util.Date date42 = year33.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass44 = year43.getClass();
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date42, timeZone46);
        timePeriodValues1.setKey((java.lang.Comparable) date42);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) 10);
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        boolean boolean13 = year0.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        int int9 = day8.getYear();
        long long10 = day8.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43830L + "'", long10 == 43830L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (byte) 10, 4);
        java.lang.Object obj9 = timePeriodValues8.clone();
        timePeriodValues8.delete(8, (int) (byte) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues8.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        java.util.Date date4 = year0.getStart();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1577779200000L);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        java.lang.String str9 = timePeriodValue7.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,1.5777792E12]" + "'", str9.equals("TimePeriodValue[2019,1.5777792E12]"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues2.setRangeDescription("hi!");
        java.lang.String str5 = timePeriodValues2.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues2.createCopy((-1), 3);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        int int4 = year0.getYear();
        long long5 = year0.getFirstMillisecond();
        long long6 = year0.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        long long6 = day5.getLastMillisecond();
        int int7 = day5.getYear();
        long long8 = day5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean11 = timePeriodValues10.isEmpty();
        java.lang.Class<?> wildcardClass12 = timePeriodValues10.getClass();
        int int13 = timePeriodValues10.getMinMiddleIndex();
        int int14 = timePeriodValues10.getMaxEndIndex();
        int int15 = timePeriodValues10.getItemCount();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) 10);
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getLastMillisecond();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day20, (double) (short) 100);
        int int24 = timePeriodValues10.getItemCount();
        timePeriodValues10.setDescription("13-June-2019");
        java.lang.Object obj27 = timePeriodValues10.clone();
        java.lang.String str28 = timePeriodValues10.getRangeDescription();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) 10);
        java.util.Date date32 = year29.getEnd();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass35 = year34.getClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date32, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) 10);
        java.util.Date date43 = year40.getEnd();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        long long45 = day44.getSerialIndex();
        int int46 = year39.compareTo((java.lang.Object) long45);
        java.lang.Class<?> wildcardClass47 = year39.getClass();
        long long48 = year39.getMiddleMillisecond();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) (-1.0f));
        boolean boolean51 = day5.equals((java.lang.Object) timePeriodValues10);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43830L + "'", long45 == 43830L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1562097599999L + "'", long48 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, 43830L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date20 = simpleTimePeriod19.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        int int23 = day22.getDayOfMonth();
        long long24 = day22.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day22, (java.lang.Number) 9);
        int int27 = day22.getMonth();
        int int29 = day22.compareTo((java.lang.Object) ' ');
        int int30 = day22.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43830L + "'", long24 == 43830L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.delete((int) ' ', (-1));
        boolean boolean10 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues1.createCopy(6, (int) (short) -1);
        timePeriodValues13.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=100]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(100, 1);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        timePeriodValues1.setRangeDescription("2019");
        java.lang.String str6 = timePeriodValues1.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener9);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues1.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day16.getMiddleMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        timePeriodValues1.setRangeDescription("hi!");
        java.lang.String str17 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year18, 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year18.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        boolean boolean10 = year0.equals((java.lang.Object) date7);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year0.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass7 = year6.getClass();
        int int8 = day4.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        int int10 = year6.getYear();
        java.lang.Object obj11 = null;
        boolean boolean12 = year6.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean15 = timePeriodValues14.isEmpty();
        java.lang.Class<?> wildcardClass16 = timePeriodValues14.getClass();
        int int17 = timePeriodValues14.getMinMiddleIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass19 = year18.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year18);
        java.lang.Class<?> wildcardClass21 = year18.getClass();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year18, (double) '4');
        boolean boolean24 = year6.equals((java.lang.Object) year18);
        java.util.Calendar calendar25 = null;
        try {
            year18.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getSerialIndex();
        int int17 = year10.compareTo((java.lang.Object) long16);
        java.lang.Class<?> wildcardClass18 = year10.getClass();
        long long19 = year10.getMiddleMillisecond();
        long long20 = year10.getLastMillisecond();
        long long21 = year10.getFirstMillisecond();
        java.util.Calendar calendar22 = null;
        try {
            year10.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        int int7 = timePeriodValues1.getMinEndIndex();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("13-June-2019");
        java.lang.Object obj18 = timePeriodValues1.clone();
        java.lang.String str19 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) 10);
        java.util.Date date23 = year20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass26 = year25.getClass();
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date23, timeZone28);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        java.util.Date date34 = year31.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        long long36 = day35.getSerialIndex();
        int int37 = year30.compareTo((java.lang.Object) long36);
        java.lang.Class<?> wildcardClass38 = year30.getClass();
        long long39 = year30.getMiddleMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year30, (java.lang.Number) (-1.0f));
        long long42 = year30.getSerialIndex();
        long long43 = year30.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43830L + "'", long36 == 43830L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1562097599999L + "'", long39 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 10L);
        int int5 = timePeriodValues1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        int int10 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        java.lang.Class<?> wildcardClass7 = day4.getClass();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day4.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 100L);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        int int16 = day11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day11.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10);
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean23 = timePeriodValues22.isEmpty();
        java.lang.Class<?> wildcardClass24 = timePeriodValues22.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) 10);
        java.util.Date date31 = year28.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date31, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) 10);
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date38, timeZone40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date17, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date38, "2019", "");
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        boolean boolean48 = year46.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean51 = timePeriodValues50.isEmpty();
        java.lang.Class<?> wildcardClass52 = timePeriodValues50.getClass();
        int int53 = timePeriodValues50.getMinMiddleIndex();
        int int54 = timePeriodValues50.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = timePeriodValues50.createCopy((int) (byte) 10, 4);
        boolean boolean58 = year46.equals((java.lang.Object) timePeriodValues57);
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean58);
        int int60 = timePeriodValues59.getItemCount();
        boolean boolean61 = timePeriodValues45.equals((java.lang.Object) timePeriodValues59);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        long long14 = day13.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        boolean boolean16 = year6.equals((java.lang.Object) day13);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 0L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 100L);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10);
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        int int12 = simpleTimePeriod2.compareTo((java.lang.Object) regularTimePeriod11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass19 = year18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date16);
        int int25 = simpleTimePeriod2.compareTo((java.lang.Object) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1577865599999L);
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1.5777792E12]");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, 43629L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        java.lang.String str5 = timePeriodValue4.toString();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,10.0]" + "'", str5.equals("TimePeriodValue[2019,10.0]"));
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod11, "org.jfree.data.general.SeriesChangeEvent[source=4]", "Time");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        timePeriodValues1.setKey((java.lang.Comparable) 1577822399999L);
        java.lang.Object obj18 = timePeriodValues1.clone();
        int int19 = timePeriodValues1.getMinMiddleIndex();
        int int20 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10);
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date17, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean23 = timePeriodValues22.isEmpty();
        java.lang.Class<?> wildcardClass24 = timePeriodValues22.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) 10);
        java.util.Date date31 = year28.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date31, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) 10);
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date38, timeZone40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date17, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date38, "2019", "");
        timePeriodValues45.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timePeriodValues45.removeChangeListener(seriesChangeListener48);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, 43830L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) (byte) -1);
        long long6 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getStart();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("13-June-2019");
        java.lang.Object obj18 = timePeriodValues1.clone();
        java.lang.String str19 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener20);
        java.lang.Class<?> wildcardClass22 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) ' ');
        long long6 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10);
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 4);
        java.lang.Object obj14 = seriesChangeEvent13.getSource();
        java.lang.Object obj15 = seriesChangeEvent13.getSource();
        boolean boolean16 = year11.equals(obj15);
        try {
            int int17 = simpleTimePeriod2.compareTo((java.lang.Object) boolean16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + 4 + "'", obj14.equals(4));
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + 4 + "'", obj15.equals(4));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        int int7 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        timePeriodValues1.setNotify(true);
        int int12 = timePeriodValues1.getMaxEndIndex();
        try {
            java.lang.Number number14 = timePeriodValues1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.delete(8, (int) (byte) -1);
        java.lang.String str8 = timePeriodValues1.getDescription();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        try {
            java.lang.Number number12 = timePeriodValues1.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=100]");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=100]");
        java.lang.String str5 = seriesException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str7 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str5.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str7.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        java.lang.Class<?> wildcardClass7 = day4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, 43830L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Object obj4 = null;
        boolean boolean5 = simpleTimePeriod2.equals(obj4);
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        timePeriodValues1.setRangeDescription("2019");
        int int6 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, 0.0d);
        java.lang.String str11 = timePeriodValue10.toString();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass13 = year12.getClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
        boolean boolean17 = timePeriodValue10.equals((java.lang.Object) wildcardClass13);
        java.lang.String str18 = timePeriodValue10.toString();
        java.lang.Number number19 = timePeriodValue10.getValue();
        timePeriodValue10.setValue((java.lang.Number) 0L);
        java.lang.Number number22 = timePeriodValue10.getValue();
        timePeriodValues1.add(timePeriodValue10);
        java.lang.String str24 = timePeriodValue10.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str11.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str18.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0L + "'", number22.equals(0L));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[2019,0]" + "'", str24.equals("TimePeriodValue[2019,0]"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.next();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day12.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        int int8 = day4.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean11 = timePeriodValues10.isEmpty();
        java.lang.Class<?> wildcardClass12 = timePeriodValues10.getClass();
        int int13 = timePeriodValues10.getMinMiddleIndex();
        int int14 = timePeriodValues10.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues10.createCopy((int) (byte) 10, 4);
        java.lang.String str18 = timePeriodValues10.getDomainDescription();
        java.lang.Comparable comparable19 = timePeriodValues10.getKey();
        boolean boolean20 = day4.equals((java.lang.Object) comparable19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean29 = timePeriodValues28.isEmpty();
        java.lang.Class<?> wildcardClass30 = timePeriodValues28.getClass();
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) 10);
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date37, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) 10);
        java.util.Date date44 = year41.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date44, timeZone46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date24, timeZone46);
        int int49 = day4.compareTo((java.lang.Object) date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day4.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (byte) 10 + "'", comparable19.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 31, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        long long6 = day5.getLastMillisecond();
        int int7 = day5.getYear();
        long long8 = day5.getLastMillisecond();
        int int9 = day5.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date20 = simpleTimePeriod19.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        int int23 = day22.getDayOfMonth();
        long long24 = day22.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day22, (java.lang.Number) 9);
        int int27 = day22.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day22.previous();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.String str30 = year29.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, 0.0d);
        java.lang.String str33 = timePeriodValue32.toString();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass35 = year34.getClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
        boolean boolean39 = timePeriodValue32.equals((java.lang.Object) wildcardClass35);
        java.lang.String str40 = timePeriodValue32.toString();
        java.lang.Number number41 = timePeriodValue32.getValue();
        java.lang.Object obj42 = timePeriodValue32.clone();
        org.jfree.data.time.TimePeriod timePeriod43 = timePeriodValue32.getPeriod();
        boolean boolean44 = day22.equals((java.lang.Object) timePeriodValue32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43830L + "'", long24 == 43830L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str33.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str40.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.0d + "'", number41.equals(0.0d));
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(timePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        boolean boolean2 = timePeriodValues1.isEmpty();
//        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        int int5 = timePeriodValues1.getMaxEndIndex();
//        int int6 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        boolean boolean9 = year7.equals((java.lang.Object) 10);
//        java.util.Date date10 = year7.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        long long12 = day11.getLastMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
//        timePeriodValues1.setRangeDescription("hi!");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
//        java.util.Date date20 = simpleTimePeriod19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
//        int int23 = day22.getDayOfMonth();
//        long long24 = day22.getSerialIndex();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day22, (java.lang.Number) 9);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day27);
//        java.lang.String str29 = day27.toString();
//        long long30 = day27.getFirstMillisecond();
//        boolean boolean31 = day22.equals((java.lang.Object) long30);
//        java.util.Calendar calendar32 = null;
//        try {
//            day22.peg(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43830L + "'", long24 == 43830L);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, 43830L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getLastMillisecond();
        java.util.Date date16 = day11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean19 = timePeriodValues18.isEmpty();
        java.lang.Class<?> wildcardClass20 = timePeriodValues18.getClass();
        int int21 = timePeriodValues18.getMinMiddleIndex();
        int int22 = timePeriodValues18.getMaxEndIndex();
        int int23 = timePeriodValues18.getItemCount();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) 10);
        java.util.Date date27 = year24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        long long29 = day28.getLastMillisecond();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day28, (double) (short) 100);
        timePeriodValues18.setRangeDescription("hi!");
        java.lang.String str34 = timePeriodValues18.getRangeDescription();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.lang.String str36 = year35.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.previous();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) year35, 10.0d);
        boolean boolean40 = day11.equals((java.lang.Object) year35);
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year35.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        java.lang.String str6 = day4.toString();
        int int7 = day4.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass9 = year8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year8);
        long long11 = year8.getFirstMillisecond();
        int int12 = year8.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 'a');
        long long15 = year8.getFirstMillisecond();
        int int16 = day4.compareTo((java.lang.Object) year8);
        int int17 = day4.getMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass7 = year6.getClass();
        int int8 = day4.compareTo((java.lang.Object) year6);
        int int9 = year6.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 10L);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) 10);
        java.util.Date date21 = year18.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date21, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date3, timeZone23);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[31-December-2019,6]");
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass7 = year6.getClass();
        int int8 = day4.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        int int10 = year6.getYear();
        java.lang.Object obj11 = null;
        boolean boolean12 = year6.equals(obj11);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean15 = timePeriodValues14.isEmpty();
        java.lang.Class<?> wildcardClass16 = timePeriodValues14.getClass();
        int int17 = timePeriodValues14.getMinMiddleIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass19 = year18.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year18);
        java.lang.Class<?> wildcardClass21 = year18.getClass();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year18, (double) '4');
        boolean boolean24 = year6.equals((java.lang.Object) year18);
        long long25 = year18.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean28 = timePeriodValues27.isEmpty();
        java.lang.Class<?> wildcardClass29 = timePeriodValues27.getClass();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) 10);
        java.util.Date date33 = year30.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        long long35 = day34.getSerialIndex();
        timePeriodValues27.setKey((java.lang.Comparable) long35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.lang.String str38 = year37.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year37, 0.0d);
        java.lang.String str41 = timePeriodValue40.toString();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass43 = year42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        boolean boolean47 = timePeriodValue40.equals((java.lang.Object) wildcardClass43);
        java.lang.String str48 = timePeriodValue40.toString();
        java.lang.Number number49 = timePeriodValue40.getValue();
        timePeriodValue40.setValue((java.lang.Number) 0L);
        timePeriodValues27.add(timePeriodValue40);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = timePeriodValues27.createCopy((int) (short) 0, (int) (byte) 0);
        boolean boolean56 = year18.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43830L + "'", long35 == 43830L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str41.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str48.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 0.0d + "'", number49.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriodValues55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        boolean boolean6 = timePeriodValue4.equals((java.lang.Object) "2019");
        java.lang.Object obj7 = null;
        boolean boolean8 = timePeriodValue4.equals(obj7);
        timePeriodValue4.setValue((java.lang.Number) 1577865599999L);
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue4.getPeriod();
        java.lang.Number number12 = timePeriodValue4.getValue();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1577865599999L + "'", number12.equals(1577865599999L));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        long long9 = day8.getSerialIndex();
        timePeriodValues1.setKey((java.lang.Comparable) long9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener11);
        timePeriodValues1.setDescription("TimePeriodValue[2019,97.0]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43830L + "'", long9 == 43830L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (byte) 10, 4);
        java.lang.String str9 = timePeriodValues1.getDomainDescription();
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (byte) 10 + "'", comparable10.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (byte) 10 + "'", comparable11.equals((byte) 10));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getSerialIndex();
        int int17 = year10.compareTo((java.lang.Object) long16);
        java.lang.Class<?> wildcardClass18 = year10.getClass();
        java.util.Date date19 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date23 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean26 = timePeriodValues25.isEmpty();
        java.lang.Class<?> wildcardClass27 = timePeriodValues25.getClass();
        int int28 = timePeriodValues25.getMinMiddleIndex();
        int int29 = timePeriodValues25.getMaxEndIndex();
        int int30 = timePeriodValues25.getItemCount();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        java.util.Date date34 = year31.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        long long36 = day35.getLastMillisecond();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day35, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day35.previous();
        int int40 = simpleTimePeriod22.compareTo((java.lang.Object) regularTimePeriod39);
        long long41 = simpleTimePeriod22.getStartMillis();
        long long42 = simpleTimePeriod22.getStartMillis();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        java.util.Date date46 = year43.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        long long48 = day47.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate49 = day47.getSerialDate();
        int int50 = day47.getYear();
        int int51 = day47.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean54 = timePeriodValues53.isEmpty();
        java.lang.Class<?> wildcardClass55 = timePeriodValues53.getClass();
        int int56 = timePeriodValues53.getMinMiddleIndex();
        int int57 = timePeriodValues53.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = timePeriodValues53.createCopy((int) (byte) 10, 4);
        java.lang.String str61 = timePeriodValues53.getDomainDescription();
        java.lang.Comparable comparable62 = timePeriodValues53.getKey();
        boolean boolean63 = day47.equals((java.lang.Object) comparable62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        boolean boolean66 = year64.equals((java.lang.Object) 10);
        java.util.Date date67 = year64.getEnd();
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date67);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean72 = timePeriodValues71.isEmpty();
        java.lang.Class<?> wildcardClass73 = timePeriodValues71.getClass();
        java.util.Date date74 = null;
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date74, timeZone75);
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
        boolean boolean79 = year77.equals((java.lang.Object) 10);
        java.util.Date date80 = year77.getEnd();
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date80);
        java.util.TimeZone timeZone82 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date80, timeZone82);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year();
        boolean boolean86 = year84.equals((java.lang.Object) 10);
        java.util.Date date87 = year84.getEnd();
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date87, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date67, timeZone89);
        int int92 = day47.compareTo((java.lang.Object) date67);
        int int93 = simpleTimePeriod22.compareTo((java.lang.Object) day47);
        java.util.Date date94 = simpleTimePeriod22.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod95 = new org.jfree.data.time.SimpleTimePeriod(date19, date94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Time" + "'", str61.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable62 + "' != '" + (byte) 10 + "'", comparable62.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(date94);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass9 = year8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year8);
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.previous();
        int int13 = year6.compareTo((java.lang.Object) year8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.delete((int) ' ', (-1));
        int int10 = timePeriodValues1.getMaxStartIndex();
        int int11 = timePeriodValues1.getMinStartIndex();
        java.lang.String str12 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.previous();
        int int17 = day11.getDayOfMonth();
        java.util.Date date18 = day11.getStart();
        int int19 = day11.getDayOfMonth();
        int int20 = day11.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        long long9 = day8.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate10);
        long long13 = day12.getLastMillisecond();
        java.util.Date date14 = day12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean17 = timePeriodValues16.isEmpty();
        java.lang.Class<?> wildcardClass18 = timePeriodValues16.getClass();
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean24 = year22.equals((java.lang.Object) 10);
        java.util.Date date25 = year22.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        boolean boolean31 = year29.equals((java.lang.Object) 10);
        java.util.Date date32 = year29.getEnd();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date32, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone34);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        int int7 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (byte) 1, 12);
        int int13 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.delete((int) ' ', (-1));
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 10.0f);
        boolean boolean18 = timePeriodValue16.equals((java.lang.Object) "2019");
        boolean boolean19 = timePeriodValues1.equals((java.lang.Object) timePeriodValue16);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=100]");
        int int22 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (-1.0d));
        try {
            org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValues1.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        int int8 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues1.createCopy(5, (int) (byte) 100);
        java.lang.Comparable comparable12 = timePeriodValues1.getKey();
        java.lang.Comparable comparable13 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (byte) 10 + "'", comparable12.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (byte) 10 + "'", comparable13.equals((byte) 10));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        long long6 = day4.getSerialIndex();
        int int7 = day4.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1.0f));
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass10 = year9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date7, timeZone12);
        boolean boolean15 = timePeriodValues1.equals((java.lang.Object) timeZone12);
        java.lang.Class<?> wildcardClass16 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date20 = simpleTimePeriod19.getEnd();
        long long21 = simpleTimePeriod19.getEndMillis();
        java.lang.Class<?> wildcardClass22 = simpleTimePeriod19.getClass();
        long long23 = simpleTimePeriod19.getStartMillis();
        java.util.Date date24 = simpleTimePeriod19.getStart();
        java.util.Date date25 = simpleTimePeriod19.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) 10);
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        long long31 = day30.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
        java.lang.Class<?> wildcardClass33 = day30.getClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) 10);
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass40 = year39.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date37, timeZone42);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date48 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean51 = timePeriodValues50.isEmpty();
        java.lang.Class<?> wildcardClass52 = timePeriodValues50.getClass();
        int int53 = timePeriodValues50.getMinMiddleIndex();
        int int54 = timePeriodValues50.getMaxEndIndex();
        int int55 = timePeriodValues50.getItemCount();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) 10);
        java.util.Date date59 = year56.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        long long61 = day60.getLastMillisecond();
        timePeriodValues50.add((org.jfree.data.time.TimePeriod) day60, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = day60.previous();
        int int65 = simpleTimePeriod47.compareTo((java.lang.Object) regularTimePeriod64);
        long long66 = simpleTimePeriod47.getStartMillis();
        long long67 = simpleTimePeriod47.getStartMillis();
        java.util.Date date68 = simpleTimePeriod47.getEnd();
        java.util.Date date69 = simpleTimePeriod47.getEnd();
        java.util.Date date70 = simpleTimePeriod47.getStart();
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date70, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date25, timeZone71);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1577865599999L + "'", long61 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 100L + "'", long67 == 100L);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNull(regularTimePeriod74);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        int int5 = timePeriodValues4.getMaxMiddleIndex();
        java.lang.Object obj6 = timePeriodValues4.clone();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues4.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        boolean boolean10 = year0.equals((java.lang.Object) date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.next();
        int int12 = year0.getYear();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getSerialIndex();
        int int17 = year10.compareTo((java.lang.Object) long16);
        java.lang.Class<?> wildcardClass18 = year10.getClass();
        java.util.Date date19 = year10.getEnd();
        java.lang.String str20 = year10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year10.next();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year10.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        int int8 = day4.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.next();
        int int16 = day12.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.lang.String str4 = timePeriodValue3.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        boolean boolean10 = timePeriodValue3.equals((java.lang.Object) wildcardClass6);
        java.lang.String str11 = timePeriodValue3.toString();
        java.lang.Number number12 = timePeriodValue3.getValue();
        timePeriodValue3.setValue((java.lang.Number) 0L);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue3.getPeriod();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean21 = timePeriodValues20.isEmpty();
        java.lang.Class<?> wildcardClass22 = timePeriodValues20.getClass();
        int int23 = timePeriodValues20.getMinMiddleIndex();
        int int24 = timePeriodValues20.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues20.createCopy((int) (byte) 10, 4);
        boolean boolean28 = year16.equals((java.lang.Object) timePeriodValues27);
        java.lang.String str29 = timePeriodValues27.getRangeDescription();
        timePeriodValues27.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues27.createCopy((int) (byte) 10, (int) '#');
        boolean boolean34 = timePeriodValue3.equals((java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str4.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str11.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) 10);
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        boolean boolean13 = year0.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 6);
        long long17 = day14.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577779200000L + "'", long17 == 1577779200000L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) 10);
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        boolean boolean13 = year0.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 6);
        long long17 = day14.getLastMillisecond();
        java.lang.String str18 = day14.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-2019" + "'", str18.equals("31-December-2019"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) 10);
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        int int23 = day20.getYear();
        int int24 = day20.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean27 = timePeriodValues26.isEmpty();
        java.lang.Class<?> wildcardClass28 = timePeriodValues26.getClass();
        int int29 = timePeriodValues26.getMinMiddleIndex();
        int int30 = timePeriodValues26.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues26.createCopy((int) (byte) 10, 4);
        java.lang.String str34 = timePeriodValues26.getDomainDescription();
        java.lang.Comparable comparable35 = timePeriodValues26.getKey();
        boolean boolean36 = day20.equals((java.lang.Object) comparable35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean39 = year37.equals((java.lang.Object) 10);
        java.util.Date date40 = year37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean45 = timePeriodValues44.isEmpty();
        java.lang.Class<?> wildcardClass46 = timePeriodValues44.getClass();
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date47, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        boolean boolean52 = year50.equals((java.lang.Object) 10);
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date53, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        boolean boolean59 = year57.equals((java.lang.Object) 10);
        java.util.Date date60 = year57.getEnd();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date60, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date40, timeZone62);
        int int65 = day20.compareTo((java.lang.Object) date40);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date40);
        timePeriodValues1.setKey((java.lang.Comparable) date40);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass70 = year69.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year69);
        java.lang.Object obj72 = timePeriodValues71.clone();
        int int73 = day68.compareTo((java.lang.Object) timePeriodValues71);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        boolean boolean76 = year74.equals((java.lang.Object) 10);
        java.util.Date date77 = year74.getEnd();
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date77);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass80 = year79.getClass();
        java.util.Date date81 = null;
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date81, timeZone82);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date77, timeZone82);
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year();
        boolean boolean87 = year85.equals((java.lang.Object) 10);
        java.util.Date date88 = year85.getEnd();
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date88);
        long long90 = day89.getSerialIndex();
        int int91 = year84.compareTo((java.lang.Object) long90);
        long long92 = year84.getFirstMillisecond();
        long long93 = year84.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = year84.next();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) regularTimePeriod94, (double) 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (byte) 10 + "'", comparable35.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 43830L + "'", long90 == 43830L);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 1546329600000L + "'", long92 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 1577865599999L + "'", long93 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day11, "hi!", "TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        int int8 = day4.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean11 = timePeriodValues10.isEmpty();
        java.lang.Class<?> wildcardClass12 = timePeriodValues10.getClass();
        int int13 = timePeriodValues10.getMinMiddleIndex();
        int int14 = timePeriodValues10.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues10.createCopy((int) (byte) 10, 4);
        java.lang.String str18 = timePeriodValues10.getDomainDescription();
        java.lang.Comparable comparable19 = timePeriodValues10.getKey();
        boolean boolean20 = day4.equals((java.lang.Object) comparable19);
        long long21 = day4.getSerialIndex();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day4.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (byte) 10 + "'", comparable19.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass10 = year9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date7, timeZone12);
        boolean boolean15 = timePeriodValues1.equals((java.lang.Object) timeZone12);
        java.lang.Class<?> wildcardClass16 = timePeriodValues1.getClass();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass18 = year17.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year17);
        long long20 = year17.getFirstMillisecond();
        int int21 = year17.getYear();
        java.lang.Number number22 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, number22);
        java.util.Date date24 = year17.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) 10);
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean32 = year30.equals((java.lang.Object) 10);
        java.util.Date date33 = year30.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean37 = timePeriodValues36.isEmpty();
        java.lang.Class<?> wildcardClass38 = timePeriodValues36.getClass();
        java.util.Date date39 = null;
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date39, timeZone40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        boolean boolean44 = year42.equals((java.lang.Object) 10);
        java.util.Date date45 = year42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date45, timeZone47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        boolean boolean51 = year49.equals((java.lang.Object) 10);
        java.util.Date date52 = year49.getEnd();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date52, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date33, timeZone54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date28, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date24, timeZone54);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date24);
        java.util.Calendar calendar60 = null;
        try {
            long long61 = year59.getFirstMillisecond(calendar60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod58);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.util.Date date0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean7 = timePeriodValues6.isEmpty();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        int int9 = timePeriodValues6.getMinMiddleIndex();
        int int10 = timePeriodValues6.getMaxEndIndex();
        int int11 = timePeriodValues6.getItemCount();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10);
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        long long17 = day16.getLastMillisecond();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day16, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.previous();
        int int21 = simpleTimePeriod3.compareTo((java.lang.Object) regularTimePeriod20);
        long long22 = simpleTimePeriod3.getStartMillis();
        long long23 = simpleTimePeriod3.getStartMillis();
        java.util.Date date24 = simpleTimePeriod3.getEnd();
        long long25 = simpleTimePeriod3.getStartMillis();
        java.util.Date date26 = simpleTimePeriod3.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean29 = timePeriodValues28.isEmpty();
        java.lang.Class<?> wildcardClass30 = timePeriodValues28.getClass();
        int int31 = timePeriodValues28.getMinMiddleIndex();
        int int32 = timePeriodValues28.getMaxEndIndex();
        int int33 = timePeriodValues28.getItemCount();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) 10);
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        long long39 = day38.getLastMillisecond();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day38, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day38.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day38.next();
        java.util.Date date44 = regularTimePeriod43.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date48 = simpleTimePeriod47.getEnd();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date44, timeZone49);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date26, timeZone49);
        try {
            org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date0, timeZone49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 10L);
        int int5 = timePeriodValues1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
        timePeriodValues1.setRangeDescription("31-December-2019");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 10);
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        long long15 = day14.getLastMillisecond();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass17 = year16.getClass();
        int int18 = day14.compareTo((java.lang.Object) year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        int int20 = year16.getYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = year16.equals(obj21);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean25 = timePeriodValues24.isEmpty();
        java.lang.Class<?> wildcardClass26 = timePeriodValues24.getClass();
        int int27 = timePeriodValues24.getMinMiddleIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass29 = year28.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year28);
        java.lang.Class<?> wildcardClass31 = year28.getClass();
        timePeriodValues24.add((org.jfree.data.time.TimePeriod) year28, (double) '4');
        boolean boolean34 = year16.equals((java.lang.Object) year28);
        long long35 = year28.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean14 = timePeriodValues13.isEmpty();
        java.lang.Class<?> wildcardClass15 = timePeriodValues13.getClass();
        int int16 = timePeriodValues13.getMinMiddleIndex();
        int int17 = timePeriodValues13.getMaxEndIndex();
        int int18 = timePeriodValues13.getItemCount();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) 10);
        java.util.Date date22 = year19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        long long24 = day23.getLastMillisecond();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day23, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day23.next();
        java.util.Date date29 = regularTimePeriod28.getStart();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date35 = simpleTimePeriod34.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean38 = timePeriodValues37.isEmpty();
        java.lang.Class<?> wildcardClass39 = timePeriodValues37.getClass();
        int int40 = timePeriodValues37.getMinMiddleIndex();
        int int41 = timePeriodValues37.getMaxEndIndex();
        int int42 = timePeriodValues37.getItemCount();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        java.util.Date date46 = year43.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        long long48 = day47.getLastMillisecond();
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day47, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day47.previous();
        int int52 = simpleTimePeriod34.compareTo((java.lang.Object) regularTimePeriod51);
        long long53 = simpleTimePeriod34.getStartMillis();
        long long54 = simpleTimePeriod34.getStartMillis();
        java.util.Date date55 = simpleTimePeriod34.getEnd();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean58 = year56.equals((java.lang.Object) 10);
        java.util.Date date59 = year56.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass62 = year61.getClass();
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date63, timeZone64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date59, timeZone64);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date55, timeZone64);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date29, timeZone64);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date3, timeZone64);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        int int5 = timePeriodValues4.getMaxMiddleIndex();
        java.lang.Object obj6 = timePeriodValues4.clone();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues4.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass7 = year6.getClass();
        int int8 = day4.compareTo((java.lang.Object) year6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) 10);
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10);
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean21 = timePeriodValues20.isEmpty();
        java.lang.Class<?> wildcardClass22 = timePeriodValues20.getClass();
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date23, timeZone24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) 10);
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date29, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        boolean boolean35 = year33.equals((java.lang.Object) 10);
        java.util.Date date36 = year33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date36, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date17, timeZone38);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date12, timeZone38);
        boolean boolean42 = year6.equals((java.lang.Object) day41);
        java.lang.String str43 = year6.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019" + "'", str43.equals("2019"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        int int8 = timePeriodValues5.getMinMiddleIndex();
        int int9 = timePeriodValues5.getMaxEndIndex();
        int int10 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.previous();
        int int20 = simpleTimePeriod2.compareTo((java.lang.Object) regularTimePeriod19);
        long long21 = simpleTimePeriod2.getStartMillis();
        long long22 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) 10);
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        long long28 = day27.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
        int int30 = day27.getYear();
        int int31 = day27.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean34 = timePeriodValues33.isEmpty();
        java.lang.Class<?> wildcardClass35 = timePeriodValues33.getClass();
        int int36 = timePeriodValues33.getMinMiddleIndex();
        int int37 = timePeriodValues33.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues33.createCopy((int) (byte) 10, 4);
        java.lang.String str41 = timePeriodValues33.getDomainDescription();
        java.lang.Comparable comparable42 = timePeriodValues33.getKey();
        boolean boolean43 = day27.equals((java.lang.Object) comparable42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        boolean boolean46 = year44.equals((java.lang.Object) 10);
        java.util.Date date47 = year44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean52 = timePeriodValues51.isEmpty();
        java.lang.Class<?> wildcardClass53 = timePeriodValues51.getClass();
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        boolean boolean59 = year57.equals((java.lang.Object) 10);
        java.util.Date date60 = year57.getEnd();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date60, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        boolean boolean66 = year64.equals((java.lang.Object) 10);
        java.util.Date date67 = year64.getEnd();
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date67);
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date67, timeZone69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date47, timeZone69);
        int int72 = day27.compareTo((java.lang.Object) date47);
        int int73 = simpleTimePeriod2.compareTo((java.lang.Object) day27);
        java.util.Date date74 = simpleTimePeriod2.getStart();
        long long75 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + (byte) 10 + "'", comparable42.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1577865599999L + "'", long75 == 1577865599999L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        int int7 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDomainDescription("");
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, (int) (short) 10, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        long long12 = day11.getLastMillisecond();
        org.jfree.data.time.Year year14 = org.jfree.data.time.Year.parseYear("2019");
        long long15 = year14.getFirstMillisecond();
        int int16 = day11.compareTo((java.lang.Object) long15);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 9);
        long long19 = day11.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43830L + "'", long19 == 43830L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        java.lang.String str8 = day4.toString();
        int int9 = day4.getYear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date13 = simpleTimePeriod12.getStart();
        int int14 = day4.compareTo((java.lang.Object) date13);
        int int15 = day4.getDayOfMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(10L, 43830L);
        boolean boolean19 = day4.equals((java.lang.Object) 43830L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
        int int9 = day4.getYear();
        java.lang.String str10 = day4.toString();
        java.lang.String str11 = day4.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        timePeriodValues1.setRangeDescription("hi!");
        timePeriodValues1.fireSeriesChanged();
        int int18 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        long long6 = day5.getLastMillisecond();
        int int7 = day5.getYear();
        long long8 = day5.getLastMillisecond();
        long long9 = day5.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43830L + "'", long9 == 43830L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        long long15 = day11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.previous();
        int int17 = day11.getDayOfMonth();
        java.util.Date date18 = day11.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.lang.String str4 = timePeriodValue3.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        boolean boolean10 = timePeriodValue3.equals((java.lang.Object) wildcardClass6);
        java.lang.String str11 = timePeriodValue3.toString();
        java.lang.Number number12 = timePeriodValue3.getValue();
        java.lang.String str13 = timePeriodValue3.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str4.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str11.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str13.equals("TimePeriodValue[2019,0.0]"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        int int8 = day4.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean11 = timePeriodValues10.isEmpty();
        java.lang.Class<?> wildcardClass12 = timePeriodValues10.getClass();
        int int13 = timePeriodValues10.getMinMiddleIndex();
        int int14 = timePeriodValues10.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues10.createCopy((int) (byte) 10, 4);
        java.lang.String str18 = timePeriodValues10.getDomainDescription();
        java.lang.Comparable comparable19 = timePeriodValues10.getKey();
        boolean boolean20 = day4.equals((java.lang.Object) comparable19);
        org.jfree.data.time.SerialDate serialDate21 = day4.getSerialDate();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (byte) 10 + "'", comparable19.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        boolean boolean2 = timePeriodValues1.isEmpty();
//        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
//        java.lang.String str4 = timePeriodValues1.getDescription();
//        int int5 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
//        java.lang.String str8 = day6.toString();
//        long long9 = day6.getFirstMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) long9);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
//        int int12 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setRangeDescription("Time");
//        java.lang.Object obj15 = timePeriodValues1.clone();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(obj15);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        int int5 = timePeriodValues4.getMaxMiddleIndex();
        int int6 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean16 = timePeriodValues15.isEmpty();
        java.lang.Class<?> wildcardClass17 = timePeriodValues15.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date24, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) 10);
        java.util.Date date31 = year28.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date31, timeZone33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date10, date31);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod35);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod35, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "TimePeriodValue[2019,null]");
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        int int7 = day4.compareTo((java.lang.Object) 2019L);
        java.util.Date date8 = day4.getEnd();
        long long9 = day4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43830L + "'", long9 == 43830L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Object obj3 = timePeriodValues2.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        int int8 = timePeriodValues5.getMinMiddleIndex();
        int int9 = timePeriodValues5.getMaxEndIndex();
        int int10 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.next();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 13);
        timePeriodValues2.setDomainDescription("");
        timePeriodValues2.update((int) (short) 0, (java.lang.Number) (-1L));
        int int28 = timePeriodValues2.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Class<?> wildcardClass17 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.lang.String str4 = timePeriodValue3.toString();
        java.lang.Object obj5 = timePeriodValue3.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str4.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: 13-June-2019");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        int int8 = day4.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean11 = timePeriodValues10.isEmpty();
        java.lang.Class<?> wildcardClass12 = timePeriodValues10.getClass();
        int int13 = timePeriodValues10.getMinMiddleIndex();
        int int14 = timePeriodValues10.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues10.createCopy((int) (byte) 10, 4);
        java.lang.String str18 = timePeriodValues10.getDomainDescription();
        java.lang.Comparable comparable19 = timePeriodValues10.getKey();
        boolean boolean20 = day4.equals((java.lang.Object) comparable19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean29 = timePeriodValues28.isEmpty();
        java.lang.Class<?> wildcardClass30 = timePeriodValues28.getClass();
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) 10);
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date37, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) 10);
        java.util.Date date44 = year41.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date44, timeZone46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date24, timeZone46);
        int int49 = day4.compareTo((java.lang.Object) date24);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException52.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        java.lang.Throwable[] throwableArray56 = timePeriodFormatException54.getSuppressed();
        org.jfree.data.general.SeriesException seriesException58 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=100]");
        java.lang.String str59 = seriesException58.toString();
        org.jfree.data.general.SeriesException seriesException61 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=100]");
        java.lang.String str62 = seriesException61.toString();
        seriesException58.addSuppressed((java.lang.Throwable) seriesException61);
        timePeriodFormatException54.addSuppressed((java.lang.Throwable) seriesException61);
        boolean boolean65 = year50.equals((java.lang.Object) timePeriodFormatException54);
        java.lang.Throwable[] throwableArray66 = timePeriodFormatException54.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (byte) 10 + "'", comparable19.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str59.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str62.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(throwableArray66);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, 43830L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean10 = timePeriodValues9.isEmpty();
        java.lang.Class<?> wildcardClass11 = timePeriodValues9.getClass();
        int int12 = timePeriodValues9.getMinMiddleIndex();
        int int13 = timePeriodValues9.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues9.createCopy((int) (byte) 10, 4);
        boolean boolean17 = year5.equals((java.lang.Object) timePeriodValues16);
        java.lang.String str18 = timePeriodValues16.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues16.createCopy((int) (byte) 1, 0);
        int int24 = year0.compareTo((java.lang.Object) timePeriodValues16);
        int int25 = timePeriodValues16.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener26);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean22 = timePeriodValues21.isEmpty();
        java.lang.Class<?> wildcardClass23 = timePeriodValues21.getClass();
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) 10);
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean36 = year34.equals((java.lang.Object) 10);
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date37, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date17, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        boolean boolean44 = year42.equals((java.lang.Object) 10);
        java.util.Date date45 = year42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean49 = timePeriodValues48.isEmpty();
        java.lang.Class<?> wildcardClass50 = timePeriodValues48.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        boolean boolean56 = year54.equals((java.lang.Object) 10);
        java.util.Date date57 = year54.getEnd();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date57, timeZone59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        boolean boolean63 = year61.equals((java.lang.Object) 10);
        java.util.Date date64 = year61.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date64, timeZone66);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date45, timeZone66);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date17, timeZone66);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("31-December-2019");
        java.lang.String str10 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=100]");
        java.lang.String str8 = seriesException7.toString();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=100]");
        java.lang.String str11 = seriesException10.toString();
        seriesException7.addSuppressed((java.lang.Throwable) seriesException10);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException10);
        java.lang.String str14 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str8.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str11.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass6 = year5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getSerialIndex();
        int int17 = year10.compareTo((java.lang.Object) long16);
        java.lang.Class<?> wildcardClass18 = year10.getClass();
        java.util.Date date19 = year10.getEnd();
        java.lang.String str20 = year10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year10.next();
        java.lang.String str22 = year10.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        int int8 = day4.getYear();
        long long9 = day4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        int int4 = year0.getYear();
        long long5 = year0.getFirstMillisecond();
        long long6 = year0.getMiddleMillisecond();
        int int7 = year0.getYear();
        long long8 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        long long9 = day8.getSerialIndex();
        timePeriodValues1.setKey((java.lang.Comparable) long9);
        int int11 = timePeriodValues1.getMaxStartIndex();
        boolean boolean12 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43830L + "'", long9 == 43830L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.lang.Class<?> wildcardClass5 = simpleTimePeriod2.getClass();
//        long long6 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date7 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day8);
//        java.lang.String str10 = day8.toString();
//        long long11 = day8.getFirstMillisecond();
//        long long12 = day8.getLastMillisecond();
//        int int13 = day8.getDayOfMonth();
//        int int14 = simpleTimePeriod2.compareTo((java.lang.Object) day8);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean12 = timePeriodValues11.isEmpty();
        java.lang.Class<?> wildcardClass13 = timePeriodValues11.getClass();
        java.lang.String str14 = timePeriodValues11.getDescription();
        int int15 = timePeriodValues11.getMaxMiddleIndex();
        boolean boolean16 = timePeriodValues11.getNotify();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) 10);
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        long long22 = day21.getLastMillisecond();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass24 = year23.getClass();
        int int25 = day21.compareTo((java.lang.Object) year23);
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener28);
        boolean boolean30 = timePeriodValues1.equals((java.lang.Object) timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        timePeriodValues1.setRangeDescription("hi!");
        int int17 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass19 = year18.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year18);
        long long21 = year18.getFirstMillisecond();
        int int22 = year18.getYear();
        java.lang.Number number23 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, number23);
        timePeriodValues1.add(timePeriodValue24);
        try {
            java.lang.Number number27 = timePeriodValues1.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        boolean boolean2 = timePeriodValues1.isEmpty();
//        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
//        java.lang.String str4 = timePeriodValues1.getDescription();
//        int int5 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day6);
//        java.lang.String str8 = day6.toString();
//        long long9 = day6.getFirstMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) long9);
//        int int11 = timePeriodValues1.getMinMiddleIndex();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.Class<?> wildcardClass13 = year12.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year12);
//        long long15 = year12.getFirstMillisecond();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        boolean boolean18 = year16.equals((java.lang.Object) 10);
//        java.util.Date date19 = year16.getEnd();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
//        boolean boolean22 = year12.equals((java.lang.Object) date19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
//        java.util.Date date27 = simpleTimePeriod26.getStart();
//        java.util.Date date28 = simpleTimePeriod26.getEnd();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) 10);
//        java.util.Date date32 = year29.getEnd();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.lang.Class<?> wildcardClass35 = year34.getClass();
//        java.util.Date date36 = null;
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date32, timeZone37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date28, timeZone37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date19, timeZone37);
//        boolean boolean42 = timePeriodValues1.equals((java.lang.Object) day41);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass10 = year9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date7, timeZone12);
        boolean boolean15 = timePeriodValues1.equals((java.lang.Object) timeZone12);
        java.lang.Class<?> wildcardClass16 = timePeriodValues1.getClass();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
        long long17 = day16.getLastMillisecond();
        boolean boolean18 = timePeriodValues1.equals((java.lang.Object) long17);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean21 = timePeriodValues20.isEmpty();
        java.lang.Class<?> wildcardClass22 = timePeriodValues20.getClass();
        int int23 = timePeriodValues20.getMinMiddleIndex();
        int int24 = timePeriodValues20.getMaxEndIndex();
        int int25 = timePeriodValues20.getItemCount();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean28 = year26.equals((java.lang.Object) 10);
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        long long31 = day30.getLastMillisecond();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day30, (double) (short) 100);
        long long34 = day30.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
        int int36 = day30.getDayOfMonth();
        timePeriodValues1.setKey((java.lang.Comparable) day30);
        org.jfree.data.time.SerialDate serialDate38 = day30.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 31 + "'", int36 == 31);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        java.lang.String str6 = day4.toString();
        int int7 = day4.getYear();
        long long8 = day4.getLastMillisecond();
        long long9 = day4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577779200000L + "'", long9 == 1577779200000L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=4]");
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Object obj3 = timePeriodValues2.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        int int8 = timePeriodValues5.getMinMiddleIndex();
        int int9 = timePeriodValues5.getMaxEndIndex();
        int int10 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.next();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 13);
        java.lang.String str23 = timePeriodValues2.getDomainDescription();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.lang.String str25 = year24.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 10.0f);
        long long29 = year24.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year24.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean33 = timePeriodValues32.isEmpty();
        java.lang.Class<?> wildcardClass34 = timePeriodValues32.getClass();
        int int35 = timePeriodValues32.getMinMiddleIndex();
        int int36 = timePeriodValues32.getMaxEndIndex();
        int int37 = timePeriodValues32.getMinStartIndex();
        int int38 = timePeriodValues32.getMinStartIndex();
        int int39 = year24.compareTo((java.lang.Object) timePeriodValues32);
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 2019);
        try {
            java.lang.Object obj42 = timePeriodValues2.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(100L, 1577865599999L);
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        long long14 = day13.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        boolean boolean16 = year6.equals((java.lang.Object) day13);
        int int17 = day13.getMonth();
        java.util.Date date18 = day13.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day12, (-1.0d));
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
        int int9 = day4.getYear();
        java.lang.String str10 = day4.toString();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = day4.equals((java.lang.Object) regularTimePeriod13);
        java.lang.Object obj15 = null;
        int int16 = day4.compareTo(obj15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.String str5 = seriesChangeEvent4.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        int int16 = day11.getMonth();
        int int17 = day11.getMonth();
        long long18 = day11.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        int int7 = day4.getYear();
        int int8 = day4.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean11 = timePeriodValues10.isEmpty();
        java.lang.Class<?> wildcardClass12 = timePeriodValues10.getClass();
        int int13 = timePeriodValues10.getMinMiddleIndex();
        int int14 = timePeriodValues10.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues10.createCopy((int) (byte) 10, 4);
        java.lang.String str18 = timePeriodValues10.getDomainDescription();
        java.lang.Comparable comparable19 = timePeriodValues10.getKey();
        boolean boolean20 = day4.equals((java.lang.Object) comparable19);
        java.util.Date date21 = day4.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (byte) 10 + "'", comparable19.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        timePeriodValues8.setKey((java.lang.Comparable) "hi!");
        int int11 = timePeriodValues8.getMinEndIndex();
        int int12 = day4.compareTo((java.lang.Object) int11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass1 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.String str3 = timePeriodValues2.getDescription();
        timePeriodValues2.delete(3, 0);
        timePeriodValues2.delete((int) '#', 13);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getMinStartIndex();
        java.lang.Object obj7 = timePeriodValues1.clone();
        int int8 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0f);
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) 10);
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        boolean boolean13 = year0.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 6);
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue16.getPeriod();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timePeriod17);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean6 = timePeriodValues5.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues5.getClass();
        int int8 = timePeriodValues5.getMinMiddleIndex();
        int int9 = timePeriodValues5.getMaxEndIndex();
        int int10 = timePeriodValues5.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        long long19 = day15.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day15, (double) (short) 100);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, 0.0d);
        java.lang.String str26 = timePeriodValue25.toString();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass28 = year27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        boolean boolean32 = timePeriodValue25.equals((java.lang.Object) wildcardClass28);
        java.lang.Object obj33 = timePeriodValue25.clone();
        timePeriodValues1.add(timePeriodValue25);
        timePeriodValue25.setValue((java.lang.Number) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43830L + "'", long19 == 43830L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str26.equals("TimePeriodValue[2019,0.0]"));
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
        int int16 = day11.getMonth();
        java.util.Date date17 = day11.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10);
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass11 = year10.getClass();
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date8, timeZone13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date4, timeZone13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean19 = timePeriodValues18.isEmpty();
        java.lang.Class<?> wildcardClass20 = timePeriodValues18.getClass();
        int int21 = timePeriodValues18.getMinMiddleIndex();
        int int22 = timePeriodValues18.getMaxEndIndex();
        int int23 = timePeriodValues18.getItemCount();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) 10);
        java.util.Date date27 = year24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        long long29 = day28.getLastMillisecond();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day28, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day28.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date4, date34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date4);
        java.util.Date date38 = year37.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getSerialIndex();
        java.lang.String str6 = day4.toString();
        int int7 = day4.getYear();
        long long8 = day4.getLastMillisecond();
        long long9 = day4.getMiddleMillisecond();
        int int10 = day4.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577822399999L + "'", long9 == 1577822399999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass3 = timePeriodValues1.getClass();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        boolean boolean9 = year7.equals((java.lang.Object) 10);
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        long long12 = day11.getLastMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) (short) 100);
        int int15 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("13-June-2019");
        java.lang.Object obj18 = timePeriodValues1.clone();
        java.lang.String str19 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) 10);
        java.util.Date date23 = year20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass26 = year25.getClass();
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date23, timeZone28);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        java.util.Date date34 = year31.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        long long36 = day35.getSerialIndex();
        int int37 = year30.compareTo((java.lang.Object) long36);
        java.lang.Class<?> wildcardClass38 = year30.getClass();
        long long39 = year30.getMiddleMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year30, (java.lang.Number) (-1.0f));
        timePeriodValues1.setDescription("2019");
        int int44 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43830L + "'", long36 == 43830L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1562097599999L + "'", long39 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }
}

