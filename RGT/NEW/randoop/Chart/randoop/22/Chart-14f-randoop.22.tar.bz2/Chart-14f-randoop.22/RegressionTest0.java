import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.data.RangeType rangeType6 = null;
        try {
            numberAxis1.setRangeType(rangeType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        try {
            numberAxis1.setRange((double) 'a', (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.data.Range range3 = null;
        try {
            numberAxis1.setRange(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        try {
            numberAxis1.setRange((double) 10, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        java.awt.Shape shape9 = null;
        try {
            numberAxis1.setUpArrow(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopInset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets4.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType12, lengthAdjustmentType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis1.getStandardTickUnits();
        boolean boolean8 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str2, jFreeChart3, chartChangeEventType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        java.awt.Stroke stroke3 = null;
        try {
            numberAxis1.setTickMarkStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopOutset((double) 5);
        double double12 = rectangleInsets4.extendWidth((double) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 111.0d + "'", double12 == 111.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) ' ', (double) (byte) 0, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        float[] floatArray11 = new float[] { (-1.0f), 6, (byte) 1, ' ', ' ' };
        float[] floatArray12 = chartColor5.getColorComponents(floatArray11);
        try {
            float[] floatArray13 = color0.getComponents(colorSpace1, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Comparable comparable1 = null;
        try {
            java.awt.Font font2 = categoryAxis0.getTickLabelFont(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int2 = color1.getBlue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color1, color3, color4 };
        java.awt.Color color6 = java.awt.Color.RED;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Stroke[] strokeArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Shape[] shapeArray11 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray5, paintArray7, strokeArray8, strokeArray10, shapeArray11);
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextFillPaint();
        try {
            java.awt.Paint paint14 = defaultDrawingSupplier12.getNextPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean2 = color0.equals((java.lang.Object) shape1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1);
        java.lang.Object obj3 = objectList1.get((int) (short) 1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 500, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-268) + "'", int3 == (-268));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        org.jfree.data.Range range10 = null;
        try {
            numberAxis1.setRange(range10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        dateAxis0.setRangeAboutValue((double) (-1.0f), (double) (short) 10);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis9.setMinimumDate(date11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        org.jfree.data.Range range15 = dateAxis13.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date17 = dateAxis13.calculateLowestVisibleTickValue(dateTickUnit16);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone19 = dateAxis18.getTimeZone();
        org.jfree.data.Range range20 = dateAxis18.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date22 = dateAxis18.calculateLowestVisibleTickValue(dateTickUnit21);
        dateAxis13.setMinimumDate(date22);
        try {
            dateAxis0.setRange(date11, date22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(255, 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        numberAxis1.setUpperBound((double) 100.0f);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit8, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        categoryAxis0.setLowerMargin((double) 2);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1), (double) 500, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.data.RangeType rangeType9 = null;
        try {
            numberAxis1.setRangeType(rangeType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        int int3 = day0.compareTo((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        double double2 = numberAxis1.getLabelAngle();
        java.awt.Shape shape3 = null;
        try {
            numberAxis1.setUpArrow(shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        int int4 = objectList1.indexOf((java.lang.Object) (byte) 1);
        objectList1.clear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SortOrder.DESCENDING");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        java.lang.String str2 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str2.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        java.awt.Paint paint3 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str6, jFreeChart7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMinimumDate(date7);
        try {
            dateAxis0.setRange(date4, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit8);
        dateAxis0.setMinimumDate(date9);
        java.util.Date date11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        try {
            double double14 = dateAxis0.dateToJava2D(date11, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis1.addChangeListener(axisChangeListener10);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopOutset((double) 5);
        double double11 = rectangleInsets4.getTop();
        double double13 = rectangleInsets4.calculateBottomInset((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            rectangleInsets4.trim(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.0d + "'", double11 == 97.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("NO_CHANGE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setVisible(true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.resizeRange((double) (short) -1, (double) 10.0f);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setLabelAngle(111.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int2 = color1.getBlue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color1, color3, color4 };
        java.awt.Color color6 = java.awt.Color.RED;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Stroke[] strokeArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Shape[] shapeArray11 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray5, paintArray7, strokeArray8, strokeArray10, shapeArray11);
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextFillPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean15 = defaultDrawingSupplier12.equals((java.lang.Object) plotOrientation14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.String str2 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SortOrder.DESCENDING" + "'", str2.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopOutset((double) 5);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets4.createInsetRectangle(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            xYPlot10.draw(graphics2D11, rectangle2D12, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(point2D15);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        java.lang.String str6 = dateAxis0.getLabelToolTip();
        dateAxis0.setAutoRangeMinimumSize((double) 500, false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color4 = java.awt.Color.getColor("SortOrder.DESCENDING", (int) (byte) 1);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, (double) 5, (java.awt.Paint) color4, stroke5, paint6, stroke7, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) objectList1, jFreeChart2, chartChangeEventType3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int3 = java.awt.Color.HSBtoRGB((float) 0, (float) (-1L), (float) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-253) + "'", int3 == (-253));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj5 = numberAxis4.clone();
        numberAxis4.setRangeWithMargins((double) (byte) 0, (double) 10L);
        numberAxis4.setUpperBound((double) 100.0f);
        boolean boolean11 = dateAxis0.equals((java.lang.Object) numberAxis4);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        try {
            double double17 = dateAxis0.java2DToValue(108.0d, rectangle2D13, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAxis0.equals(obj3);
        double double5 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        int int76 = xYPlot32.getBackgroundImageAlignment();
        org.jfree.chart.plot.Marker marker77 = null;
        try {
            xYPlot32.addDomainMarker(marker77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 15 + "'", int76 == 15);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.setLabelToolTip("UnitType.RELATIVE");
        numberAxis1.resizeRange((double) 192);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopOutset((double) 5);
        double double11 = rectangleInsets4.getTop();
        double double12 = rectangleInsets4.getRight();
        double double14 = rectangleInsets4.calculateRightInset((double) 192);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.0d + "'", double11 == 97.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit8);
        dateAxis0.setMinimumDate(date9);
        dateAxis0.setRange((double) (-1), (double) 1L);
        org.jfree.chart.plot.Plot plot14 = dateAxis0.getPlot();
        boolean boolean16 = dateAxis0.isHiddenValue((long) 192);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Stroke stroke7 = null;
        try {
            numberAxis1.setAxisLineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double9 = rectangleInsets4.getBottom();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Paint paint3 = numberAxis1.getLabelPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation7, plotOrientation8);
        try {
            java.util.List list10 = numberAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        xYPlot10.setRangeCrosshairValue((double) '#');
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation56 = null;
        try {
            xYPlot10.setDomainAxisLocation(axisLocation56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit8);
        dateAxis0.setMinimumDate(date9);
        dateAxis0.setRange((double) (-1), (double) 1L);
        org.jfree.chart.plot.Plot plot14 = dateAxis0.getPlot();
        java.util.TimeZone timeZone15 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        java.awt.Paint paint3 = categoryAxis0.getTickLabelPaint();
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Color color6 = java.awt.Color.BLUE;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) (-1), (java.awt.Paint) color6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj13 = numberAxis12.clone();
        numberAxis12.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis12.setMarkerBand(markerAxisBand16);
        numberAxis12.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double26 = rectangleInsets24.extendHeight(1.0d);
        double double28 = rectangleInsets24.calculateRightOutset((double) (short) 100);
        double double30 = rectangleInsets24.calculateTopOutset((double) 5);
        double double31 = rectangleInsets24.getTop();
        numberAxis12.setLabelInsets(rectangleInsets24);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj36 = numberAxis35.clone();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis38, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str46 = numberAxis45.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj49 = numberAxis48.clone();
        numberAxis48.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand58 = null;
        numberAxis54.setMarkerBand(markerAxisBand58);
        org.jfree.chart.axis.TickUnitSource tickUnitSource60 = numberAxis54.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj63 = numberAxis62.clone();
        numberAxis62.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand66 = null;
        numberAxis62.setMarkerBand(markerAxisBand66);
        numberAxis62.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double76 = rectangleInsets74.extendHeight(1.0d);
        double double78 = rectangleInsets74.calculateRightOutset((double) (short) 100);
        double double80 = rectangleInsets74.calculateTopOutset((double) 5);
        double double81 = rectangleInsets74.getTop();
        numberAxis62.setLabelInsets(rectangleInsets74);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray83 = new org.jfree.chart.axis.ValueAxis[] { numberAxis45, numberAxis48, numberAxis54, numberAxis62 };
        xYPlot43.setDomainAxes(valueAxisArray83);
        java.awt.Stroke stroke85 = xYPlot43.getRangeGridlineStroke();
        numberAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot43);
        org.jfree.chart.axis.AxisLocation axisLocation88 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot43.setRangeAxisLocation((int) '4', axisLocation88, true);
        xYPlot43.setBackgroundAlpha((float) 5);
        java.awt.Paint paint93 = xYPlot43.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge94 = xYPlot43.getRangeAxisEdge();
        try {
            double double95 = categoryAxis0.getCategoryMiddle((int) '#', 100, rectangle2D10, rectangleEdge94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 108.0d + "'", double26 == 108.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 97.0d + "'", double30 == 97.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 97.0d + "'", double31 == 97.0d);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource60);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 108.0d + "'", double76 == 108.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 10.0d + "'", double78 == 10.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 97.0d + "'", double80 == 97.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 97.0d + "'", double81 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray83);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(axisLocation88);
        org.junit.Assert.assertNotNull(paint93);
        org.junit.Assert.assertNotNull(rectangleEdge94);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        java.util.Date date2 = dateAxis0.getMinimumDate();
        dateAxis0.setLabelToolTip("hi!");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.awt.Paint paint54 = xYPlot10.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        java.awt.Paint paint11 = null;
        try {
            xYPlot10.setRangeGridlinePaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        double double3 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.centerRange(0.0d);
        double double9 = numberAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.5d) + "'", double9 == (-0.5d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 97.0d);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj9 = numberAxis8.clone();
        numberAxis8.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis8.setMarkerBand(markerAxisBand12);
        numberAxis8.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double22 = rectangleInsets20.extendHeight(1.0d);
        double double24 = rectangleInsets20.calculateRightOutset((double) (short) 100);
        double double26 = rectangleInsets20.calculateTopOutset((double) 5);
        double double27 = rectangleInsets20.getTop();
        numberAxis8.setLabelInsets(rectangleInsets20);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj32 = numberAxis31.clone();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj35 = numberAxis34.clone();
        numberAxis34.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str42 = numberAxis41.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj45 = numberAxis44.clone();
        numberAxis44.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj51 = numberAxis50.clone();
        numberAxis50.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand54 = null;
        numberAxis50.setMarkerBand(markerAxisBand54);
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis50.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj59 = numberAxis58.clone();
        numberAxis58.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis58.setMarkerBand(markerAxisBand62);
        numberAxis58.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double72 = rectangleInsets70.extendHeight(1.0d);
        double double74 = rectangleInsets70.calculateRightOutset((double) (short) 100);
        double double76 = rectangleInsets70.calculateTopOutset((double) 5);
        double double77 = rectangleInsets70.getTop();
        numberAxis58.setLabelInsets(rectangleInsets70);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray79 = new org.jfree.chart.axis.ValueAxis[] { numberAxis41, numberAxis44, numberAxis50, numberAxis58 };
        xYPlot39.setDomainAxes(valueAxisArray79);
        java.awt.Stroke stroke81 = xYPlot39.getRangeGridlineStroke();
        numberAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot39);
        org.jfree.chart.axis.AxisLocation axisLocation84 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot39.setRangeAxisLocation((int) '4', axisLocation84, true);
        xYPlot39.setBackgroundAlpha((float) 5);
        java.awt.Paint paint89 = xYPlot39.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = xYPlot39.getRangeAxisEdge();
        try {
            double double91 = categoryAxis0.getCategoryStart(0, 10, rectangle2D6, rectangleEdge90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 108.0d + "'", double22 == 108.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 97.0d + "'", double26 == 97.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 97.0d + "'", double27 == 97.0d);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 108.0d + "'", double72 == 108.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.0d + "'", double74 == 10.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 97.0d + "'", double76 == 97.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 97.0d + "'", double77 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray79);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(rectangleEdge90);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleAnchor0.equals(obj1);
        java.awt.Color color3 = java.awt.Color.cyan;
        boolean boolean4 = rectangleAnchor0.equals((java.lang.Object) color3);
        java.lang.Object obj5 = null;
        boolean boolean6 = color3.equals(obj5);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        org.jfree.data.Range range6 = dateAxis4.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date8 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit7);
        java.util.Date date9 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit7);
        boolean boolean10 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setForegroundAlpha(10.0f);
        org.jfree.data.xy.XYDataset xYDataset83 = null;
        org.jfree.chart.axis.NumberAxis numberAxis85 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj86 = numberAxis85.clone();
        org.jfree.chart.axis.NumberAxis numberAxis88 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj89 = numberAxis88.clone();
        numberAxis88.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer92 = null;
        org.jfree.chart.plot.XYPlot xYPlot93 = new org.jfree.chart.plot.XYPlot(xYDataset83, (org.jfree.chart.axis.ValueAxis) numberAxis85, (org.jfree.chart.axis.ValueAxis) numberAxis88, xYItemRenderer92);
        try {
            xYPlot32.setRangeAxis((-268), (org.jfree.chart.axis.ValueAxis) numberAxis85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(obj86);
        org.junit.Assert.assertNotNull(obj89);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L), jFreeChart1, chartChangeEventType2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setForegroundAlpha(10.0f);
        xYPlot32.clearRangeMarkers((-253));
        java.awt.Paint paint84 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot32.setDomainTickBandPaint(paint84);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation86 = null;
        try {
            boolean boolean88 = xYPlot32.removeAnnotation(xYAnnotation86, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(paint84);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str59 = numberAxis54.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean61 = numberAxis54.equals((java.lang.Object) plotOrientation60);
        numberAxis54.setFixedDimension((double) 100L);
        numberAxis54.setUpperMargin((double) (-268));
        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis54, true);
        double double68 = xYPlot10.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone71 = dateAxis70.getTimeZone();
        org.jfree.data.Range range72 = dateAxis70.getRange();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        java.util.Date date74 = day73.getEnd();
        dateAxis70.setMaximumDate(date74);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone77 = dateAxis76.getTimeZone();
        org.jfree.data.Range range78 = dateAxis76.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date80 = dateAxis76.calculateLowestVisibleTickValue(dateTickUnit79);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone82 = dateAxis81.getTimeZone();
        org.jfree.data.Range range83 = dateAxis81.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date85 = dateAxis81.calculateLowestVisibleTickValue(dateTickUnit84);
        dateAxis76.setMinimumDate(date85);
        dateAxis70.setMinimumDate(date85);
        xYPlot10.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) dateAxis70, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = xYPlot10.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(dateTickUnit84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(rectangleEdge90);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Paint paint52 = xYPlot10.getBackgroundPaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        dateAxis0.setUpperMargin((double) 10);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setDomainAxisLocation(192, axisLocation53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        try {
            xYPlot10.handleClick(7, 15, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(axisLocation53);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color6 = chartColor5.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.Object obj11 = null;
        boolean boolean12 = rectangleAnchor10.equals(obj11);
        java.awt.Color color13 = java.awt.Color.cyan;
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) color13);
        categoryMarker8.setLabelAnchor(rectangleAnchor10);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = null;
        try {
            categoryMarker8.setLabelOffset(rectangleInsets16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        dateAxis0.setMaximumDate(date4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        int int2 = day0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.setLabelToolTip("UnitType.RELATIVE");
        numberAxis1.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.centerRange((double) 43629L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getEnd();
        org.jfree.chart.ChartColor chartColor74 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color75 = chartColor74.darker();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day69, (java.awt.Paint) color75, stroke76);
        boolean boolean78 = xYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = categoryMarker77.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker77.setLabelOffsetType(lengthAdjustmentType80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77, layer82);
        java.lang.Class class84 = null;
        try {
            java.util.EventListener[] eventListenerArray85 = categoryMarker77.getListeners(class84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(layer82);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            java.awt.Color color1 = java.awt.Color.decode("DatasetRenderingOrder.FORWARD");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DatasetRenderingOrder.FORWARD\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color2 = java.awt.Color.getColor("", 5);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        int int4 = color3.getRGB();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        java.awt.Color color6 = java.awt.Color.pink;
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        float[] floatArray16 = new float[] { (-1.0f), 6, (byte) 1, ' ', ' ' };
        float[] floatArray17 = chartColor10.getColorComponents(floatArray16);
        float[] floatArray18 = color6.getComponents(floatArray17);
        float[] floatArray19 = color2.getColorComponents(colorSpace5, floatArray17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-65281) + "'", int4 == (-65281));
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setDomainAxisLocation(192, axisLocation53);
        java.awt.Paint paint55 = xYPlot10.getNoDataMessagePaint();
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        try {
            xYPlot10.setQuadrantPaint((int) (short) -1, (java.awt.Paint) color57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date5 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        org.jfree.data.Range range8 = dateAxis6.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit9);
        dateAxis1.setMinimumDate(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone12);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 100, (double) 3, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setBackgroundAlpha((float) 5);
        org.jfree.chart.util.RectangleInsets rectangleInsets86 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) (short) -1, 0.0d, (double) 10);
        double double87 = rectangleInsets86.getRight();
        double double88 = rectangleInsets86.getLeft();
        xYPlot32.setAxisOffset(rectangleInsets86);
        java.awt.geom.Rectangle2D rectangle2D90 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D91 = rectangleInsets86.createInsetRectangle(rectangle2D90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 10.0d + "'", double87 == 10.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + (-1.0d) + "'", double88 == (-1.0d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Paint paint3 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int2 = color1.getBlue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color1, color3, color4 };
        java.awt.Color color6 = java.awt.Color.RED;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Stroke[] strokeArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Shape[] shapeArray11 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray5, paintArray7, strokeArray8, strokeArray10, shapeArray11);
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        dateAxis0.setLabel("SeriesRenderingOrder.REVERSE");
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) (short) -1, 0.0d, (double) 10);
        double double5 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets4.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        xYPlot10.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Stroke stroke7 = numberAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = xYPlot10.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopOutset((double) 5);
        double double11 = rectangleInsets4.getTop();
        double double12 = rectangleInsets4.getRight();
        double double14 = rectangleInsets4.extendWidth((double) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.0d + "'", double11 == 97.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 111.0d + "'", double14 == 111.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.pink;
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        float[] floatArray12 = new float[] { (-1.0f), 6, (byte) 1, ' ', ' ' };
        float[] floatArray13 = chartColor6.getColorComponents(floatArray12);
        float[] floatArray14 = color2.getComponents(floatArray13);
        try {
            float[] floatArray15 = color0.getComponents(colorSpace1, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        double double2 = numberAxis1.getLabelAngle();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D((double) '4', rectangle2D4, rectangleEdge5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        dateAxis0.setLabel("SortOrder.DESCENDING");
        java.util.Date date8 = null;
        try {
            dateAxis0.setMaximumDate(date8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Paint paint2 = null;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color9 = chartColor8.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day3, (java.awt.Paint) color9, stroke10);
        java.awt.Stroke stroke12 = categoryMarker11.getOutlineStroke();
        java.awt.Color color13 = java.awt.Color.WHITE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 2.0f, 0.0d, paint2, stroke12, (java.awt.Paint) color13, stroke14, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        boolean boolean2 = textAnchor0.equals((java.lang.Object) tickUnitSource1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) (short) -1, 0.0d, (double) 10);
        double double5 = rectangleInsets4.getRight();
        java.awt.Color color6 = java.awt.Color.GRAY;
        java.awt.Color color7 = color6.darker();
        boolean boolean8 = rectangleInsets4.equals((java.lang.Object) color6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke58 = xYPlot10.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        java.awt.Paint paint3 = categoryAxis0.getTickLabelPaint();
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        java.lang.Object obj5 = categoryAxis0.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        numberAxis1.setUpperBound((double) 100.0f);
        numberAxis1.setTickMarksVisible(true);
        double double10 = numberAxis1.getLowerBound();
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        numberAxis1.addChangeListener(axisChangeListener11);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.5d) + "'", double10 == (-0.5d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getEnd();
        org.jfree.chart.ChartColor chartColor74 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color75 = chartColor74.darker();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day69, (java.awt.Paint) color75, stroke76);
        boolean boolean78 = xYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = categoryMarker77.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker77.setLabelOffsetType(lengthAdjustmentType80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77, layer82);
        java.lang.Class<?> wildcardClass84 = layer82.getClass();
        java.lang.Class class85 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass84);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(class85);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setBackgroundAlpha((float) 5);
        org.jfree.chart.util.RectangleInsets rectangleInsets86 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) (short) -1, 0.0d, (double) 10);
        double double87 = rectangleInsets86.getRight();
        double double88 = rectangleInsets86.getLeft();
        xYPlot32.setAxisOffset(rectangleInsets86);
        try {
            xYPlot32.setBackgroundImageAlpha((float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 10.0d + "'", double87 == 10.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + (-1.0d) + "'", double88 == (-1.0d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        int int1 = color0.getRGB();
        java.awt.color.ColorSpace colorSpace2 = color0.getColorSpace();
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        int int4 = color3.getRGB();
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        float[] floatArray15 = new float[] { (-1.0f), 6, (byte) 1, ' ', ' ' };
        float[] floatArray16 = chartColor9.getColorComponents(floatArray15);
        float[] floatArray17 = color0.getColorComponents(colorSpace5, floatArray15);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-65281) + "'", int1 == (-65281));
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-65281) + "'", int4 == (-65281));
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.data.Range range5 = dateAxis3.getRange();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        org.jfree.data.Range range8 = dateAxis6.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit9);
        java.util.Date date11 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit9);
        boolean boolean12 = chartChangeEventType2.equals((java.lang.Object) dateAxis3);
        dateAxis3.setVisible(false);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setDomainAxisLocation(192, axisLocation53);
        java.awt.Paint paint55 = xYPlot10.getNoDataMessagePaint();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone57 = dateAxis56.getTimeZone();
        org.jfree.data.Range range58 = dateAxis56.getRange();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        java.util.Date date60 = day59.getEnd();
        dateAxis56.setMaximumDate(date60);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) (short) -1, 0.0d, (double) 10);
        double double68 = rectangleInsets66.calculateBottomInset((double) (short) 1);
        dateAxis56.setLabelInsets(rectangleInsets66);
        xYPlot10.setInsets(rectangleInsets66, true);
        java.awt.Paint paint72 = xYPlot10.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(paint72);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) (short) -1, 0.0d, (double) 10);
        double double5 = rectangleInsets4.getRight();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets4.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = null;
        xYPlot10.setBackgroundPaint(paint16);
        double double18 = xYPlot10.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
//        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis3.getTickMarkPosition();
//        dateAxis2.setTickMarkPosition(dateTickMarkPosition5);
//        int int7 = day0.compareTo((java.lang.Object) dateAxis2);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        xYPlot10.clearDomainMarkers(7);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setRangeAboutValue(0.0d, (double) ' ');
        java.lang.String str15 = numberAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation52 = null;
        try {
            xYPlot10.addAnnotation(xYAnnotation52, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        java.awt.Stroke stroke80 = xYPlot32.getRangeZeroBaselineStroke();
        xYPlot32.setNoDataMessage("DatasetRenderingOrder.FORWARD");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(stroke80);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis4.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj10 = numberAxis9.clone();
        boolean boolean11 = categoryAnchor7.equals(obj10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj17 = numberAxis16.clone();
        numberAxis16.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis16.setMarkerBand(markerAxisBand20);
        numberAxis16.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double30 = rectangleInsets28.extendHeight(1.0d);
        double double32 = rectangleInsets28.calculateRightOutset((double) (short) 100);
        double double34 = rectangleInsets28.calculateTopOutset((double) 5);
        double double35 = rectangleInsets28.getTop();
        numberAxis16.setLabelInsets(rectangleInsets28);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj40 = numberAxis39.clone();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj43 = numberAxis42.clone();
        numberAxis42.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis42, xYItemRenderer46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str50 = numberAxis49.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj53 = numberAxis52.clone();
        numberAxis52.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj59 = numberAxis58.clone();
        numberAxis58.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis58.setMarkerBand(markerAxisBand62);
        org.jfree.chart.axis.TickUnitSource tickUnitSource64 = numberAxis58.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj67 = numberAxis66.clone();
        numberAxis66.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand70 = null;
        numberAxis66.setMarkerBand(markerAxisBand70);
        numberAxis66.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double80 = rectangleInsets78.extendHeight(1.0d);
        double double82 = rectangleInsets78.calculateRightOutset((double) (short) 100);
        double double84 = rectangleInsets78.calculateTopOutset((double) 5);
        double double85 = rectangleInsets78.getTop();
        numberAxis66.setLabelInsets(rectangleInsets78);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray87 = new org.jfree.chart.axis.ValueAxis[] { numberAxis49, numberAxis52, numberAxis58, numberAxis66 };
        xYPlot47.setDomainAxes(valueAxisArray87);
        java.awt.Stroke stroke89 = xYPlot47.getRangeGridlineStroke();
        numberAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot47);
        org.jfree.chart.axis.AxisLocation axisLocation92 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot47.setRangeAxisLocation((int) '4', axisLocation92, true);
        xYPlot47.setBackgroundAlpha((float) 5);
        java.awt.Paint paint97 = xYPlot47.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge98 = xYPlot47.getRangeAxisEdge();
        try {
            double double99 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor7, 4, (-65281), rectangle2D14, rectangleEdge98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 108.0d + "'", double30 == 108.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 10.0d + "'", double32 == 10.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 97.0d + "'", double34 == 97.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 97.0d + "'", double35 == 97.0d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(tickUnitSource64);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 108.0d + "'", double80 == 108.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 10.0d + "'", double82 == 10.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 97.0d + "'", double84 == 97.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 97.0d + "'", double85 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray87);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(axisLocation92);
        org.junit.Assert.assertNotNull(paint97);
        org.junit.Assert.assertNotNull(rectangleEdge98);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        categoryMarker60.setDrawAsLine(false);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        java.util.Date date65 = day64.getEnd();
        org.jfree.chart.ChartColor chartColor69 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color70 = chartColor69.darker();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day64, (java.awt.Paint) color70, stroke71);
        categoryMarker60.setKey((java.lang.Comparable) day64);
        java.awt.Paint paint74 = null;
        categoryMarker60.setOutlinePaint(paint74);
        java.awt.Stroke stroke76 = categoryMarker60.getStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.event.PlotChangeListener plotChangeListener52 = null;
        xYPlot10.removeChangeListener(plotChangeListener52);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getEnd();
        org.jfree.chart.ChartColor chartColor74 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color75 = chartColor74.darker();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day69, (java.awt.Paint) color75, stroke76);
        boolean boolean78 = xYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = categoryMarker77.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker77.setLabelOffsetType(lengthAdjustmentType80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77, layer82);
        float float84 = categoryMarker77.getAlpha();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertTrue("'" + float84 + "' != '" + 1.0f + "'", float84 == 1.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        java.lang.String str2 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1.0f), (double) 5, (double) 1.0f, (-0.5d));
        double double9 = rectangleInsets7.extendHeight((double) (short) 100);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.RELATIVE" + "'", str2.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("UnitType.RELATIVE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Color color52 = java.awt.Color.WHITE;
        xYPlot10.setDomainTickBandPaint((java.awt.Paint) color52);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(color52);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Color color0 = java.awt.Color.blue;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        int int5 = day3.compareTo((java.lang.Object) 'a');
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int7 = day3.compareTo((java.lang.Object) color6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        java.awt.Font font9 = categoryAxis0.getTickLabelFont((java.lang.Comparable) regularTimePeriod8);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj15 = numberAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj18 = numberAxis17.clone();
        numberAxis17.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str25 = numberAxis24.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj34 = numberAxis33.clone();
        numberAxis33.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis33.setMarkerBand(markerAxisBand37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = numberAxis33.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj42 = numberAxis41.clone();
        numberAxis41.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis41.setMarkerBand(markerAxisBand45);
        numberAxis41.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double55 = rectangleInsets53.extendHeight(1.0d);
        double double57 = rectangleInsets53.calculateRightOutset((double) (short) 100);
        double double59 = rectangleInsets53.calculateTopOutset((double) 5);
        double double60 = rectangleInsets53.getTop();
        numberAxis41.setLabelInsets(rectangleInsets53);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis27, numberAxis33, numberAxis41 };
        xYPlot22.setDomainAxes(valueAxisArray62);
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setDomainAxisLocation(192, axisLocation65);
        org.jfree.chart.axis.AxisLocation axisLocation67 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setRangeAxisLocation(axisLocation67);
        xYPlot10.setRangeAxisLocation((int) (short) 100, axisLocation67, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent71 = null;
        xYPlot10.datasetChanged(datasetChangeEvent71);
        org.jfree.data.xy.XYDataset xYDataset73 = xYPlot10.getDataset();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(tickUnitSource39);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 108.0d + "'", double55 == 108.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 97.0d + "'", double59 == 97.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 97.0d + "'", double60 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNull(xYDataset73);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        boolean boolean4 = categoryAnchor0.equals(obj3);
        java.lang.String str5 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str5.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot10.getDatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj19 = numberAxis18.clone();
        numberAxis18.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis18.setMarkerBand(markerAxisBand22);
        numberAxis18.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double32 = rectangleInsets30.extendHeight(1.0d);
        double double34 = rectangleInsets30.calculateRightOutset((double) (short) 100);
        double double36 = rectangleInsets30.calculateTopOutset((double) 5);
        double double37 = rectangleInsets30.getTop();
        numberAxis18.setLabelInsets(rectangleInsets30);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj42 = numberAxis41.clone();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj45 = numberAxis44.clone();
        numberAxis44.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) numberAxis41, (org.jfree.chart.axis.ValueAxis) numberAxis44, xYItemRenderer48);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str52 = numberAxis51.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj61 = numberAxis60.clone();
        numberAxis60.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = null;
        numberAxis60.setMarkerBand(markerAxisBand64);
        org.jfree.chart.axis.TickUnitSource tickUnitSource66 = numberAxis60.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj69 = numberAxis68.clone();
        numberAxis68.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand72 = null;
        numberAxis68.setMarkerBand(markerAxisBand72);
        numberAxis68.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double82 = rectangleInsets80.extendHeight(1.0d);
        double double84 = rectangleInsets80.calculateRightOutset((double) (short) 100);
        double double86 = rectangleInsets80.calculateTopOutset((double) 5);
        double double87 = rectangleInsets80.getTop();
        numberAxis68.setLabelInsets(rectangleInsets80);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray89 = new org.jfree.chart.axis.ValueAxis[] { numberAxis51, numberAxis54, numberAxis60, numberAxis68 };
        xYPlot49.setDomainAxes(valueAxisArray89);
        java.awt.Stroke stroke91 = xYPlot49.getRangeGridlineStroke();
        numberAxis18.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot49);
        org.jfree.chart.axis.AxisLocation axisLocation94 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot49.setRangeAxisLocation((int) '4', axisLocation94, true);
        java.awt.Stroke stroke97 = xYPlot49.getRangeZeroBaselineStroke();
        xYPlot10.setRangeZeroBaselineStroke(stroke97);
        int int99 = xYPlot10.getSeriesCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 108.0d + "'", double32 == 108.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 97.0d + "'", double36 == 97.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 97.0d + "'", double37 == 97.0d);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertNotNull(tickUnitSource66);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 108.0d + "'", double82 == 108.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 10.0d + "'", double84 == 10.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 97.0d + "'", double86 == 97.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 97.0d + "'", double87 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray89);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(axisLocation94);
        org.junit.Assert.assertNotNull(stroke97);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 0 + "'", int99 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) (short) -1, 0.0d, (double) 10);
        double double5 = rectangleInsets4.getRight();
        double double6 = rectangleInsets4.getLeft();
        java.lang.String str7 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=1.0,l=-1.0,b=0.0,r=10.0]" + "'", str7.equals("RectangleInsets[t=1.0,l=-1.0,b=0.0,r=10.0]"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis6.valueToJava2D((double) 5, rectangle2D9, rectangleEdge10);
        boolean boolean12 = dateAxis0.equals((java.lang.Object) rectangle2D9);
        dateAxis0.setTickMarkInsideLength((float) (byte) 0);
        java.text.DateFormat dateFormat15 = null;
        dateAxis0.setDateFormatOverride(dateFormat15);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        java.awt.Image image58 = null;
        xYPlot10.setBackgroundImage(image58);
        org.jfree.chart.plot.Plot plot60 = xYPlot10.getRootPlot();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(plot60);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.JFreeChart jFreeChart2 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(jFreeChart2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        java.lang.String str6 = dateAxis0.getLabelToolTip();
        java.awt.Shape shape7 = dateAxis0.getRightArrow();
        dateAxis0.resizeRange((double) (short) 0, (double) 10.0f);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.data.Range range5 = dateAxis3.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit6);
        java.util.Date date8 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit6);
        dateAxis0.zoomRange(0.0d, (double) 6);
        dateAxis0.setUpperBound(0.05d);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        boolean boolean17 = xYPlot10.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot10.getDomainAxis();
        xYPlot10.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(valueAxis18);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopInset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets4.createInsetRectangle(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.data.Range range5 = dateAxis3.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit6);
        java.util.Date date8 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit6);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource9);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setBackgroundAlpha((float) 5);
        org.jfree.chart.plot.Marker marker82 = null;
        boolean boolean83 = xYPlot32.removeDomainMarker(marker82);
        org.jfree.data.xy.XYDataset xYDataset84 = null;
        xYPlot32.setDataset(xYDataset84);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis1.getStandardTickUnits();
        org.jfree.data.Range range8 = numberAxis1.getRange();
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        double double2 = numberAxis1.getLabelAngle();
        java.awt.Shape shape3 = numberAxis1.getLeftArrow();
        java.lang.Object obj4 = numberAxis1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str59 = numberAxis54.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean61 = numberAxis54.equals((java.lang.Object) plotOrientation60);
        numberAxis54.setFixedDimension((double) 100L);
        numberAxis54.setUpperMargin((double) (-268));
        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis54, true);
        double double68 = xYPlot10.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone71 = dateAxis70.getTimeZone();
        org.jfree.data.Range range72 = dateAxis70.getRange();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        java.util.Date date74 = day73.getEnd();
        dateAxis70.setMaximumDate(date74);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone77 = dateAxis76.getTimeZone();
        org.jfree.data.Range range78 = dateAxis76.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date80 = dateAxis76.calculateLowestVisibleTickValue(dateTickUnit79);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone82 = dateAxis81.getTimeZone();
        org.jfree.data.Range range83 = dateAxis81.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date85 = dateAxis81.calculateLowestVisibleTickValue(dateTickUnit84);
        dateAxis76.setMinimumDate(date85);
        dateAxis70.setMinimumDate(date85);
        xYPlot10.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) dateAxis70, true);
        boolean boolean90 = xYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace91 = xYPlot10.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(dateTickUnit84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(axisSpace91);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        org.jfree.chart.plot.Marker marker81 = null;
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            xYPlot32.addDomainMarker(2, marker81, layer82, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(layer82);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.data.Range range5 = dateAxis3.getRange();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        org.jfree.data.Range range8 = dateAxis6.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit9);
        java.util.Date date11 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit9);
        boolean boolean12 = chartChangeEventType2.equals((java.lang.Object) dateAxis3);
        dateAxis3.setAutoRangeMinimumSize((double) 10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        dateAxis0.setTimeZone(timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        org.jfree.data.Range range8 = dateAxis6.getRange();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        dateAxis6.setMaximumDate(date10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj14 = numberAxis13.clone();
        numberAxis13.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis13.setMarkerBand(markerAxisBand17);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = numberAxis13.getStandardTickUnits();
        org.jfree.data.Range range20 = numberAxis13.getRange();
        dateAxis6.setRangeWithMargins(range20, false, true);
        dateAxis0.setRange(range20, false, true);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis56.configure();
        xYPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis56);
        org.jfree.chart.axis.AxisLocation axisLocation59 = xYPlot10.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        java.awt.Image image58 = null;
        xYPlot10.setBackgroundImage(image58);
        double double60 = xYPlot10.getRangeCrosshairValue();
        java.awt.Image image61 = null;
        xYPlot10.setBackgroundImage(image61);
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone65 = dateAxis64.getTimeZone();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition66 = dateAxis64.getTickMarkPosition();
        xYPlot10.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis64);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNotNull(dateTickMarkPosition66);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = null;
        xYPlot10.setBackgroundPaint(paint16);
        java.awt.Paint paint18 = xYPlot10.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.Plot plot6 = null;
        dateAxis0.setPlot(plot6);
        dateAxis0.setLabelAngle((-1.0d));
        java.lang.String str10 = dateAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setDomainAxisLocation(192, axisLocation53);
        java.awt.Paint paint55 = xYPlot10.getNoDataMessagePaint();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone57 = dateAxis56.getTimeZone();
        org.jfree.data.Range range58 = dateAxis56.getRange();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        java.util.Date date60 = day59.getEnd();
        dateAxis56.setMaximumDate(date60);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) (short) -1, 0.0d, (double) 10);
        double double68 = rectangleInsets66.calculateBottomInset((double) (short) 1);
        dateAxis56.setLabelInsets(rectangleInsets66);
        xYPlot10.setInsets(rectangleInsets66, true);
        xYPlot10.setNoDataMessage("CategoryAnchor.MIDDLE");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        org.jfree.chart.axis.AxisLocation axisLocation80 = xYPlot32.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(axisLocation80);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        float[] floatArray4 = new float[] { 10.0f };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB(500, 4, (-65281), floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot10.getRangeAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj19 = numberAxis18.clone();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj32 = numberAxis31.clone();
        numberAxis31.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = null;
        numberAxis37.setMarkerBand(markerAxisBand41);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = numberAxis37.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj46 = numberAxis45.clone();
        numberAxis45.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis45.setMarkerBand(markerAxisBand49);
        numberAxis45.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double59 = rectangleInsets57.extendHeight(1.0d);
        double double61 = rectangleInsets57.calculateRightOutset((double) (short) 100);
        double double63 = rectangleInsets57.calculateTopOutset((double) 5);
        double double64 = rectangleInsets57.getTop();
        numberAxis45.setLabelInsets(rectangleInsets57);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { numberAxis28, numberAxis31, numberAxis37, numberAxis45 };
        xYPlot26.setDomainAxes(valueAxisArray66);
        java.awt.Stroke stroke68 = xYPlot26.getRangeGridlineStroke();
        xYPlot26.clearRangeMarkers();
        java.lang.String str70 = xYPlot26.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder71 = xYPlot26.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        xYPlot26.setRenderer(7, xYItemRenderer73, true);
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation77 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation76, plotOrientation77);
        xYPlot26.setOrientation(plotOrientation77);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation77);
        org.jfree.chart.axis.AxisLocation axisLocation81 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation82 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation81, plotOrientation82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation82);
        org.jfree.chart.text.TextAnchor textAnchor85 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean86 = axisLocation15.equals((java.lang.Object) textAnchor85);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(tickUnitSource43);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 108.0d + "'", double59 == 108.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 97.0d + "'", double63 == 97.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(datasetRenderingOrder71);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(plotOrientation77);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertNotNull(plotOrientation82);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertNotNull(textAnchor85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj14 = numberAxis13.clone();
        numberAxis13.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis13.setMarkerBand(markerAxisBand17);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = numberAxis13.getStandardTickUnits();
        numberAxis13.setUpperBound((double) 0.0f);
        numberAxis13.setRangeWithMargins((double) (byte) -1, (double) 2);
        xYPlot10.setDomainAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis27.setLabelPaint((java.awt.Paint) color29);
        float float31 = numberAxis27.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = numberAxis27.getTickUnit();
        numberAxis13.setTickUnit(numberTickUnit32);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(numberTickUnit32);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) -1);
        categoryAxis0.setAxisLineVisible(false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setForegroundAlpha(10.0f);
        xYPlot32.clearRangeMarkers((-253));
        float float84 = xYPlot32.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + float84 + "' != '" + 1.0f + "'", float84 == 1.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        java.lang.Object obj56 = null;
        boolean boolean57 = datasetRenderingOrder55.equals(obj56);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset58 = xYPlot10.getDataset((int) (byte) 100);
        boolean boolean59 = xYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = xYPlot10.getInsets();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(xYDataset58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleInsets60);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        numberAxis1.setUpperBound((double) 100.0f);
        numberAxis1.setTickMarksVisible(true);
        double double10 = numberAxis1.getLowerBound();
        java.awt.Shape shape11 = numberAxis1.getDownArrow();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.5d) + "'", double10 == (-0.5d));
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit8);
        dateAxis0.setMinimumDate(date9);
        dateAxis0.setRange((double) (-1), (double) 1L);
        org.jfree.chart.plot.Plot plot14 = dateAxis0.getPlot();
        try {
            dateAxis0.setRangeWithMargins(0.2d, (double) (-268));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.2) <= upper (-268.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getEnd();
        org.jfree.chart.ChartColor chartColor74 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color75 = chartColor74.darker();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day69, (java.awt.Paint) color75, stroke76);
        boolean boolean78 = xYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = categoryMarker77.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker77.setLabelOffsetType(lengthAdjustmentType80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77, layer82);
        xYPlot10.configureRangeAxes();
        java.awt.Graphics2D graphics2D85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.axis.NumberAxis numberAxis88 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj89 = numberAxis88.clone();
        java.awt.Graphics2D graphics2D90 = null;
        org.jfree.chart.axis.AxisState axisState91 = null;
        java.awt.geom.Rectangle2D rectangle2D92 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = null;
        java.util.List list94 = numberAxis88.refreshTicks(graphics2D90, axisState91, rectangle2D92, rectangleEdge93);
        xYPlot10.drawRangeTickBands(graphics2D85, rectangle2D86, list94);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertNotNull(obj89);
        org.junit.Assert.assertNotNull(list94);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAxis0.equals(obj3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis8.valueToJava2D((double) 5, rectangle2D11, rectangleEdge12);
        org.jfree.chart.plot.Plot plot14 = null;
        dateAxis8.setPlot(plot14);
        boolean boolean16 = color6.equals((java.lang.Object) dateAxis8);
        java.awt.Paint paint17 = dateAxis8.getTickLabelPaint();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean2 = layer0.equals((java.lang.Object) (-268));
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setDomainAxisLocation(192, axisLocation53);
        java.awt.Paint paint55 = xYPlot10.getNoDataMessagePaint();
        java.util.List list56 = xYPlot10.getAnnotations();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(list56);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        java.awt.Image image58 = null;
        xYPlot10.setBackgroundImage(image58);
        java.awt.Stroke stroke60 = xYPlot10.getRangeCrosshairStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        xYPlot10.addChangeListener(plotChangeListener61);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        dateAxis0.resizeRange((double) '#');
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 6, (double) 1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        double double2 = numberAxis1.getLabelAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets7);
        numberAxis1.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.centerRange(0.0d);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj12 = numberAxis11.clone();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj15 = numberAxis14.clone();
        numberAxis14.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str22 = numberAxis21.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        numberAxis24.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj31 = numberAxis30.clone();
        numberAxis30.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis30.setMarkerBand(markerAxisBand34);
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = numberAxis30.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        numberAxis38.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double52 = rectangleInsets50.extendHeight(1.0d);
        double double54 = rectangleInsets50.calculateRightOutset((double) (short) 100);
        double double56 = rectangleInsets50.calculateTopOutset((double) 5);
        double double57 = rectangleInsets50.getTop();
        numberAxis38.setLabelInsets(rectangleInsets50);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray59 = new org.jfree.chart.axis.ValueAxis[] { numberAxis21, numberAxis24, numberAxis30, numberAxis38 };
        xYPlot19.setDomainAxes(valueAxisArray59);
        org.jfree.chart.axis.AxisLocation axisLocation62 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot19.setDomainAxisLocation(192, axisLocation62);
        java.awt.Paint paint64 = xYPlot19.getNoDataMessagePaint();
        java.awt.Font font65 = xYPlot19.getNoDataMessageFont();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot19);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 108.0d + "'", double52 == 108.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 10.0d + "'", double54 == 10.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 97.0d + "'", double56 == 97.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 97.0d + "'", double57 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray59);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(font65);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj15 = numberAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj18 = numberAxis17.clone();
        numberAxis17.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str25 = numberAxis24.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj34 = numberAxis33.clone();
        numberAxis33.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis33.setMarkerBand(markerAxisBand37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = numberAxis33.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj42 = numberAxis41.clone();
        numberAxis41.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis41.setMarkerBand(markerAxisBand45);
        numberAxis41.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double55 = rectangleInsets53.extendHeight(1.0d);
        double double57 = rectangleInsets53.calculateRightOutset((double) (short) 100);
        double double59 = rectangleInsets53.calculateTopOutset((double) 5);
        double double60 = rectangleInsets53.getTop();
        numberAxis41.setLabelInsets(rectangleInsets53);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis27, numberAxis33, numberAxis41 };
        xYPlot22.setDomainAxes(valueAxisArray62);
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setDomainAxisLocation(192, axisLocation65);
        org.jfree.chart.axis.AxisLocation axisLocation67 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setRangeAxisLocation(axisLocation67);
        xYPlot10.setRangeAxisLocation((int) (short) 100, axisLocation67, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        int int72 = xYPlot10.getIndexOf(xYItemRenderer71);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(tickUnitSource39);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 108.0d + "'", double55 == 108.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 97.0d + "'", double59 == 97.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 97.0d + "'", double60 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit8);
        dateAxis0.setMinimumDate(date9);
        dateAxis0.setRange((double) (-1), (double) 1L);
        org.jfree.chart.plot.Plot plot14 = dateAxis0.getPlot();
        dateAxis0.setNegativeArrowVisible(false);
        boolean boolean17 = dateAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = categoryMarker60.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker60.setLabelOffsetType(lengthAdjustmentType63);
        java.lang.Object obj65 = null;
        boolean boolean66 = lengthAdjustmentType63.equals(obj65);
        java.lang.String str67 = lengthAdjustmentType63.toString();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(lengthAdjustmentType63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "EXPAND" + "'", str67.equals("EXPAND"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot10.getRangeAxisLocation(255);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot10.getRenderer();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) 3);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj8 = numberAxis7.clone();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj11 = numberAxis10.clone();
        numberAxis10.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.chart.axis.AxisLocation axisLocation70 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot27.setDomainAxisLocation(192, axisLocation70);
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot27.setRangeAxisLocation(axisLocation72);
        xYPlot15.setRangeAxisLocation((int) (short) 100, axisLocation72, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent76 = null;
        xYPlot15.datasetChanged(datasetChangeEvent76);
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = null;
        org.jfree.chart.axis.AxisSpace axisSpace80 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace81 = categoryAxis0.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) xYPlot15, rectangle2D78, rectangleEdge79, axisSpace80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(axisLocation72);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setDomainAxisLocation(192, axisLocation53);
        org.jfree.chart.axis.AxisLocation axisLocation55 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setRangeAxisLocation(axisLocation55);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        xYPlot10.setDataset(xYDataset57);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.data.Range range5 = dateAxis3.getRange();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        org.jfree.data.Range range8 = dateAxis6.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit9);
        java.util.Date date11 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit9);
        boolean boolean12 = chartChangeEventType2.equals((java.lang.Object) dateAxis3);
        java.lang.String str13 = chartChangeEventType2.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str13.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        try {
            java.util.List list6 = categoryAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset58 = xYPlot10.getDataset((int) (byte) 100);
        boolean boolean59 = xYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone62 = dateAxis61.getTimeZone();
        org.jfree.data.Range range63 = dateAxis61.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit64 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date65 = dateAxis61.calculateLowestVisibleTickValue(dateTickUnit64);
        java.awt.Shape shape66 = dateAxis61.getDownArrow();
        xYPlot10.setRangeAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(xYDataset58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(dateTickUnit64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(shape66);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        dateAxis0.setMaximumDate(date4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj8 = numberAxis7.clone();
        numberAxis7.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis7.setMarkerBand(markerAxisBand11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis7.getStandardTickUnits();
        org.jfree.data.Range range14 = numberAxis7.getRange();
        dateAxis0.setRangeWithMargins(range14, false, true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone19 = dateAxis18.getTimeZone();
        org.jfree.data.Range range20 = dateAxis18.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date22 = dateAxis18.calculateLowestVisibleTickValue(dateTickUnit21);
        java.util.Date date23 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone25 = dateAxis24.getTimeZone();
        org.jfree.data.Range range26 = dateAxis24.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date28 = dateAxis24.calculateLowestVisibleTickValue(dateTickUnit27);
        java.util.Date date29 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone31 = dateAxis30.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = dateAxis30.valueToJava2D((double) 5, rectangle2D33, rectangleEdge34);
        dateAxis30.setRangeAboutValue((double) (-1.0f), (double) (short) 10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis30.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition39);
        java.text.DateFormat dateFormat41 = null;
        dateAxis0.setDateFormatOverride(dateFormat41);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAxis0.equals(obj3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color6);
        categoryAxis0.setUpperMargin((double) (short) -1);
        java.lang.String str10 = categoryAxis0.getLabel();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        try {
            double double17 = categoryAxis0.getCategoryStart(0, (-1), rectangle2D13, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        categoryMarker60.setDrawAsLine(false);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        java.util.Date date65 = day64.getEnd();
        org.jfree.chart.ChartColor chartColor69 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color70 = chartColor69.darker();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day64, (java.awt.Paint) color70, stroke71);
        categoryMarker60.setKey((java.lang.Comparable) day64);
        java.awt.Paint paint74 = null;
        categoryMarker60.setOutlinePaint(paint74);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent76 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor77 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        categoryMarker60.setLabelAnchor(rectangleAnchor77);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleAnchor77);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj18 = numberAxis17.clone();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj21 = numberAxis20.clone();
        numberAxis20.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj43 = numberAxis42.clone();
        numberAxis42.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj49 = numberAxis48.clone();
        numberAxis48.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand52 = null;
        numberAxis48.setMarkerBand(markerAxisBand52);
        org.jfree.chart.axis.TickUnitSource tickUnitSource54 = numberAxis48.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj57 = numberAxis56.clone();
        numberAxis56.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand60 = null;
        numberAxis56.setMarkerBand(markerAxisBand60);
        numberAxis56.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double70 = rectangleInsets68.extendHeight(1.0d);
        double double72 = rectangleInsets68.calculateRightOutset((double) (short) 100);
        double double74 = rectangleInsets68.calculateTopOutset((double) 5);
        double double75 = rectangleInsets68.getTop();
        numberAxis56.setLabelInsets(rectangleInsets68);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray77 = new org.jfree.chart.axis.ValueAxis[] { numberAxis39, numberAxis42, numberAxis48, numberAxis56 };
        xYPlot37.setDomainAxes(valueAxisArray77);
        org.jfree.chart.axis.AxisLocation axisLocation80 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot37.setDomainAxisLocation(192, axisLocation80);
        org.jfree.chart.axis.AxisLocation axisLocation82 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot37.setRangeAxisLocation(axisLocation82);
        xYPlot25.setRangeAxisLocation((int) (short) 100, axisLocation82, false);
        xYPlot10.setRangeAxisLocation(12, axisLocation82);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(tickUnitSource54);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 108.0d + "'", double70 == 108.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 10.0d + "'", double72 == 10.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 97.0d + "'", double74 == 97.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 97.0d + "'", double75 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray77);
        org.junit.Assert.assertNotNull(axisLocation80);
        org.junit.Assert.assertNotNull(axisLocation82);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color6 = chartColor5.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj13 = numberAxis12.clone();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj26 = numberAxis25.clone();
        numberAxis25.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj32 = numberAxis31.clone();
        numberAxis31.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = null;
        numberAxis31.setMarkerBand(markerAxisBand35);
        org.jfree.chart.axis.TickUnitSource tickUnitSource37 = numberAxis31.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj40 = numberAxis39.clone();
        numberAxis39.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand43 = null;
        numberAxis39.setMarkerBand(markerAxisBand43);
        numberAxis39.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double53 = rectangleInsets51.extendHeight(1.0d);
        double double55 = rectangleInsets51.calculateRightOutset((double) (short) 100);
        double double57 = rectangleInsets51.calculateTopOutset((double) 5);
        double double58 = rectangleInsets51.getTop();
        numberAxis39.setLabelInsets(rectangleInsets51);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray60 = new org.jfree.chart.axis.ValueAxis[] { numberAxis22, numberAxis25, numberAxis31, numberAxis39 };
        xYPlot20.setDomainAxes(valueAxisArray60);
        java.awt.Stroke stroke62 = xYPlot20.getRangeGridlineStroke();
        xYPlot20.clearRangeMarkers();
        java.lang.String str64 = xYPlot20.getNoDataMessage();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis66.configure();
        xYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis66);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = xYPlot20.getAxisOffset();
        categoryMarker8.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot20);
        try {
            categoryMarker8.setAlpha((float) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(tickUnitSource37);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 108.0d + "'", double53 == 108.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 10.0d + "'", double55 == 10.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 97.0d + "'", double57 == 97.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 97.0d + "'", double58 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(rectangleInsets69);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setForegroundAlpha(10.0f);
        xYPlot32.clearRangeMarkers((-253));
        java.awt.Paint paint84 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot32.setDomainTickBandPaint(paint84);
        java.lang.String str86 = xYPlot32.getPlotType();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "XY Plot" + "'", str86.equals("XY Plot"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 15);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        numberAxis1.setFixedDimension((double) 100L);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj14 = numberAxis13.clone();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj17 = numberAxis16.clone();
        numberAxis16.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str24 = numberAxis23.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj27 = numberAxis26.clone();
        numberAxis26.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis32.setMarkerBand(markerAxisBand36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis32.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj41 = numberAxis40.clone();
        numberAxis40.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = null;
        numberAxis40.setMarkerBand(markerAxisBand44);
        numberAxis40.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double54 = rectangleInsets52.extendHeight(1.0d);
        double double56 = rectangleInsets52.calculateRightOutset((double) (short) 100);
        double double58 = rectangleInsets52.calculateTopOutset((double) 5);
        double double59 = rectangleInsets52.getTop();
        numberAxis40.setLabelInsets(rectangleInsets52);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray61 = new org.jfree.chart.axis.ValueAxis[] { numberAxis23, numberAxis26, numberAxis32, numberAxis40 };
        xYPlot21.setDomainAxes(valueAxisArray61);
        java.awt.Stroke stroke63 = xYPlot21.getRangeGridlineStroke();
        xYPlot21.clearRangeMarkers();
        java.lang.String str65 = xYPlot21.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder66 = xYPlot21.getDatasetRenderingOrder();
        boolean boolean67 = xYPlot21.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke68 = xYPlot21.getRangeZeroBaselineStroke();
        numberAxis1.setTickMarkStroke(stroke68);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 108.0d + "'", double54 == 108.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 10.0d + "'", double56 == 10.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 97.0d + "'", double58 == 97.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 97.0d + "'", double59 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray61);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertNotNull(datasetRenderingOrder66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        dateAxis0.setRangeAboutValue((double) (-1.0f), (double) (short) 10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        java.util.Date date12 = dateAxis10.getMaximumDate();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        try {
            double double17 = dateAxis0.dateToJava2D(date12, rectangle2D13, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset58 = xYPlot10.getDataset((int) (byte) 100);
        xYPlot10.setDomainCrosshairValue(0.0d, false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(xYDataset58);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj4 = numberAxis3.clone();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj7 = numberAxis6.clone();
        numberAxis6.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, xYItemRenderer10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str14 = numberAxis13.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj17 = numberAxis16.clone();
        numberAxis16.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis22.setMarkerBand(markerAxisBand26);
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = numberAxis22.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj31 = numberAxis30.clone();
        numberAxis30.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis30.setMarkerBand(markerAxisBand34);
        numberAxis30.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double44 = rectangleInsets42.extendHeight(1.0d);
        double double46 = rectangleInsets42.calculateRightOutset((double) (short) 100);
        double double48 = rectangleInsets42.calculateTopOutset((double) 5);
        double double49 = rectangleInsets42.getTop();
        numberAxis30.setLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray51 = new org.jfree.chart.axis.ValueAxis[] { numberAxis13, numberAxis16, numberAxis22, numberAxis30 };
        xYPlot11.setDomainAxes(valueAxisArray51);
        java.awt.Stroke stroke53 = xYPlot11.getRangeGridlineStroke();
        xYPlot11.clearRangeMarkers();
        java.lang.String str55 = xYPlot11.getNoDataMessage();
        java.awt.Paint paint56 = xYPlot11.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke57 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint56, stroke57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 108.0d + "'", double44 == 108.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.0d + "'", double46 == 10.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 97.0d + "'", double49 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj2 = null;
        int int3 = objectList1.indexOf(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, 5, 192);
        java.awt.color.ColorSpace colorSpace4 = chartColor3.getColorSpace();
        org.junit.Assert.assertNotNull(colorSpace4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) 3);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        float float4 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj10 = numberAxis9.clone();
        numberAxis9.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis9.setMarkerBand(markerAxisBand13);
        numberAxis9.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double23 = rectangleInsets21.extendHeight(1.0d);
        double double25 = rectangleInsets21.calculateRightOutset((double) (short) 100);
        double double27 = rectangleInsets21.calculateTopOutset((double) 5);
        double double28 = rectangleInsets21.getTop();
        numberAxis9.setLabelInsets(rectangleInsets21);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj36 = numberAxis35.clone();
        numberAxis35.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer39);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str43 = numberAxis42.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj46 = numberAxis45.clone();
        numberAxis45.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        org.jfree.chart.axis.TickUnitSource tickUnitSource57 = numberAxis51.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj60 = numberAxis59.clone();
        numberAxis59.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand63 = null;
        numberAxis59.setMarkerBand(markerAxisBand63);
        numberAxis59.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double73 = rectangleInsets71.extendHeight(1.0d);
        double double75 = rectangleInsets71.calculateRightOutset((double) (short) 100);
        double double77 = rectangleInsets71.calculateTopOutset((double) 5);
        double double78 = rectangleInsets71.getTop();
        numberAxis59.setLabelInsets(rectangleInsets71);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray80 = new org.jfree.chart.axis.ValueAxis[] { numberAxis42, numberAxis45, numberAxis51, numberAxis59 };
        xYPlot40.setDomainAxes(valueAxisArray80);
        java.awt.Stroke stroke82 = xYPlot40.getRangeGridlineStroke();
        numberAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot40);
        org.jfree.chart.axis.AxisLocation axisLocation85 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot40.setRangeAxisLocation((int) '4', axisLocation85, true);
        xYPlot40.setBackgroundAlpha((float) 5);
        java.awt.Paint paint90 = xYPlot40.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = xYPlot40.getRangeAxisEdge();
        try {
            double double92 = categoryAxis0.getCategoryMiddle(0, (int) (short) 0, rectangle2D7, rectangleEdge91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 108.0d + "'", double23 == 108.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 97.0d + "'", double27 == 97.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 97.0d + "'", double28 == 97.0d);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(tickUnitSource57);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 108.0d + "'", double73 == 108.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 10.0d + "'", double75 == 10.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 97.0d + "'", double77 == 97.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 97.0d + "'", double78 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray80);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(rectangleEdge91);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        xYPlot10.setRenderer(7, xYItemRenderer57, true);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation61 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation60, plotOrientation61);
        xYPlot10.setOrientation(plotOrientation61);
        xYPlot10.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis67 = xYPlot10.getDomainAxis(0);
        org.jfree.data.general.Dataset dataset68 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent69 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) xYPlot10, dataset68);
        org.jfree.chart.axis.AxisSpace axisSpace70 = null;
        xYPlot10.setFixedDomainAxisSpace(axisSpace70);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(plotOrientation61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(valueAxis67);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj15 = numberAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj18 = numberAxis17.clone();
        numberAxis17.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str25 = numberAxis24.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj34 = numberAxis33.clone();
        numberAxis33.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis33.setMarkerBand(markerAxisBand37);
        org.jfree.chart.axis.TickUnitSource tickUnitSource39 = numberAxis33.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj42 = numberAxis41.clone();
        numberAxis41.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis41.setMarkerBand(markerAxisBand45);
        numberAxis41.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double55 = rectangleInsets53.extendHeight(1.0d);
        double double57 = rectangleInsets53.calculateRightOutset((double) (short) 100);
        double double59 = rectangleInsets53.calculateTopOutset((double) 5);
        double double60 = rectangleInsets53.getTop();
        numberAxis41.setLabelInsets(rectangleInsets53);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis27, numberAxis33, numberAxis41 };
        xYPlot22.setDomainAxes(valueAxisArray62);
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setDomainAxisLocation(192, axisLocation65);
        org.jfree.chart.axis.AxisLocation axisLocation67 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setRangeAxisLocation(axisLocation67);
        xYPlot10.setRangeAxisLocation((int) (short) 100, axisLocation67, false);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj74 = numberAxis73.clone();
        numberAxis73.setRangeWithMargins((double) (byte) 0, (double) 10L);
        numberAxis73.setUpperBound((double) 100.0f);
        numberAxis73.setTickMarksVisible(true);
        double double82 = numberAxis73.getLowerBound();
        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis73, false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(tickUnitSource39);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 108.0d + "'", double55 == 108.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 10.0d + "'", double57 == 10.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 97.0d + "'", double59 == 97.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 97.0d + "'", double60 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + (-0.5d) + "'", double82 == (-0.5d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        java.text.DateFormat dateFormat6 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(dateFormat6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        java.lang.String str6 = dateAxis0.getLabelToolTip();
        dateAxis0.setVisible(false);
        double double9 = dateAxis0.getFixedDimension();
        try {
            dateAxis0.zoomRange(111.0d, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (111.0) <= upper (8.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        double double22 = rectangleInsets13.getBottom();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setForegroundAlpha(10.0f);
        xYPlot32.clearRangeMarkers((-253));
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = xYPlot32.getDomainAxisEdge(100);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(rectangleEdge85);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset58 = xYPlot10.getDataset((int) (byte) 100);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        java.util.Date date60 = day59.getEnd();
        org.jfree.chart.ChartColor chartColor64 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color65 = chartColor64.darker();
        java.awt.Stroke stroke66 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker67 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day59, (java.awt.Paint) color65, stroke66);
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color65);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(xYDataset58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) "XY Plot");
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        numberAxis1.setLabelToolTip("UnitType.RELATIVE");
        double double8 = numberAxis1.getFixedAutoRange();
        numberAxis1.setLabelURL("UnitType.RELATIVE");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color6 = chartColor5.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.Object obj11 = null;
        boolean boolean12 = rectangleAnchor10.equals(obj11);
        java.awt.Color color13 = java.awt.Color.cyan;
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) color13);
        categoryMarker8.setLabelAnchor(rectangleAnchor10);
        categoryMarker8.setKey((java.lang.Comparable) 100.0f);
        boolean boolean18 = categoryMarker8.getDrawAsLine();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot10.getRangeAxisLocation(255);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot10.setSeriesRenderingOrder(seriesRenderingOrder16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getEnd();
        org.jfree.chart.ChartColor chartColor23 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color24 = chartColor23.darker();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day18, (java.awt.Paint) color24, stroke25);
        boolean boolean27 = seriesRenderingOrder16.equals((java.lang.Object) color24);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        double double30 = numberAxis29.getLabelAngle();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = numberAxis29.valueToJava2D((double) '4', rectangle2D32, rectangleEdge33);
        boolean boolean35 = seriesRenderingOrder16.equals((java.lang.Object) numberAxis29);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAxis0.equals(obj3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj14 = numberAxis13.clone();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj17 = numberAxis16.clone();
        numberAxis16.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer20);
        xYPlot21.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot21.getRangeAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj43 = numberAxis42.clone();
        numberAxis42.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj49 = numberAxis48.clone();
        numberAxis48.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand52 = null;
        numberAxis48.setMarkerBand(markerAxisBand52);
        org.jfree.chart.axis.TickUnitSource tickUnitSource54 = numberAxis48.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj57 = numberAxis56.clone();
        numberAxis56.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand60 = null;
        numberAxis56.setMarkerBand(markerAxisBand60);
        numberAxis56.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double70 = rectangleInsets68.extendHeight(1.0d);
        double double72 = rectangleInsets68.calculateRightOutset((double) (short) 100);
        double double74 = rectangleInsets68.calculateTopOutset((double) 5);
        double double75 = rectangleInsets68.getTop();
        numberAxis56.setLabelInsets(rectangleInsets68);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray77 = new org.jfree.chart.axis.ValueAxis[] { numberAxis39, numberAxis42, numberAxis48, numberAxis56 };
        xYPlot37.setDomainAxes(valueAxisArray77);
        java.awt.Stroke stroke79 = xYPlot37.getRangeGridlineStroke();
        xYPlot37.clearRangeMarkers();
        java.lang.String str81 = xYPlot37.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder82 = xYPlot37.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer84 = null;
        xYPlot37.setRenderer(7, xYItemRenderer84, true);
        org.jfree.chart.axis.AxisLocation axisLocation87 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation88 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation87, plotOrientation88);
        xYPlot37.setOrientation(plotOrientation88);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation26, plotOrientation88);
        org.jfree.chart.axis.AxisLocation axisLocation92 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation93 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge94 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation92, plotOrientation93);
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation26, plotOrientation93);
        try {
            double double96 = categoryAxis0.getCategoryStart(8, (int) (short) 1, rectangle2D10, rectangleEdge95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(tickUnitSource54);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 108.0d + "'", double70 == 108.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 10.0d + "'", double72 == 10.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 97.0d + "'", double74 == 97.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 97.0d + "'", double75 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray77);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNotNull(datasetRenderingOrder82);
        org.junit.Assert.assertNotNull(axisLocation87);
        org.junit.Assert.assertNotNull(plotOrientation88);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertNotNull(rectangleEdge91);
        org.junit.Assert.assertNotNull(axisLocation92);
        org.junit.Assert.assertNotNull(plotOrientation93);
        org.junit.Assert.assertNotNull(rectangleEdge94);
        org.junit.Assert.assertNotNull(rectangleEdge95);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setDomainAxisLocation(192, axisLocation53);
        java.awt.Paint paint55 = xYPlot10.getNoDataMessagePaint();
        double double56 = xYPlot10.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        int int4 = objectList1.indexOf((java.lang.Object) (byte) 1);
        int int5 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset58 = xYPlot10.getDataset((int) (byte) 100);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = xYPlot10.getRendererForDataset(xYDataset59);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(xYDataset58);
        org.junit.Assert.assertNull(xYItemRenderer60);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj5 = numberAxis4.clone();
        numberAxis4.setRangeWithMargins((double) (byte) 0, (double) 10L);
        numberAxis4.setUpperBound((double) 100.0f);
        boolean boolean11 = dateAxis0.equals((java.lang.Object) numberAxis4);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getLeftArrow();
        org.jfree.chart.plot.Plot plot14 = dateAxis12.getPlot();
        boolean boolean15 = dateAxis0.equals((java.lang.Object) dateAxis12);
        dateAxis12.setLabelAngle((double) 1560409200000L);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        numberAxis1.setFixedDimension((double) 100L);
        try {
            numberAxis1.setRangeWithMargins(100.0d, (double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (5.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color6 = chartColor5.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color6, stroke7);
        java.awt.Font font9 = categoryMarker8.getLabelFont();
        java.lang.Comparable comparable10 = categoryMarker8.getKey();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(comparable10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setLabel("13-June-2019");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = categoryMarker60.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker60.setLabelOffsetType(lengthAdjustmentType63);
        java.awt.Stroke stroke65 = categoryMarker60.getStroke();
        java.lang.Comparable comparable66 = categoryMarker60.getKey();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj69 = numberAxis68.clone();
        numberAxis68.setAxisLineVisible(false);
        boolean boolean72 = categoryMarker60.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(lengthAdjustmentType63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(comparable66);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        xYPlot10.setRenderer(7, xYItemRenderer57, true);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation61 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation60, plotOrientation61);
        xYPlot10.setOrientation(plotOrientation61);
        xYPlot10.setRangeCrosshairVisible(true);
        java.awt.Paint paint66 = xYPlot10.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(plotOrientation61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(paint66);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str59 = numberAxis54.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean61 = numberAxis54.equals((java.lang.Object) plotOrientation60);
        numberAxis54.setFixedDimension((double) 100L);
        numberAxis54.setUpperMargin((double) (-268));
        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis54, true);
        double double68 = xYPlot10.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone71 = dateAxis70.getTimeZone();
        org.jfree.data.Range range72 = dateAxis70.getRange();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        java.util.Date date74 = day73.getEnd();
        dateAxis70.setMaximumDate(date74);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone77 = dateAxis76.getTimeZone();
        org.jfree.data.Range range78 = dateAxis76.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date80 = dateAxis76.calculateLowestVisibleTickValue(dateTickUnit79);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone82 = dateAxis81.getTimeZone();
        org.jfree.data.Range range83 = dateAxis81.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date85 = dateAxis81.calculateLowestVisibleTickValue(dateTickUnit84);
        dateAxis76.setMinimumDate(date85);
        dateAxis70.setMinimumDate(date85);
        xYPlot10.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) dateAxis70, true);
        java.text.DateFormat dateFormat90 = null;
        dateAxis70.setDateFormatOverride(dateFormat90);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(dateTickUnit84);
        org.junit.Assert.assertNotNull(date85);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj10 = numberAxis9.clone();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj13 = numberAxis12.clone();
        numberAxis12.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer16);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str20 = numberAxis19.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj29 = numberAxis28.clone();
        numberAxis28.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis28.setMarkerBand(markerAxisBand32);
        org.jfree.chart.axis.TickUnitSource tickUnitSource34 = numberAxis28.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj37 = numberAxis36.clone();
        numberAxis36.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand40 = null;
        numberAxis36.setMarkerBand(markerAxisBand40);
        numberAxis36.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double50 = rectangleInsets48.extendHeight(1.0d);
        double double52 = rectangleInsets48.calculateRightOutset((double) (short) 100);
        double double54 = rectangleInsets48.calculateTopOutset((double) 5);
        double double55 = rectangleInsets48.getTop();
        numberAxis36.setLabelInsets(rectangleInsets48);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray57 = new org.jfree.chart.axis.ValueAxis[] { numberAxis19, numberAxis22, numberAxis28, numberAxis36 };
        xYPlot17.setDomainAxes(valueAxisArray57);
        java.awt.Stroke stroke59 = xYPlot17.getRangeGridlineStroke();
        xYPlot17.clearRangeMarkers();
        java.lang.String str61 = xYPlot17.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder62 = xYPlot17.getDatasetRenderingOrder();
        boolean boolean63 = xYPlot17.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset65 = xYPlot17.getDataset((int) (byte) 100);
        java.awt.Font font66 = xYPlot17.getNoDataMessageFont();
        numberAxis1.setTickLabelFont(font66);
        double double68 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(tickUnitSource34);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 108.0d + "'", double50 == 108.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 10.0d + "'", double52 == 10.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 97.0d + "'", double54 == 97.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 97.0d + "'", double55 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray57);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(datasetRenderingOrder62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(xYDataset65);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str59 = numberAxis54.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean61 = numberAxis54.equals((java.lang.Object) plotOrientation60);
        numberAxis54.setFixedDimension((double) 100L);
        numberAxis54.setUpperMargin((double) (-268));
        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis54, true);
        double double68 = xYPlot10.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone71 = dateAxis70.getTimeZone();
        org.jfree.data.Range range72 = dateAxis70.getRange();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        java.util.Date date74 = day73.getEnd();
        dateAxis70.setMaximumDate(date74);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone77 = dateAxis76.getTimeZone();
        org.jfree.data.Range range78 = dateAxis76.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date80 = dateAxis76.calculateLowestVisibleTickValue(dateTickUnit79);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone82 = dateAxis81.getTimeZone();
        org.jfree.data.Range range83 = dateAxis81.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date85 = dateAxis81.calculateLowestVisibleTickValue(dateTickUnit84);
        dateAxis76.setMinimumDate(date85);
        dateAxis70.setMinimumDate(date85);
        xYPlot10.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) dateAxis70, true);
        java.awt.Paint paint90 = xYPlot10.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(dateTickUnit84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(paint90);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        categoryMarker60.setDrawAsLine(false);
        boolean boolean64 = categoryMarker60.getDrawAsLine();
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryMarker60.setOutlinePaint((java.awt.Paint) color65);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.text.DateFormat dateFormat2 = null;
        dateAxis0.setDateFormatOverride(dateFormat2);
        dateAxis0.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAxis0.equals(obj3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis8.valueToJava2D((double) 5, rectangle2D11, rectangleEdge12);
        org.jfree.chart.plot.Plot plot14 = null;
        dateAxis8.setPlot(plot14);
        boolean boolean16 = color6.equals((java.lang.Object) dateAxis8);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone18 = dateAxis17.getTimeZone();
        org.jfree.data.Range range19 = dateAxis17.getRange();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getEnd();
        dateAxis17.setMaximumDate(date21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        numberAxis24.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis24.setMarkerBand(markerAxisBand28);
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = numberAxis24.getStandardTickUnits();
        org.jfree.data.Range range31 = numberAxis24.getRange();
        dateAxis17.setRangeWithMargins(range31, false, true);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone36 = dateAxis35.getTimeZone();
        org.jfree.data.Range range37 = dateAxis35.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date39 = dateAxis35.calculateLowestVisibleTickValue(dateTickUnit38);
        java.util.Date date40 = dateAxis17.calculateLowestVisibleTickValue(dateTickUnit38);
        dateAxis8.setTickUnit(dateTickUnit38, false, false);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(tickUnitSource30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(dateTickUnit38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = categoryMarker60.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker60.setLabelOffsetType(lengthAdjustmentType63);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = categoryMarker60.getLabelOffsetType();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent66 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker60);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(lengthAdjustmentType63);
        org.junit.Assert.assertNotNull(lengthAdjustmentType65);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.data.Range range5 = dateAxis3.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit6);
        java.util.Date date8 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit6);
        dateAxis0.zoomRange(0.0d, (double) 6);
        double double12 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.java2DToValue(0.05d, rectangle2D3, rectangleEdge4);
        double double6 = dateAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.223372036854776E18d + "'", double5 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopOutset((double) 5);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertNotNull(unitType11);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        java.awt.Image image58 = null;
        xYPlot10.setBackgroundImage(image58);
        java.awt.Stroke stroke60 = xYPlot10.getRangeCrosshairStroke();
        java.lang.Object obj61 = xYPlot10.clone();
        xYPlot10.clearAnnotations();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setLowerBound(108.0d);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAxis0.equals(obj3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color6);
        java.awt.Paint paint8 = categoryAxis0.getAxisLinePaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj19 = numberAxis18.clone();
        numberAxis18.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer22);
        xYPlot23.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot23.getRangeAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj32 = numberAxis31.clone();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj35 = numberAxis34.clone();
        numberAxis34.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str42 = numberAxis41.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj45 = numberAxis44.clone();
        numberAxis44.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj51 = numberAxis50.clone();
        numberAxis50.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand54 = null;
        numberAxis50.setMarkerBand(markerAxisBand54);
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis50.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj59 = numberAxis58.clone();
        numberAxis58.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis58.setMarkerBand(markerAxisBand62);
        numberAxis58.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double72 = rectangleInsets70.extendHeight(1.0d);
        double double74 = rectangleInsets70.calculateRightOutset((double) (short) 100);
        double double76 = rectangleInsets70.calculateTopOutset((double) 5);
        double double77 = rectangleInsets70.getTop();
        numberAxis58.setLabelInsets(rectangleInsets70);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray79 = new org.jfree.chart.axis.ValueAxis[] { numberAxis41, numberAxis44, numberAxis50, numberAxis58 };
        xYPlot39.setDomainAxes(valueAxisArray79);
        java.awt.Stroke stroke81 = xYPlot39.getRangeGridlineStroke();
        xYPlot39.clearRangeMarkers();
        java.lang.String str83 = xYPlot39.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder84 = xYPlot39.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer86 = null;
        xYPlot39.setRenderer(7, xYItemRenderer86, true);
        org.jfree.chart.axis.AxisLocation axisLocation89 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation90 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation89, plotOrientation90);
        xYPlot39.setOrientation(plotOrientation90);
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation28, plotOrientation90);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo94 = null;
        try {
            org.jfree.chart.axis.AxisState axisState95 = categoryAxis0.draw(graphics2D9, 0.0d, rectangle2D11, rectangle2D12, rectangleEdge93, plotRenderingInfo94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 108.0d + "'", double72 == 108.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.0d + "'", double74 == 10.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 97.0d + "'", double76 == 97.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 97.0d + "'", double77 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray79);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertNotNull(datasetRenderingOrder84);
        org.junit.Assert.assertNotNull(axisLocation89);
        org.junit.Assert.assertNotNull(plotOrientation90);
        org.junit.Assert.assertNotNull(rectangleEdge91);
        org.junit.Assert.assertNotNull(rectangleEdge93);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        xYPlot10.setRenderer(7, xYItemRenderer57, true);
        java.util.List list60 = xYPlot10.getAnnotations();
        xYPlot10.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertNotNull(list60);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        dateAxis0.setRangeAboutValue((double) (-1.0f), (double) (short) 10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = dateAxis10.valueToJava2D((double) 5, rectangle2D13, rectangleEdge14);
        dateAxis10.setLabel("SortOrder.DESCENDING");
        org.jfree.chart.axis.Timeline timeline18 = dateAxis10.getTimeline();
        dateAxis0.setTimeline(timeline18);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(timeline18);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        dateAxis0.setLabelAngle(108.0d);
        java.awt.Shape shape4 = null;
        try {
            dateAxis0.setUpArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        xYPlot10.setBackgroundImageAlignment((int) (short) -1);
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot10.getDomainAxisLocation(6);
        java.lang.String str62 = axisLocation61.toString();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str62.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str59 = numberAxis54.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean61 = numberAxis54.equals((java.lang.Object) plotOrientation60);
        numberAxis54.setFixedDimension((double) 100L);
        numberAxis54.setUpperMargin((double) (-268));
        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis54, true);
        double double68 = xYPlot10.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone71 = dateAxis70.getTimeZone();
        org.jfree.data.Range range72 = dateAxis70.getRange();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        java.util.Date date74 = day73.getEnd();
        dateAxis70.setMaximumDate(date74);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone77 = dateAxis76.getTimeZone();
        org.jfree.data.Range range78 = dateAxis76.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date80 = dateAxis76.calculateLowestVisibleTickValue(dateTickUnit79);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone82 = dateAxis81.getTimeZone();
        org.jfree.data.Range range83 = dateAxis81.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date85 = dateAxis81.calculateLowestVisibleTickValue(dateTickUnit84);
        dateAxis76.setMinimumDate(date85);
        dateAxis70.setMinimumDate(date85);
        xYPlot10.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) dateAxis70, true);
        org.jfree.data.xy.XYDataset xYDataset91 = xYPlot10.getDataset(0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(dateTickUnit84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNull(xYDataset91);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        dateAxis0.setLabel("SortOrder.DESCENDING");
        org.jfree.chart.axis.Timeline timeline8 = dateAxis0.getTimeline();
        double double9 = dateAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        xYPlot10.setRenderer(7, xYItemRenderer57, true);
        java.util.List list60 = xYPlot10.getAnnotations();
        boolean boolean61 = xYPlot10.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertNotNull(list60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        java.lang.String str6 = dateAxis0.getLabelToolTip();
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis0.setTimeZone(timeZone8);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) 3);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj5 = dateAxis4.clone();
        dateAxis4.setLabelAngle(108.0d);
        boolean boolean8 = categoryAxis0.equals((java.lang.Object) 108.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.clearCategoryLabelToolTips();
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAxis0.equals(obj3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 10, (java.awt.Paint) color6);
        categoryAxis0.setUpperMargin((double) (short) -1);
        int int10 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        java.awt.Image image58 = null;
        xYPlot10.setBackgroundImage(image58);
        java.awt.Stroke stroke60 = xYPlot10.getRangeCrosshairStroke();
        int int61 = xYPlot10.getRangeAxisCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        org.jfree.chart.plot.Plot plot2 = dateAxis0.getPlot();
        java.awt.Font font3 = null;
        try {
            dateAxis0.setTickLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        categoryMarker60.setDrawAsLine(false);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        java.util.Date date65 = day64.getEnd();
        org.jfree.chart.ChartColor chartColor69 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color70 = chartColor69.darker();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day64, (java.awt.Paint) color70, stroke71);
        categoryMarker60.setKey((java.lang.Comparable) day64);
        java.awt.Paint paint74 = categoryMarker60.getLabelPaint();
        java.lang.String str75 = categoryMarker60.getLabel();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNull(str75);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.data.Range range5 = dateAxis3.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit6);
        java.util.Date date8 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit6);
        dateAxis0.setUpperMargin((double) 43629L);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        xYPlot10.setRenderer(7, xYItemRenderer57, true);
        java.util.List list60 = xYPlot10.getAnnotations();
        xYPlot10.clearRangeMarkers();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertNotNull(list60);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getEnd();
        org.jfree.chart.ChartColor chartColor74 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color75 = chartColor74.darker();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day69, (java.awt.Paint) color75, stroke76);
        boolean boolean78 = xYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = categoryMarker77.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker77.setLabelOffsetType(lengthAdjustmentType80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77, layer82);
        java.awt.Paint paint84 = null;
        categoryMarker77.setOutlinePaint(paint84);
        java.awt.Stroke stroke86 = categoryMarker77.getStroke();
        float float87 = categoryMarker77.getAlpha();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertTrue("'" + float87 + "' != '" + 1.0f + "'", float87 == 1.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int2 = color1.getBlue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color1, color3, color4 };
        java.awt.Color color6 = java.awt.Color.RED;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Stroke[] strokeArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Shape[] shapeArray11 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray5, paintArray7, strokeArray8, strokeArray10, shapeArray11);
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextFillPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        boolean boolean19 = defaultDrawingSupplier12.equals((java.lang.Object) (short) 10);
        try {
            java.awt.Paint paint20 = defaultDrawingSupplier12.getNextPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getEnd();
        org.jfree.chart.ChartColor chartColor74 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color75 = chartColor74.darker();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day69, (java.awt.Paint) color75, stroke76);
        boolean boolean78 = xYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = categoryMarker77.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker77.setLabelOffsetType(lengthAdjustmentType80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77, layer82);
        java.lang.String str84 = categoryMarker77.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = categoryMarker77.getLabelAnchor();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertNull(str84);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj15 = numberAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj18 = numberAxis17.clone();
        numberAxis17.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        xYPlot22.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color26 = java.awt.Color.GREEN;
        xYPlot22.setRangeGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot22.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj32 = numberAxis31.clone();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj35 = numberAxis34.clone();
        numberAxis34.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str42 = numberAxis41.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj45 = numberAxis44.clone();
        numberAxis44.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj51 = numberAxis50.clone();
        numberAxis50.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand54 = null;
        numberAxis50.setMarkerBand(markerAxisBand54);
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis50.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj59 = numberAxis58.clone();
        numberAxis58.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis58.setMarkerBand(markerAxisBand62);
        numberAxis58.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double72 = rectangleInsets70.extendHeight(1.0d);
        double double74 = rectangleInsets70.calculateRightOutset((double) (short) 100);
        double double76 = rectangleInsets70.calculateTopOutset((double) 5);
        double double77 = rectangleInsets70.getTop();
        numberAxis58.setLabelInsets(rectangleInsets70);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray79 = new org.jfree.chart.axis.ValueAxis[] { numberAxis41, numberAxis44, numberAxis50, numberAxis58 };
        xYPlot39.setDomainAxes(valueAxisArray79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
        java.util.Date date82 = day81.getEnd();
        org.jfree.chart.ChartColor chartColor86 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color87 = chartColor86.darker();
        java.awt.Stroke stroke88 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker89 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day81, (java.awt.Paint) color87, stroke88);
        boolean boolean90 = xYPlot39.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker89);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor91 = categoryMarker89.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType92 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker89.setLabelOffsetType(lengthAdjustmentType92);
        org.jfree.chart.util.Layer layer94 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot22.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker89, layer94);
        java.lang.Class<?> wildcardClass96 = layer94.getClass();
        java.util.Collection collection97 = xYPlot10.getDomainMarkers(8, layer94);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 108.0d + "'", double72 == 108.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.0d + "'", double74 == 10.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 97.0d + "'", double76 == 97.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 97.0d + "'", double77 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray79);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor91);
        org.junit.Assert.assertNotNull(lengthAdjustmentType92);
        org.junit.Assert.assertNotNull(layer94);
        org.junit.Assert.assertNotNull(wildcardClass96);
        org.junit.Assert.assertNull(collection97);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
        java.util.Date date64 = day63.getEnd();
        org.jfree.chart.ChartColor chartColor68 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color69 = chartColor68.darker();
        java.awt.Stroke stroke70 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker71 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day63, (java.awt.Paint) color69, stroke70);
        java.awt.Stroke stroke72 = categoryMarker71.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.Object obj74 = null;
        boolean boolean75 = rectangleAnchor73.equals(obj74);
        java.awt.Color color76 = java.awt.Color.cyan;
        boolean boolean77 = rectangleAnchor73.equals((java.lang.Object) color76);
        categoryMarker71.setLabelAnchor(rectangleAnchor73);
        org.jfree.chart.util.Layer layer79 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker(255, (org.jfree.chart.plot.Marker) categoryMarker71, layer79, true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(rectangleAnchor73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(layer79);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        categoryAxis0.setCategoryLabelPositionOffset((-65281));
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj11 = numberAxis10.clone();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj14 = numberAxis13.clone();
        numberAxis13.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer17);
        xYPlot18.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot18.getRangeAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj27 = numberAxis26.clone();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis29, xYItemRenderer33);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str37 = numberAxis36.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj40 = numberAxis39.clone();
        numberAxis39.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj46 = numberAxis45.clone();
        numberAxis45.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis45.setMarkerBand(markerAxisBand49);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = numberAxis45.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj54 = numberAxis53.clone();
        numberAxis53.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = null;
        numberAxis53.setMarkerBand(markerAxisBand57);
        numberAxis53.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double67 = rectangleInsets65.extendHeight(1.0d);
        double double69 = rectangleInsets65.calculateRightOutset((double) (short) 100);
        double double71 = rectangleInsets65.calculateTopOutset((double) 5);
        double double72 = rectangleInsets65.getTop();
        numberAxis53.setLabelInsets(rectangleInsets65);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray74 = new org.jfree.chart.axis.ValueAxis[] { numberAxis36, numberAxis39, numberAxis45, numberAxis53 };
        xYPlot34.setDomainAxes(valueAxisArray74);
        java.awt.Stroke stroke76 = xYPlot34.getRangeGridlineStroke();
        xYPlot34.clearRangeMarkers();
        java.lang.String str78 = xYPlot34.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder79 = xYPlot34.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer81 = null;
        xYPlot34.setRenderer(7, xYItemRenderer81, true);
        org.jfree.chart.axis.AxisLocation axisLocation84 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation85 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation84, plotOrientation85);
        xYPlot34.setOrientation(plotOrientation85);
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation23, plotOrientation85);
        try {
            java.util.List list89 = categoryAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 108.0d + "'", double67 == 108.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.0d + "'", double69 == 10.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 97.0d + "'", double71 == 97.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 97.0d + "'", double72 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(datasetRenderingOrder79);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(plotOrientation85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertNotNull(rectangleEdge88);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis56.configure();
        xYPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis56);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = xYPlot10.getAxisOffset();
        org.jfree.chart.event.PlotChangeListener plotChangeListener60 = null;
        xYPlot10.removeChangeListener(plotChangeListener60);
        java.awt.Stroke stroke62 = null;
        try {
            xYPlot10.setRangeZeroBaselineStroke(stroke62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(rectangleInsets59);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        boolean boolean14 = xYPlot10.isDomainCrosshairVisible();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot10.getDataset();
        java.awt.Stroke stroke16 = xYPlot10.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        int int76 = xYPlot32.getBackgroundImageAlignment();
        xYPlot32.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 15 + "'", int76 == 15);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.util.Date date2 = dateAxis0.getMaximumDate();
        double double3 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot10.setDomainAxisLocation(192, axisLocation53);
        java.awt.Paint paint55 = xYPlot10.getNoDataMessagePaint();
        java.awt.Font font56 = xYPlot10.getNoDataMessageFont();
        float float57 = xYPlot10.getForegroundAlpha();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 1.0f + "'", float57 == 1.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        boolean boolean10 = numberAxis1.equals((java.lang.Object) categoryAnchor9);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis4.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions5);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj15 = numberAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj18 = numberAxis17.clone();
        numberAxis17.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj27 = numberAxis26.clone();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis29, xYItemRenderer33);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str37 = numberAxis36.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj40 = numberAxis39.clone();
        numberAxis39.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj46 = numberAxis45.clone();
        numberAxis45.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis45.setMarkerBand(markerAxisBand49);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = numberAxis45.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj54 = numberAxis53.clone();
        numberAxis53.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = null;
        numberAxis53.setMarkerBand(markerAxisBand57);
        numberAxis53.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double67 = rectangleInsets65.extendHeight(1.0d);
        double double69 = rectangleInsets65.calculateRightOutset((double) (short) 100);
        double double71 = rectangleInsets65.calculateTopOutset((double) 5);
        double double72 = rectangleInsets65.getTop();
        numberAxis53.setLabelInsets(rectangleInsets65);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray74 = new org.jfree.chart.axis.ValueAxis[] { numberAxis36, numberAxis39, numberAxis45, numberAxis53 };
        xYPlot34.setDomainAxes(valueAxisArray74);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot34.setDomainAxisLocation(192, axisLocation77);
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot34.setRangeAxisLocation(axisLocation79);
        xYPlot22.setRangeAxisLocation((int) (short) 100, axisLocation79, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = xYPlot22.getDomainAxisEdge(6);
        try {
            double double85 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 15.0d, (java.lang.Comparable) 15.0d, categoryDataset9, (double) 9, rectangle2D11, rectangleEdge84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 108.0d + "'", double67 == 108.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.0d + "'", double69 == 10.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 97.0d + "'", double71 == 97.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 97.0d + "'", double72 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(rectangleEdge84);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str59 = numberAxis54.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean61 = numberAxis54.equals((java.lang.Object) plotOrientation60);
        numberAxis54.setFixedDimension((double) 100L);
        numberAxis54.setUpperMargin((double) (-268));
        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis54, true);
        double double68 = xYPlot10.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone71 = dateAxis70.getTimeZone();
        org.jfree.data.Range range72 = dateAxis70.getRange();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        java.util.Date date74 = day73.getEnd();
        dateAxis70.setMaximumDate(date74);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone77 = dateAxis76.getTimeZone();
        org.jfree.data.Range range78 = dateAxis76.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date80 = dateAxis76.calculateLowestVisibleTickValue(dateTickUnit79);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone82 = dateAxis81.getTimeZone();
        org.jfree.data.Range range83 = dateAxis81.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date85 = dateAxis81.calculateLowestVisibleTickValue(dateTickUnit84);
        dateAxis76.setMinimumDate(date85);
        dateAxis70.setMinimumDate(date85);
        xYPlot10.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) dateAxis70, true);
        boolean boolean90 = xYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation91 = xYPlot10.getOrientation();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(dateTickUnit84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(plotOrientation91);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color58 = chartColor57.darker();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day52, (java.awt.Paint) color58, stroke59);
        boolean boolean61 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        categoryMarker60.setDrawAsLine(false);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        java.util.Date date65 = day64.getEnd();
        org.jfree.chart.ChartColor chartColor69 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color70 = chartColor69.darker();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day64, (java.awt.Paint) color70, stroke71);
        categoryMarker60.setKey((java.lang.Comparable) day64);
        java.awt.Paint paint74 = null;
        categoryMarker60.setOutlinePaint(paint74);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent76 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker60);
        java.awt.Stroke stroke77 = categoryMarker60.getStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke77);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = null;
        xYPlot10.setBackgroundPaint(paint16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot10.handleClick(0, (int) (short) 1, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.java2DToValue(0.05d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        org.jfree.data.Range range8 = dateAxis6.getRange();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        org.jfree.data.Range range11 = dateAxis9.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date13 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit12);
        java.util.Date date14 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit12);
        dateAxis0.setMinimumDate(date14);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.223372036854776E18d + "'", double5 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING");
        categoryAxis0.setCategoryLabelPositionOffset((-65281));
        java.lang.Object obj5 = categoryAxis0.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        java.lang.String str6 = dateAxis0.getLabelToolTip();
        java.awt.Paint paint7 = dateAxis0.getAxisLinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        org.jfree.data.Range range10 = dateAxis8.getRange();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getEnd();
        dateAxis8.setMaximumDate(date12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis15.setMarkerBand(markerAxisBand19);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = numberAxis15.getStandardTickUnits();
        org.jfree.data.Range range22 = numberAxis15.getRange();
        dateAxis8.setRangeWithMargins(range22, false, true);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone27 = dateAxis26.getTimeZone();
        org.jfree.data.Range range28 = dateAxis26.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date30 = dateAxis26.calculateLowestVisibleTickValue(dateTickUnit29);
        java.util.Date date31 = dateAxis8.calculateLowestVisibleTickValue(dateTickUnit29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone33 = dateAxis32.getTimeZone();
        org.jfree.data.Range range34 = dateAxis32.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date36 = dateAxis32.calculateLowestVisibleTickValue(dateTickUnit35);
        java.util.Date date37 = dateAxis8.calculateLowestVisibleTickValue(dateTickUnit35);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone39 = dateAxis38.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = dateAxis38.valueToJava2D((double) 5, rectangle2D41, rectangleEdge42);
        dateAxis38.setRangeAboutValue((double) (-1.0f), (double) (short) 10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition47 = dateAxis38.getTickMarkPosition();
        dateAxis8.setTickMarkPosition(dateTickMarkPosition47);
        dateAxis0.setTickMarkPosition(dateTickMarkPosition47);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition47);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        xYPlot10.setBackgroundImageAlignment((int) (short) -1);
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot10.getDomainAxisLocation(6);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj64 = numberAxis63.clone();
        java.awt.Color color65 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis63.setLabelPaint((java.awt.Paint) color65);
        int int67 = color65.getAlpha();
        xYPlot10.setDomainGridlinePaint((java.awt.Paint) color65);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 255 + "'", int67 == 255);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setPositiveArrowVisible(false);
        numberAxis1.setUpperBound(111.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot10.getRangeAxisLocation(255);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot10.setSeriesRenderingOrder(seriesRenderingOrder16);
        java.awt.Paint paint18 = xYPlot10.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double6 = rectangleInsets4.extendHeight(1.0d);
        double double8 = rectangleInsets4.calculateRightOutset((double) (short) 100);
        double double10 = rectangleInsets4.calculateTopOutset((double) 5);
        double double11 = rectangleInsets4.getTop();
        double double13 = rectangleInsets4.calculateBottomInset((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            rectangleInsets4.trim(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.0d + "'", double6 == 108.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.0d + "'", double11 == 97.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset58 = xYPlot10.getDataset((int) (byte) 100);
        java.awt.Font font59 = xYPlot10.getNoDataMessageFont();
        java.awt.Stroke stroke60 = xYPlot10.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(xYDataset58);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        numberAxis1.setLabelPaint((java.awt.Paint) color3);
        float float5 = numberAxis1.getTickMarkInsideLength();
        boolean boolean6 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.data.RangeType rangeType7 = numberAxis1.getRangeType();
        numberAxis1.setLabelToolTip("");
        numberAxis1.resizeRange((double) (-268), (double) 100.0f);
        org.jfree.data.RangeType rangeType13 = numberAxis1.getRangeType();
        java.awt.Font font14 = numberAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        boolean boolean14 = xYPlot10.isDomainCrosshairVisible();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot10.getDataset();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot10.getDataset((int) (short) -1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNull(xYDataset17);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.java2DToValue(0.05d, rectangle2D3, rectangleEdge4);
        java.awt.Paint paint6 = dateAxis0.getTickMarkPaint();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.223372036854776E18d + "'", double5 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot10.getRangeAxisLocation(255);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj19 = numberAxis18.clone();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj32 = numberAxis31.clone();
        numberAxis31.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = null;
        numberAxis37.setMarkerBand(markerAxisBand41);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = numberAxis37.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj46 = numberAxis45.clone();
        numberAxis45.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis45.setMarkerBand(markerAxisBand49);
        numberAxis45.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double59 = rectangleInsets57.extendHeight(1.0d);
        double double61 = rectangleInsets57.calculateRightOutset((double) (short) 100);
        double double63 = rectangleInsets57.calculateTopOutset((double) 5);
        double double64 = rectangleInsets57.getTop();
        numberAxis45.setLabelInsets(rectangleInsets57);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { numberAxis28, numberAxis31, numberAxis37, numberAxis45 };
        xYPlot26.setDomainAxes(valueAxisArray66);
        java.awt.Stroke stroke68 = xYPlot26.getRangeGridlineStroke();
        xYPlot26.clearRangeMarkers();
        java.lang.String str70 = xYPlot26.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder71 = xYPlot26.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        xYPlot26.setRenderer(7, xYItemRenderer73, true);
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation77 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation76, plotOrientation77);
        xYPlot26.setOrientation(plotOrientation77);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation77);
        org.jfree.chart.plot.PlotOrientation plotOrientation81 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation81);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(tickUnitSource43);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 108.0d + "'", double59 == 108.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 97.0d + "'", double63 == 97.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(datasetRenderingOrder71);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(plotOrientation77);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(plotOrientation81);
        org.junit.Assert.assertNotNull(rectangleEdge82);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 15);
        double double3 = intervalMarker2.getEndValue();
        double double4 = intervalMarker2.getEndValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.0d + "'", double3 == 15.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 15.0d + "'", double4 == 15.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int2 = color1.getBlue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color1, color3, color4 };
        java.awt.Color color6 = java.awt.Color.RED;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color6 };
        java.awt.Stroke[] strokeArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Shape[] shapeArray11 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray5, paintArray7, strokeArray8, strokeArray10, shapeArray11);
        java.lang.Object obj13 = defaultDrawingSupplier12.clone();
        try {
            java.awt.Shape shape14 = defaultDrawingSupplier12.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis6.valueToJava2D((double) 5, rectangle2D9, rectangleEdge10);
        boolean boolean12 = dateAxis0.equals((java.lang.Object) rectangle2D9);
        org.jfree.data.Range range13 = dateAxis0.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.awt.Font font6 = numberAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        dateAxis0.setMaximumDate(date4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj8 = numberAxis7.clone();
        numberAxis7.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis7.setMarkerBand(markerAxisBand11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis7.getStandardTickUnits();
        org.jfree.data.Range range14 = numberAxis7.getRange();
        dateAxis0.setRangeWithMargins(range14, false, true);
        dateAxis0.setAutoRange(false);
        java.awt.Stroke stroke20 = dateAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        java.lang.String str6 = dateAxis0.getLabelToolTip();
        java.awt.Shape shape7 = dateAxis0.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        org.jfree.data.Range range10 = dateAxis8.getRange();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getEnd();
        dateAxis8.setMaximumDate(date12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis15.setMarkerBand(markerAxisBand19);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = numberAxis15.getStandardTickUnits();
        org.jfree.data.Range range22 = numberAxis15.getRange();
        dateAxis8.setRangeWithMargins(range22, false, true);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone27 = dateAxis26.getTimeZone();
        org.jfree.data.Range range28 = dateAxis26.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date30 = dateAxis26.calculateLowestVisibleTickValue(dateTickUnit29);
        java.util.Date date31 = dateAxis8.calculateLowestVisibleTickValue(dateTickUnit29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone33 = dateAxis32.getTimeZone();
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis32.setMinimumDate(date34);
        dateAxis0.setRange(date31, date34);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.valueToJava2D((double) 5, rectangle2D3, rectangleEdge4);
        dateAxis0.setLabel("SortOrder.DESCENDING");
        org.jfree.chart.axis.Timeline timeline8 = dateAxis0.getTimeline();
        boolean boolean9 = dateAxis0.isVisible();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) 3);
        categoryAxis0.clearCategoryLabelToolTips();
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str2.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color6 = chartColor5.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.Object obj11 = null;
        boolean boolean12 = rectangleAnchor10.equals(obj11);
        java.awt.Color color13 = java.awt.Color.cyan;
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) color13);
        categoryMarker8.setLabelAnchor(rectangleAnchor10);
        java.awt.Paint paint16 = categoryMarker8.getOutlinePaint();
        java.lang.String str17 = categoryMarker8.getLabel();
        java.awt.Stroke stroke18 = categoryMarker8.getOutlineStroke();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        boolean boolean76 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = xYPlot10.getRangeZeroBaselinePaint();
        xYPlot10.clearDomainMarkers(0);
        java.awt.Paint paint19 = xYPlot10.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) 3);
        categoryAxis0.configure();
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        java.lang.String str2 = unitType0.toString();
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean4 = unitType0.equals((java.lang.Object) strokeArray3);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.RELATIVE" + "'", str2.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = null;
        xYPlot10.setBackgroundPaint(paint16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot10.getRangeMarkers(0, layer19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot10.setRenderer(1, xYItemRenderer22, false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj55 = numberAxis54.clone();
        numberAxis54.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str59 = numberAxis54.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean61 = numberAxis54.equals((java.lang.Object) plotOrientation60);
        numberAxis54.setFixedDimension((double) 100L);
        numberAxis54.setUpperMargin((double) (-268));
        xYPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis54, true);
        double double68 = xYPlot10.getDomainCrosshairValue();
        java.awt.Paint paint69 = xYPlot10.getRangeCrosshairPaint();
        xYPlot10.setDomainCrosshairValue(0.0d, false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        int int76 = xYPlot32.getBackgroundImageAlignment();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent77 = null;
        xYPlot32.axisChanged(axisChangeEvent77);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 15 + "'", int76 == 15);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getEnd();
        org.jfree.chart.ChartColor chartColor74 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color75 = chartColor74.darker();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day69, (java.awt.Paint) color75, stroke76);
        boolean boolean78 = xYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = categoryMarker77.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker77.setLabelOffsetType(lengthAdjustmentType80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77, layer82);
        java.awt.Paint paint84 = null;
        categoryMarker77.setOutlinePaint(paint84);
        java.awt.Stroke stroke86 = categoryMarker77.getStroke();
        categoryMarker77.setLabel("AxisLocation.TOP_OR_RIGHT");
        categoryMarker77.setLabel("AxisLocation.TOP_OR_RIGHT");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertNotNull(stroke86);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        org.jfree.data.Range range7 = dateAxis5.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit8);
        dateAxis0.setMinimumDate(date9);
        dateAxis0.setRange((double) (-1), (double) 1L);
        org.jfree.chart.plot.Plot plot14 = dateAxis0.getPlot();
        dateAxis0.setNegativeArrowVisible(false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke17);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        xYPlot10.mapDatasetToRangeAxis((int) (byte) 100, (int) (byte) 0);
        java.awt.Color color14 = java.awt.Color.GREEN;
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj20 = numberAxis19.clone();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj33 = numberAxis32.clone();
        numberAxis32.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj39 = numberAxis38.clone();
        numberAxis38.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis38.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis38.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj47 = numberAxis46.clone();
        numberAxis46.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis46.setMarkerBand(markerAxisBand50);
        numberAxis46.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double60 = rectangleInsets58.extendHeight(1.0d);
        double double62 = rectangleInsets58.calculateRightOutset((double) (short) 100);
        double double64 = rectangleInsets58.calculateTopOutset((double) 5);
        double double65 = rectangleInsets58.getTop();
        numberAxis46.setLabelInsets(rectangleInsets58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, numberAxis32, numberAxis38, numberAxis46 };
        xYPlot27.setDomainAxes(valueAxisArray67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getEnd();
        org.jfree.chart.ChartColor chartColor74 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color75 = chartColor74.darker();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day69, (java.awt.Paint) color75, stroke76);
        boolean boolean78 = xYPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = categoryMarker77.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker77.setLabelOffsetType(lengthAdjustmentType80);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker77, layer82);
        xYPlot10.configureRangeAxes();
        xYPlot10.clearDomainMarkers();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.0d + "'", double60 == 108.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 97.0d + "'", double64 == 97.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 97.0d + "'", double65 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(layer82);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double15 = rectangleInsets13.extendHeight(1.0d);
        double double17 = rectangleInsets13.calculateRightOutset((double) (short) 100);
        double double19 = rectangleInsets13.calculateTopOutset((double) 5);
        double double20 = rectangleInsets13.getTop();
        numberAxis1.setLabelInsets(rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj25 = numberAxis24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj28 = numberAxis27.clone();
        numberAxis27.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj38 = numberAxis37.clone();
        numberAxis37.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj44 = numberAxis43.clone();
        numberAxis43.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis43.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = numberAxis43.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj52 = numberAxis51.clone();
        numberAxis51.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis51.setMarkerBand(markerAxisBand55);
        numberAxis51.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double65 = rectangleInsets63.extendHeight(1.0d);
        double double67 = rectangleInsets63.calculateRightOutset((double) (short) 100);
        double double69 = rectangleInsets63.calculateTopOutset((double) 5);
        double double70 = rectangleInsets63.getTop();
        numberAxis51.setLabelInsets(rectangleInsets63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis37, numberAxis43, numberAxis51 };
        xYPlot32.setDomainAxes(valueAxisArray72);
        java.awt.Stroke stroke74 = xYPlot32.getRangeGridlineStroke();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot32);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot32.setRangeAxisLocation((int) '4', axisLocation77, true);
        xYPlot32.setBackgroundAlpha((float) 5);
        org.jfree.chart.plot.Marker marker82 = null;
        boolean boolean83 = xYPlot32.removeDomainMarker(marker82);
        java.awt.Paint paint84 = null;
        xYPlot32.setDomainTickBandPaint(paint84);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 108.0d + "'", double15 == 108.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 97.0d + "'", double20 == 97.0d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 108.0d + "'", double65 == 108.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 10.0d + "'", double67 == 10.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 97.0d + "'", double69 == 97.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 97.0d + "'", double70 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        double double2 = numberAxis1.getLabelAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        numberAxis1.setTickLabelInsets(rectangleInsets7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getLeftArrow();
        numberAxis1.setLeftArrow(shape10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setRangeWithMargins((double) (byte) 0, (double) 10L);
        java.lang.String str6 = numberAxis1.getLabelURL();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean8 = numberAxis1.equals((java.lang.Object) plotOrientation7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.ChartColor chartColor15 = new org.jfree.chart.ChartColor(3, 0, (int) (short) 1);
        java.awt.Color color16 = chartColor15.darker();
        numberAxis1.setTickMarkPaint((java.awt.Paint) chartColor15);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        java.awt.Image image58 = null;
        xYPlot10.setBackgroundImage(image58);
        java.awt.Stroke stroke60 = xYPlot10.getRangeCrosshairStroke();
        java.awt.Color color62 = java.awt.Color.LIGHT_GRAY;
        xYPlot10.setQuadrantPaint(1, (java.awt.Paint) color62);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color62);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke57 = xYPlot10.getRangeZeroBaselineStroke();
        java.awt.Image image58 = null;
        xYPlot10.setBackgroundImage(image58);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder60 = xYPlot10.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(datasetRenderingOrder60);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        org.jfree.data.Range range2 = dateAxis0.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date4 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit3);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        java.lang.String str6 = dateAxis0.getLabelToolTip();
        java.util.Date date7 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj6 = numberAxis5.clone();
        numberAxis5.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj16 = numberAxis15.clone();
        numberAxis15.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj22 = numberAxis21.clone();
        numberAxis21.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis21.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis21.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj30 = numberAxis29.clone();
        numberAxis29.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis29.setMarkerBand(markerAxisBand33);
        numberAxis29.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double43 = rectangleInsets41.extendHeight(1.0d);
        double double45 = rectangleInsets41.calculateRightOutset((double) (short) 100);
        double double47 = rectangleInsets41.calculateTopOutset((double) 5);
        double double48 = rectangleInsets41.getTop();
        numberAxis29.setLabelInsets(rectangleInsets41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis21, numberAxis29 };
        xYPlot10.setDomainAxes(valueAxisArray50);
        java.awt.Stroke stroke52 = xYPlot10.getRangeGridlineStroke();
        xYPlot10.clearRangeMarkers();
        java.lang.String str54 = xYPlot10.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean56 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset58 = xYPlot10.getDataset((int) (byte) 100);
        java.awt.Image image59 = xYPlot10.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace60, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder63 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot10.setDatasetRenderingOrder(datasetRenderingOrder63);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 108.0d + "'", double43 == 108.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10.0d + "'", double45 == 10.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 97.0d + "'", double47 == 97.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(xYDataset58);
        org.junit.Assert.assertNull(image59);
        org.junit.Assert.assertNotNull(datasetRenderingOrder63);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getLeftArrow();
        java.text.DateFormat dateFormat2 = null;
        dateAxis0.setDateFormatOverride(dateFormat2);
        dateAxis0.resizeRange((double) 13, 100.0d);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj4 = numberAxis3.clone();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj7 = numberAxis6.clone();
        numberAxis6.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis6, xYItemRenderer10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str14 = numberAxis13.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj17 = numberAxis16.clone();
        numberAxis16.setRangeWithMargins((double) (byte) 0, (double) 10L);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj23 = numberAxis22.clone();
        numberAxis22.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis22.setMarkerBand(markerAxisBand26);
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = numberAxis22.getStandardTickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj31 = numberAxis30.clone();
        numberAxis30.setAxisLineVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis30.setMarkerBand(markerAxisBand34);
        numberAxis30.setAutoRangeStickyZero(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets((double) 'a', 100.0d, (double) 10.0f, (double) (short) 10);
        double double44 = rectangleInsets42.extendHeight(1.0d);
        double double46 = rectangleInsets42.calculateRightOutset((double) (short) 100);
        double double48 = rectangleInsets42.calculateTopOutset((double) 5);
        double double49 = rectangleInsets42.getTop();
        numberAxis30.setLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray51 = new org.jfree.chart.axis.ValueAxis[] { numberAxis13, numberAxis16, numberAxis22, numberAxis30 };
        xYPlot11.setDomainAxes(valueAxisArray51);
        java.awt.Stroke stroke53 = xYPlot11.getRangeGridlineStroke();
        xYPlot11.clearRangeMarkers();
        java.lang.String str55 = xYPlot11.getNoDataMessage();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder56 = xYPlot11.getDatasetRenderingOrder();
        boolean boolean57 = xYPlot11.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke58 = xYPlot11.getRangeZeroBaselineStroke();
        java.awt.Image image59 = null;
        xYPlot11.setBackgroundImage(image59);
        java.awt.Paint[] paintArray61 = null;
        java.awt.Color color62 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int63 = color62.getBlue();
        java.awt.Color color64 = java.awt.Color.WHITE;
        java.awt.Color color65 = java.awt.Color.RED;
        java.awt.Paint[] paintArray66 = new java.awt.Paint[] { color62, color64, color65 };
        java.awt.Color color67 = java.awt.Color.RED;
        java.awt.Paint[] paintArray68 = new java.awt.Paint[] { color67 };
        java.awt.Stroke[] strokeArray69 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke70 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray71 = new java.awt.Stroke[] { stroke70 };
        java.awt.Shape[] shapeArray72 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier73 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray61, paintArray66, paintArray68, strokeArray69, strokeArray71, shapeArray72);
        boolean boolean74 = xYPlot11.equals((java.lang.Object) paintArray68);
        java.awt.Stroke[] strokeArray75 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray76 = null;
        java.awt.Shape[] shapeArray77 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier78 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray68, strokeArray75, strokeArray76, shapeArray77);
        java.awt.Paint paint79 = defaultDrawingSupplier78.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 108.0d + "'", double44 == 108.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.0d + "'", double46 == 10.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 97.0d + "'", double48 == 97.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 97.0d + "'", double49 == 97.0d);
        org.junit.Assert.assertNotNull(valueAxisArray51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(datasetRenderingOrder56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 192 + "'", int63 == 192);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(paintArray66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(paintArray68);
        org.junit.Assert.assertNotNull(strokeArray69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(strokeArray71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(strokeArray75);
        org.junit.Assert.assertNotNull(shapeArray77);
        org.junit.Assert.assertNotNull(paint79);
    }
}

