import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1560409200000L);
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        boolean boolean4 = spreadsheetDate1.isOn(serialDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek((int) (short) 1);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        java.lang.String str12 = serialDate11.getDescription();
        boolean boolean13 = spreadsheetDate1.isOn(serialDate11);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test03");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, class19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = timeSeries20.equals(obj23);
//        java.util.Collection collection25 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getLastMillisecond();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long27, class28);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.addChangeListener(seriesChangeListener30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long33, class34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) (byte) 10);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) day41);
//        long long43 = timeSeries29.getMaximumItemAge();
//        java.util.Collection collection44 = timeSeries29.getTimePeriods();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        long long46 = month45.getFirstMillisecond();
//        org.jfree.data.time.Year year47 = month45.getYear();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, number48);
//        java.util.Collection collection50 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560495599999L + "'", long27 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1559372400000L + "'", long46 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(collection50);
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.util.Date date6 = spreadsheetDate5.toDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek((int) (short) 1);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(4, serialDate13);
        boolean boolean16 = spreadsheetDate5.isBefore(serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        boolean boolean21 = spreadsheetDate18.isOn(serialDate20);
        boolean boolean22 = spreadsheetDate2.isInRange(serialDate13, serialDate20);
        int int23 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj26 = null;
        boolean boolean27 = spreadsheetDate25.equals(obj26);
        java.lang.Class<?> wildcardClass28 = spreadsheetDate25.getClass();
        boolean boolean29 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate30);
    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test05");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = timeSeries3.equals(obj6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.lang.Number number11 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
//        java.util.Calendar calendar12 = null;
//        try {
//            month10.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(number11);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(5, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "May" + "'", str2.equals("May"));
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test07");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.String str11 = day9.toString();
//        timeSeries3.setKey((java.lang.Comparable) str11);
//        java.lang.String str13 = timeSeries3.getDomainDescription();
//        timeSeries3.fireSeriesChanged();
//        java.lang.Object obj15 = timeSeries3.clone();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getLastMillisecond();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long21, class22);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries23.addChangeListener(seriesChangeListener24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getLastMillisecond();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long27, class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (double) (byte) 10);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) day35);
//        int int37 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) day35);
//        timeSeries19.setDomainDescription("");
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = null;
//        java.lang.Number number42 = null;
//        try {
//            timeSeries3.update(regularTimePeriod41, number42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560495599999L + "'", long27 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(collection40);
//    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long16, class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) (byte) 10);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) day24);
//        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 10.0f);
//        boolean boolean33 = timeSeriesDataItem29.equals((java.lang.Object) day30);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day30.equals(obj34);
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, number36);
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        long long39 = day30.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560409200000L + "'", long39 == 1560409200000L);
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj2 = null;
        boolean boolean3 = spreadsheetDate1.equals(obj2);
        java.lang.Class<?> wildcardClass4 = spreadsheetDate1.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj7 = null;
        boolean boolean8 = spreadsheetDate6.equals(obj7);
        int int9 = spreadsheetDate6.getYYYY();
        java.util.Date date10 = spreadsheetDate6.toDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 10.0f);
        boolean boolean15 = timeSeriesDataItem13.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem13.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem13.getPeriod();
        java.util.Date date18 = regularTimePeriod17.getStart();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod22);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        seriesException9.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException4.addSuppressed((java.lang.Throwable) seriesException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek((int) (short) 1);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears(4, serialDate12);
        boolean boolean15 = spreadsheetDate4.isBefore(serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        boolean boolean20 = spreadsheetDate17.isOn(serialDate19);
        boolean boolean21 = spreadsheetDate1.isInRange(serialDate12, serialDate19);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate1.getFollowingDayOfWeek(6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        boolean boolean26 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 10.0f);
        boolean boolean6 = timeSeriesDataItem2.equals((java.lang.Object) day3);
        java.lang.Object obj7 = null;
        boolean boolean8 = day3.equals(obj7);
        boolean boolean10 = day3.equals((java.lang.Object) (byte) 10);
        int int12 = day3.compareTo((java.lang.Object) 100.0f);
        java.util.Date date13 = day3.getEnd();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test14");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Number number4 = timeSeriesDataItem2.getValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
//        int int9 = fixedMillisecond5.compareTo((java.lang.Object) 1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond5.next();
//        int int11 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond5);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560441592932L + "'", long7 == 1560441592932L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("May");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        java.lang.String str4 = timeSeries3.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        long long8 = month7.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = month7.getYear();
//        long long10 = month7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month7.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month7);
//        java.lang.String str13 = timeSeries3.getDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str13);
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "", "Time", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, class7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries8.addChangeListener(seriesChangeListener9);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries8.equals(obj11);
//        int int13 = timeSeries8.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries8.addChangeListener(seriesChangeListener14);
//        java.util.Collection collection16 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        timeSeries4.setDomainDescription("June 2019");
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(collection16);
//    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.String str11 = day9.toString();
//        timeSeries3.setKey((java.lang.Comparable) str11);
//        java.lang.String str13 = timeSeries3.getDomainDescription();
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.util.Date date16 = month15.getEnd();
//        long long17 = month15.getLastMillisecond();
//        int int18 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        java.util.Date date19 = month15.getStart();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        boolean boolean24 = spreadsheetDate21.isOn(serialDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        java.lang.Object obj27 = null;
//        boolean boolean28 = spreadsheetDate26.equals(obj27);
//        int int29 = spreadsheetDate26.getYYYY();
//        boolean boolean30 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        int int31 = spreadsheetDate21.getMonth();
//        boolean boolean32 = month15.equals((java.lang.Object) spreadsheetDate21);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test19");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        long long17 = timeSeries3.getMaximumItemAge();
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        boolean boolean25 = timeSeriesDataItem21.equals((java.lang.Object) day22);
//        java.lang.Object obj26 = null;
//        boolean boolean27 = day22.equals(obj26);
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, number28);
//        timeSeriesDataItem29.setValue((java.lang.Number) 10L);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long33, class34);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long39, class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (double) (byte) 10);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        long long50 = day49.getLastMillisecond();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long50, class51);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries52.addChangeListener(seriesChangeListener53);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = timeSeries52.equals(obj55);
//        java.util.Collection collection57 = timeSeries48.getTimePeriodsUniqueToOtherSeries(timeSeries52);
//        int int58 = timeSeriesDataItem29.compareTo((java.lang.Object) timeSeries48);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries3.addAndOrUpdate(timeSeries48);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        long long61 = month60.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month60, (double) 1900);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560495599999L + "'", long50 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(collection57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 24234L + "'", long61 == 24234L);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.String str2 = month1.toString();
        org.jfree.data.time.Year year3 = month1.getYear();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 10, year3);
        long long5 = year3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = timeSeries3.equals(obj6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        java.util.Date date13 = day10.getEnd();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.util.Date date15 = month14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15, timeZone16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date13, timeZone16);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date13);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.addOrUpdate(regularTimePeriod21, (java.lang.Number) 2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            year3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test23");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long16, class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) (byte) 10);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) day24);
//        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.util.Collection collection27 = timeSeries12.getTimePeriods();
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries12.removePropertyChangeListener(propertyChangeListener28);
//        timeSeries12.setNotify(false);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertNotNull(collection27);
//    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 10.0f);
        java.util.Date date5 = day2.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: hi!", class9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesException: ERROR : Relative To String", class9);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(inputStream10);
        org.junit.Assert.assertNull(uRL11);
    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test25");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5, class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 10);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day14, (org.jfree.data.time.RegularTimePeriod) day19);
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day19);
//        timeSeries3.setDomainDescription("");
//        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test26");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, class5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (double) (byte) 10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long13, class14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getLastMillisecond();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long19, class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (byte) 10);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day27);
//        java.util.Collection collection29 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 10.0f);
//        boolean boolean36 = timeSeriesDataItem32.equals((java.lang.Object) day33);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = day33.equals(obj37);
//        java.lang.Number number39 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, number39);
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day33);
//        int int42 = fixedMillisecond0.compareTo((java.lang.Object) day33);
//        org.jfree.data.time.SerialDate serialDate43 = day33.getSerialDate();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray47 = timePeriodFormatException46.getSuppressed();
//        java.lang.Class<?> wildcardClass48 = throwableArray47.getClass();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        long long50 = day49.getLastMillisecond();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long50, class51);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries52.addChangeListener(seriesChangeListener53);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = timeSeries52.equals(obj55);
//        java.beans.PropertyChangeListener propertyChangeListener57 = null;
//        timeSeries52.addPropertyChangeListener(propertyChangeListener57);
//        java.lang.Class<?> wildcardClass59 = timeSeries52.getClass();
//        timeSeries52.setKey((java.lang.Comparable) 1560452399999L);
//        timeSeries52.clear();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day63, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day66, (java.lang.Number) 10.0f);
//        boolean boolean69 = timeSeriesDataItem65.equals((java.lang.Object) day66);
//        java.lang.Object obj70 = null;
//        boolean boolean71 = day66.equals(obj70);
//        java.lang.Number number72 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day66, number72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = timeSeriesDataItem73.getPeriod();
//        timeSeries52.delete(regularTimePeriod74);
//        java.lang.Class<?> wildcardClass76 = regularTimePeriod74.getClass();
//        java.lang.Object obj77 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass48, (java.lang.Class) wildcardClass76);
//        boolean boolean78 = day33.equals((java.lang.Object) wildcardClass48);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441594196L + "'", long2 == 1560441594196L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(throwableArray47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560495599999L + "'", long50 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(wildcardClass76);
//        org.junit.Assert.assertNull(obj77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) (short) 1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        java.lang.String str7 = serialDate6.getDescription();
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek((int) (byte) 1);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test28");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond1.peg(calendar2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond1.peg(calendar4);
//        int int7 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long9, class10);
//        java.lang.String str12 = timeSeries11.getDescription();
//        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) timeSeries11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long15, class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) (byte) 10);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        java.lang.String str25 = day23.toString();
//        timeSeries17.setKey((java.lang.Comparable) str25);
//        java.lang.String str27 = timeSeries17.getDomainDescription();
//        timeSeries17.fireSeriesChanged();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        java.util.Date date30 = month29.getEnd();
//        long long31 = month29.getLastMillisecond();
//        int int32 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month29);
//        boolean boolean33 = timeSeries11.equals((java.lang.Object) month29);
//        timeSeries11.setDescription("");
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 10.0f);
//        boolean boolean40 = timeSeriesDataItem38.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem38.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeriesDataItem38.getPeriod();
//        java.util.Date date43 = regularTimePeriod42.getStart();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43, timeZone45);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date43);
//        int int48 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month47);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass6 = throwableArray5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 31, "", "June 2019", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test32");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getEnd();
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long9, class10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries11.addChangeListener(seriesChangeListener12);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = timeSeries11.equals(obj14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener16);
//        java.lang.Class<?> wildcardClass18 = timeSeries11.getClass();
//        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "Value", "", (java.lang.Class) wildcardClass18);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNull(uRL19);
//    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test33");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5, class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = timeSeries7.equals(obj10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener12);
//        java.lang.Class<?> wildcardClass14 = timeSeries7.getClass();
//        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass14);
//        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 10.0f);
//        boolean boolean21 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem19.getPeriod();
//        java.util.Date date24 = regularTimePeriod23.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 10.0f);
//        boolean boolean30 = timeSeriesDataItem28.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem28.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem28.getPeriod();
//        java.util.Date date33 = regularTimePeriod32.getStart();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date24, timeZone35);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        java.lang.String str39 = month38.toString();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 10.0f);
//        java.util.Date date43 = day40.getEnd();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        java.util.Date date45 = month44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date45, timeZone46);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date43, timeZone46);
//        boolean boolean49 = month38.equals((java.lang.Object) timeZone46);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date24, timeZone46);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date1, timeZone46);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        java.lang.String str53 = month52.toString();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day54, (java.lang.Number) 10.0f);
//        java.util.Date date57 = day54.getEnd();
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
//        java.util.Date date59 = month58.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date59, timeZone60);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date57, timeZone60);
//        boolean boolean63 = month52.equals((java.lang.Object) timeZone60);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date1, timeZone60);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(uRL15);
//        org.junit.Assert.assertNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "June 2019" + "'", str53.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        int int7 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        java.util.Date date9 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test35");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 10.0f);
//        boolean boolean6 = timeSeriesDataItem2.equals((java.lang.Object) day3);
//        java.lang.Object obj7 = null;
//        boolean boolean8 = day3.equals(obj7);
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, number9);
//        long long11 = day3.getLastMillisecond();
//        java.lang.String str12 = day3.toString();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day3.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test37");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, class19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = timeSeries20.equals(obj23);
//        java.util.Collection collection25 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        java.util.Collection collection26 = timeSeries20.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNotNull(collection26);
//    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test39");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        boolean boolean4 = spreadsheetDate1.isOn(serialDate3);
//        int int5 = spreadsheetDate1.toSerial();
//        int int6 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = timeSeries12.equals(obj15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener17);
//        java.lang.Class<?> wildcardClass19 = timeSeries12.getClass();
//        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass19);
//        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", (java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass19);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNull(uRL20);
//        org.junit.Assert.assertNull(inputStream21);
//    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test40");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        long long17 = timeSeries3.getMaximumItemAge();
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        boolean boolean25 = timeSeriesDataItem21.equals((java.lang.Object) day22);
//        java.lang.Object obj26 = null;
//        boolean boolean27 = day22.equals(obj26);
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, number28);
//        timeSeriesDataItem29.setValue((java.lang.Number) 10L);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long33, class34);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long39, class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (double) (byte) 10);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        long long50 = day49.getLastMillisecond();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long50, class51);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries52.addChangeListener(seriesChangeListener53);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = timeSeries52.equals(obj55);
//        java.util.Collection collection57 = timeSeries48.getTimePeriodsUniqueToOtherSeries(timeSeries52);
//        int int58 = timeSeriesDataItem29.compareTo((java.lang.Object) timeSeries48);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries3.addAndOrUpdate(timeSeries48);
//        boolean boolean60 = timeSeries48.isEmpty();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560495599999L + "'", long50 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(collection57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test41");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long16, class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) (byte) 10);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) day24);
//        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 10.0f);
//        boolean boolean33 = timeSeriesDataItem29.equals((java.lang.Object) day30);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day30.equals(obj34);
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, number36);
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        java.util.Calendar calendar39 = null;
//        try {
//            long long40 = day30.getLastMillisecond(calendar39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test42");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.String str11 = day9.toString();
//        timeSeries3.setKey((java.lang.Comparable) str11);
//        java.lang.String str13 = timeSeries3.getDomainDescription();
//        timeSeries3.fireSeriesChanged();
//        java.lang.Object obj15 = timeSeries3.clone();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getLastMillisecond();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long21, class22);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries23.addChangeListener(seriesChangeListener24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getLastMillisecond();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long27, class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (double) (byte) 10);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) day35);
//        int int37 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) day35);
//        timeSeries19.setDomainDescription("");
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        timeSeries19.setDescription("ERROR : Relative To String");
//        java.lang.String str43 = timeSeries19.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(10L);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        long long47 = day46.getLastMillisecond();
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long47, class48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day50, (double) (byte) 10);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        long long56 = day55.getLastMillisecond();
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long56, class57);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries58.addChangeListener(seriesChangeListener59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        long long62 = day61.getLastMillisecond();
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long62, class63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day65, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day65, (double) (byte) 10);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) day65, (org.jfree.data.time.RegularTimePeriod) day70);
//        java.util.Collection collection72 = timeSeries49.getTimePeriodsUniqueToOtherSeries(timeSeries58);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar75 = null;
//        fixedMillisecond74.peg(calendar75);
//        java.util.Calendar calendar77 = null;
//        fixedMillisecond74.peg(calendar77);
//        int int80 = fixedMillisecond74.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (double) 1559372400000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = timeSeries49.getNextTimePeriod();
//        boolean boolean84 = fixedMillisecond45.equals((java.lang.Object) regularTimePeriod83);
//        try {
//            timeSeries19.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (java.lang.Number) 1561964399999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560495599999L + "'", long27 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ERROR : Relative To String" + "'", str43.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560495599999L + "'", long47 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560495599999L + "'", long56 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560495599999L + "'", long62 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//        org.junit.Assert.assertNotNull(timeSeries71);
//        org.junit.Assert.assertNotNull(collection72);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test43");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long16, class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) (byte) 10);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) day24);
//        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar29 = null;
//        fixedMillisecond28.peg(calendar29);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        int int34 = fixedMillisecond28.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1559372400000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries3.getNextTimePeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod37, (java.lang.Number) 7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 10.0f);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 10.0f);
        boolean boolean12 = timeSeriesDataItem8.equals((java.lang.Object) day9);
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) timeSeriesDataItem8);
        timeSeriesDataItem8.setValue((java.lang.Number) 1560441570099L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond1.peg(calendar10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

//    @Test
//    public void test46() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test46");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond1.peg(calendar2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond1.peg(calendar4);
//        int int7 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long9, class10);
//        java.lang.String str12 = timeSeries11.getDescription();
//        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) timeSeries11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getLastMillisecond();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long15, class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) (byte) 10);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        java.lang.String str25 = day23.toString();
//        timeSeries17.setKey((java.lang.Comparable) str25);
//        java.lang.String str27 = timeSeries17.getDomainDescription();
//        timeSeries17.fireSeriesChanged();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        java.util.Date date30 = month29.getEnd();
//        long long31 = month29.getLastMillisecond();
//        int int32 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month29);
//        boolean boolean33 = timeSeries11.equals((java.lang.Object) month29);
//        timeSeries11.clear();
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test47");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = timeSeries3.equals(obj6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond11.peg(calendar12);
//        long long14 = fixedMillisecond11.getMiddleMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond11.getMiddleMillisecond(calendar15);
//        try {
//            timeSeries3.setKey((java.lang.Comparable) calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
//    }

//    @Test
//    public void test48() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test48");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.String str11 = day9.toString();
//        timeSeries3.setKey((java.lang.Comparable) str11);
//        java.lang.Object obj13 = timeSeries3.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries3.getNextTimePeriod();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Wed Dec 31 15:59:59 PST 1969");
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test51");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem2.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem2.getPeriod();
//        java.util.Date date7 = regularTimePeriod6.getStart();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getFirstMillisecond();
//        org.jfree.data.time.Year year11 = month9.getYear();
//        int int12 = year11.getYear();
//        int int14 = year11.compareTo((java.lang.Object) 10L);
//        java.lang.Class<?> wildcardClass15 = year11.getClass();
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("June 2019", (java.lang.Class) wildcardClass15);
//        java.util.Date date17 = null;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getLastMillisecond();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long21, class22);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries23.addChangeListener(seriesChangeListener24);
//        java.lang.Object obj26 = null;
//        boolean boolean27 = timeSeries23.equals(obj26);
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries23.addPropertyChangeListener(propertyChangeListener28);
//        java.lang.Class<?> wildcardClass30 = timeSeries23.getClass();
//        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass30);
//        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 10.0f);
//        boolean boolean37 = timeSeriesDataItem35.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeriesDataItem35.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem35.getPeriod();
//        java.util.Date date40 = regularTimePeriod39.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 10.0f);
//        boolean boolean46 = timeSeriesDataItem44.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = timeSeriesDataItem44.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = timeSeriesDataItem44.getPeriod();
//        java.util.Date date49 = regularTimePeriod48.getStart();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date49, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date40, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date17, timeZone51);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date7, timeZone51);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNull(inputStream16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(uRL31);
//        org.junit.Assert.assertNull(obj32);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem2.getPeriod();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        java.lang.Object obj7 = null;
        int int8 = timeSeriesDataItem2.compareTo(obj7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test53() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test53");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries3.addChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries3.addChangeListener(seriesChangeListener21);
//        try {
//            java.lang.Number number24 = timeSeries3.getValue((int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        boolean boolean4 = year2.equals((java.lang.Object) 4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj7 = null;
        boolean boolean8 = spreadsheetDate6.equals(obj7);
        int int9 = spreadsheetDate6.getYYYY();
        java.lang.String str10 = spreadsheetDate6.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate6.getPreviousDayOfWeek(5);
        int int13 = year2.compareTo((java.lang.Object) 5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9999, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test56() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test56");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, class5);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) (byte) 10);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day13, (org.jfree.data.time.RegularTimePeriod) day18);
//        int int20 = month0.compareTo((java.lang.Object) day18);
//        java.util.Calendar calendar21 = null;
//        try {
//            month0.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

//    @Test
//    public void test57() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test57");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getLastMillisecond();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, class4);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries5.addChangeListener(seriesChangeListener6);
//        java.lang.Object obj8 = null;
//        boolean boolean9 = timeSeries5.equals(obj8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener10);
//        java.lang.Class<?> wildcardClass12 = timeSeries5.getClass();
//        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass12);
//        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 10.0f);
//        boolean boolean19 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem17.getPeriod();
//        java.util.Date date22 = regularTimePeriod21.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 10.0f);
//        boolean boolean28 = timeSeriesDataItem26.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeriesDataItem26.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem26.getPeriod();
//        java.util.Date date31 = regularTimePeriod30.getStart();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date31, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone33);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        java.lang.String str37 = month36.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) 10.0f);
//        java.util.Date date41 = day38.getEnd();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        java.util.Date date43 = month42.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date43, timeZone44);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date41, timeZone44);
//        boolean boolean47 = month36.equals((java.lang.Object) timeZone44);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date22, timeZone44);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        long long50 = day49.getLastMillisecond();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long50, class51);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries52.addChangeListener(seriesChangeListener53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        long long56 = day55.getLastMillisecond();
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long56, class57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (double) (byte) 10);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) day59, (org.jfree.data.time.RegularTimePeriod) day64);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        long long67 = day66.getLastMillisecond();
//        java.lang.Class class68 = null;
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long67, class68);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener70 = null;
//        timeSeries69.addChangeListener(seriesChangeListener70);
//        java.lang.Object obj72 = null;
//        boolean boolean73 = timeSeries69.equals(obj72);
//        java.util.Collection collection74 = timeSeries65.getTimePeriodsUniqueToOtherSeries(timeSeries69);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day75, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day78, (java.lang.Number) 10.0f);
//        boolean boolean81 = timeSeriesDataItem77.equals((java.lang.Object) day78);
//        java.lang.Object obj82 = null;
//        boolean boolean83 = day78.equals(obj82);
//        int int84 = timeSeries65.getIndex((org.jfree.data.time.RegularTimePeriod) day78);
//        timeSeries65.setNotify(false);
//        boolean boolean87 = year48.equals((java.lang.Object) false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(uRL13);
//        org.junit.Assert.assertNull(obj14);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560495599999L + "'", long50 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560495599999L + "'", long56 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560495599999L + "'", long67 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(collection74);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test58");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5, class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = timeSeries7.equals(obj10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener12);
//        java.lang.Class<?> wildcardClass14 = timeSeries7.getClass();
//        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass14);
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", (java.lang.Class) wildcardClass14);
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass14);
//        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: ERROR : Relative To String", (java.lang.Class) wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(uRL15);
//        org.junit.Assert.assertNull(inputStream16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertNull(inputStream18);
//    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj3 = null;
        boolean boolean4 = spreadsheetDate2.equals(obj3);
        int int5 = spreadsheetDate2.getYYYY();
        java.lang.String str6 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        boolean boolean11 = spreadsheetDate8.isOn(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj14 = null;
        boolean boolean15 = spreadsheetDate13.equals(obj14);
        int int16 = spreadsheetDate13.getYYYY();
        boolean boolean17 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean18 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str20 = serialDate19.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6-April-1900" + "'", str20.equals("6-April-1900"));
    }

//    @Test
//    public void test60() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test60");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 10.0f);
//        boolean boolean6 = timeSeriesDataItem2.equals((java.lang.Object) day3);
//        java.lang.Object obj7 = null;
//        boolean boolean8 = day3.equals(obj7);
//        long long9 = day3.getMiddleMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            day3.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560452399999L + "'", long9 == 1560452399999L);
//    }

//    @Test
//    public void test61() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test61");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getLastMillisecond();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, class4);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries5.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long9, class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 10);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day12, (org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getLastMillisecond();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long20, class21);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries22.addChangeListener(seriesChangeListener23);
//        java.lang.Object obj25 = null;
//        boolean boolean26 = timeSeries22.equals(obj25);
//        java.util.Collection collection27 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries22);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 10.0f);
//        boolean boolean34 = timeSeriesDataItem30.equals((java.lang.Object) day31);
//        java.lang.Object obj35 = null;
//        boolean boolean36 = day31.equals(obj35);
//        int int37 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar40 = null;
//        fixedMillisecond39.peg(calendar40);
//        long long42 = fixedMillisecond39.getMiddleMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond39.getFirstMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond39.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 0.0d);
//        java.util.Calendar calendar48 = null;
//        fixedMillisecond39.peg(calendar48);
//        boolean boolean50 = month0.equals((java.lang.Object) fixedMillisecond39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 1560441533502L);
//        long long53 = fixedMillisecond39.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560495599999L + "'", long20 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-1L) + "'", long53 == (-1L));
//    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 1560441547150L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem2.getPeriod();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day8.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        int int7 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        java.util.Date date9 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) date9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test65() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test65");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        long long17 = timeSeries3.getMaximumItemAge();
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        boolean boolean25 = timeSeriesDataItem21.equals((java.lang.Object) day22);
//        java.lang.Object obj26 = null;
//        boolean boolean27 = day22.equals(obj26);
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, number28);
//        timeSeriesDataItem29.setValue((java.lang.Number) 10L);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long33, class34);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long39, class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (double) (byte) 10);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        long long50 = day49.getLastMillisecond();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long50, class51);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries52.addChangeListener(seriesChangeListener53);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = timeSeries52.equals(obj55);
//        java.util.Collection collection57 = timeSeries48.getTimePeriodsUniqueToOtherSeries(timeSeries52);
//        int int58 = timeSeriesDataItem29.compareTo((java.lang.Object) timeSeries48);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries3.addAndOrUpdate(timeSeries48);
//        int int60 = timeSeries48.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560495599999L + "'", long50 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(collection57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
//    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.util.Date date2 = spreadsheetDate1.toDate();
        int int3 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
    }

//    @Test
//    public void test67() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test67");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, class5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (double) (byte) 10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long13, class14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getLastMillisecond();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long19, class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (byte) 10);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) day27);
//        java.util.Collection collection29 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 10.0f);
//        boolean boolean36 = timeSeriesDataItem32.equals((java.lang.Object) day33);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = day33.equals(obj37);
//        java.lang.Number number39 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, number39);
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day33);
//        int int42 = fixedMillisecond0.compareTo((java.lang.Object) day33);
//        int int43 = day33.getMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441601708L + "'", long2 == 1560441601708L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//    }

//    @Test
//    public void test68() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test68");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        long long17 = timeSeries3.getMaximumItemAge();
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        boolean boolean25 = timeSeriesDataItem21.equals((java.lang.Object) day22);
//        java.lang.Object obj26 = null;
//        boolean boolean27 = day22.equals(obj26);
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, number28);
//        timeSeriesDataItem29.setValue((java.lang.Number) 10L);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long33, class34);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getLastMillisecond();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long39, class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (double) (byte) 10);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        long long50 = day49.getLastMillisecond();
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long50, class51);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries52.addChangeListener(seriesChangeListener53);
//        java.lang.Object obj55 = null;
//        boolean boolean56 = timeSeries52.equals(obj55);
//        java.util.Collection collection57 = timeSeries48.getTimePeriodsUniqueToOtherSeries(timeSeries52);
//        int int58 = timeSeriesDataItem29.compareTo((java.lang.Object) timeSeries48);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries3.addAndOrUpdate(timeSeries48);
//        timeSeries48.setMaximumItemCount(3);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
//        long long63 = month62.getFirstMillisecond();
//        org.jfree.data.time.Year year64 = month62.getYear();
//        long long65 = month62.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month62.previous();
//        timeSeries48.setKey((java.lang.Comparable) month62);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560495599999L + "'", long50 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(collection57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1559372400000L + "'", long63 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//    }

//    @Test
//    public void test69() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test69");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate1);
//        int int5 = day4.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
//        java.lang.Class<?> wildcardClass11 = throwableArray10.getClass();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long13, class14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.addChangeListener(seriesChangeListener16);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = timeSeries15.equals(obj18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        java.lang.Class<?> wildcardClass22 = timeSeries15.getClass();
//        timeSeries15.setKey((java.lang.Comparable) 1560452399999L);
//        timeSeries15.clear();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 10.0f);
//        boolean boolean32 = timeSeriesDataItem28.equals((java.lang.Object) day29);
//        java.lang.Object obj33 = null;
//        boolean boolean34 = day29.equals(obj33);
//        java.lang.Number number35 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, number35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
//        timeSeries15.delete(regularTimePeriod37);
//        java.lang.Class<?> wildcardClass39 = regularTimePeriod37.getClass();
//        java.lang.Object obj40 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass39);
//        java.lang.Object obj41 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass39);
//        int int42 = day4.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
//        long long43 = day4.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNull(obj40);
//        org.junit.Assert.assertNull(obj41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560409200000L + "'", long43 == 1560409200000L);
//    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (byte) -1, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test71() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test71");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1.0d);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year23);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//    }

//    @Test
//    public void test72() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test72");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries3.addChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries3.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        java.lang.String str24 = month23.toString();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getLastMillisecond();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long26, class27);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long32, class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (byte) 10);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getLastMillisecond();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long43, class44);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
//        timeSeries45.addChangeListener(seriesChangeListener46);
//        java.lang.Object obj48 = null;
//        boolean boolean49 = timeSeries45.equals(obj48);
//        java.util.Collection collection50 = timeSeries41.getTimePeriodsUniqueToOtherSeries(timeSeries45);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day54, (java.lang.Number) 10.0f);
//        boolean boolean57 = timeSeriesDataItem53.equals((java.lang.Object) day54);
//        java.lang.Object obj58 = null;
//        boolean boolean59 = day54.equals(obj58);
//        int int60 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) day54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar63 = null;
//        fixedMillisecond62.peg(calendar63);
//        long long65 = fixedMillisecond62.getMiddleMillisecond();
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond62.getFirstMillisecond(calendar66);
//        java.util.Date date68 = fixedMillisecond62.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, 0.0d);
//        java.util.Calendar calendar71 = null;
//        fixedMillisecond62.peg(calendar71);
//        boolean boolean73 = month23.equals((java.lang.Object) fixedMillisecond62);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560495599999L + "'", long26 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560495599999L + "'", long43 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-1L) + "'", long65 == (-1L));
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-1L) + "'", long67 == (-1L));
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) 10.0f);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

//    @Test
//    public void test74() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test74");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        java.lang.Object obj2 = null;
//        boolean boolean3 = spreadsheetDate1.equals(obj2);
//        int int4 = spreadsheetDate1.getYYYY();
//        java.lang.String str5 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        boolean boolean10 = spreadsheetDate7.isOn(serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        java.lang.Object obj13 = null;
//        boolean boolean14 = spreadsheetDate12.equals(obj13);
//        int int15 = spreadsheetDate12.getYYYY();
//        boolean boolean16 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        boolean boolean17 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getFollowingDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate27.getEndOfCurrentMonth(serialDate29);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate23.getEndOfCurrentMonth(serialDate30);
//        boolean boolean33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate23, (java.lang.Object) 0.0f);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(12, serialDate23);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears(6, serialDate23);
//        boolean boolean36 = spreadsheetDate1.isAfter(serialDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        boolean boolean39 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getLastMillisecond();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long43, class44);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
//        timeSeries45.addChangeListener(seriesChangeListener46);
//        java.lang.Object obj48 = null;
//        boolean boolean49 = timeSeries45.equals(obj48);
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries45.addPropertyChangeListener(propertyChangeListener50);
//        java.lang.Class<?> wildcardClass52 = timeSeries45.getClass();
//        java.net.URL uRL53 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass52);
//        java.lang.Object obj54 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass52);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 10.0f);
//        boolean boolean59 = timeSeriesDataItem57.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeriesDataItem57.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = timeSeriesDataItem57.getPeriod();
//        java.util.Date date62 = regularTimePeriod61.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(date62);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day64, (java.lang.Number) 10.0f);
//        boolean boolean68 = timeSeriesDataItem66.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeriesDataItem66.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = timeSeriesDataItem66.getPeriod();
//        java.util.Date date71 = regularTimePeriod70.getStart();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date71);
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date71, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date62, timeZone73);
//        boolean boolean76 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560495599999L + "'", long43 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNull(uRL53);
//        org.junit.Assert.assertNull(obj54);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//    }

//    @Test
//    public void test75() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test75");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "", "Time", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, class7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries8.addChangeListener(seriesChangeListener9);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries8.equals(obj11);
//        int int13 = timeSeries8.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries8.addChangeListener(seriesChangeListener14);
//        java.util.Collection collection16 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        java.util.Date date19 = spreadsheetDate18.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        java.util.Date date22 = spreadsheetDate21.toDate();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getFollowingDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate27.getEndOfCurrentMonth(serialDate29);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(4, serialDate29);
//        boolean boolean32 = spreadsheetDate21.isBefore(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        boolean boolean37 = spreadsheetDate34.isOn(serialDate36);
//        boolean boolean38 = spreadsheetDate18.isInRange(serialDate29, serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate18.getFollowingDayOfWeek(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        java.lang.Object obj43 = null;
//        boolean boolean44 = spreadsheetDate42.equals(obj43);
//        int int45 = spreadsheetDate42.getYYYY();
//        java.lang.String str46 = spreadsheetDate42.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        boolean boolean51 = spreadsheetDate48.isOn(serialDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        java.lang.Object obj54 = null;
//        boolean boolean55 = spreadsheetDate53.equals(obj54);
//        int int56 = spreadsheetDate53.getYYYY();
//        boolean boolean57 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        boolean boolean58 = spreadsheetDate42.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        boolean boolean59 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int62 = spreadsheetDate61.getMonth();
//        boolean boolean63 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
//        timeSeries4.setKey((java.lang.Comparable) spreadsheetDate18);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1900 + "'", int45 == 1900);
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1900 + "'", int56 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//    }

//    @Test
//    public void test76() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test76");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries3.addChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        java.util.Date date20 = month19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20, timeZone21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
//        java.lang.String str24 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 10.0f);
//        boolean boolean31 = timeSeriesDataItem27.equals((java.lang.Object) day28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.next();
//        java.lang.Number number33 = timeSeries3.getValue(regularTimePeriod32);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener34);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(number33);
//    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test78() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test78");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long16, class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) (byte) 10);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) day24);
//        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.lang.Object obj27 = timeSeries12.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond29.peg(calendar30);
//        long long32 = fixedMillisecond29.getMiddleMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond29.getMiddleMillisecond(calendar33);
//        java.lang.Number number35 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number35);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
        java.lang.String str4 = month3.toString();
        int int5 = month3.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

//    @Test
//    public void test80() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test80");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getMiddleMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441605125L + "'", long2 == 1560441605125L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441605125L + "'", long4 == 1560441605125L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441605125L + "'", long8 == 1560441605125L);
//    }

//    @Test
//    public void test81() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test81");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day1, (java.lang.Number) 10.0f);
//        java.util.Date date4 = day1.getEnd();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getLastMillisecond();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long8, class9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (byte) 10);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        java.lang.String str18 = day16.toString();
//        timeSeries10.setKey((java.lang.Comparable) str18);
//        java.lang.String str20 = timeSeries10.getDomainDescription();
//        timeSeries10.fireSeriesChanged();
//        java.lang.Object obj22 = timeSeries10.clone();
//        boolean boolean23 = year5.equals((java.lang.Object) timeSeries10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year5.previous();
//        try {
//            org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) -1, year5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

//    @Test
//    public void test82() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test82");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "", "Time", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, class7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries8.addChangeListener(seriesChangeListener9);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries8.equals(obj11);
//        int int13 = timeSeries8.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries8.addChangeListener(seriesChangeListener14);
//        java.util.Collection collection16 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        java.util.Collection collection17 = timeSeries8.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertNotNull(collection17);
//    }

//    @Test
//    public void test83() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test83");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = timeSeries3.equals(obj6);
//        int int8 = timeSeries3.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries3.addChangeListener(seriesChangeListener9);
//        boolean boolean11 = timeSeries3.isEmpty();
//        int int12 = timeSeries3.getMaximumItemCount();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
//    }

//    @Test
//    public void test84() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test84");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, class5);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10, class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) (byte) 10);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day13, (org.jfree.data.time.RegularTimePeriod) day18);
//        int int20 = month0.compareTo((java.lang.Object) day18);
//        java.lang.String str21 = day18.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//    }

//    @Test
//    public void test85() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test85");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5, class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = timeSeries7.equals(obj10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener12);
//        java.lang.Class<?> wildcardClass14 = timeSeries7.getClass();
//        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass14);
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass14);
//        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("6-April-1900", (java.lang.Class) wildcardClass14);
//        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("13-June-2019", (java.lang.Class) wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(uRL15);
//        org.junit.Assert.assertNull(inputStream16);
//        org.junit.Assert.assertNull(uRL17);
//        org.junit.Assert.assertNull(inputStream18);
//    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test86");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        int int7 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 0);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getFollowingDayOfWeek((int) (short) 1);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getEndOfCurrentMonth(serialDate17);
        int int19 = spreadsheetDate11.compare(serialDate18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek((int) (short) 1);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        boolean boolean26 = spreadsheetDate11.isOnOrAfter(serialDate25);
        int int27 = fixedMillisecond1.compareTo((java.lang.Object) spreadsheetDate11);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-43549) + "'", int19 == (-43549));
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test87");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test88() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test88");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441605417L + "'", long2 == 1560441605417L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441605417L + "'", long4 == 1560441605417L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test89() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test89");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray3 = timePeriodFormatException2.getSuppressed();
//        java.lang.Class<?> wildcardClass4 = throwableArray3.getClass();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, class7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries8.addChangeListener(seriesChangeListener9);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries8.equals(obj11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.Class<?> wildcardClass15 = timeSeries8.getClass();
//        timeSeries8.setKey((java.lang.Comparable) 1560452399999L);
//        timeSeries8.clear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10.0f);
//        boolean boolean25 = timeSeriesDataItem21.equals((java.lang.Object) day22);
//        java.lang.Object obj26 = null;
//        boolean boolean27 = day22.equals(obj26);
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, number28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem29.getPeriod();
//        timeSeries8.delete(regularTimePeriod30);
//        java.lang.Class<?> wildcardClass32 = regularTimePeriod30.getClass();
//        java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getStart();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        long long40 = day39.getLastMillisecond();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long40, class41);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timeSeries42.addChangeListener(seriesChangeListener43);
//        java.lang.Object obj45 = null;
//        boolean boolean46 = timeSeries42.equals(obj45);
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries42.addPropertyChangeListener(propertyChangeListener47);
//        java.lang.Class<?> wildcardClass49 = timeSeries42.getClass();
//        java.net.URL uRL50 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass49);
//        java.lang.Object obj51 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass49);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day52, (java.lang.Number) 10.0f);
//        boolean boolean56 = timeSeriesDataItem54.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = timeSeriesDataItem54.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeriesDataItem54.getPeriod();
//        java.util.Date date59 = regularTimePeriod58.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond(date59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) 10.0f);
//        boolean boolean65 = timeSeriesDataItem63.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = timeSeriesDataItem63.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = timeSeriesDataItem63.getPeriod();
//        java.util.Date date68 = regularTimePeriod67.getStart();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date68, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date59, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date35, timeZone70);
//        org.junit.Assert.assertNotNull(throwableArray3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNull(obj33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560495599999L + "'", long40 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNull(uRL50);
//        org.junit.Assert.assertNull(obj51);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//    }

//    @Test
//    public void test90() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test90");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, class19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = timeSeries20.equals(obj23);
//        java.util.Collection collection25 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 10.0f);
//        boolean boolean32 = timeSeriesDataItem28.equals((java.lang.Object) day29);
//        java.lang.Object obj33 = null;
//        boolean boolean34 = day29.equals(obj33);
//        int int35 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar38 = null;
//        fixedMillisecond37.peg(calendar38);
//        long long40 = fixedMillisecond37.getMiddleMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond37.getFirstMillisecond(calendar41);
//        java.util.Date date43 = fixedMillisecond37.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, 0.0d);
//        java.lang.String str46 = fixedMillisecond37.toString();
//        long long47 = fixedMillisecond37.getLastMillisecond();
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond37.getFirstMillisecond(calendar48);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str46.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1L) + "'", long47 == (-1L));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
//    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test91");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0f);
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date3, timeZone6);
        org.jfree.data.time.Year year9 = month8.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year9);
    }

//    @Test
//    public void test92() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test92");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day4, (double) (byte) 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        java.lang.String str11 = day9.toString();
//        timeSeries3.setKey((java.lang.Comparable) str11);
//        java.lang.String str13 = timeSeries3.getDomainDescription();
//        timeSeries3.fireSeriesChanged();
//        java.lang.Object obj15 = timeSeries3.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 10.0f);
//        boolean boolean24 = timeSeriesDataItem20.equals((java.lang.Object) day21);
//        java.lang.Object obj25 = null;
//        boolean boolean26 = day21.equals(obj25);
//        boolean boolean28 = day21.equals((java.lang.Object) (byte) 10);
//        java.lang.String str29 = day21.toString();
//        java.lang.Number number30 = null;
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day21, number30, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//    }
//}

