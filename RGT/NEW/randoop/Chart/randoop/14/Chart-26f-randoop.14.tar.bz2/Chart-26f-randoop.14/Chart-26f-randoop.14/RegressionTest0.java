import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Shape shape0 = null;
        java.awt.Paint paint1 = null;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Stroke stroke2 = null;
        java.awt.Color color3 = java.awt.Color.DARK_GRAY;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) dateTickUnit0, paint1, stroke2, (java.awt.Paint) color3, stroke4, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) '4', jFreeChart1, chartChangeEventType2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Font font1 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2);
        java.awt.Paint paint4 = waferMapPlot3.getNoDataMessagePaint();
        try {
            org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("", font1, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.data.Range range2 = null;
        try {
            dateAxis1.setRangeWithMargins(range2, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            statisticalLineAndShapeRenderer0.drawBackground(graphics2D1, categoryPlot2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str4 = textAnchor3.toString();
        try {
            org.jfree.chart.axis.DateTick dateTick6 = new org.jfree.chart.axis.DateTick(date0, "", textAnchor2, textAnchor3, (double) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str4.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Stroke stroke15 = null;
        try {
            categoryPlot7.setRangeGridlineStroke(stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1.0d), (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot13.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { (short) 0 };
        try {
            float[] floatArray4 = color0.getColorComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        try {
            java.util.Date date2 = dateTickUnit0.rollDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        java.lang.Comparable comparable2 = null;
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, dataset1, comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", graphics2D1, (float) (byte) 100, (float) '#', textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
//        org.junit.Assert.assertNotNull(uRL2);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        java.util.List list2 = taskSeries1.getTasks();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint2 = categoryMarker1.getOutlinePaint();
        try {
            categoryMarker1.setAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        stackedBarRenderer3D1.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        try {
            dateAxis1.zoomRange((double) (byte) 100, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (97.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        float[] floatArray4 = new float[] {};
        try {
            float[] floatArray5 = color2.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        try {
            statisticalLineAndShapeRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = categoryAxis0.draw(graphics2D1, (double) 4, rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE6" + "'", str1.equals("ItemLabelAnchor.INSIDE6"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", 2);
        boolean boolean4 = color2.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        boolean boolean9 = stackedBarRenderer3D1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        plot2.addChangeListener(plotChangeListener3);
        org.junit.Assert.assertNotNull(plot2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getRootPlot();
        org.jfree.chart.plot.Plot plot3 = waferMapPlot1.getParent();
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            textFragment3.draw(graphics2D4, (float) 0L, (float) 0, textAnchor7, 0.0f, (float) (-1L), (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String[] strArray2 = dataPackageResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker18.setLabel("TextAnchor.TOP_CENTER");
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot7.addDomainMarker((int) (short) 100, categoryMarker18, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getRootPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot1.getDataset();
        waferMapPlot1.setForegroundAlpha((float) 6);
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = null;
        categoryPlot7.setBackgroundImage(image19);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        java.lang.Object obj4 = statisticalLineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int3 = java.awt.Color.HSBtoRGB(10.0f, (float) 5, (float) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-3695) + "'", int3 == (-3695));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String[] strArray2 = dataPackageResources0.getStringArray("12/31/69");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key 12/31/69");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color5 = java.awt.Color.YELLOW;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        piePlot3D7.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke10);
        java.awt.Color color12 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        try {
            org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem(attributedString0, "12/31/69", "Last", "", shape4, (java.awt.Paint) color5, stroke10, (java.awt.Paint) color12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = stackedBarRenderer3D1.getLegendItemURLGenerator();
        boolean boolean8 = stackedBarRenderer3D1.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryMiddle((int) (short) 0, 10, rectangle2D4, rectangleEdge5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.axis.AxisState axisState13 = categoryAxis0.draw(graphics2D7, (double) 12, rectangle2D9, rectangle2D10, rectangleEdge11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) '4');
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            java.awt.Color color1 = java.awt.Color.decode("TextAnchor.TOP_CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"TextAnchor.TOP_CENTER\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0E-5d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer8.setSeriesOutlinePaint(4, (java.awt.Paint) color10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer8);
        categoryPlot12.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        categoryPlot12.markerChanged(markerChangeEvent16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis20.setTickUnit(dateTickUnit21);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            stackedBarRenderer1.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D4, categoryPlot12, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset23, (int) 'a', (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        java.lang.Comparable comparable3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer7.setSeriesOutlinePaint(4, (java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer7);
        categoryPlot11.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17);
        boolean boolean19 = categoryPlot11.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot11.setDataset(categoryDataset20);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot11.setRangeCrosshairPaint(paint22);
        java.awt.Paint paint24 = categoryPlot11.getDomainGridlinePaint();
        try {
            piePlot3D1.setSectionOutlinePaint(comparable3, paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2019);
        java.lang.Object obj3 = objectList1.get(100);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer5.setSeriesOutlinePaint(4, (java.awt.Paint) color7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer5);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 10L);
        statisticalLineAndShapeRenderer5.setSeriesShape((int) (byte) 100, shape13, true);
        try {
            java.awt.GradientPaint gradientPaint16 = standardGradientPaintTransformer0.transform(gradientPaint1, shape13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.lang.Comparable comparable2 = null;
        try {
            java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        dateAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = dateAxis5.getDownArrow();
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        boolean boolean27 = categoryPlot19.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        categoryPlot19.setDataset(categoryDataset28);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot19.setRangeCrosshairPaint(paint30);
        java.awt.Paint paint32 = categoryPlot19.getDomainGridlinePaint();
        try {
            org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "RectangleAnchor.BOTTOM_RIGHT", "ThreadContext", shape8, paint9, stroke11, paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        dateAxis17.setNegativeArrowVisible(false);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        categoryPlot7.setDomainGridlineStroke(stroke20);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        org.jfree.chart.util.Layer layer25 = null;
        try {
            categoryPlot7.addDomainMarker(12, categoryMarker24, layer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = null;
        try {
            dateAxis1.setRange(range3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 6;
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer3.getSeriesPaint(4);
        boolean boolean10 = statisticalLineAndShapeRenderer3.getAutoPopulateSeriesStroke();
        java.awt.Paint paint11 = null;
        try {
            statisticalLineAndShapeRenderer3.setBaseItemLabelPaint(paint11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Shape shape9 = statisticalLineAndShapeRenderer3.getSeriesShape((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        try {
            statisticalLineAndShapeRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        waferMapPlot1.removeChangeListener(plotChangeListener3);
        org.junit.Assert.assertNotNull(plot2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(5, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        categoryPlot7.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot7.zoomDomainAxes(0.05d, plotRenderingInfo23, point2D24);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D13.setSeriesPaint((int) (byte) 100, paint15, false);
        double double18 = stackedBarRenderer3D13.getItemMargin();
        stackedBarRenderer3D13.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer27.setSeriesOutlinePaint(4, (java.awt.Paint) color29);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer27);
        categoryPlot31.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot31.zoomRangeAxes(0.0d, plotRenderingInfo36, point2D37);
        java.awt.Image image39 = categoryPlot31.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline42 = null;
        dateAxis41.setTimeline(timeline42);
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker45.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        stackedBarRenderer3D13.drawRangeMarker(graphics2D23, categoryPlot31, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.plot.Marker) categoryMarker45, rectangle2D48);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        try {
            stackedBarRenderer3D1.drawBackground(graphics2D11, categoryPlot31, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(image39);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) (short) 100, 7, (int) 'a', 6, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year5);
        task3.addSubtask(task7);
        task7.setDescription("{0}");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getItemPaint((int) (short) 0, (int) (byte) 10);
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 10, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalLineAndShapeRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator7);
        org.jfree.chart.LegendItem legendItem11 = statisticalLineAndShapeRenderer0.getLegendItem((-1), (int) (short) 100);
        org.jfree.chart.LegendItem legendItem14 = statisticalLineAndShapeRenderer0.getLegendItem(5, 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNull(legendItem14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        try {
            java.lang.String[] strArray3 = dataPackageResources0.getStringArray("12/31/69");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key 12/31/69");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Paint paint14 = stackedBarRenderer3D1.getItemPaint(0, (int) (byte) 100);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer19.setSeriesOutlinePaint(4, (java.awt.Paint) color21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer19);
        categoryPlot23.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot23.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29);
        boolean boolean31 = categoryPlot23.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        categoryPlot23.setDataset(categoryDataset32);
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot23.setRangeCrosshairPaint(paint34);
        java.awt.Paint paint36 = categoryPlot23.getDomainGridlinePaint();
        categoryPlot23.setAnchorValue((double) '#');
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        try {
            stackedBarRenderer3D1.drawOutline(graphics2D15, categoryPlot23, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = stackedBarRenderer3D1.getSeriesToolTipGenerator(0);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        stackedBarRenderer3D1.setBasePaint(paint9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration2 = dataPackageResources0.getKeys();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalLineAndShapeRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            statisticalLineAndShapeRenderer0.drawOutline(graphics2D9, categoryPlot10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot7.addDomainMarker(categoryMarker14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot7.getDomainAxisForDataset(2019);
        org.jfree.chart.util.SortOrder sortOrder18 = null;
        try {
            categoryPlot7.setRowRenderingOrder(sortOrder18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(categoryAxis17);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1, lengthConstraintType2, (double) (-1.0f), range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getRootPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot1.getDataset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity9 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis1, shape5, "", "Last");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity12 = new org.jfree.chart.entity.TickLabelEntity(shape5, "ItemLabelAnchor.INSIDE6", "ThreadContext");
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick8 = new org.jfree.chart.axis.DateTick(date2, "12/31/69", textAnchor4, textAnchor6, 0.0d);
        java.lang.Object obj9 = null;
        boolean boolean10 = dateTick8.equals(obj9);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str5.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 10L);
        statisticalLineAndShapeRenderer3.setSeriesShape((int) (byte) 100, shape11, true);
        boolean boolean14 = statisticalLineAndShapeRenderer3.getUseFillPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setCircular(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        try {
            piePlot3D1.setLegendLabelGenerator(pieSectionLabelGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ThreadContext, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint37 = categoryMarker36.getOutlinePaint();
        stackedBarRenderer3D1.setBaseFillPaint(paint37, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        boolean boolean16 = stackedBarRenderer3D1.getAutoPopulateSeriesFillPaint();
        boolean boolean17 = stackedBarRenderer3D1.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        java.lang.Object obj1 = keyToGroupMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("TextAnchor.TOP_CENTER");
        double double3 = textTitle0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle0.getMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) defaultDrawingSupplier0, obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot7.addDomainMarker(categoryMarker14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot7.getDomainAxisForDataset(2019);
        int int18 = categoryAxis17.getMaximumCategoryLabelLines();
        double double19 = categoryAxis17.getCategoryMargin();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font1, (java.awt.Paint) color2);
        java.awt.Font font4 = textFragment3.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ThreadContext", graphics2D1, (float) 1577865599999L, 0.0f, textAnchor4, 100.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year5);
        task3.addSubtask(task7);
        java.lang.Double double9 = task7.getPercentComplete();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNull(double9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        dateAxis27.configure();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        long long4 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        boolean boolean3 = waferMapPlot1.equals((java.lang.Object) 100L);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D6.setSeriesPaint((int) (byte) 100, paint8, false);
        double double11 = stackedBarRenderer3D6.getItemMargin();
        stackedBarRenderer3D6.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        stackedBarRenderer3D6.setAutoPopulateSeriesStroke(false);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 10L);
        stackedBarRenderer3D6.setSeriesShape((int) (short) 0, shape21);
        java.awt.Color color24 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D28.setSeriesPaint((int) (byte) 100, paint30, false);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer36 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer36.setSeriesOutlinePaint(4, (java.awt.Paint) color38);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer36);
        categoryPlot40.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot40.zoomRangeAxes(0.0d, plotRenderingInfo45, point2D46);
        java.awt.Image image48 = categoryPlot40.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        dateAxis50.setNegativeArrowVisible(false);
        java.awt.Stroke stroke53 = dateAxis50.getAxisLineStroke();
        categoryPlot40.setDomainGridlineStroke(stroke53);
        java.awt.Shape shape56 = null;
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D58 = new org.jfree.chart.plot.PiePlot3D(pieDataset57);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke61 = defaultDrawingSupplier60.getNextOutlineStroke();
        piePlot3D58.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke61);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer63 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer63.setSeriesOutlinePaint(4, (java.awt.Paint) color65);
        statisticalLineAndShapeRenderer63.setBaseShapesFilled(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator70 = null;
        statisticalLineAndShapeRenderer63.setSeriesToolTipGenerator(0, categoryToolTipGenerator70);
        java.awt.Paint paint73 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        statisticalLineAndShapeRenderer63.setSeriesPaint((int) (byte) 0, paint73);
        try {
            org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem(attributedString0, "Last", "CategoryAnchor.MIDDLE", "ThreadContext", false, shape21, true, (java.awt.Paint) color24, true, paint30, stroke53, true, shape56, stroke61, paint73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(image48);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(paint73);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getItemPaint((int) (short) 0, (int) (byte) 10);
        boolean boolean9 = statisticalLineAndShapeRenderer0.getItemLineVisible(0, 6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) (-3695), (float) 1577865599999L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Paint paint7 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Color color9 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        dateAxis12.setNegativeArrowVisible(false);
        java.awt.Stroke stroke15 = dateAxis12.getAxisLineStroke();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer20 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke21 = minMaxCategoryRenderer20.getGroupStroke();
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset22);
        java.awt.Paint paint24 = waferMapPlot23.getNoDataMessagePaint();
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem(attributedString0, "TextAnchor.TOP_CENTER", "RectangleAnchor.BOTTOM_RIGHT", "", false, shape5, true, paint7, false, (java.awt.Paint) color9, stroke15, false, shape18, stroke21, paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setStartAngle(1.0E-5d);
        java.lang.Comparable comparable5 = null;
        try {
            java.awt.Stroke stroke6 = piePlot3D1.getSectionOutlineStroke(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getRootPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot1.getDataset();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            waferMapPlot1.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        boolean boolean6 = piePlot3D1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str5 = textAnchor4.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.text.TextUtilities.drawAlignedString("ItemLabelAnchor.INSIDE6", graphics2D1, 0.0f, (float) 10, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str5.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot7.setRenderer(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer6.setSeriesOutlinePaint(4, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer6);
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot10.getDatasetGroup();
        categoryPlot10.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            minMaxCategoryRenderer0.drawBackground(graphics2D2, categoryPlot10, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(datasetGroup11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D25.setMinimumBarLength((double) (byte) -1);
        boolean boolean30 = stackedBarRenderer3D25.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = stackedBarRenderer3D25.getBaseToolTipGenerator();
        stackedBarRenderer3D25.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryPlot44.markerChanged(markerChangeEvent48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        double double55 = dateAxis51.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        stackedBarRenderer3D25.drawRangeGridline(graphics2D36, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D56, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        dateAxis60.setNegativeArrowVisible(false);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis60.setRangeWithMargins(range63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis51, dateAxis60 };
        xYPlot16.setRangeAxes(valueAxisArray65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        try {
            xYPlot16.handleClick((-3695), (int) (short) 100, plotRenderingInfo69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        categoryPlot13.setRangeCrosshairValue((double) 0, true);
        java.awt.Stroke stroke19 = null;
        try {
            categoryPlot13.setDomainGridlineStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        javax.swing.Icon icon1 = null;
        try {
            minMaxCategoryRenderer0.setMinIcon(icon1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D13.setMinimumBarLength((double) (byte) -1);
        boolean boolean18 = stackedBarRenderer3D13.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D13.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = stackedBarRenderer3D13.getBaseToolTipGenerator();
        stackedBarRenderer3D13.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer28.setSeriesOutlinePaint(4, (java.awt.Paint) color30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer28);
        categoryPlot32.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot32.markerChanged(markerChangeEvent36);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = null;
        dateAxis39.setTickUnit(dateTickUnit40);
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = dateAxis39.getTickUnit();
        double double43 = dateAxis39.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        stackedBarRenderer3D13.drawRangeGridline(graphics2D24, categoryPlot32, (org.jfree.chart.axis.ValueAxis) dateAxis39, rectangle2D44, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot32.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            org.jfree.chart.axis.AxisState axisState49 = categoryAxis1.draw(graphics2D8, (double) 100.0f, rectangle2D10, rectangle2D11, rectangleEdge47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(dateTickUnit42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (short) -1);
        double double4 = rectangleInsets0.calculateBottomInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot7.getDatasetGroup();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot7.setRangeGridlineStroke(stroke9);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray9, comparableArray10, numberArray11, numberArray12);
        boolean boolean14 = dateAxis1.hasListener((java.util.EventListener) defaultIntervalCategoryDataset13);
        java.awt.Paint paint15 = null;
        try {
            dateAxis1.setAxisLinePaint(paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean2 = categoryLabelPositions0.equals((java.lang.Object) 1L);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D25.setMinimumBarLength((double) (byte) -1);
        boolean boolean30 = stackedBarRenderer3D25.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = stackedBarRenderer3D25.getBaseToolTipGenerator();
        stackedBarRenderer3D25.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryPlot44.markerChanged(markerChangeEvent48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        double double55 = dateAxis51.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        stackedBarRenderer3D25.drawRangeGridline(graphics2D36, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D56, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        dateAxis60.setNegativeArrowVisible(false);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis60.setRangeWithMargins(range63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis51, dateAxis60 };
        xYPlot16.setRangeAxes(valueAxisArray65);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation67 = null;
        try {
            xYPlot16.addAnnotation(xYAnnotation67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        categoryAxis0.setMaximumCategoryLabelLines(31);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ERROR : Relative To String", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer8.setSeriesOutlinePaint(4, (java.awt.Paint) color10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer8);
        categoryPlot12.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        categoryPlot12.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot12.addDomainMarker(categoryMarker19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot12.getDomainAxisForDataset(2019);
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            categoryPlot12.addDomainMarker((int) (short) -1, categoryMarker25, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(categoryAxis22);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = null;
        try {
            numberAxis3D0.setTickUnit(numberTickUnit1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        try {
            categoryPlot13.zoom((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = null;
        try {
            defaultCategoryDataset0.setGroup(datasetGroup1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset30 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit29, dataset30);
        java.util.Date date32 = dateAxis25.calculateHighestVisibleTickValue(dateTickUnit29);
        int int33 = dateTickUnit29.getCalendarField();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("Last", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("TextAnchor.TOP_CENTER");
        textTitle0.setExpandToFitSpace(false);
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        textTitle0.setBackgroundPaint(paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, 0.0d);
        org.jfree.data.Range range11 = rectangleConstraint10.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle0.arrange(graphics2D7, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.extendWidth(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.0d + "'", double2 == 12.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap();
        boolean boolean2 = areaRendererEndType0.equals((java.lang.Object) keyToGroupMap1);
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (short) -1);
        double double4 = rectangleInsets0.calculateBottomInset((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray0, comparableArray1, numberArray2, numberArray3);
        java.lang.Comparable[] comparableArray5 = null;
        double[][] doubleArray6 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray5, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        boolean boolean14 = stackedBarRenderer3D1.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot20.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot20.getDomainAxisForDataset((int) '#');
        java.awt.Paint paint38 = categoryAxis37.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(categoryAxis37);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(list1);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        try {
            double double6 = numberAxis3D0.valueToJava2D((double) 100.0f, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        java.awt.Shape shape5 = statisticalLineAndShapeRenderer0.getSeriesShape((int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        statisticalLineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator6);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D9.setMinimumBarLength((double) (byte) -1);
        boolean boolean14 = stackedBarRenderer3D9.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D9.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = statisticalLineAndShapeRenderer17.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D9.setBasePositiveItemLabelPosition(itemLabelPosition20);
        statisticalLineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.awt.Shape shape3 = chartEntity2.getArea();
        java.lang.String str4 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot16.getIndexOf(xYItemRenderer18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker22.setLabel("TextAnchor.TOP_CENTER");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        categoryMarker22.setLabelAnchor(rectangleAnchor25);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker22);
        org.jfree.chart.util.Layer layer28 = null;
        try {
            xYPlot16.addDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) categoryMarker22, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        stackedBarRenderer3D1.setSeriesItemLabelsVisible(100, (java.lang.Boolean) true, true);
        java.awt.Color color22 = java.awt.Color.getColor("hi!", 2);
        stackedBarRenderer3D1.setWallPaint((java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = null;
        try {
            xYPlot16.setSeriesRenderingOrder(seriesRenderingOrder18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        boolean boolean20 = xYPlot16.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer7.setErrorIndicatorPaint((java.awt.Paint) color8);
        java.lang.Object obj10 = statisticalLineAndShapeRenderer7.clone();
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer7.getItemPaint((int) (short) 0, (int) (byte) 10);
        try {
            org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem(attributedString0, "ERROR : Relative To String", "TextAnchor.TOP_CENTER", "TextAnchor.TOP_CENTER", shape5, paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        double double35 = dateAxis27.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        dateAxis25.setUpperMargin((double) (-3695));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        dateAxis25.centerRange((double) 100.0f);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean36 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            org.jfree.chart.axis.AxisState axisState38 = dateAxis25.draw(graphics2D31, (double) 0.0f, rectangle2D33, rectangle2D34, rectangleEdge35, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        statisticalLineAndShapeRenderer16.notifyListeners(rendererChangeEvent20);
        categoryPlot7.setRenderer(3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16, false);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = statisticalLineAndShapeRenderer16.initialise(graphics2D24, rectangle2D25, categoryPlot26, (-1), plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setLabelGap((double) 4);
        java.awt.Paint paint6 = piePlot3D1.getSectionPaint((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        piePlot3D4.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke7);
        java.awt.Color color9 = java.awt.Color.darkGray;
        piePlot3D4.setShadowPaint((java.awt.Paint) color9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color15 = java.awt.Color.DARK_GRAY;
        float[] floatArray20 = new float[] { 1L, (short) 100, (short) 100, 10 };
        float[] floatArray21 = color15.getColorComponents(floatArray20);
        float[] floatArray22 = color14.getComponents(floatArray20);
        float[] floatArray23 = color13.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color9.getComponents(colorSpace12, floatArray23);
        float[] floatArray25 = java.awt.Color.RGBtoHSB((int) (byte) 10, 9999, 0, floatArray24);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset2 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit1, dataset2);
        tickUnits0.add((org.jfree.chart.axis.TickUnit) dateTickUnit1);
        org.jfree.chart.axis.TickUnit tickUnit6 = tickUnits0.getCeilingTickUnit(0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(tickUnit6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray0, comparableArray1, numberArray2, numberArray3);
        java.lang.Comparable[] comparableArray5 = null;
        double[][] doubleArray6 = new double[][] {};
        try {
            org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray5, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer20.setSeriesOutlinePaint(4, (java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer20);
        categoryPlot24.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo29, point2D30);
        boolean boolean32 = categoryPlot24.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot24.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot24.getDomainAxisLocation(10);
        categoryPlot13.setRangeAxisLocation((int) '4', axisLocation35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.Point2D point2D39 = null;
        org.jfree.chart.plot.PlotState plotState40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        try {
            categoryPlot13.draw(graphics2D37, rectangle2D38, point2D39, plotState40, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        categoryPlot7.configureRangeAxes();
        boolean boolean16 = categoryPlot7.isRangeZoomable();
        double double17 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis20.setTickUnit(dateTickUnit21);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        dateAxis20.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        dateAxis27.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer33);
        xYPlot34.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot44.zoomRangeAxes(0.0d, plotRenderingInfo49, point2D50);
        boolean boolean52 = categoryPlot44.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection53 = categoryPlot44.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot44.getDomainAxisLocation(10);
        xYPlot34.setRangeAxisLocation((int) (byte) 10, axisLocation55);
        categoryPlot7.setRangeAxisLocation(axisLocation55, false);
        try {
            categoryPlot7.zoom((double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit23);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(legendItemCollection53);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot16.getDomainAxisLocation();
        java.awt.Paint paint19 = xYPlot16.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = null;
        try {
            xYPlot16.setOrientation(plotOrientation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 0.5f, (double) 12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryMiddle((int) (short) 0, 10, rectangle2D4, rectangleEdge5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer10.setSeriesOutlinePaint(4, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer10);
        categoryPlot14.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        boolean boolean22 = categoryPlot14.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot14.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        int int25 = categoryPlot14.getDomainAxisIndex(categoryAxis24);
        java.awt.Image image26 = categoryPlot14.getBackgroundImage();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = statisticalLineAndShapeRenderer28.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = statisticalLineAndShapeRenderer28.getSeriesURLGenerator((int) (byte) 100);
        java.awt.Color color34 = java.awt.Color.darkGray;
        statisticalLineAndShapeRenderer28.setBaseFillPaint((java.awt.Paint) color34, false);
        int int37 = statisticalLineAndShapeRenderer28.getPassCount();
        statisticalLineAndShapeRenderer28.setSeriesShapesVisible(12, (java.lang.Boolean) true);
        boolean boolean41 = categoryPlot14.equals((java.lang.Object) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNull(categoryURLGenerator33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        java.awt.Shape shape35 = dateAxis27.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        int int21 = xYPlot16.getRangeAxisIndex(valueAxis20);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint24 = categoryMarker23.getOutlinePaint();
        categoryMarker23.setDrawAsLine(false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.chart.util.Layer layer28 = null;
        try {
            xYPlot16.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        javax.swing.Icon icon2 = null;
        try {
            minMaxCategoryRenderer0.setMinIcon(icon2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'icon' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot7.getDomainAxis();
        double double9 = categoryAxis8.getUpperMargin();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        categoryMarker1.setLabelOffset(rectangleInsets6);
        java.awt.Stroke stroke8 = categoryMarker1.getStroke();
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setCategoryLabelPositionOffset(2019);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot20.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot20.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis16 };
        categoryPlot7.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.plot.Marker marker19 = null;
        try {
            categoryPlot7.addRangeMarker(marker19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) (short) 0, (long) 31);
        java.lang.Object obj9 = null;
        boolean boolean10 = segmentedTimeline3.equals(obj9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getItemPaint((int) (short) 0, (int) (byte) 10);
        java.lang.Boolean boolean8 = statisticalLineAndShapeRenderer0.getSeriesShapesFilled(9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        stackedBarRenderer3D1.notifyListeners(rendererChangeEvent7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer13.setSeriesOutlinePaint(4, (java.awt.Paint) color15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer13);
        categoryPlot17.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot17.markerChanged(markerChangeEvent21);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot17.addDomainMarker(categoryMarker24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot17.getDomainAxisForDataset(2019);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        dateAxis29.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.Marker marker35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D9, categoryPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis29, marker35, rectangle2D36);
        try {
            dateAxis29.setRange(100.0d, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(categoryAxis27);
        org.junit.Assert.assertNull(dateTickUnit32);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setCircular(true);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D1.equals(obj5);
        int int7 = piePlot3D1.getPieIndex();
        boolean boolean8 = piePlot3D1.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray0, comparableArray1, numberArray2, numberArray3);
        java.lang.Number number7 = null;
        try {
            defaultIntervalCategoryDataset4.setStartValue((int) (byte) 100, (java.lang.Comparable) (short) 1, number7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        categoryPlot7.configureRangeAxes();
        boolean boolean16 = categoryPlot7.isRangeZoomable();
        double double17 = categoryPlot7.getRangeCrosshairValue();
        java.awt.Paint paint18 = categoryPlot7.getRangeCrosshairPaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder(paint18, stroke20, rectangleInsets21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 10, (double) ' ');
        java.awt.Stroke stroke4 = barRenderer3D2.lookupSeriesStroke(9999);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer10.setSeriesOutlinePaint(4, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer10);
        categoryPlot14.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        java.awt.Image image22 = categoryPlot14.getBackgroundImage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot14.getRenderer((-3695));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer3D2.initialise(graphics2D5, rectangle2D6, categoryPlot14, (int) (short) -1, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(image22);
        org.junit.Assert.assertNull(categoryItemRenderer24);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot13.setRenderers(categoryItemRendererArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer21.setSeriesOutlinePaint(4, (java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer21);
        categoryPlot25.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot25.zoomRangeAxes(0.0d, plotRenderingInfo30, point2D31);
        categoryPlot25.configureRangeAxes();
        boolean boolean34 = categoryPlot25.isRangeZoomable();
        double double35 = categoryPlot25.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateBottomOutset((double) (short) -1);
        categoryPlot25.setAxisOffset(rectangleInsets36);
        categoryPlot13.setInsets(rectangleInsets36);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Color color2 = java.awt.Color.getColor("DateTickMarkPosition.MIDDLE", 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke18 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke19 = xYPlot16.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot16.getDataset();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYDataset20);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.data.KeyToGroupMap keyToGroupMap2 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        keyToGroupMap2.mapKeyToGroup((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) year4);
        java.util.List list6 = keyToGroupMap2.getGroups();
        projectInfo0.setContributors(list6);
        org.jfree.chart.ui.Library library8 = null;
        try {
            projectInfo0.addOptionalLibrary(library8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        java.awt.Paint paint8 = stackedBarRenderer3D1.lookupSeriesOutlinePaint(10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setAutoTickUnitSelection(false);
        dateAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNull(dateTickUnit4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            stackedBarRenderer1.drawDomainGridline(graphics2D2, categoryPlot3, rectangle2D4, (double) 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        boolean boolean6 = statisticalLineAndShapeRenderer0.getUseFillPaint();
        boolean boolean8 = statisticalLineAndShapeRenderer0.isSeriesVisibleInLegend((int) (byte) 0);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        dateAxis1.setAutoRangeMinimumSize((double) 31, false);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        java.lang.Object obj8 = piePlot3D1.clone();
        piePlot3D1.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot7.setDataset(categoryDataset16);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot7.setRangeCrosshairPaint(paint18);
        java.awt.Paint paint20 = categoryPlot7.getDomainGridlinePaint();
        java.awt.Font font21 = categoryPlot7.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot7.getDomainMarkers(layer22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot7.getRenderer();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(categoryItemRenderer24);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        float float16 = categoryPlot13.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis11);
        categoryPlot7.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = null;
        try {
            categoryPlot7.setOrientation(plotOrientation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str1.equals("TextBlockAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot7.addDomainMarker(categoryMarker14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer19.setSeriesOutlinePaint(4, (java.awt.Paint) color21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer19);
        categoryPlot23.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot23.setDomainAxis(categoryAxis27);
        java.awt.Font font30 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font30, (java.awt.Paint) color31);
        categoryPlot23.setNoDataMessageFont(font30);
        categoryMarker14.setLabelFont(font30);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker36.setLabel("TextAnchor.TOP_CENTER");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        categoryMarker36.setLabelAnchor(rectangleAnchor39);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker36);
        categoryMarker14.notifyListeners(markerChangeEvent41);
        boolean boolean43 = categoryMarker14.getDrawAsLine();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", (double) 0L);
        try {
            java.lang.Number number5 = defaultKeyedValues0.getValue((java.lang.Comparable) 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 1.0E-5");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSectionDepth(0.2d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker1.setLabel("TextAnchor.TOP_CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer7.setSeriesOutlinePaint(4, (java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer7);
        categoryPlot11.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17);
        boolean boolean19 = categoryPlot11.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot11.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        int int22 = categoryPlot11.getDomainAxisIndex(categoryAxis21);
        java.awt.Image image23 = categoryPlot11.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot11.getDataset();
        categoryPlot11.configureDomainAxes();
        java.awt.Stroke stroke26 = categoryPlot11.getRangeGridlineStroke();
        categoryPlot11.mapDatasetToDomainAxis(100, (int) 'a');
        categoryMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot11);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) (-1));
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D25.setMinimumBarLength((double) (byte) -1);
        boolean boolean30 = stackedBarRenderer3D25.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = stackedBarRenderer3D25.getBaseToolTipGenerator();
        stackedBarRenderer3D25.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryPlot44.markerChanged(markerChangeEvent48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        double double55 = dateAxis51.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        stackedBarRenderer3D25.drawRangeGridline(graphics2D36, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D56, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        dateAxis60.setNegativeArrowVisible(false);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis60.setRangeWithMargins(range63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis51, dateAxis60 };
        xYPlot16.setRangeAxes(valueAxisArray65);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder67 = xYPlot16.getSeriesRenderingOrder();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
        org.junit.Assert.assertNotNull(seriesRenderingOrder67);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke18 = xYPlot16.getRangeZeroBaselineStroke();
        xYPlot16.setRangeCrosshairValue((double) (-3695));
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer24.setSeriesOutlinePaint(4, (java.awt.Paint) color26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer24);
        categoryPlot28.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot28.zoomRangeAxes(0.0d, plotRenderingInfo33, point2D34);
        categoryPlot28.configureRangeAxes();
        boolean boolean37 = categoryPlot28.isRangeZoomable();
        double double38 = categoryPlot28.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = null;
        dateAxis41.setTickUnit(dateTickUnit42);
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = dateAxis41.getTickUnit();
        dateAxis41.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = null;
        dateAxis48.setTickUnit(dateTickUnit49);
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = dateAxis48.getTickUnit();
        dateAxis48.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis48, xYItemRenderer54);
        xYPlot55.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer61 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color63 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer61.setSeriesOutlinePaint(4, (java.awt.Paint) color63);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer61);
        categoryPlot65.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        java.awt.geom.Point2D point2D71 = null;
        categoryPlot65.zoomRangeAxes(0.0d, plotRenderingInfo70, point2D71);
        boolean boolean73 = categoryPlot65.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection74 = categoryPlot65.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation76 = categoryPlot65.getDomainAxisLocation(10);
        xYPlot55.setRangeAxisLocation((int) (byte) 10, axisLocation76);
        categoryPlot28.setRangeAxisLocation(axisLocation76, false);
        xYPlot16.setRangeAxisLocation(axisLocation76, false);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit44);
        org.junit.Assert.assertNull(dateTickUnit51);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(legendItemCollection74);
        org.junit.Assert.assertNotNull(axisLocation76);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            multiplePiePlot4.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        categoryPlot7.configureRangeAxes();
        boolean boolean16 = categoryPlot7.isRangeZoomable();
        double double17 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomOutset((double) (short) -1);
        categoryPlot7.setAxisOffset(rectangleInsets18);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot7.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot24 = new org.jfree.chart.plot.WaferMapPlot();
        categoryPlot7.setParent((org.jfree.chart.plot.Plot) waferMapPlot24);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int1 = defaultKeyedValues0.getItemCount();
        defaultKeyedValues0.clear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int5 = year4.getYear();
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year4);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year8);
        task6.addSubtask(task10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        java.util.Date date14 = year12.getEnd();
        int int16 = year12.compareTo((java.lang.Object) 0.05d);
        task10.setDuration((org.jfree.data.time.TimePeriod) year12);
        java.util.Date date18 = year12.getEnd();
        defaultKeyedValues0.removeValue((java.lang.Comparable) date18);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        keyToGroupMap0.mapKeyToGroup((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) year2);
        java.util.List list4 = keyToGroupMap0.getGroups();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryMiddle((int) (short) 0, 10, rectangle2D4, rectangleEdge5);
        categoryAxis0.setCategoryMargin((double) 100L);
        boolean boolean9 = categoryAxis0.isVisible();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D14.setMinimumBarLength((double) (byte) -1);
        boolean boolean19 = stackedBarRenderer3D14.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D14.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = stackedBarRenderer3D14.getBaseToolTipGenerator();
        stackedBarRenderer3D14.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer29.setSeriesOutlinePaint(4, (java.awt.Paint) color31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer29);
        categoryPlot33.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        categoryPlot33.markerChanged(markerChangeEvent37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = null;
        dateAxis40.setTickUnit(dateTickUnit41);
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = dateAxis40.getTickUnit();
        double double44 = dateAxis40.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        stackedBarRenderer3D14.drawRangeGridline(graphics2D25, categoryPlot33, (org.jfree.chart.axis.ValueAxis) dateAxis40, rectangle2D45, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot33.getDomainAxisEdge();
        try {
            double double49 = categoryAxis0.getCategoryStart((int) 'a', 2019, rectangle2D12, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(dateTickUnit43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke18 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke19 = xYPlot16.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint23 = categoryMarker22.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D(pieDataset24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke28 = defaultDrawingSupplier27.getNextOutlineStroke();
        piePlot3D25.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 2, paint23, stroke28);
        double double31 = valueMarker30.getValue();
        org.jfree.chart.util.Layer layer32 = null;
        try {
            xYPlot16.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker30, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("({0}, {1}) = {2}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities((-3695));
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        java.awt.Shape shape5 = statisticalLineAndShapeRenderer0.getSeriesShape((int) ' ');
        java.lang.Object obj6 = null;
        boolean boolean7 = statisticalLineAndShapeRenderer0.equals(obj6);
        java.awt.Stroke stroke8 = null;
        try {
            statisticalLineAndShapeRenderer0.setBaseStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.awt.Shape shape3 = chartEntity2.getArea();
        java.awt.Shape shape4 = chartEntity2.getArea();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        javax.swing.Icon icon2 = minMaxCategoryRenderer0.getMinIcon();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = minMaxCategoryRenderer0.getToolTipGenerator(6, (int) (short) 100);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(icon2);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        java.awt.Font font6 = statisticalLineAndShapeRenderer0.getItemLabelFont((int) (short) 1, (int) (byte) 10);
        statisticalLineAndShapeRenderer0.setSeriesShapesFilled(2, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        double double4 = ringPlot1.getOuterSeparatorExtension();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer8.setSeriesOutlinePaint(4, (java.awt.Paint) color10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer8);
        categoryPlot12.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot12.zoomRangeAxes(0.0d, plotRenderingInfo17, point2D18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot12.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray22 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis21 };
        categoryPlot12.setDomainAxes(categoryAxisArray22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D(pieDataset24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke28 = defaultDrawingSupplier27.getNextOutlineStroke();
        piePlot3D25.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke28);
        java.awt.Color color30 = java.awt.Color.darkGray;
        piePlot3D25.setShadowPaint((java.awt.Paint) color30);
        categoryPlot12.setOutlinePaint((java.awt.Paint) color30);
        ringPlot1.setLabelLinkPaint((java.awt.Paint) color30);
        double double34 = ringPlot1.getLabelGap();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(categoryAxisArray22);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = categoryAxis0.draw(graphics2D4, 126.0d, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getRootPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot1.getDataset();
        float float4 = waferMapPlot1.getForegroundAlpha();
        java.lang.String str5 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNull(waferMapDataset3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "WMAP_Plot" + "'", str5.equals("WMAP_Plot"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        try {
            shapeList0.setShape((-3695), shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        categoryPlot13.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomRangeAxes(0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryPlot13.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getLegendItems();
        boolean boolean23 = statisticalLineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint27 = categoryMarker26.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D(pieDataset28);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke32 = defaultDrawingSupplier31.getNextOutlineStroke();
        piePlot3D29.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 2, paint27, stroke32);
        categoryPlot13.setRangeCrosshairStroke(stroke32);
        org.jfree.chart.plot.Plot plot36 = categoryPlot13.getRootPlot();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(plot36);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = categoryLabelPosition1.getLabelAnchor();
        boolean boolean3 = rectangleEdge0.equals((java.lang.Object) textBlockAnchor2);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getNotify();
        java.lang.String str2 = textTitle0.getURLText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        segmentedTimeline3.addException((long) 0);
        int int7 = segmentedTimeline3.getSegmentsIncluded();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        stackedBarRenderer3D1.setItemMargin(0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        piePlot3D1.setLabelLinksVisible(false);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D1.setBaseSectionOutlineStroke(stroke10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer3.getSeriesPaint(4);
        boolean boolean10 = statisticalLineAndShapeRenderer3.getAutoPopulateSeriesStroke();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo25, point2D26);
        boolean boolean28 = categoryPlot20.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot20.setDataset(categoryDataset29);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot20.setRangeCrosshairPaint(paint31);
        java.awt.Paint paint33 = categoryPlot20.getDomainGridlinePaint();
        java.awt.Font font34 = categoryPlot20.getNoDataMessageFont();
        categoryPlot20.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState38 = statisticalLineAndShapeRenderer3.initialise(graphics2D11, rectangle2D12, categoryPlot20, 4, plotRenderingInfo37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = categoryItemRendererState38.getInfo();
        categoryItemRendererState38.setBarWidth((double) 0L);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(categoryItemRendererState38);
        org.junit.Assert.assertNull(plotRenderingInfo39);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        dateAxis1.setTickMarkOutsideLength((float) 32L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.darkGray;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color6, false);
        int int9 = statisticalLineAndShapeRenderer0.getPassCount();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible(12, (java.lang.Boolean) true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent13);
        boolean boolean17 = statisticalLineAndShapeRenderer0.getItemVisible(31, 6);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getNotify();
        java.awt.Paint paint2 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = categoryLabelPosition0.getLabelAnchor();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        boolean boolean3 = categoryLabelPosition0.equals((java.lang.Object) year2);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (short) -1);
        double double4 = rectangleInsets0.calculateBottomOutset((double) 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Last", graphics2D1, (float) 0L, (float) 12, 2.0d, 1.0f, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        java.util.Date date4 = null;
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline3.getSegment(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        java.awt.Paint paint3 = waferMapPlot2.getNoDataMessagePaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer4.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer8.setSeriesOutlinePaint(4, (java.awt.Paint) color10);
        statisticalLineAndShapeRenderer8.setBaseShapesFilled(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        statisticalLineAndShapeRenderer8.setSeriesToolTipGenerator(0, categoryToolTipGenerator15);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        statisticalLineAndShapeRenderer8.setSeriesPaint((int) (byte) 0, paint18);
        statisticalLineAndShapeRenderer4.setBaseFillPaint(paint18, false);
        waferMapPlot2.setOutlinePaint(paint18);
        boolean boolean23 = verticalAlignment0.equals((java.lang.Object) waferMapPlot2);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        java.util.TimeZone timeZone35 = dateAxis27.getTimeZone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(timeZone35);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setLabelGap((double) 4);
        piePlot3D1.setLabelLinkMargin(3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Shape shape9 = statisticalLineAndShapeRenderer3.getSeriesShape((int) (byte) 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalLineAndShapeRenderer3.getURLGenerator((int) (short) 1, 128);
        double double13 = statisticalLineAndShapeRenderer3.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = categoryLabelPosition0.getCategoryAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        boolean boolean11 = categoryLabelWidthType5.equals((java.lang.Object) multiplePiePlot10);
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2, textAnchor3, (double) 'a', categoryLabelWidthType5, (float) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 10L);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        boolean boolean5 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape4);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        java.lang.String str2 = axisChangeEvent1.toString();
        java.lang.Object obj3 = axisChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer20.setSeriesOutlinePaint(4, (java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer20);
        categoryPlot24.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot24.setDomainAxis(categoryAxis28);
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font31, (java.awt.Paint) color32);
        categoryPlot24.setNoDataMessageFont(font31);
        dateAxis9.setTickLabelFont(font31);
        dateAxis9.setTickMarkInsideLength((float) (byte) 10);
        java.util.Date date38 = null;
        try {
            dateAxis9.setMaximumDate(date38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font14, (java.awt.Paint) color15);
        categoryPlot7.setNoDataMessageFont(font14);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        int int19 = categoryPlot7.getDomainAxisIndex(categoryAxis18);
        boolean boolean20 = categoryPlot7.isDomainZoomable();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date8 = dateAxis7.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str11 = textAnchor10.toString();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick14 = new org.jfree.chart.axis.DateTick(date8, "12/31/69", textAnchor10, textAnchor12, 0.0d);
        try {
            float float15 = textFragment3.calculateBaselineOffset(graphics2D5, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str4.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str11.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date3 = dateAxis2.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str6 = textAnchor5.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick9 = new org.jfree.chart.axis.DateTick(date3, "12/31/69", textAnchor5, textAnchor7, 0.0d);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str6.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        boolean boolean38 = stackedBarRenderer3D1.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        categoryPlot13.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomRangeAxes(0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryPlot13.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getLegendItems();
        boolean boolean23 = statisticalLineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot13);
        categoryPlot13.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            categoryPlot13.handleClick((int) (short) 100, (int) (short) 1, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getVersion();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat4 = dateAxis1.getDateFormatOverride();
        java.awt.Shape shape5 = dateAxis1.getRightArrow();
        try {
            dateAxis1.zoomRange((double) 1546329600000L, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.5463296E12) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D6.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, (double) ' ', rectangleAnchor11);
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D15.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) (short) -1, (double) ' ', rectangleAnchor20);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D23.setMinimumBarLength((double) (byte) -1);
        boolean boolean28 = stackedBarRenderer3D23.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D23.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = stackedBarRenderer3D23.getBaseToolTipGenerator();
        stackedBarRenderer3D23.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer38 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer38.setSeriesOutlinePaint(4, (java.awt.Paint) color40);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer38);
        categoryPlot42.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = null;
        categoryPlot42.markerChanged(markerChangeEvent46);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = null;
        dateAxis49.setTickUnit(dateTickUnit50);
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = dateAxis49.getTickUnit();
        double double53 = dateAxis49.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        stackedBarRenderer3D23.drawRangeGridline(graphics2D34, categoryPlot42, (org.jfree.chart.axis.ValueAxis) dateAxis49, rectangle2D54, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot42.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        try {
            org.jfree.chart.axis.AxisState axisState59 = numberAxis3D0.draw(graphics2D2, 1.0E-5d, rectangle2D12, rectangle2D21, rectangleEdge57, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(dateTickUnit52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.0d + "'", double53 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot20.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot20.getDomainAxisForDataset((int) '#');
        org.jfree.data.general.WaferMapDataset waferMapDataset39 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot40 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset39);
        org.jfree.chart.plot.Plot plot41 = waferMapPlot40.getRootPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset42 = waferMapPlot40.getDataset();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_RED;
        waferMapPlot40.setNoDataMessagePaint((java.awt.Paint) color43);
        categoryAxis37.setTickLabelPaint((java.lang.Comparable) "TextBlockAnchor.BOTTOM_LEFT", (java.awt.Paint) color43);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(categoryAxis37);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNull(waferMapDataset42);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        boolean boolean4 = ringPlot1.getSeparatorsVisible();
        boolean boolean5 = ringPlot1.isOutlineVisible();
        double double6 = ringPlot1.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleAnchor.BOTTOM_RIGHT");
        try {
            org.jfree.data.gantt.Task task3 = taskSeries1.get((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.data.KeyToGroupMap keyToGroupMap6 = new org.jfree.data.KeyToGroupMap();
        int int7 = keyToGroupMap6.getGroupCount();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date12 = dateAxis11.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str15 = textAnchor14.toString();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick18 = new org.jfree.chart.axis.DateTick(date12, "12/31/69", textAnchor14, textAnchor16, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date21 = dateAxis20.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str24 = textAnchor23.toString();
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick27 = new org.jfree.chart.axis.DateTick(date21, "12/31/69", textAnchor23, textAnchor25, 0.0d);
        org.jfree.chart.axis.NumberTick numberTick29 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0L, "hi!", textAnchor16, textAnchor23, (double) (short) 10);
        boolean boolean30 = keyToGroupMap6.equals((java.lang.Object) textAnchor23);
        try {
            java.awt.Shape shape31 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("CategoryAnchor.MIDDLE", graphics2D1, (float) 0, (float) 1559372400000L, textAnchor4, (double) (short) 1, textAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str15.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str24.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset30 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit29, dataset30);
        java.util.Date date32 = dateAxis25.calculateHighestVisibleTickValue(dateTickUnit29);
        java.awt.Shape shape33 = dateAxis25.getRightArrow();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1.0f), (double) 2958465, (double) 1L, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getItemPaint((int) (short) 0, (int) (byte) 10);
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        statisticalLineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", (double) 0L);
        java.lang.Object obj4 = null;
        boolean boolean5 = defaultKeyedValues0.equals(obj4);
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByValues(sortOrder6);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        boolean boolean9 = sortOrder6.equals((java.lang.Object) tickUnitSource8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", (double) 0L);
        java.lang.Object obj4 = null;
        boolean boolean5 = defaultKeyedValues0.equals(obj4);
        defaultKeyedValues0.clear();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset0.getRowKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer1.setSeriesOutlinePaint(4, (java.awt.Paint) color3);
        java.awt.Font font7 = statisticalLineAndShapeRenderer1.getItemLabelFont((int) (short) 1, (int) (byte) 10);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer8 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        ringPlot10.setOuterSeparatorExtension(100.0d);
        java.awt.Paint paint13 = ringPlot10.getBackgroundPaint();
        ganttRenderer8.setIncompletePaint(paint13);
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("Last", font7, paint13, 0.0f, (-3695), textMeasurer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        java.util.Date date4 = null;
        try {
            long long5 = segmentedTimeline3.toTimelineValue(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        java.awt.Paint paint38 = dateAxis29.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(2, 0, dateFormat2);
        int int4 = dateTickUnit3.getRollCount();
        int int5 = dateTickUnit3.getRollUnit();
        int int6 = dateTickUnit3.getRollCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year5);
        task3.addSubtask(task7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        java.util.Date date11 = year9.getEnd();
        int int13 = year9.compareTo((java.lang.Object) 0.05d);
        task7.setDuration((org.jfree.data.time.TimePeriod) year9);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int16 = year15.getYear();
        task7.setDuration((org.jfree.data.time.TimePeriod) year15);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset18);
        ringPlot19.setOuterSeparatorExtension(100.0d);
        java.awt.Paint paint22 = ringPlot19.getBackgroundPaint();
        boolean boolean23 = year15.equals((java.lang.Object) paint22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D4.setSeriesPaint((int) (byte) 100, paint6, false);
        double double9 = stackedBarRenderer3D4.getItemMargin();
        stackedBarRenderer3D4.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint15 = null;
        stackedBarRenderer3D4.setSeriesPaint((int) (byte) 0, paint15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer21.setSeriesOutlinePaint(4, (java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer21);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot25.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        stackedBarRenderer3D4.drawRangeGridline(graphics2D17, categoryPlot25, (org.jfree.chart.axis.ValueAxis) dateAxis28, rectangle2D29, (double) (short) 10);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot(pieDataset32);
        ringPlot33.setOuterSeparatorExtension(100.0d);
        boolean boolean36 = ringPlot33.getSeparatorsVisible();
        boolean boolean37 = dateAxis28.hasListener((java.util.EventListener) ringPlot33);
        boolean boolean38 = categoryLabelPositions2.equals((java.lang.Object) ringPlot33);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot7.addDomainMarker(categoryMarker14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot7.getDomainAxisForDataset(2019);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot7.getRangeAxis(2019);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(categoryAxis17);
        org.junit.Assert.assertNull(valueAxis19);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer1.setErrorIndicatorPaint((java.awt.Paint) color2);
        java.lang.Object obj4 = statisticalLineAndShapeRenderer1.clone();
        boolean boolean5 = categoryLabelWidthType0.equals(obj4);
        java.awt.Color color8 = java.awt.Color.getColor("hi!", 2);
        boolean boolean9 = categoryLabelWidthType0.equals((java.lang.Object) 2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        double double38 = dateAxis29.getUpperBound();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-3695), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity9 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis1, shape5, "", "Last");
        java.lang.String str10 = axisLabelEntity9.getShapeCoords();
        org.jfree.chart.axis.Axis axis11 = axisLabelEntity9.getAxis();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0,-100,100,100,-100,100,-100,100" + "'", str10.equals("0,-100,100,100,-100,100,-100,100"));
        org.junit.Assert.assertNull(axis11);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getNotify();
        java.lang.Object obj2 = textTitle0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle0.setPosition(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot7.setDataset(categoryDataset16);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot7.setRangeCrosshairPaint(paint18);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot7.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(sortOrder20);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setLabelGap((double) 4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getURLGenerator();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.darkGray;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color6, false);
        int int9 = statisticalLineAndShapeRenderer0.getPassCount();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible(12, (java.lang.Boolean) true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent13);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        java.awt.Paint paint18 = statisticalLineAndShapeRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer5.setSeriesOutlinePaint(4, (java.awt.Paint) color7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer5);
        categoryPlot9.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo14, point2D15);
        java.awt.Image image17 = categoryPlot9.getBackgroundImage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot9.getRenderer((-3695));
        int int20 = month0.compareTo((java.lang.Object) (-3695));
        int int21 = month0.getMonth();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month0.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font2, (java.awt.Paint) color3);
        java.lang.String str5 = textFragment4.getText();
        textLine0.addFragment(textFragment4);
        org.jfree.chart.text.TextFragment textFragment7 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str5.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textFragment7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        double double3 = size2D2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        piePlot3D1.setLabelLinksVisible(false);
        piePlot3D1.setIgnoreNullValues(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, 2);
        piePlot3D1.setDataset(pieDataset14);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(pieDataset14);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setText("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle0.draw(graphics2D3, rectangle2D4);
        double double6 = textTitle0.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle0.getHorizontalAlignment();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = stackedBarRenderer3D1.getLegendItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("{0}");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.String str4 = standardCategorySeriesLabelGenerator1.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 2);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset3, (java.lang.Comparable) 0.0f);
        legendItemBlockContainer5.setURLText("Last");
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.width;
        double[][] doubleArray6 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray6);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset7, 6);
        boolean boolean10 = size2D2.equals((java.lang.Object) 6);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date4 = dateAxis3.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str7 = textAnchor6.toString();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick10 = new org.jfree.chart.axis.DateTick(date4, "12/31/69", textAnchor6, textAnchor8, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date13 = dateAxis12.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str16 = textAnchor15.toString();
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick19 = new org.jfree.chart.axis.DateTick(date13, "12/31/69", textAnchor15, textAnchor17, 0.0d);
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0L, "hi!", textAnchor8, textAnchor15, (double) (short) 10);
        java.lang.Number number22 = numberTick21.getNumber();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str7.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str16.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0L + "'", number22.equals(0L));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        int int1 = keyToGroupMap0.getGroupCount();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str9 = textAnchor8.toString();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick12 = new org.jfree.chart.axis.DateTick(date6, "12/31/69", textAnchor8, textAnchor10, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str18 = textAnchor17.toString();
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick21 = new org.jfree.chart.axis.DateTick(date15, "12/31/69", textAnchor17, textAnchor19, 0.0d);
        org.jfree.chart.axis.NumberTick numberTick23 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0L, "hi!", textAnchor10, textAnchor17, (double) (short) 10);
        boolean boolean24 = keyToGroupMap0.equals((java.lang.Object) textAnchor17);
        java.lang.String str25 = textAnchor17.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str9.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str18.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str25.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis11);
        categoryPlot7.axisChanged(axisChangeEvent12);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot7.setDomainGridlinePosition(categoryAnchor14);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(categoryAnchor14);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.TOP_CENTER", graphics2D1, (float) 3, (float) '#', textAnchor4, (double) (-1), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("0,-100,100,100,-100,100,-100,100", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        stackedBarRenderer3D1.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        double double9 = stackedBarRenderer3D1.getBase();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = stackedBarRenderer3D1.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        org.jfree.data.Range range2 = numberAxis3D0.getDefaultAutoRange();
        java.lang.Object obj3 = numberAxis3D0.clone();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D4.setMinimumBarLength((double) (byte) -1);
        boolean boolean9 = stackedBarRenderer3D4.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D4.setDrawBarOutline(true);
        double double12 = stackedBarRenderer3D4.getYOffset();
        boolean boolean13 = horizontalAlignment2.equals((java.lang.Object) stackedBarRenderer3D4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment14, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement17);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D19.configure();
        java.text.NumberFormat numberFormat21 = null;
        numberAxis3D19.setNumberFormatOverride(numberFormat21);
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D26.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, (double) (short) -1, (double) ' ', rectangleAnchor31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double34 = numberAxis3D19.valueToJava2D((double) 'a', rectangle2D32, rectangleEdge33);
        blockContainer18.setBounds(rectangle2D32);
        try {
            boolean boolean36 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 9359.5d + "'", double34 == 9359.5d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D3.setMinimumBarLength((double) (byte) -1);
        boolean boolean8 = stackedBarRenderer3D3.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D3.setDrawBarOutline(true);
        double double11 = stackedBarRenderer3D3.getYOffset();
        boolean boolean12 = horizontalAlignment1.equals((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment13, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle18.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D21.setMinimumBarLength((double) (byte) -1);
        boolean boolean26 = stackedBarRenderer3D21.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D21.setDrawBarOutline(true);
        double double29 = stackedBarRenderer3D21.getYOffset();
        boolean boolean30 = horizontalAlignment19.equals((java.lang.Object) stackedBarRenderer3D21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment19, verticalAlignment31, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D36.configure();
        java.text.NumberFormat numberFormat38 = null;
        numberAxis3D36.setNumberFormatOverride(numberFormat38);
        org.jfree.chart.util.Size2D size2D43 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D43.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D49 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, (double) (short) -1, (double) ' ', rectangleAnchor48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double51 = numberAxis3D36.valueToJava2D((double) 'a', rectangle2D49, rectangleEdge50);
        blockContainer35.setBounds(rectangle2D49);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.data.Range range54 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint(range54, 0.0d);
        org.jfree.data.Range range57 = rectangleConstraint56.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D58 = columnArrangement16.arrange(blockContainer35, graphics2D53, rectangleConstraint56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 9359.5d + "'", double51 == 9359.5d);
        org.junit.Assert.assertNull(range57);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, 2);
        org.jfree.data.Range range5 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        try {
            defaultCategoryDataset2.removeRow(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis1.getTickLabelFont();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int4 = color3.getGreen();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.TOP_CENTER", font2, (java.awt.Paint) color3, 2.0f, textMeasurer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        java.awt.Paint paint7 = stackedBarRenderer3D1.getWallPaint();
        stackedBarRenderer3D1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        stackedBarRenderer3D1.setMaximumBarWidth((double) 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        defaultCategoryDataset0.addValue((double) 2.0f, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "TextAnchor.TOP_CENTER");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj10 = defaultCategoryDataset9.clone();
        org.jfree.data.KeyToGroupMap keyToGroupMap11 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        keyToGroupMap11.mapKeyToGroup((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) year13);
        defaultCategoryDataset9.removeValue((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) 8.0d);
        org.jfree.data.general.DatasetGroup datasetGroup17 = defaultCategoryDataset9.getGroup();
        defaultCategoryDataset0.setGroup(datasetGroup17);
        java.util.List list19 = defaultCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(datasetGroup17);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        java.awt.Shape shape5 = statisticalLineAndShapeRenderer0.getSeriesShape((int) ' ');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        statisticalLineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer4.setSeriesOutlinePaint(4, (java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer4);
        categoryPlot8.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot8.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot8.addDomainMarker(categoryMarker15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer20.setSeriesOutlinePaint(4, (java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer20);
        categoryPlot24.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot24.setDomainAxis(categoryAxis28);
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font31, (java.awt.Paint) color32);
        categoryPlot24.setNoDataMessageFont(font31);
        categoryMarker15.setLabelFont(font31);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("", font31, (java.awt.Paint) color36);
        int int38 = color36.getRGB();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-32513) + "'", int38 == (-32513));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension((double) (byte) 100);
        java.awt.Stroke stroke4 = ringPlot1.getSeparatorStroke();
        ringPlot1.setSectionDepth((double) 9999);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(1);
        boolean boolean8 = statisticalLineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, 2);
        org.jfree.data.Range range5 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        stackedBarRenderer1.setBaseItemLabelGenerator(categoryItemLabelGenerator6, false);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year5);
        task3.addSubtask(task7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        java.util.Date date11 = year9.getEnd();
        int int13 = year9.compareTo((java.lang.Object) 0.05d);
        task7.setDuration((org.jfree.data.time.TimePeriod) year9);
        java.util.Date date15 = year9.getEnd();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year9.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setAutoRangeMinimumSize((double) 32L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        dateAxis25.centerRange((double) 100.0f);
        dateAxis25.resizeRange((double) (byte) -1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        piePlot3D1.setLabelLinkMargin(0.0d);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray9, comparableArray10, numberArray11, numberArray12);
        boolean boolean14 = dateAxis1.hasListener((java.util.EventListener) defaultIntervalCategoryDataset13);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit15, dataset16);
        java.lang.String str19 = dateTickUnit15.valueToString((double) (-1.0f));
        try {
            int int20 = defaultIntervalCategoryDataset13.getSeriesIndex((java.lang.Comparable) dateTickUnit15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12/31/69 3:59 PM" + "'", str19.equals("12/31/69 3:59 PM"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        double double4 = ringPlot1.getOuterSeparatorExtension();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        ringPlot6.setOuterSeparatorExtension(100.0d);
        double double9 = ringPlot6.getOuterSeparatorExtension();
        ringPlot6.setShadowXOffset(1.0E-8d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = ringPlot6.getLegendLabelGenerator();
        ringPlot1.setLegendLabelGenerator(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot16.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat6 = dateAxis3.getDateFormatOverride();
        java.awt.Shape shape7 = dateAxis3.getRightArrow();
        dateAxis3.setAutoTickUnitSelection(true);
        java.awt.Paint paint10 = dateAxis3.getTickLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("{0}", font1, paint10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            labelBlock11.draw(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str9 = textAnchor8.toString();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick12 = new org.jfree.chart.axis.DateTick(date6, "12/31/69", textAnchor8, textAnchor10, 0.0d);
        double double13 = dateTick12.getAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D15.setSeriesPaint((int) (byte) 100, paint17, false);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer23.setSeriesOutlinePaint(4, (java.awt.Paint) color25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer23);
        org.jfree.data.general.DatasetGroup datasetGroup28 = categoryPlot27.getDatasetGroup();
        stackedBarRenderer3D15.setPlot(categoryPlot27);
        boolean boolean30 = dateTick12.equals((java.lang.Object) categoryPlot27);
        org.jfree.chart.text.TextAnchor textAnchor31 = dateTick12.getRotationAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) 9, (float) (short) 0, textAnchor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str9.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(datasetGroup28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(textAnchor31);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension((double) (byte) 100);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke5 = minMaxCategoryRenderer4.getGroupStroke();
        ringPlot1.setSeparatorStroke(stroke5);
        boolean boolean7 = ringPlot1.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getFirstMillisecond();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("NO_CHANGE", (org.jfree.data.time.TimePeriod) month1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat2);
        numberAxis3D0.setAutoRangeStickyZero(false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        segmentedTimeline3.addException((long) (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        double double6 = rectangleInsets4.calculateBottomOutset((double) 9999);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D1.getNegativeItemLabelPositionFallback();
        stackedBarRenderer3D1.setAutoPopulateSeriesOutlineStroke(true);
        int int19 = stackedBarRenderer3D1.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer10.setSeriesOutlinePaint(4, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer10);
        categoryPlot14.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        categoryPlot14.configureRangeAxes();
        boolean boolean23 = categoryPlot14.isRangeZoomable();
        double double24 = categoryPlot14.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.calculateBottomOutset((double) (short) -1);
        categoryPlot14.setAxisOffset(rectangleInsets25);
        dateAxis1.setLabelInsets(rectangleInsets25);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = textTitle30.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D33.setMinimumBarLength((double) (byte) -1);
        boolean boolean38 = stackedBarRenderer3D33.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D33.setDrawBarOutline(true);
        double double41 = stackedBarRenderer3D33.getYOffset();
        boolean boolean42 = horizontalAlignment31.equals((java.lang.Object) stackedBarRenderer3D33);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement46 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment31, verticalAlignment43, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement46);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D48.configure();
        java.text.NumberFormat numberFormat50 = null;
        numberAxis3D48.setNumberFormatOverride(numberFormat50);
        org.jfree.chart.util.Size2D size2D55 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D55.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D55, (double) (short) -1, (double) ' ', rectangleAnchor60);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double63 = numberAxis3D48.valueToJava2D((double) 'a', rectangle2D61, rectangleEdge62);
        blockContainer47.setBounds(rectangle2D61);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets25.createInsetRectangle(rectangle2D61, false, true);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 8.0d + "'", double41 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 9359.5d + "'", double63 == 9359.5d);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setStartAngle(1.0E-5d);
        piePlot3D1.setShadowXOffset((double) (short) -1);
        piePlot3D1.setCircular(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) "TextBlockAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        categoryMarker1.setLabelOffset(rectangleInsets6);
        double double9 = rectangleInsets6.calculateLeftInset((-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 12.0d + "'", double9 == 12.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        org.junit.Assert.assertNotNull(timeline2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range3 = dateAxis1.getRange();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot7.addDomainMarker(categoryMarker14);
        java.lang.Comparable comparable16 = categoryMarker14.getKey();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 1 + "'", comparable16.equals(1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 10L);
        statisticalLineAndShapeRenderer3.setSeriesShape((int) (byte) 100, shape11, true);
        boolean boolean14 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        ganttRenderer0.setCompletePaint(paint3);
        java.awt.Paint paint5 = ganttRenderer0.getIncompletePaint();
        double double6 = ganttRenderer0.getStartPercent();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.35d + "'", double6 == 0.35d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis25.getStandardTickUnits();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(tickUnitSource29);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2019);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D4.setSeriesPaint((int) (byte) 100, paint6, false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer12.setSeriesOutlinePaint(4, (java.awt.Paint) color14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer12);
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot16.getDatasetGroup();
        stackedBarRenderer3D4.setPlot(categoryPlot16);
        boolean boolean19 = stackedBarRenderer3D4.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D4.setRenderAsPercentages(true);
        objectList1.set(128, (java.lang.Object) stackedBarRenderer3D4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer5.setSeriesOutlinePaint(4, (java.awt.Paint) color7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer5);
        categoryPlot9.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryPlot9.markerChanged(markerChangeEvent13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot9.addDomainMarker(categoryMarker16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer21.setSeriesOutlinePaint(4, (java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer21);
        categoryPlot25.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot25.setDomainAxis(categoryAxis29);
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font32, (java.awt.Paint) color33);
        categoryPlot25.setNoDataMessageFont(font32);
        categoryMarker16.setLabelFont(font32);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("", font32, (java.awt.Paint) color37);
        java.awt.Paint paint39 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer41 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("0,-100,100,100,-100,100,-100,100", font32, paint39, (float) 1546329600000L, textMeasurer41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot7.setDataset(categoryDataset16);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot7.setRangeCrosshairPaint(paint18);
        java.awt.Paint paint20 = categoryPlot7.getDomainGridlinePaint();
        categoryPlot7.setAnchorValue((double) 7);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        categoryPlot7.setWeight(0);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot7.getFixedLegendItems();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNull(legendItemCollection23);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.configure();
        java.text.NumberFormat numberFormat3 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D8.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (short) -1, (double) ' ', rectangleAnchor13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double16 = numberAxis3D1.valueToJava2D((double) 'a', rectangle2D14, rectangleEdge15);
        try {
            boolean boolean17 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 9359.5d + "'", double16 == 9359.5d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot16.getDomainAxisLocation();
        java.awt.Paint paint19 = xYPlot16.getDomainCrosshairPaint();
        boolean boolean20 = xYPlot16.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D25.setMinimumBarLength((double) (byte) -1);
        boolean boolean30 = stackedBarRenderer3D25.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = stackedBarRenderer3D25.getBaseToolTipGenerator();
        stackedBarRenderer3D25.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryPlot44.markerChanged(markerChangeEvent48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        double double55 = dateAxis51.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        stackedBarRenderer3D25.drawRangeGridline(graphics2D36, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D56, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        dateAxis60.setNegativeArrowVisible(false);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis60.setRangeWithMargins(range63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis51, dateAxis60 };
        xYPlot16.setRangeAxes(valueAxisArray65);
        xYPlot16.setRangeCrosshairValue((-1.0d), true);
        org.jfree.chart.util.Layer layer70 = null;
        java.util.Collection collection71 = xYPlot16.getDomainMarkers(layer70);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
        org.junit.Assert.assertNull(collection71);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot7.getLegendItems();
        java.lang.Object obj16 = legendItemCollection15.clone();
        org.jfree.chart.LegendItem legendItem17 = null;
        legendItemCollection15.add(legendItem17);
        int int19 = legendItemCollection15.getItemCount();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot7.addDomainMarker(categoryMarker14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            categoryPlot7.handleClick(2958465, 5, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setDrawLines(false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("{0}");
        minMaxCategoryRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        minMaxCategoryRenderer0.setAutoPopulateSeriesShape(false);
        javax.swing.Icon icon8 = minMaxCategoryRenderer0.getMinIcon();
        org.junit.Assert.assertNotNull(icon8);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer3.getSeriesPaint(4);
        boolean boolean10 = statisticalLineAndShapeRenderer3.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = statisticalLineAndShapeRenderer3.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        categoryPlot7.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = null;
        dateAxis16.setTickUnit(dateTickUnit17);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis16.getTickUnit();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer23.setSeriesOutlinePaint(4, (java.awt.Paint) color25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer23);
        categoryPlot27.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        categoryPlot27.markerChanged(markerChangeEvent31);
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot27.addDomainMarker(categoryMarker34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot27.getDomainAxisForDataset(2019);
        dateAxis16.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        java.awt.Stroke stroke39 = dateAxis16.getTickMarkStroke();
        categoryPlot7.setOutlineStroke(stroke39);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(categoryAxis37);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String str2 = dataPackageResources0.getString("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ERROR : Relative To String");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, 2.0d, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("TextAnchor.TOP_CENTER");
        textTitle0.setExpandToFitSpace(false);
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        textTitle0.setBackgroundPaint(paint5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle0.draw(graphics2D7, rectangle2D8);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        xYPlot16.clearAnnotations();
        xYPlot16.clearAnnotations();
        java.awt.geom.Point2D point2D20 = null;
        try {
            xYPlot16.setQuadrantOrigin(point2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        int int3 = lineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat6 = dateAxis3.getDateFormatOverride();
        java.awt.Shape shape7 = dateAxis3.getRightArrow();
        dateAxis3.setAutoTickUnitSelection(true);
        java.awt.Paint paint10 = dateAxis3.getTickLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("{0}", font1, paint10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = null;
        dateAxis14.setTickUnit(dateTickUnit15);
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = dateAxis14.getTickUnit();
        dateAxis14.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = null;
        dateAxis21.setTickUnit(dateTickUnit22);
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis21.getTickUnit();
        dateAxis21.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer27);
        xYPlot28.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot28.getDomainAxisLocation();
        java.awt.Paint paint31 = xYPlot28.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        int int33 = xYPlot28.getIndexOf(xYItemRenderer32);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint35 = defaultDrawingSupplier34.getNextOutlinePaint();
        xYPlot28.setDomainZeroBaselinePaint(paint35);
        labelBlock11.setPaint(paint35);
        labelBlock11.setURLText("ThreadContext");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(dateTickUnit17);
        org.junit.Assert.assertNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.isCircular();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Paint paint14 = stackedBarRenderer3D1.getItemPaint(0, (int) (byte) 100);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D1.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer20.setSeriesOutlinePaint(4, (java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer20);
        categoryPlot24.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo29, point2D30);
        boolean boolean32 = categoryPlot24.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot24.getLegendItems();
        float float34 = categoryPlot24.getBackgroundImageAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot24.getDomainAxis(3);
        boolean boolean37 = standardGradientPaintTransformer15.equals((java.lang.Object) categoryPlot24);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.5f + "'", float34 == 0.5f);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 60000L, (double) 1559372400000L);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer3D2.getToolTipGenerator((int) '#', 9);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat4 = dateAxis1.getDateFormatOverride();
        java.awt.Shape shape5 = dateAxis1.getRightArrow();
        dateAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = stackedBarRenderer3D1.getGradientPaintTransformer();
        java.awt.Paint paint10 = stackedBarRenderer3D1.getItemPaint((int) 'a', 12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D1.getNegativeItemLabelPositionFallback();
        stackedBarRenderer3D1.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        ringPlot21.setOuterSeparatorExtension((double) (byte) 100);
        java.awt.Stroke stroke24 = ringPlot21.getSeparatorStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 0, stroke24);
        boolean boolean27 = stackedBarRenderer3D1.isSeriesVisible(10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick8 = new org.jfree.chart.axis.DateTick(date2, "12/31/69", textAnchor4, textAnchor6, 0.0d);
        double double9 = dateTick8.getAngle();
        java.lang.Object obj10 = dateTick8.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str5.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.25d, 97.0d);
    }
}

